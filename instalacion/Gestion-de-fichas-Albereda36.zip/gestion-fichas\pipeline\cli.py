"""Punto de entrada del pipeline.  Uso:  python -m pipeline <comando>"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import auditoria
import cargar_app as mod_cargar
import config
import entrada as mod_entrada
import escanear as mod_escanear
import informes as mod_informes
import salida as mod_salida
from modelo import Inventario

EPILOGO = """
Ejemplos
--------
  python -m pipeline escanear
  python -m pipeline auditar
  python -m pipeline demo-entrada -n 12
  python -m pipeline entrada --simular
  python -m pipeline entrada --aplicar
  python -m pipeline salida --cliente Maxi --ejercicio 2025 --trimestre 4T --aplicar --zip
  python -m pipeline informe --tipo trimestral
  python -m pipeline informe --tipo libro-iva --cliente Alfonso --ejercicio 2021
  python -m pipeline cortes
  python -m pipeline todo

El archivo del cliente (Albereda36) se abre SIEMPRE en solo lectura.
Todo lo que se genera va a pipeline/_trabajo/.
"""


def _inventario(args) -> Inventario:
    """Carga el inventario de disco; si no existe, escanea."""
    ruta = Path(args.inventario) if getattr(args, "inventario", None) \
        else config.INVENTARIO_JSON
    if ruta.exists():
        return Inventario.cargar_json(ruta)
    print("  (no hay inventario, escaneando...)", file=sys.stderr)
    inv = mod_escanear.escanear(config.RAIZ_DATOS, verbose=False)
    inv.guardar_json(config.INVENTARIO_JSON)
    return inv


# ---------------------------------------------------------------- comandos
def cmd_escanear(args) -> int:
    inv = mod_escanear.escanear(config.RAIZ_DATOS,
                                calcular_hash=not args.sin_hash)
    inv.guardar_json(config.INVENTARIO_JSON)
    inv.guardar_csv(config.INVENTARIO_CSV, config.CSV_ENCODING, config.CSV_SEP)
    print(mod_escanear.resumen_texto(inv))
    print(f"\nInventario -> {config.INVENTARIO_JSON}")
    print(f"CSV        -> {config.INVENTARIO_CSV}")
    return 0


def cmd_auditar(args) -> int:
    inv = _inventario(args)
    texto = auditoria.informe(inv, config.RAIZ_DATOS)
    destino = config.CARPETA_TRABAJO / "auditoria.txt"
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text(texto, encoding="utf-8")
    mod_informes.exportar_csv(
        mod_informes.documentos_incompletos(inv),
        config.CARPETA_TRABAJO / "auditoria_incidencias.csv")
    print(texto)
    print(f"\nInforme -> {destino}")
    return 0


def cmd_demo_entrada(args) -> int:
    inv = _inventario(args)
    puestos = mod_entrada.crear_buzon_demo(
        config.BUZON_ENTRADA, inv, config.RAIZ_DATOS, n=args.n)
    print(f"Buzon preparado con {len(puestos)} archivos reales del fondo:")
    for p in puestos:
        print(f"  {p}")
    print(f"\n-> {config.BUZON_ENTRADA}")
    print("\nAhora:  python -m pipeline entrada --simular")
    return 0


def cmd_entrada(args) -> int:
    inv = _inventario(args)
    modo = "aplicar" if args.aplicar else "simular"
    res = mod_entrada.procesar_entrada(
        config.BUZON_ENTRADA, config.CARPETA_TRABAJO / "_ARCHIVO", inv, modo)
    print(mod_entrada.informe_entrada(res, modo))
    mod_entrada.guardar_informe(res, config.CARPETA_TRABAJO / "entrada.json")
    return 0


def cmd_salida(args) -> int:
    inv = _inventario(args)
    modo = "aplicar" if args.aplicar else "simular"
    res = mod_salida.preparar_salida(
        inv, config.RAIZ_DATOS, args.cliente, args.ejercicio, args.trimestre,
        config.CARPETA_SALIDA, modo)
    print(f"SALIDA {res.cliente} {res.ejercicio} {res.trimestre} (modo {modo})")
    print(f"  esperados : {res.esperados}")
    print(f"  copiados  : {res.copiados}")
    print(f"  colisiones: {res.colisiones}")
    if res.ausentes:
        print(f"  AUSENTES  : {len(res.ausentes)}")
    print(f"  destino   : {res.destino}")
    if modo == "simular":
        print("\n  (SIMULACION: no se ha copiado nada)")
    if args.zip and modo == "aplicar":
        z = mod_salida.empaquetar(
            Path(res.destino),
            config.CARPETA_SALIDA /
            f"{res.cliente}_{res.ejercicio}_{res.trimestre}.zip")
        print(f"  zip       : {z}")
    return 0


def cmd_cortes(args) -> int:
    inv = _inventario(args)
    print("CORTES DISPONIBLES PARA ENTREGA")
    print(mod_informes.tabla_texto(
        [["cliente", "ejercicio", "trimestre", "docs"]] +
        [list(c) for c in mod_salida.cortes_disponibles(inv)], max_filas=100))
    return 0


def cmd_informe(args) -> int:
    inv = _inventario(args)
    dest = config.CARPETA_TRABAJO / "informes"
    if args.tipo == "trimestral":
        filas = mod_informes.resumen_trimestral(inv)
        mod_informes.exportar_csv(filas, dest / "resumen_trimestral.csv")
        print(mod_informes.tabla_texto(filas, max_filas=100))
    elif args.tipo == "proveedor":
        filas = mod_informes.resumen_por_proveedor(inv, args.cliente)
        mod_informes.exportar_csv(filas, dest / "resumen_proveedor.csv")
        print(mod_informes.tabla_texto(filas))
    elif args.tipo == "incompletos":
        filas = mod_informes.documentos_incompletos(inv)
        mod_informes.exportar_csv(filas, dest / "incompletos.csv")
        print(mod_informes.tabla_texto(filas, max_filas=40))
    elif args.tipo == "libro-iva":
        if not (args.cliente and args.ejercicio):
            print("libro-iva exige --cliente y --ejercicio", file=sys.stderr)
            return 2
        for tipo in ("emitida", "recibida"):
            filas = mod_informes.libro_iva(inv, args.cliente, args.ejercicio, tipo)
            nombre = f"libro_{tipo}s_{args.cliente}_{args.ejercicio}.csv"
            mod_informes.exportar_csv(filas, dest / nombre,
                                      cabecera=mod_informes.COLS_LIBRO)
            print(f"\n=== {tipo.upper()}S · {args.cliente} {args.ejercicio} "
                  f"({len(filas)} facturas) ===")
            print(mod_informes.tabla_texto(
                [mod_informes.COLS_LIBRO[:7]] + [f[:7] for f in filas],
                max_filas=25))
            print(f"-> {dest / nombre}")
    print(f"\nCSV en {dest}")
    return 0


def cmd_cargar_app(args) -> int:
    inv = _inventario(args)
    r = mod_cargar.cargar(inv, config.RAIZ_DATOS, base=args.base,
                          simular=not args.aplicar,
                          con_binarios=args.subir_binarios,
                          limite=args.limite)
    return 1 if r.get("error") else 0


def cmd_todo(args) -> int:
    print(">>> ESCANEAR");  cmd_escanear(args)
    print("\n>>> AUDITAR");  cmd_auditar(args)
    print("\n>>> RESUMEN TRIMESTRAL")
    args.tipo, args.cliente, args.ejercicio = "trimestral", None, None
    cmd_informe(args)
    return 0


# ---------------------------------------------------------------- parser
def construir_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="pipeline",
        description="Gestion de archivos de Asesoria Albereda 36, S.L.",
        epilog=EPILOGO,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--inventario", help="ruta a un inventario.json ya generado")
    sub = p.add_subparsers(dest="comando", required=True)

    s = sub.add_parser("escanear", help="recorre el archivo y crea el inventario")
    s.add_argument("--sin-hash", action="store_true",
                   help="mas rapido, pero no detecta duplicados")
    s.set_defaults(func=cmd_escanear)

    s = sub.add_parser("auditar", help="informe de lo que esta mal en el archivo")
    s.set_defaults(func=cmd_auditar)

    s = sub.add_parser("demo-entrada", help="llena el buzon con archivos reales")
    s.add_argument("-n", type=int, default=12)
    s.set_defaults(func=cmd_demo_entrada)

    s = sub.add_parser("entrada", help="clasifica y archiva lo que hay en el buzon")
    g = s.add_mutually_exclusive_group()
    g.add_argument("--simular", action="store_true", default=True)
    g.add_argument("--aplicar", action="store_true")
    s.set_defaults(func=cmd_entrada)

    s = sub.add_parser("salida", help="prepara un trimestre para entregar")
    s.add_argument("--cliente", required=True)
    s.add_argument("--ejercicio", type=int, required=True)
    s.add_argument("--trimestre", required=True, choices=["1T", "2T", "3T", "4T"])
    g = s.add_mutually_exclusive_group()
    g.add_argument("--simular", action="store_true", default=True)
    g.add_argument("--aplicar", action="store_true")
    s.add_argument("--zip", action="store_true")
    s.set_defaults(func=cmd_salida)

    s = sub.add_parser("cortes", help="lista los trimestres entregables")
    s.set_defaults(func=cmd_cortes)

    s = sub.add_parser("informe", help="genera un informe")
    s.add_argument("--tipo", required=True,
                   choices=["libro-iva", "trimestral", "proveedor", "incompletos"])
    s.add_argument("--cliente")
    s.add_argument("--ejercicio", type=int)
    s.set_defaults(func=cmd_informe)

    s = sub.add_parser("cargar-app", help="vuelca el inventario en la app :4360")
    s.add_argument("--base", default=config.API_BASE)
    g = s.add_mutually_exclusive_group()
    g.add_argument("--simular", action="store_true", default=True)
    g.add_argument("--aplicar", action="store_true")
    s.add_argument("--subir-binarios", action="store_true",
                   help="ademas sube el PDF real (lento, duplica ficheros)")
    s.add_argument("--limite", type=int, help="solo los N primeros (pruebas)")
    s.set_defaults(func=cmd_cargar_app)

    s = sub.add_parser("todo", help="escanear + auditar + resumen")
    s.add_argument("--sin-hash", action="store_true")
    s.set_defaults(func=cmd_todo)
    return p


def main(argv: list[str] | None = None) -> int:
    args = construir_parser().parse_args(argv)
    config.CARPETA_TRABAJO.mkdir(parents=True, exist_ok=True)
    if not config.RAIZ_DATOS.exists():
        print(f"ERROR: no existe {config.RAIZ_DATOS}", file=sys.stderr)
        return 1
    return args.func(args)
