/*
 * Gestión de fichas — Asesoría Albereda 36, S.L.
 * Servidor local sin dependencias (Node >= 18). Base de datos en data/db.json.
 *
 * Arranque:  node server.js   ->  http://localhost:4360
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
// Reglas de nombres de factura: se usan ya al arrancar (fecha de cada documento).
const { clave, anioDelNombre, fechaDelNombre, SERIES_EMITIDA } = require('./lib/clasificador');
const ACTUALIZAR = require('./lib/actualizar');
const HACIENDA = require('./lib/plantillas-hacienda');
const { rangoDeAnios } = require('./lib/importar');
const IMPORTE = require('./lib/importe');
const SEPARAR = require('./lib/separar');
const PERFILES = require('./lib/perfiles');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PUBLIC_DIR = path.join(ROOT, 'public');
// --- .env -----------------------------------------------------------------
// Lector minimo de .env: KEY=VALOR, una por linea. # = comentario.
// Lo que ya venga en el entorno del sistema manda sobre el fichero.
function cargarEnv() {
  const f = path.join(ROOT, '.env');
  if (!fs.existsSync(f)) return;
  const bruto = fs.readFileSync(f);
  let texto = bruto.toString('utf8').replace(/^\uFEFF/, '');
  // Guardado en «ANSI» (Bloc de notas antiguo): las tildes no son UTF-8 válido.
  if (texto.includes('\uFFFD')) {
    texto = bruto.toString('latin1');
    console.error('  [!] El archivo .env no está guardado en UTF-8: se lee como ANSI. Guárdalo como UTF-8 si alguna ruta con tildes no funciona.');
  }
  for (const linea of texto.split(String.fromCharCode(10))) {
    const t = linea.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 1) continue;
    const clave = t.slice(0, i).trim();
    let valor = t.slice(i + 1).trim();
    if (/^".*"$/.test(valor) || /^'.*'$/.test(valor)) valor = valor.slice(1, -1);
    if (valor !== '' && process.env[clave] === undefined) process.env[clave] = valor;
  }
}
cargarEnv();

// Campo de config  ->  variable de .env que lo sobreescribe.
const CLAVES_ENV = {
  apiBaseUrl: 'GF_API_URL',
  apiKey: 'GF_API_KEY',
  servidorLocal: 'GF_SERVIDOR_LOCAL',
  rutaArchivo: 'GF_RUTA_ARCHIVO',
};

// Config que usa el programa: db.json como base, .env manda si define el campo.
function configEfectiva() {
  const c = { ...DB.config };
  for (const [campo, envVar] of Object.entries(CLAVES_ENV)) {
    if (process.env[envVar]) c[campo] = process.env[envVar];
  }
  return c;
}

const PORT = process.env.PORT || 4360;

// --- Red y acceso ------------------------------------------------------------
// Por defecto el programa SOLO atiende al propio ordenador. Abrirlo a la red
// (GF_HOST=0.0.0.0) exige contraseña: sin ella los datos de las facturas
// quedarían a la vista de cualquiera conectado al mismo wifi.
const HOST = process.env.GF_HOST || '127.0.0.1';
const CLAVE_ACCESO = process.env.GF_CLAVE_ACCESO || '';
const SOLO_LOCAL = ['127.0.0.1', 'localhost', '::1'].includes(HOST);
if (!SOLO_LOCAL && CLAVE_ACCESO.length < 8) {
  console.error('\n  [X] GF_HOST=' + HOST + ' abre el programa a la red, pero falta GF_CLAVE_ACCESO');
  console.error('      (mínimo 8 caracteres) en el archivo .env. No se arranca sin ella.\n');
  process.exit(1);
}

// «De este equipo» exige las dos cosas: que la conexión venga del propio
// ordenador Y que vaya dirigida a localhost. Una web cuyo dominio pase a
// apuntar a 127.0.0.1 (DNS rebinding) cumple lo primero pero no lo segundo,
// así que no se salta la contraseña ni puede instalar o volver atrás, tampoco
// con el programa abierto a la red.
const NOMBRES_LOCALES = ['localhost', '127.0.0.1', '[::1]'];
const nombreDelHost = (req) => String(req.headers.host || '').toLowerCase().replace(/:\d+$/, '');
const hostLocal = (req) => NOMBRES_LOCALES.includes(nombreDelHost(req));
const esLocal = (req) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress) && hostLocal(req);

function accesoPermitido(req) {
  if (esLocal(req) || !CLAVE_ACCESO) return true;
  const m = String(req.headers.authorization || '').match(/^Basic\s+(.+)$/i);
  if (!m) return false;
  const pass = Buffer.from(m[1], 'base64').toString('utf8').split(':').slice(1).join(':');
  const a = crypto.createHash('sha256').update(pass).digest();
  const b = crypto.createHash('sha256').update(CLAVE_ACCESO).digest();
  return crypto.timingSafeEqual(a, b);
}

// Carpeta donde se guardan las facturas que entran por "Importar".
const IMPORT_DIR = path.resolve(process.env.GF_CARPETA_IMPORTADAS || path.join(DATA_DIR, 'archivo'));
const COPIAS_DIR = path.join(DATA_DIR, 'copias');

for (const d of [DATA_DIR, UPLOAD_DIR, IMPORT_DIR, COPIAS_DIR]) {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
const uid = () => crypto.randomBytes(8).toString('hex');
const now = () => new Date().toISOString();

// ¿Está la ruta f dentro de la carpeta raiz (o es ella)? Una raíz de unidad o
// de recurso compartido (Z:, \SERVIDORFacturas) ya acaba en barra, y en
// Windows no importan las mayúsculas: sin esto, un archivo en la raíz de una
// unidad de red decía «2 de 2 encontrados» pero no se abría ninguno.
function dentroDe(f, raiz) {
  const igualar = (x) => { const r = path.resolve(x); return process.platform === 'win32' ? r.toLowerCase() : r; };
  const F = igualar(f), R = igualar(raiz).replace(/[\\/]+$/, '');
  return F === R || F.startsWith(R + path.sep);
}
// Dentro, pero sin ser la propia carpeta (con las mismas mayúsculas/minúsculas que dentroDe).
function dentroSinSerElla(f, raiz) {
  return dentroDe(f, raiz) && !dentroDe(raiz, f);
}

const COLLECTIONS = ['grupos', 'sujetos', 'facturas', 'documentos', 'informes'];

// Un programa recién instalado empieza VACÍO: sin grupos, clientes ni datos de
// ejemplo (antes traía los de la demostración).
function seedDB() {
  return {
    config: {
      apiBaseUrl: '',
      apiKey: '',
      servidorLocal: '',
      carpetaFichas: '',
      brandInversion: '',
      notas: '',
      sincronizado: null,
    },
    grupos: [],
    sujetos: [],
    facturas: [],
    documentos: [],
    informes: [],
    movimientos: [],
  };
}

// Antes, CUALQUIER fallo al leer (el antivirus con el fichero bloqueado un
// instante, un fichero a medias) sembraba los datos de ejemplo y los escribía
// ENCIMA de los reales. Ahora solo se siembra si el fichero no existe; si
// existe y no se puede leer, se reintenta y, si no, se para sin tocar nada.
function loadDB() {
  let raw;
  for (let intento = 0; ; intento++) {
    try {
      raw = fs.readFileSync(DB_FILE, 'utf8');
      break;
    } catch (e) {
      if (e.code === 'ENOENT') { const db = seedDB(); saveDB(db); RECIEN_INSTALADO = true; return db; }
      if (intento < 10 && ['EBUSY', 'EPERM', 'EACCES'].includes(e.code)) {
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 300);
        continue;
      }
      datosIlegibles('no se puede leer (' + e.code + ')');
    }
  }
  let db;
  try { db = JSON.parse(raw); } catch (e) { datosIlegibles('está dañada (' + e.message + ')'); }
  if (!db.config) db.config = seedDB().config;
  for (const c of COLLECTIONS) if (!Array.isArray(db[c])) db[c] = [];
  // Los movimientos no son una colección editable: solo se escriben aquí.
  if (!Array.isArray(db.movimientos)) db.movimientos = [];
  return db;
}

// Código 5: el lanzador lo reconoce y no culpa (ni retira) a la versión.
function datosIlegibles(motivo) {
  console.error('\n  [X] La base de datos ' + DB_FILE + ' ' + motivo + '.');
  console.error('      NO se ha tocado. Hay copias diarias en ' + path.join(ROOT, 'data', 'copias'));
  console.error('      Copia la más reciente encima de data\\db.json y vuelve a abrir el programa.\n');
  process.exit(5);
}

// Se escribe en un .tmp, se fuerza al disco y se cambia por el bueno: un
// apagón no deja nunca un db.json vacío. Si el antivirus, OneDrive o una copia
// de seguridad lo tienen abierto un momento, se reintenta unos segundos en vez
// de fallar con «EPERM» y dejar el cambio solo en memoria.
let _saveTimer = null;
const espera = (ms) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
function saveDB(db) {
  clearTimeout(_saveTimer);
  const tmp = DB_FILE + '.tmp';
  const datos = JSON.stringify(db, null, 2);
  for (let intento = 0; ; intento++) {
    try {
      const fd = fs.openSync(tmp, 'w');
      try { fs.writeFileSync(fd, datos); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      fs.renameSync(tmp, DB_FILE);
      return;
    } catch (e) {
      const bloqueo = ['EBUSY', 'EPERM', 'EACCES'].includes(e.code);
      if (intento < 20 && bloqueo) { espera(300); continue; }
      const err = new Error('No se han podido guardar los datos: ' + (bloqueo
        ? 'otro programa (antivirus, OneDrive, copia de seguridad) tiene abierto ' + DB_FILE + '. Espera un momento y vuelve a intentarlo.'
        : (e.code === 'ENOSPC' ? 'el disco está lleno' : e.message) + '.'));
      err.code = e.code;
      throw err;
    }
  }
}

// --- Un solo equipo a la vez ------------------------------------------------
// Si la carpeta del programa está en una unidad de red o sincronizada y otro
// equipo la tiene abierta, los dos reescribirían db.json entero y el último
// borraría sin avisar lo del otro. Cada programa abierto apunta aquí su equipo
// y lo renueva cada 30 s; si otro equipo lo renovó hace menos de 2 minutos, no
// se arranca. (Código 5: el lanzador no culpa a la versión.)
const EN_USO = path.join(DATA_DIR, 'en-uso.json');
const EQUIPO = require('os').hostname();
// El otro equipo que lo tiene abierto ahora mismo, o null. Su hora la pone SU
// reloj: si va muy adelantado tampoco vale (si no, al apagarse dejaría a los
// demás fuera durante horas).
function otroEquipoAbierto() {
  let o = null;
  try { o = JSON.parse(fs.readFileSync(EN_USO, 'utf8')); } catch { return null; }
  return o && o.equipo && o.equipo !== EQUIPO && Math.abs(Date.now() - Number(o.hora || 0)) < 2 * 60 * 1000 ? o : null;
}
function salirPorOtroEquipo(o) {
  console.error('\n  [X] El programa ya está abierto en el equipo ' + o.equipo + ' con esta misma carpeta de datos.');
  console.error('      Si los dos lo usaran a la vez, uno borraría sin avisar lo que hace el otro.');
  console.error('      Ciérralo allí (o espera 2 minutos si ese equipo se apagó) y vuelve a abrirlo aquí.\n');
  process.exit(5);
}
// Cada renovación mira antes que no lo haya cogido otro equipo (dos que
// arrancan a la vez): el que lo encuentra cogido se cierra.
function apuntarEnUso() {
  const o = otroEquipoAbierto();
  if (o) salirPorOtroEquipo(o);
  try { fs.writeFileSync(EN_USO, JSON.stringify({ equipo: EQUIPO, pid: process.pid, hora: Date.now() })); } catch { /* la próxima vez */ }
}
{
  const o = otroEquipoAbierto();
  if (o) salirPorOtroEquipo(o);
  // Se apunta cuando el programa ya escucha (en server.listen): uno que no
  // llega a arrancar (puerto ocupado) no puede quitar el apunte del bueno.
  process.on('exit', () => {
    try { const yo = JSON.parse(fs.readFileSync(EN_USO, 'utf8')); if (yo.equipo === EQUIPO && yo.pid === process.pid) fs.unlinkSync(EN_USO); } catch { /* nada */ }
  });
}

let RECIEN_INSTALADO = false; // sin data/db.json: un programa que empieza de cero
let DB = loadDB();

// --- Copias de seguridad -----------------------------------------------------
// Una copia de db.json por día (al arrancar y cada 24 h). Se guardan 30.
function copiaDiaria() {
  try {
    const hoy = new Date().toISOString().slice(0, 10);
    const f = path.join(COPIAS_DIR, 'db-' + hoy + '.json');
    if (!fs.existsSync(f) && fs.existsSync(DB_FILE)) fs.copyFileSync(DB_FILE, f);
    const copias = fs.readdirSync(COPIAS_DIR).filter((x) => /^db-\d{4}-\d{2}-\d{2}\.json$/.test(x)).sort();
    for (const vieja of copias.slice(0, Math.max(0, copias.length - 30))) fs.unlinkSync(path.join(COPIAS_DIR, vieja));
    // El historial, igual: una copia por día, 30 días.
    const fh = path.join(COPIAS_DIR, 'historial-' + hoy + '.jsonl');
    if (!fs.existsSync(fh) && fs.existsSync(path.join(DATA_DIR, 'historial.jsonl'))) fs.copyFileSync(path.join(DATA_DIR, 'historial.jsonl'), fh);
    const ch = fs.readdirSync(COPIAS_DIR).filter((x) => /^historial-\d{4}-\d{2}-\d{2}\.jsonl$/.test(x)).sort();
    for (const vieja of ch.slice(0, Math.max(0, ch.length - 30))) fs.unlinkSync(path.join(COPIAS_DIR, vieja));
  } catch (e) {
    console.error('  [!] No se pudo hacer la copia de seguridad: ' + e.message);
  }
}
copiaDiaria();
setInterval(copiaDiaria, 24 * 3600 * 1000).unref();

// Fecha con la que cada documento se coloca en el calendario del archivo.
// Es un cálculo barato (no abre ningún PDF) y deja la vista siempre coherente.
if (refrescarFechas()) saveDB(DB);

// ---------------------------------------------------------------------------
// Respuestas HTTP
// ---------------------------------------------------------------------------
function sendJSON(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
  // Lo que cambia algo y sale bien queda en el historial.
  if (res.accionHistorial && code < 400) {
    const a = res.accionHistorial; res.accionHistorial = null;
    try { const d = describirAccion(a.metodo, a.parts, obj, a.extra); if (d) apuntar(d[0], d[1]); } catch { /* el historial no puede tumbar una respuesta */ }
  }
}

// Cada vez que se abre el programa: con qué versión y en qué equipo (y si es
// la primera vez, o si la versión cambió desde la última).
function anotarArranque() {
  cerrarHistorial();
  const version = ACTUALIZAR.versionInstalada();
  let antes = null;
  try { antes = leerHistorial({ accion: 'programa', limite: 1 }).entradas[0]; } catch { /* se apunta igual */ }
  if (RECIEN_INSTALADO && !antes) apuntar('programa', `Programa instalado en ${EQUIPO} (versión ${version}). Empieza vacío.`, { version });
  else if (antes && antes.version && antes.version !== version) apuntar('programa', `Programa abierto con la versión ${version} (la última vez, la ${antes.version}).`, { version });
  else apuntar('programa', `Programa abierto (versión ${version}).`, { version });
  quitarDemo();
}

// Los programas instalados con la demostración traen sus grupos de ejemplo,
// un servidor y un periodo inventados y una nota de muestra. Se quitan UNA
// vez, y solo si siguen tal cual (un grupo con clientes o cambiado se queda).
// Los clientes, facturas y documentos no se tocan nunca.
const GRUPOS_DEMO = { 'Personas fijas': 'Sujetos fijos habituales', 'Fijos extras': 'Sujetos fijos con servicios adicionales', 'Fijos periódicos': 'Sujetos con presentación periódica' };
function quitarDemo() {
  if (DB.config.demoQuitada) return;
  const quitado = [];
  DB.grupos = DB.grupos.filter((g) => {
    const demo = GRUPOS_DEMO[g.nombre] !== undefined && GRUPOS_DEMO[g.nombre] === g.descripcion
      && !DB.sujetos.some((x) => x.grupoId === g.id)
      && (g.campos || []).every((c) => c.key === 'periodicidad' && c.label === 'Periodicidad');
    if (demo) quitado.push('el grupo «' + g.nombre + '»');
    return !demo;
  });
  if (DB.config.servidorLocal === '\\\\SERVIDOR-OFICINA\\Asesoria') { DB.config.servidorLocal = ''; quitado.push('el servidor de ejemplo'); }
  if (DB.config.notas === 'Correo / anotación manuscrita — pendiente de precisar') { DB.config.notas = ''; quitado.push('la nota de ejemplo'); }
  if (DB.config.brandInversion === '4T-26') { DB.config.brandInversion = ''; quitado.push('el periodo fijo «4T-26» (ahora se propone el trimestre que toca)'); }
  DB.config.demoQuitada = now();
  try { saveDB(DB); } catch (e) { console.error('  [!] ' + e.message); return; }
  if (quitado.length) apuntar('programa', 'Quitado lo de la demostración: ' + quitado.join(', ') + '. Los clientes, facturas y documentos no se tocan.');
}

// ---------------------------------------------------------------------------
// Historial: lo que se hace en el programa, desde el primer día
// ---------------------------------------------------------------------------
// Va en un fichero aparte (data/historial.jsonl), una línea por acción, al que
// solo se AÑADE: ordenar una carpeta nueva, recuperar la anterior o volver a
// una copia de db.json sustituyen los datos, pero no borran lo que se hizo.
const HISTORIAL_FILE = path.join(DATA_DIR, 'historial.jsonl');
function apuntar(accion, texto, extra) {
  try {
    const linea = JSON.stringify({ ...(extra || {}), fecha: now(), equipo: EQUIPO, accion, texto: String(texto || '').slice(0, 600) }) + '\n';
    // Como saveDB: a disco antes de seguir (un corte de luz no se lleva la línea).
    const fd = fs.openSync(HISTORIAL_FILE, 'a');
    try { fs.writeSync(fd, linea); try { fs.fsyncSync(fd); } catch { /* unidad que no lo admite */ } } finally { fs.closeSync(fd); }
  } catch (e) { console.error('  [!] No se pudo apuntar en el historial: ' + e.message); }
}
// Para lo que se envía por partes (Excel, ZIP, PDF): se apunta al terminar de
// enviarlo, y solo si salió bien (puede fallar antes o a mitad).
function apuntarSiSaleBien(res, accion, texto) {
  res.on('finish', () => { if (res.statusCode < 400) apuntar(accion, texto); });
}
// Una línea a medias (un corte de luz al escribir) se cierra antes de seguir,
// para que la siguiente no se pegue a ella; al leer, se salta.
function cerrarHistorial() {
  try {
    const fd = fs.openSync(HISTORIAL_FILE, 'r');
    try {
      const n = fs.fstatSync(fd).size;
      const b = Buffer.alloc(1);
      if (n && fs.readSync(fd, b, 0, 1, n - 1) === 1 && b[0] !== 10) fs.appendFileSync(HISTORIAL_FILE, '\n');
    } finally { fs.closeSync(fd); }
  } catch { /* aún no existe */ }
}
function leerHistorial(q = {}) {
  let lineas = [];
  try { lineas = fs.readFileSync(HISTORIAL_FILE, 'utf8').split('\n'); } catch (e) {
    if (e.code !== 'ENOENT') throw Object.assign(new Error('No se pudo leer el historial (' + (e.code || e.message) + '). Vuelve a intentarlo en un momento.'), { status: 503 });
  }
  // «Desde/hasta»: un día (AAAA-MM-DD, en UTC) o, desde la pantalla, el
  // instante en que empieza y acaba el día en la hora de este equipo.
  const desdeOk = (x) => !q.desde || (q.desde.length > 10 ? x >= q.desde : x.slice(0, 10) >= q.desde);
  const hastaOk = (x) => !q.hasta || (q.hasta.length > 10 ? x <= q.hasta : x.slice(0, 10) <= q.hasta);
  const busca = String(q.busca || '').trim().toLowerCase();
  const lista = [];
  for (const l of lineas) {
    if (!l.trim()) continue;
    let e;
    try { e = JSON.parse(l); } catch { continue; }
    if (!e || typeof e.fecha !== 'string') continue;
    if (q.accion && e.accion !== q.accion) continue;
    if (!desdeOk(e.fecha) || !hastaOk(e.fecha)) continue;
    if (busca && !(String(e.texto || '') + ' ' + (e.equipo || '')).toLowerCase().includes(busca)) continue;
    lista.push(e);
  }
  lista.reverse();
  const limite = Math.max(1, Math.min(5000, Number(q.limite) || 200));
  return { total: lista.length, entradas: lista.slice(0, limite) };
}
// [tipo en el historial, nombre, terminación (creado/creada)]
const NOMBRE_COLECCION = { sujetos: ['clientes', 'Cliente', 'o'], grupos: ['grupos', 'Grupo', 'o'], facturas: ['facturas', 'Factura', 'a'], documentos: ['documentos', 'Documento', 'o'], informes: ['informes', 'Informe', 'o'] };
const cuantos = (x) => (Array.isArray(x) ? x.length : Number(x) || 0);
// [tipo, texto] de una petición que ha cambiado algo, o null si no se apunta.
function describirAccion(metodo, parts, r, extra = '') {
  r = r || {};
  const [, a, b] = parts;
  if (a === 'config') return ['configuracion', 'Configuración guardada.'];
  if (a === 'actualizacion') {
    if (b === 'volver' && r.a) return ['actualizacion', `Vuelta a la versión ${r.a}${r.de ? ' (desde la ' + r.de + ')' : ''}.`];
    if (r.instalada) return ['actualizacion', `Instalada la versión ${r.version}${r.de ? ' (antes la ' + r.de + ')' : ''}${b === 'fichero' ? ', desde un fichero' : ''}.`];
    return null;
  }
  if (a === 'sincronizar') return cuantos(r.creados) ? ['documentos', `Sincronizado con el servidor de la oficina: ${cuantos(r.creados)} documento(s) nuevo(s).`] : null;
  if (a === 'upload') return ['documentos', `Documento subido: ${r.nombre || ''}.`];
  if (a === 'ordenar') {
    // (Si falla al empezar, ordenar.js ya apunta el fallo.)
    if (b === 'ordenar') return r.fase === 'error' ? null : ['ordenar', `Empieza a ordenar la carpeta ${r.ruta || ''}.`];
    if (b === 'recuperar' && r.fase === 'error') return ['ordenar', `No se pudo recuperar la copia: ${r.error || r.mensaje || ''}`];
    if (b === 'recuperar' && r.resultado) return ['ordenar', `Recuperada ${r.resultado.original ? 'la carpeta original' : 'la carpeta anterior'} (${r.resultado.documentos} documentos, ${r.resultado.facturas} facturas).`];
    return null;
  }
  if (a === 'importar') {
    if (b === 'analizar') return cuantos(r.items) ? ['importar', `Soltados ${cuantos(r.items)} fichero(s) en Importar para revisarlos.`] : null;
    if (b === 'confirmar' && !cuantos(r.importados)) return cuantos(r.errores) ? ['importar', `No se pudo importar ninguna (${cuantos(r.errores)} con error).`] : null;
    if (b === 'confirmar') return ['importar', `Importadas ${cuantos(r.importados)} factura(s) al archivo${cuantos(r.errores) ? ` (${cuantos(r.errores)} con error)` : ''}${r.importados && r.importados.length ? ': ' + r.importados.slice(0, 5).map((x) => x.nombre).join(', ') + (r.importados.length > 5 ? '…' : '') : ''}.`];
    if (b === 'descartar') return cuantos(r.descartados) ? ['importar', `Descartadas ${cuantos(r.descartados)} de Importar (no entran en el archivo).`] : null;
    if (b === 'separar') return ['importar', 'Un PDF de Importar se ha separado por páginas.'];
    return null;
  }
  if (a === 'movimientos' && parts[3] === 'deshacer') return ['revisar', `Deshecho: ${r.nombre || ''}${r.texto ? ' — ' + r.texto : ''}.`];
  if (a === 'revision') {
    if (b === 'leer-importes' && !cuantos(r.revisadas)) return null;
    if (b === 'auditar' && !cuantos(r.revisados)) return null;
    if (b === 'aplicar' && !cuantos(r.aplicados)) return null;
    if (b === 'leer-importes') return ['revisar', `Leídos los importes de las facturas: ${cuantos(r.revisadas)} revisadas, ${cuantos(r.propuestas)} propuestas.`];
    if (b === 'auditar') return ['revisar', `Repasadas ${cuantos(r.revisados)} facturas contra su PDF.`];
    if (b === 'aplicar') return ['revisar', `Revisar: aprobado el bloque «${r.bloque || ''}» (${cuantos(r.aplicados)} documento(s)).`];
    if (b === 'documento') {
      const tipo = { emitida: 'emitida', recibida: 'gasto', hacienda: 'Hacienda', 'no-factura': 'no es factura' }[r.sentido] || r.sentido || '';
      return ['revisar', `${r.revisado ? 'Revisado' : 'Tipo confirmado'} en Revisar: ${r.nombre || ''}${tipo ? ` (queda como ${tipo}${r.cliente ? ', ' + r.cliente : ''}${r.trimestre ? ' ' + r.ejercicio + ' ' + r.trimestre : ''})` : ''}${r.revisado ? '' : '; sigue pendiente por otros avisos'}.`];
    }
    if (b === 'factura') return ['revisar', `Importes confirmados en Revisar: factura ${r.numero || 's/n'}${r.contraparte ? ' de ' + r.contraparte : ''} (${r.total} €).`];
    return null;
  }
  if (a === 'copia') return ['copia', `Copia de seguridad hecha: ${r.fichero || ''}.`];
  if (NOMBRE_COLECCION[a]) {
    const [tipo, quien, o] = NOMBRE_COLECCION[a];
    const nombre = a === 'facturas'
      ? (r.numero || 's/n') + (r.contraparte ? ' de ' + r.contraparte : '')
      : (r.nombre || r.titulo || '(sin nombre)');
    if (metodo === 'POST' && !b) return [tipo, `${quien} cread${o}: ${nombre}.`];
    if ((metodo === 'PUT' || metodo === 'PATCH') && b) return [tipo, `${quien} modificad${o}: ${nombre}.`];
    if (metodo === 'DELETE' && b) return [tipo, `${quien} borrad${o}: ${nombre}${extra}.`];
  }
  return null;
}

function sendText(res, code, text, type = 'text/plain; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type });
  res.end(text);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 50 * 1024 * 1024) { reject(new Error('Cuerpo demasiado grande (máx. 50 MB)')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(new Error('JSON no válido')); }
    });
    req.on('error', reject);
  });
}

const MIME_DOC = {
  '.pdf': 'application/pdf', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
  '.tif': 'image/tiff', '.tiff': 'image/tiff', '.xml': 'text/plain; charset=utf-8', '.xsig': 'text/plain; charset=utf-8',
};

// Sirve un documento para verlo en el navegador. Lo que no es PDF ni imagen se
// descarga en vez de abrirse, para que nunca se ejecute nada.
function enviarFichero(res, ruta, nombre) {
  const ext = path.extname(ruta).toLowerCase();
  const tipo = MIME_DOC[ext];
  const nom = encodeURIComponent(nombre || path.basename(ruta));
  const cab = {
    'Content-Type': tipo || 'application/octet-stream',
    'Content-Disposition': (tipo ? 'inline' : 'attachment') + "; filename*=UTF-8''" + nom,
    'Cache-Control': 'no-store',
  };
  // El visor de PDF de Chrome no funciona bajo "sandbox"; el resto sí se aísla.
  if (ext !== '.pdf') cab['Content-Security-Policy'] = "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox";
  res.writeHead(200, cab);
  fs.createReadStream(ruta).on('error', () => res.end()).pipe(res);
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
};

function serveStatic(req, res, urlPath) {
  let rel = urlPath === '/' ? '/index.html' : urlPath;
  rel = decodeURIComponent(rel.split('?')[0]);
  const full = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!full.startsWith(PUBLIC_DIR)) return sendText(res, 403, 'Prohibido');
  fs.readFile(full, (err, data) => {
    if (err) return sendText(res, 404, 'No encontrado');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream' });
    res.end(data);
  });
}

// ---------------------------------------------------------------------------
// Lógica de negocio
// ---------------------------------------------------------------------------
function coerceRecord(col, data, existing) {
  const base = existing || { id: uid(), creado: now() };
  const rec = { ...base, ...data, id: base.id, creado: base.creado, actualizado: now() };

  if (col === 'grupos') {
    rec.nombre = String(rec.nombre || '').trim();
    rec.descripcion = String(rec.descripcion || '');
    rec.campos = Array.isArray(rec.campos)
      ? rec.campos.filter((c) => c && c.key).map((c) => ({ key: String(c.key).trim(), label: String(c.label || c.key), type: c.type || 'text' }))
      : [];
  }
  if (col === 'sujetos') {
    rec.grupoId = rec.grupoId || null;
    rec.nombre = String(rec.nombre || '').trim();
    rec.nif = String(rec.nif || '').trim();
    rec.email = String(rec.email || '');
    rec.telefono = String(rec.telefono || '');
    rec.direccion = String(rec.direccion || '');
    rec.notas = String(rec.notas || '');
    rec.datos = rec.datos && typeof rec.datos === 'object' ? rec.datos : {};
  }
  if (col === 'facturas') {
    rec.sujetoId = rec.sujetoId || null;
    rec.numero = String(rec.numero || '');
    rec.fecha = rec.fecha || now().slice(0, 10);
    rec.concepto = String(rec.concepto || '');
    // Columnas del «Informe» de la asesoría: «Concepto» (cuenta: COMPRAS
    // MERCADERIAS, SUMINISTROS…) y «Nºfra.rec.» (su número de registro).
    if ('conceptoContable' in rec) rec.conceptoContable = String(rec.conceptoContable || '').replace(/\s+/g, ' ').trim().toUpperCase().slice(0, 60);
    if ('numeroRegistro' in rec) rec.numeroRegistro = String(rec.numeroRegistro || '').trim().slice(0, 20);
    rec.base = Number(rec.base) || 0;
    rec.iva = rec.iva == null || rec.iva === '' ? 21 : Number(rec.iva) || 0;
    rec.irpf = Number(rec.irpf) || 0;
    // Recargo de equivalencia: su tipo (5,2 / 1,4 / 0,5…); sin él, no se guarda.
    if ('recargo' in rec) { rec.recargo = Number(rec.recargo) || 0; if (!rec.recargo) delete rec.recargo; }
    // Varios tipos de IVA: base = suma de las bases, iva = el de la base mayor.
    // Si se tocan base o IVA a mano (un solo tipo), el desglose deja de valer.
    if (data && 'desglose' in data) rec.desglose = IMPORTE.limpiarDesglose(data.desglose);
    else if (data && ('base' in data || 'iva' in data) && existing && existing.desglose) {
      // Al confirmar se reenvían base e IVA tal cual: el desglose solo deja de
      // valer si de verdad cambian (antes se perdía y el Informe calculaba
      // todo al tipo principal).
      const sigue = Math.abs(rec.base - IMPORTE.resumenDesglose(existing.desglose).base) <= 0.01
        && (!('iva' in data) || Number(data.iva) === Number(existing.iva));
      rec.desglose = sigue ? existing.desglose : null;
    }
    if (rec.desglose) Object.assign(rec, IMPORTE.resumenDesglose(rec.desglose));
    else delete rec.desglose;
    // Si se ha cambiado la base o el IVA sin dar un total nuevo, el total se
    // recalcula. Antes se conservaba el viejo y quedaba descuadrado.
    const calculado = IMPORTE.totalCalculado(rec);
    const tocaImporte = data && ('base' in data || 'iva' in data || 'irpf' in data || 'desglose' in data);
    if (data && 'total' in data && data.total !== '' && data.total != null) rec.total = Number(data.total) || 0;
    else if (tocaImporte || !existing) rec.total = calculado;
    else rec.total = Number(rec.total) || 0;
    if (tocaImporte || (data && 'total' in data)) {
      // Un abono va en negativo: «sin importe» es total 0, no total ≤ 0.
      rec.importePendienteExtraccion = !IMPORTE.tieneImporte(rec);
    }
    rec.abono = rec.total < 0 || rec.base < 0;
    rec.sentido = ['emitida', 'recibida'].includes(rec.sentido) ? rec.sentido : 'emitida';
    rec.estado = ['pendiente', 'pagada', 'vencida'].includes(rec.estado) ? rec.estado : 'pendiente';
  }
  if (col === 'informes') {
    rec.titulo = String(rec.titulo || '').trim();
    rec.tipo = String(rec.tipo || 'general');
    rec.periodo = String(rec.periodo || DB.config.brandInversion || '');
    rec.sujetoIds = Array.isArray(rec.sujetoIds) ? rec.sujetoIds : [];
    rec.campos = Array.isArray(rec.campos) ? rec.campos : ['nombre', 'nif', 'email'];
    rec.estado = ['borrador', 'revision', 'completado'].includes(rec.estado) ? rec.estado : 'borrador';
    rec.observaciones = String(rec.observaciones || '');
  }
  if (col === 'documentos') {
    rec.sujetoId = rec.sujetoId || null;
    rec.nombre = String(rec.nombre || 'documento');
    rec.tipo = String(rec.tipo || 'archivo');
    rec.origen = rec.origen || 'manual';
    rec.tamano = Number(rec.tamano) || 0;
    rec.ruta = rec.ruta || null;
  }
  return rec;
}

// ---------------------------------------------------------------------------
// Explorador del archivo (vista ERP)
// ---------------------------------------------------------------------------

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
  'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const SIN_FECHA = '(sin fecha exacta)';

// La fecha con la que el documento se coloca en el calendario, y de dónde sale.
// Nunca se inventa: si solo hay una fecha estimada del trimestre, no vale.
function fechaEfectivaDe(d) {
  // Hacienda: el 303 del 4T se presenta en enero. En el calendario solo se usa
  // su fecha si cae en el periodo que declara; si no, iría a otro trimestre.
  if (d.sentido === 'hacienda') {
    const f = d.fechaDocumento;
    const dentro = f && Number(f.slice(0, 4)) === Number(d.ejercicio) && Math.floor((Number(f.slice(5, 7)) - 1) / 3) + 1 + 'T' === d.trimestre;
    return dentro ? { valor: f, origen: 'documento' } : { valor: null, origen: null };
  }
  if (d.fechaDocumento) return { valor: d.fechaDocumento, origen: d.fechaOrigen || 'documento' };
  const f = DB.facturas.find((x) => x.documentoId === d.id);
  if (f && f.fecha && !f.fechaEstimada) return { valor: f.fecha, origen: 'factura' };
  const n = fechaDelNombre(d.nombre || '');
  if (n && n.f && !n.soloMes) return { valor: n.f, origen: 'nombre' };
  return { valor: null, origen: null };
}

// Recalcula `fechaEfectiva` de los documentos. Es barato (no abre ningún PDF).
function refrescarFechas(lista) {
  let n = 0;
  for (const d of lista || DB.documentos) {
    const f = fechaEfectivaDe(d);
    if (d.fechaEfectiva !== f.valor || d.fechaEfectivaOrigen !== f.origen) {
      d.fechaEfectiva = f.valor; d.fechaEfectivaOrigen = f.origen; n++;
    }
  }
  return n;
}

// Las carpetas de calendario de una fecha: mes, semana y día.
// Cada nivel lleva el filtro con el que el navegador selecciona sus documentos,
// así que la etiqueta se escribe UNA vez y no hay dos criterios distintos.
function carpetasDeFecha(iso) {
  if (!iso) return [{ nombre: SIN_FECHA, filtro: { campo: 'sinFecha' } }];
  const [a, m, d] = iso.split('-').map(Number);
  const mes = iso.slice(0, 7);
  const ultimo = new Date(Date.UTC(a, m, 0)).getUTCDate();
  const semana = Math.floor((d - 1) / 7) + 1;
  const desde = (semana - 1) * 7 + 1;
  const hasta = Math.min(semana * 7, ultimo);
  const dosD = (x) => String(x).padStart(2, '0');
  const iso2 = (x) => `${a}-${dosD(m)}-${dosD(x)}`;
  return [
    { nombre: `${dosD(m)} · ${MESES[m - 1]}`, filtro: { campo: 'mes', valor: mes } },
    { nombre: `Semana ${semana} · ${desde}-${hasta}`, filtro: { campo: 'fecha', desde: iso2(desde), hasta: iso2(hasta) } },
    { nombre: `${DIAS[new Date(Date.UTC(a, m - 1, d)).getUTCDay()]} ${d}`, filtro: { campo: 'fecha', desde: iso, hasta: iso } },
  ];
}

const CARPETA_SENTIDO = { emitida: 'Emitidas', recibida: 'Recibidas', hacienda: 'Hacienda' };

// Árbol Cliente > Año > Trimestre > Tipo > Mes > Semana > Día, con conteos.
function construirArbol() {
  const raiz = { nombre: 'Archivo', hijos: {}, docs: 0, bytes: 0 };
  const sumar = (nodo, doc) => { nodo.docs++; nodo.bytes += doc.tamano || 0; };

  for (const d of DB.documentos) {
    sumar(raiz, d);
    const niveles = [
      { nombre: d.cliente || '(sin cliente)', filtro: { campo: 'cliente', valor: d.cliente || null } },
      { nombre: d.ejercicio ? String(d.ejercicio) : '(sin ejercicio)', filtro: { campo: 'ejercicio', valor: d.ejercicio || null } },
      { nombre: d.trimestre || '(sin trimestre)', filtro: { campo: 'trimestre', valor: d.trimestre || null } },
      { nombre: CARPETA_SENTIDO[d.sentido] || 'Otros', filtro: { campo: 'sentido', valor: CARPETA_SENTIDO[d.sentido] ? d.sentido : 'otros' } },
      ...carpetasDeFecha(d.fechaEfectiva),
    ];
    let nodo = raiz;
    const ruta = [];
    for (const nivel of niveles) {
      ruta.push(nivel.nombre);
      if (!nodo.hijos[nivel.nombre]) {
        nodo.hijos[nivel.nombre] = { nombre: nivel.nombre, ruta: ruta.join('/'), filtro: nivel.filtro, hijos: {}, docs: 0, bytes: 0 };
      }
      nodo = nodo.hijos[nivel.nombre];
      sumar(nodo, d);
    }
  }

  // Convertir los mapas en arrays ordenados para que el cliente los pinte tal cual.
  // "(sin fecha exacta)" va al final; el resto, por nombre.
  const orden = (a, b) => (a.nombre === SIN_FECHA) - (b.nombre === SIN_FECHA) ||
    a.nombre.localeCompare(b.nombre, 'es', { numeric: true });
  const aLista = (nodo) => ({
    nombre: nodo.nombre,
    ruta: nodo.ruta || '',
    filtro: nodo.filtro || null,
    docs: nodo.docs,
    bytes: nodo.bytes,
    hijos: Object.values(nodo.hijos).sort(orden).map(aLista),
  });
  return aLista(raiz);
}

// Raíces permitidas para abrir. Nada fuera de aquí se abre jamás.
function raicesPermitidas() {
  const rutaArchivo = configEfectiva().rutaArchivo;
  const extra = rutaArchivo ? [path.resolve(rutaArchivo)] : [];
  return [
    path.resolve(ROOT, '..', 'Albereda36'),
    path.resolve(UPLOAD_DIR),
    path.resolve(ROOT, 'pipeline', '_trabajo'),
    IMPORT_DIR,
    ...extra,
  ].filter((r) => fs.existsSync(r));
}

// Ruta real de un documento del archivo, comprobada contra las raíces
// permitidas. Lo importado vive en su propia carpeta; lo demás, en el archivo
// del cliente.
function rutaDeDocumento(doc) {
  if (!doc) return { error: 'Documento no encontrado.', codigo: 'sin-documento' };
  if (doc.ruta) {
    const f = path.resolve(UPLOAD_DIR, String(doc.ruta));
    if (!dentroSinSerElla(f, UPLOAD_DIR)) return { error: 'Ruta fuera del archivo permitido.', codigo: 'fuera' };
    return fs.existsSync(f) ? { ruta: f } : { error: 'El archivo subido ya no está.', codigo: 'subida-perdida' };
  }
  if (!doc.rutaRelativa) return { error: 'Este documento no tiene archivo asociado.', codigo: 'sin-fichero' };
  const raices = raicesPermitidas();
  const orden = doc.almacen === 'importadas'
    ? [IMPORT_DIR, ...raices.filter((r) => r !== IMPORT_DIR)]
    : raices.filter((r) => r !== IMPORT_DIR);
  // Primero donde dice la ruta guardada; si no está, por nombre dentro de la
  // carpeta del archivo, que basta con que alguien renombre una carpeta.
  const destino = resolverDestino(null, doc.rutaRelativa, orden) || buscarPorNombre(doc);
  if (!destino) return { error: porQueNoAparece(doc), codigo: codigoDeFallo() };
  const dentro = raices.some((r) => dentroDe(destino, r));
  if (!dentro) return { error: 'Ruta fuera del archivo permitido.', codigo: 'fuera' };
  return { ruta: destino };
}

// Un mensaje que diga qué hacer, no solo que algo falló.
function codigoDeFallo() {
  const raiz = raizArchivo();
  if (!raiz) return 'sin-carpeta';
  return fs.existsSync(raiz) ? 'no-encontrado' : 'carpeta-no-existe';
}
function porQueNoAparece(doc) {
  const raiz = raizArchivo();
  const primera = String(doc.rutaRelativa || '').split('/')[0];
  if (!raiz) {
    return 'Todavía no se ha dicho dónde están las facturas en este ordenador. '
      + 'Entra en Configuración, rellena «Carpeta del archivo de facturas» con la carpeta que contiene «'
      + primera + '» y pulsa Comprobar. Después este botón abrirá el PDF.';
  }
  if (!fs.existsSync(raiz)) {
    return 'La carpeta del archivo configurada no existe en este ordenador (' + raiz + '). '
      + 'Corrígela en Configuración.';
  }
  return 'Ese documento no aparece dentro de la carpeta del archivo (' + doc.rutaRelativa + '). '
    + 'Comprueba en Configuración que la carpeta elegida es la que contiene «' + primera + '»; '
    + 'si el fichero se ha movido o borrado fuera del programa, ya no se puede abrir.';
}

// --- Encontrar la carpeta de las facturas ------------------------------------
// El programa cambia de ordenador y la carpeta del archivo, también. Si la ruta
// guardada no aparece bajo ninguna raíz permitida se busca el fichero por su
// nombre dentro de la carpeta configurada (alguien pudo renombrar una carpeta
// intermedia), y si no hay carpeta configurada se dice exactamente eso, que un
// «no se encuentra» a secas no lleva a ninguna parte.

const INDICE_TTL = 30000;
let INDICE = { raiz: null, creado: 0, mapa: new Map(), ficheros: 0 };
function olvidarIndice() { INDICE = { raiz: null, creado: 0, mapa: new Map(), ficheros: 0 }; }

function raizArchivo() {
  const r = configEfectiva().rutaArchivo;
  return r ? path.resolve(String(r)) : null;
}

// Un solo recorrido de la carpeta del archivo: nombre de fichero -> rutas.
function indiceDelArchivo() {
  const raiz = raizArchivo();
  if (!raiz || !fs.existsSync(raiz)) return null;
  if (INDICE.raiz === raiz && Date.now() - INDICE.creado < INDICE_TTL) return INDICE;
  const mapa = new Map();
  let ficheros = 0;
  const pila = [raiz];
  while (pila.length && ficheros < 60000) {
    const dir = pila.pop();
    let entradas = [];
    try { entradas = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of entradas) {
      const abs = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (e.name[0] !== '.' && e.name !== 'node_modules') pila.push(abs);
        continue;
      }
      ficheros++;
      const k = e.name.toLowerCase();
      if (!mapa.has(k)) mapa.set(k, []);
      const l = mapa.get(k);
      if (l.length < 8) l.push(abs);
    }
  }
  INDICE = { raiz, creado: Date.now(), mapa, ficheros };
  return INDICE;
}

// Solo vale un fichero con EXACTAMENTE el mismo contenido que el documento
// (su sha256). El nombre no basta: 229 documentos del archivo comparten nombre
// con otro («Factura 1-000001.pdf» es de un mismo cliente en 2021 y en 2022), y abrir el
// de otro cliente haría que se escribieran importes que no son suyos.
function mismoContenido(abs, doc) {
  try {
    if (doc.tamano && fs.statSync(abs).size !== doc.tamano) return false;
    return crypto.createHash('sha256').update(fs.readFileSync(abs)).digest('hex') === doc.sha256;
  } catch {
    return false;
  }
}

function buscarPorNombre(doc) {
  if (!doc.sha256) return null; // sin huella no hay forma de estar seguros
  const idx = indiceDelArchivo();
  if (!idx) return null;
  const rutas = idx.mapa.get(String(doc.nombre || '').toLowerCase()) || [];
  return rutas.find((abs) => mismoContenido(abs, doc)) || null;
}

// Se comprueba de verdad, documento a documento: que la carpeta exista no
// basta para saber si el botón «Ver» va a funcionar.
function estadoArchivo(rutaPropuesta) {
  const cfg = rutaPropuesta !== undefined ? String(rutaPropuesta || '') : (configEfectiva().rutaArchivo || '');
  const raiz = cfg ? path.resolve(cfg) : null;
  const existe = !!(raiz && fs.existsSync(raiz));
  // Lo importado u ordenado vive en la carpeta del propio programa: no cuenta aquí.
  const docs = DB.documentos.filter((d) => !d.ruta && d.rutaRelativa && d.almacen !== 'importadas');
  const ejemplos = [];
  let encontrados = 0;
  if (existe) {
    for (const d of docs) {
      const abs = path.resolve(raiz, String(d.rutaRelativa).split('/').join(path.sep));
      if (fs.existsSync(abs)) encontrados++;
      else if (ejemplos.length < 8) ejemplos.push(d.rutaRelativa);
    }
  }
  return {
    configurada: !!cfg, ruta: cfg, raiz, existe,
    total: docs.length, encontrados, faltan: docs.length - encontrados, ejemplos,
    porEnv: !!process.env.GF_RUTA_ARCHIVO,
    carpetasEsperadas: carpetasRaizDelArchivo(),
  };
}

// Las carpetas de primer nivel que el archivo debería tener dentro.
function carpetasRaizDelArchivo() {
  const n = new Set();
  for (const d of DB.documentos) {
    if (!d.rutaRelativa || d.almacen === 'importadas') continue;
    const t = String(d.rutaRelativa).split('/')[0];
    // Los .rar sin extraer salen como primer tramo: no son carpetas del archivo.
    if (t && !/\.[a-z0-9]{2,4}$/i.test(t)) n.add(t);
  }
  return [...n];
}

// Buscarla sola: se mira donde suele estar y se puntúa cada candidata por
// cuántas de esas carpetas aparecen dentro. No se abre nada, solo se propone.
const SALTAR = new Set(['node_modules', 'Windows', 'AppData', 'Program Files', 'Program Files (x86)', '$Recycle.Bin', 'ProgramData', 'System Volume Information']);
function candidatosDeArchivo(limiteDirs = 2500) {
  const nombres = carpetasRaizDelArchivo();
  if (!nombres.length) return [];
  const home = process.env.USERPROFILE || process.env.HOME || '';
  // Primero las carpetas personales y las de OneDrive (también la de empresa,
  // «OneDrive - Asesoría…»), luego alrededor del programa y al final todas las
  // unidades que hay en el equipo, también las de red con letra (Z:).
  const unidades = process.platform === 'win32'
    ? 'DEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((l) => l + ':' + path.sep).filter((u) => { try { return fs.existsSync(u); } catch { return false; } })
    : [];
  const bases = [...new Set([
    process.env.OneDriveCommercial, process.env.OneDrive, process.env.OneDriveConsumer,
    home && path.join(home, 'Documents'), home && path.join(home, 'Documentos'),
    home && path.join(home, 'Desktop'), home && path.join(home, 'Escritorio'),
    home && path.join(home, 'Downloads'), home && path.join(home, 'OneDrive'),
    path.resolve(ROOT, '..'), path.resolve(ROOT, '..', '..'),
    ...unidades,
  ].filter((b) => b && fs.existsSync(b)))];

  const vistos = new Set();
  const salida = [];
  // Cada sitio con su propio presupuesto: antes uno con muchas carpetas se
  // gastaba el de todos y los demás no se miraban.
  let dirs = 0;
  const mirar = (dir, prof) => {
    if (dirs++ > limiteDirs || prof > 3 || vistos.has(dir)) return;
    vistos.add(dir);
    let entradas = [];
    try { entradas = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => e.isDirectory()); } catch { return; }
    const dentro = new Set(entradas.map((e) => e.name));
    const aciertos = nombres.filter((x) => dentro.has(x)).length;
    if (aciertos >= 2 || (aciertos === 1 && nombres.length === 1)) {
      salida.push({ ruta: dir, aciertos, de: nombres.length });
      return; // ya es la carpeta del archivo: no hace falta bajar más
    }
    for (const e of entradas) {
      if (e.name[0] === '.' || SALTAR.has(e.name)) continue;
      mirar(path.join(dir, e.name), prof + 1);
    }
  };
  for (const b of bases) { dirs = 0; mirar(b, 0); }
  // Manda cuántos documentos aparecen de verdad dentro: una copia parcial o un
  // pendrive con carpetas del mismo nombre no puede ganar al archivo completo.
  for (const c of salida) {
    const e = estadoArchivo(c.ruta);
    c.documentos = e.encontrados; c.deDocumentos = e.total;
  }
  return salida.sort((a, b) => (b.documentos - a.documentos) || (b.aciertos - a.aciertos)).slice(0, 5);
}

// Abre un documento (o su carpeta) con el visor por defecto de Windows.
// Sin shell: execFile con argumentos separados, así una ruta con comillas o
// con '&' no puede inyectar un comando.
// La ruta absoluta que se guardo al cargar los datos deja de valer en cuanto
// el archivo cambia de carpeta o de ordenador. Por eso se busca primero por
// ruta relativa dentro de las carpetas permitidas, y solo si no aparece se
// recurre a la absoluta de siempre.
function resolverDestino(rutaPedida, rutaRelativa, permitidas) {
  if (rutaRelativa) {
    const rel = String(rutaRelativa).split('/').join(path.sep);
    for (const raiz of permitidas) {
      const candidata = path.resolve(raiz, rel);
      if (fs.existsSync(candidata)) return candidata;
    }
  }
  return rutaPedida ? path.resolve(String(rutaPedida)) : null;
}

function abrirEnElSistema(rutaPedida, soloCarpeta, rutaRelativa) {
  if (!rutaPedida && !rutaRelativa) return { ok: false, error: 'Falta la ruta.' };
  const raices = raicesPermitidas();
  const destino = resolverDestino(rutaPedida, rutaRelativa, raices);
  if (!destino) {
    // Se pidio por ruta relativa y no aparecio en ninguna carpeta permitida:
    // decirlo tal cual, que no es lo mismo que no haber mandado ruta.
    return { ok: false, error: rutaRelativa
      ? 'No se encuentra ese documento dentro de la carpeta del archivo (' + rutaRelativa + ').'
      : 'Falta la ruta.' };
  }

  // La comprobacion se mantiene igual de estricta: resolver por ruta relativa
  // no exime de verificar que el resultado cae dentro de una raiz permitida.
  const dentro = raices.some((r) => dentroDe(destino, r));
  if (!dentro) {
    return { ok: false, error: 'Ruta fuera del archivo permitido.', destino };
  }
  if (!fs.existsSync(destino)) {
    return { ok: false, error: 'El archivo ya no está en esa ruta. ¿Se ha movido la carpeta del archivo?', destino };
  }

  const { execFile } = require('child_process');
  const objetivo = soloCarpeta ? path.dirname(destino) : destino;
  try {
    if (process.platform === 'win32') {
      // explorer devuelve código 1 aunque funcione: se ignora a propósito.
      execFile('explorer.exe', [objetivo], () => {});
    } else if (process.platform === 'darwin') {
      execFile('open', [objetivo], () => {});
    } else {
      execFile('xdg-open', [objetivo], () => {});
    }
    return { ok: true, abierto: objetivo };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Borrado en cascada para mantener la coherencia del "grafo"
// Lo que se va (o se queda suelto) al borrar algo, para el historial.
function arrastraAlBorrar(col, id) {
  const partes = [];
  if (col === 'sujetos') {
    const nf = DB.facturas.filter((f) => f.sujetoId === id).length;
    const nd = DB.documentos.filter((d) => d.sujetoId === id).length;
    if (nf) partes.push(`y sus ${nf} factura(s)`);
    if (nd) partes.push(`${nd} documento(s) quedan sin cliente`);
  }
  if (col === 'grupos') {
    const ns = DB.sujetos.filter((x) => x.grupoId === id).length;
    if (ns) partes.push(`${ns} cliente(s) quedan sin grupo`);
  }
  return partes.length ? ' (' + partes.join('; ') + ')' : '';
}

function cascadeDelete(col, id) {
  if (col === 'grupos') {
    DB.sujetos.filter((s) => s.grupoId === id).forEach((s) => { s.grupoId = null; });
  }
  if (col === 'sujetos') {
    DB.facturas = DB.facturas.filter((f) => f.sujetoId !== id);
    DB.documentos.filter((d) => d.sujetoId === id).forEach((d) => { d.sujetoId = null; });
    DB.informes.forEach((inf) => { inf.sujetoIds = inf.sujetoIds.filter((x) => x !== id); });
  }
  if (col === 'documentos') {
    const doc = DB.documentos.find((d) => d.id === id);
    // Nada se borra de golpe: el fichero va a una papelera, por si fue un
    // error. Y SOLO si es una copia del programa (subidas o carpeta de
    // importadas): si la copia ya no está y el programa lo encuentra en el
    // archivo original del cliente, ese no se mueve nunca.
    // 'papelera' | 'original' (es del archivo del cliente: no se toca) |
    // 'no-estaba' | 'no-se-pudo' (bloqueado: se queda donde estaba).
    let conFichero = 'no-estaba';
    const DIAS_PAPELERA = 90;
    const aLaPapelera = (ruta, raiz) => {
      const f = path.resolve(ruta);
      if (!dentroSinSerElla(f, raiz) || dentroDe(f, path.join(raiz, '_papelera'))) { conFichero = 'original'; return; }
      const papelera = path.join(raiz, '_papelera');
      try {
        fs.mkdirSync(papelera, { recursive: true });
        fs.renameSync(f, path.join(papelera, Date.now() + '_' + path.basename(f)));
        conFichero = 'papelera';
      } catch { conFichero = 'no-se-pudo'; }
      // La papelera no crece para siempre: fuera lo de más de 90 días.
      try {
        for (const x of fs.readdirSync(papelera)) {
          const p = path.join(papelera, x);
          if (Date.now() - fs.statSync(p).mtimeMs > DIAS_PAPELERA * 86400000) fs.rmSync(p, { force: true });
        }
      } catch { /* la próxima vez */ }
    };
    if (doc && doc.ruta) {
      const donde = rutaDeDocumento(doc);
      if (donde.ruta) aLaPapelera(donde.ruta, UPLOAD_DIR);
    } else if (doc && doc.almacen === 'importadas' && doc.rutaRelativa) {
      const donde = rutaDeDocumento(doc);
      if (donde.ruta) aLaPapelera(donde.ruta, IMPORT_DIR);
    } else if (doc && doc.rutaRelativa) {
      conFichero = 'original';
    }
    // Su factura no puede quedarse huérfana.
    DB.facturas = DB.facturas.filter((f) => f.documentoId !== id);
    if (doc) {
      registrarMovimiento({
        tipo: 'borrado', documentoId: id, nombre: doc.nombre, rutaRelativa: doc.rutaRelativa,
        texto: `Borrado del programa: ${resumenDoc(doc)}` + ({
          papelera: ' (el fichero va a la papelera del programa, 90 días)',
          original: ' (el fichero original no se toca)',
          'no-se-pudo': ' (su fichero no se pudo mover: sigue donde estaba)',
        }[conFichero] || ' (su fichero ya no estaba)'),
        reversible: false,
      });
    }
  }
}

function buildGraph() {
  const nodes = [];
  const edges = [];
  DB.grupos.forEach((g) => nodes.push({ id: 'grupo:' + g.id, tipo: 'grupo', label: g.nombre }));
  DB.sujetos.forEach((s) => {
    nodes.push({ id: 'sujeto:' + s.id, tipo: 'sujeto', label: s.nombre || s.nif || 'Sujeto' });
    if (s.grupoId) edges.push({ from: 'grupo:' + s.grupoId, to: 'sujeto:' + s.id, rel: 'contiene' });
  });
  DB.facturas.forEach((f) => {
    nodes.push({ id: 'factura:' + f.id, tipo: 'factura', label: (f.numero || 'Factura') + ' · ' + f.total + '€' });
    if (f.sujetoId) edges.push({ from: 'sujeto:' + f.sujetoId, to: 'factura:' + f.id, rel: 'emite' });
  });
  DB.documentos.forEach((d) => {
    nodes.push({ id: 'doc:' + d.id, tipo: 'documento', label: d.nombre });
    if (d.sujetoId) edges.push({ from: 'sujeto:' + d.sujetoId, to: 'doc:' + d.id, rel: 'adjunta' });
  });
  DB.informes.forEach((inf) => {
    nodes.push({ id: 'informe:' + inf.id, tipo: 'informe', label: inf.titulo || 'Informe' });
    inf.sujetoIds.forEach((sid) => edges.push({ from: 'informe:' + inf.id, to: 'sujeto:' + sid, rel: 'incluye' }));
  });
  return { nodes, edges };
}

// Documentos que necesitan que alguien los mire.
function avisosDeDocumento(d) {
  if (d.revisado) return [];
  const out = [];
  if (d.duplicadoDe) out.push('duplicado');
  if (d.revisionManual) out.push('revisar');
  if (/discrepante/.test(d.incidencias || '')) out.push('periodo');
  if (/sentido_dudoso|tipo_por_confirmar/.test(d.incidencias || '')) out.push('sentido');
  if (/no_es_factura/.test(d.incidencias || '')) out.push('no-factura');
  if (/abono_dudoso/.test(d.incidencias || '')) out.push('abono');
  if (/factura_dudosa|factura_otro_periodo/.test(d.incidencias || '')) out.push('paginas');
  return out;
}

function stats() {
  const suma = (l) => +l.reduce((a, f) => a + (f.total || 0), 0).toFixed(2);
  const emitidas = DB.facturas.filter((f) => f.sentido === 'emitida');
  const recibidas = DB.facturas.filter((f) => f.sentido === 'recibida');
  return {
    grupos: DB.grupos.length,
    sujetos: DB.sujetos.length,
    facturas: DB.facturas.length,
    documentos: DB.documentos.length,
    informes: DB.informes.length,
    // "Facturado" son solo los ingresos. Antes sumaba también los gastos.
    totalFacturado: suma(emitidas),
    totalGastos: suma(recibidas),
    pendienteCobro: suma(emitidas.filter((f) => f.estado !== 'pagada')),
    sinImporte: DB.facturas.filter((f) => !IMPORTE.tieneImporte(f)).length,
    importePorConfirmar: DB.facturas.filter((f) => IMPORTE.tieneImporte(f) && f.importeOrigen === 'pdf' && !f.importeConfirmado).length,
    avisosPendientes: DB.documentos.filter((d) => avisosDeDocumento(d).length).length,
    propuestasAutomaticas: propuestasRevision().reduce((a, b) => a + b.total, 0),
    movimientos: DB.movimientos.length,
    importacionesEnEspera: IMPORTAR.contarPendientes(),
    sincronizado: DB.config.sincronizado,
    apiConfigurada: !!configEfectiva().apiBaseUrl,
    version: ACTUALIZAR.versionInstalada(),
  };
}

// ---------------------------------------------------------------------------
// Informes
// ---------------------------------------------------------------------------
const CAMPOS_INFORME = {
  nombre: 'Nombre', nif: 'NIF', email: 'Email', telefono: 'Teléfono', direccion: 'Dirección',
  numEmitidas: 'Nº emitidas', baseEmitidas: 'Base emitidas', ivaRepercutido: 'IVA repercutido',
  irpfRetenido: 'IRPF retenido', totalFacturado: 'Total facturado',
  numRecibidas: 'Nº recibidas', baseRecibidas: 'Base recibidas', ivaSoportado: 'IVA soportado',
  resultadoIva: 'Resultado IVA (repercutido − soportado)',
  sinImporte: 'Facturas sin importe', porConfirmar: 'Importes por confirmar',
};

// "4T-26", "4T-2026", "4T 2026", "2026" -> { anio, trimestre }
function leerPeriodo(txt) {
  const s = String(txt || '').toUpperCase();
  const t = s.match(/([1-4])T/);
  const a = s.match(/(?:^|\D)(20\d{2}|\d{2})(?!\d)/);
  if (!a) return null;
  const anio = Number(a[1].length === 2 ? '20' + a[1] : a[1]);
  return { anio, trimestre: t ? t[1] + 'T' : null };
}

function datosInforme(inf) {
  const per = leerPeriodo(inf.periodo);
  const dentro = (f) => {
    if (!per) return true;
    const anio = Number(f.ejercicio || String(f.fecha || '').slice(0, 4));
    if (anio !== per.anio) return false;
    return !per.trimestre || f.trimestre === per.trimestre;
  };
  const r2 = (n) => Math.round(n * 100) / 100;
  const campos = (inf.campos && inf.campos.length ? inf.campos : ['nombre', 'nif']).filter((c) => CAMPOS_INFORME[c]);
  const filas = [];
  for (const id of inf.sujetoIds) {
    const s = DB.sujetos.find((x) => x.id === id);
    if (!s) continue;
    const fs_ = DB.facturas.filter((f) => f.sujetoId === s.id && dentro(f));
    const em = fs_.filter((f) => f.sentido === 'emitida');
    const re = fs_.filter((f) => f.sentido === 'recibida');
    const cuota = (l) => r2(l.reduce((a, f) => a + IMPORTE.cuota(f), 0));
    const fila = {
      nombre: s.nombre, nif: s.nif, email: s.email, telefono: s.telefono, direccion: s.direccion,
      numEmitidas: em.length, baseEmitidas: r2(em.reduce((a, f) => a + (f.base || 0), 0)),
      ivaRepercutido: cuota(em),
      irpfRetenido: r2(em.reduce((a, f) => a + (f.base || 0) * (f.irpf || 0) / 100, 0)),
      totalFacturado: r2(em.reduce((a, f) => a + (f.total || 0), 0)),
      numRecibidas: re.length, baseRecibidas: r2(re.reduce((a, f) => a + (f.base || 0), 0)),
      ivaSoportado: cuota(re),
      sinImporte: fs_.filter((f) => !IMPORTE.tieneImporte(f)).length,
      porConfirmar: fs_.filter((f) => IMPORTE.tieneImporte(f) && f.importeOrigen === 'pdf' && !f.importeConfirmado).length,
    };
    fila.resultadoIva = r2(fila.ivaRepercutido - fila.ivaSoportado);
    for (const c of campos) if (fila[c] === undefined && s.datos) fila[c] = s.datos[c];
    filas.push(fila);
  }
  const pend = filas.reduce((a, f) => a + f.sinImporte + f.porConfirmar, 0);
  return {
    periodo: per ? (per.trimestre ? per.trimestre + ' ' : '') + per.anio : 'todos los periodos',
    columnas: campos.map((k) => ({ key: k, label: CAMPOS_INFORME[k] })),
    filas,
    nota: pend ? `Atención: ${pend} factura(s) de este periodo no tienen el importe confirmado. Las cifras no son definitivas.` : '',
  };
}

// Las facturas que entran en un informe: las de sus clientes, en su periodo.
function facturasDeInforme(inf) {
  const per = leerPeriodo(inf.periodo);
  const ids = new Set(inf.sujetoIds || []);
  return DB.facturas.filter((f) => {
    if (!ids.has(f.sujetoId)) return false;
    if (!per) return true;
    const anio = Number(f.ejercicio || String(f.fecha || '').slice(0, 4));
    if (anio !== per.anio) return false;
    return !per.trimestre || f.trimestre === per.trimestre;
  });
}
const EXPORTAR = require('./lib/exportar').crear({ getDB: () => DB, rutaDeDocumento: (d) => rutaDeDocumento(d) });
const nombreDescarga = (t) => String(t || 'facturas').replace(/[<>:"/\\|?*\x00-\x1f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'facturas';
function enviarBinario(res, datos, tipo, nombre, extra = {}) {
  res.writeHead(200, {
    'Content-Type': tipo, 'Content-Length': datos.length, 'Cache-Control': 'no-store',
    'Content-Disposition': "attachment; filename*=UTF-8''" + encodeURIComponent(nombre), ...extra,
  });
  res.end(datos);
}
const MIME_XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
// Excel, ZIP o PDF único de una lista de facturas (un informe o lo filtrado).
async function exportarFacturas(res, formato, facturas, { titulo, resumen }) {
  const nombre = nombreDescarga(titulo);
  if (!facturas.length) return sendJSON(res, 400, { error: 'No hay ninguna factura que exportar.' });
  // Antes de sacar nada: empresa, NIF y código postal de las que aún no los
  // tienen (solo rellena lo vacío). Mientras se ordena una carpeta no se
  // escribe nada: el listado sale con lo que haya.
  if (!ORDENAR.bloqueaEscrituras()) { try { leerProveedores(facturas); } catch { /* el listado sale igual, sin esos datos */ } }
  if (formato === 'excel') return enviarBinario(res, EXPORTAR.excel(facturas, { titulo, resumen }), MIME_XLSX, nombre + '.xlsx');
  if (formato === 'zip') return EXPORTAR.zip(facturas, res, { titulo, resumen, nombre });
  if (formato === 'pdf') {
    const r = await EXPORTAR.pdf(facturas, { titulo });
    return enviarBinario(res, r.datos, 'application/pdf', nombre + '.pdf', { 'X-GF-Facturas': String(r.facturas), 'X-GF-Paginas': String(r.paginas), 'X-GF-Fuera': String(r.fuera.length) });
  }
  return sendJSON(res, 400, { error: 'Formato no válido.' });
}

// ---------------------------------------------------------------------------
// Revisión con el contenido de los PDF
// ---------------------------------------------------------------------------
const { extraerTexto } = require('./lib/pdftexto');
const { leer: leerFactura, contraparte: leerContraparte, abono: leerAbono } = require('./lib/datosfactura');

// Empresa, NIF y código postal de la otra parte de las facturas ya archivadas
// (las que entraron antes de que el programa leyera esos datos). Se mira cada
// factura una sola vez; lo escrito a mano no se pisa.
function leerProveedores(facturas) {
  const r = { leidas: 0, conNombre: 0, conNif: 0, conCp: 0 };
  const nifsCli = DB.sujetos.map((s) => (s.nif || '').toUpperCase()).filter(Boolean);
  const nombresCli = DB.sujetos.map((s) => s.nombre);
  for (const f of facturas || DB.facturas) {
    if (f.proveedorLeido || f.paginas) continue;
    const doc = DB.documentos.find((d) => d.id === f.documentoId);
    // (Un PDF con varias facturas no tiene «una» otra parte.)
    if (!doc || doc.paginasPdf) continue;
    f.proveedorLeido = true;
    const donde = rutaDeDocumento(doc);
    if (donde.error) continue;
    let texto = '';
    try {
      const buf = fs.readFileSync(donde.ruta);
      texto = OCR ? OCR.textoDe(buf, doc.nombre, doc.sha256).texto : (/\.pdf$/i.test(doc.nombre) ? extraerTexto(buf) : '');
    } catch { continue; }
    if (!texto) continue;
    r.leidas++;
    // Un NIF guardado (se puede escribir a mano) solo se usa si lo parece: va a
    // una expresión regular al buscar el nombre junto a él.
    let nif = [doc.nifContraparte, f.nifContraparte].map((x) => String(x || '').toUpperCase()).find((x) => /^[A-Z0-9]{8,10}$/.test(x)) || null;
    if (!nif) {
      try { nif = (leerFactura(texto).nifs || []).find((n) => !nifsCli.includes(n)) || null; } catch { nif = null; }
    }
    const otra = leerContraparte(texto, nif, { nifsCliente: nifsCli, nombresCliente: nombresCli });
    if (nif) { doc.nifContraparte = doc.nifContraparte || nif; f.nifContraparte = f.nifContraparte || nif; r.conNif++; }
    // Solo se rellena lo vacío: la empresa que ya tenía (escrita a mano en
    // Importar o sacada del nombre del fichero) no se pisa.
    if (otra.nombre && !f.contraparte && !doc.contraparte) { doc.contraparte = otra.nombre; f.contraparte = otra.nombre; doc.contraparteOrigen = 'pdf'; r.conNombre++; }
    if (otra.cp) { doc.cpContraparte = doc.cpContraparte || otra.cp; f.cpContraparte = f.cpContraparte || otra.cp; r.conCp++; }
  }
  if (r.leidas) saveDB(DB);
  return r;
}

// Lee los PDF de las facturas sin importe y propone base, IVA y total.
// Solo se rellenan las lecturas de fiabilidad alta o media, y quedan marcadas
// "por confirmar": nadie debe presentar un impuesto con un importe leído a
// máquina sin mirarlo.
//
// Una propuesta anterior que nadie ha tocado (sus importes siguen siendo los
// que se leyeron, `importeLeido`) se vuelve a leer: así una mejora del lector
// corrige lo que el lector viejo propuso mal. Lo confirmado o editado a mano
// no se toca nunca.
const mismoImporte = (f, l) => !!l && ['base', 'iva', 'total'].every((k) => Math.abs((f[k] || 0) - (l[k] || 0)) < 0.005);
function leerImportes() {
  const r = { revisadas: 0, sinTexto: 0, propuestas: 0, alta: 0, media: 0, sinDatos: 0, errores: 0, corregidas: 0, retiradas: 0 };
  for (const f of DB.facturas) {
    if (f.importeConfirmado || f.paginas) continue; // (de un PDF con varias: se leyó por sus páginas)
    const propuestaIntacta = IMPORTE.tieneImporte(f) && f.importeOrigen === 'pdf' && mismoImporte(f, f.importeLeido);
    if (IMPORTE.tieneImporte(f) && !propuestaIntacta) continue;
    const doc = DB.documentos.find((d) => d.id === f.documentoId);
    if (!doc || doc.paginasPdf || (doc.extension || '').toLowerCase() !== 'pdf') continue;
    r.revisadas++;
    const donde = rutaDeDocumento(doc);
    if (donde.error) { r.errores++; continue; }
    let datos;
    try { datos = leerFactura(extraerTexto(fs.readFileSync(donde.ruta))); } catch { r.errores++; continue; }
    const imp = datos.conTexto ? datos.importes : null;
    const valida = imp && imp.fiabilidad !== 'baja' && imp.base != null;
    if (!valida) {
      if (datos.conTexto) r.sinDatos++; else r.sinTexto++;
      // El lector ya no respalda la propuesta anterior: se retira.
      if (propuestaIntacta) {
        Object.assign(f, {
          base: 0, iva: 0, irpf: 0, total: 0, importeOrigen: null, importeFiabilidad: null,
          importeLeido: null, importePendienteExtraccion: true, actualizado: now(),
        });
        r.retiradas++;
      }
      continue;
    }
    if (propuestaIntacta) {
      if (mismoImporte(f, imp)) continue;
      r.corregidas++;
    }
    Object.assign(f, {
      base: imp.base, iva: imp.iva, irpf: imp.irpf || 0, total: imp.total,
      importeOrigen: 'pdf', importeFiabilidad: imp.fiabilidad, importeConfirmado: false,
      importeLeido: { base: imp.base, iva: imp.iva, total: imp.total },
      importePendienteExtraccion: false, actualizado: now(),
    });
    if (datos.fecha && datos.fecha.como === 'etiqueta' && f.fechaEstimada) {
      f.fecha = datos.fecha.valor; f.fechaEstimada = false;
    }
    r.propuestas++; r[imp.fiabilidad]++;
  }
  refrescarFechas();
  saveDB(DB);
  return r;
}

const NOTA_PERIODO = {
  emitida: ' (una emitida se declara en el trimestre de su fecha)',
  recibida: ' (si llegó tarde puede estar bien: el IVA soportado se puede deducir en un trimestre posterior)',
};

// Repasa el archivo con lo que dicen los propios PDF y marca lo sospechoso.
// No mueve ni cambia nada: añade avisos para que una persona decida.
function auditarConPdf() {
  const r = { revisados: 0, periodo: 0, sentido: 0, noFactura: 0, fechadas: 0 };
  const alias = (d) => clave(d.cliente || '');
  const maxEmitida = {};
  for (const d of DB.documentos) {
    if (d.sentido !== 'emitida' || !d.numeroDetectado) continue;
    const k = d.cliente + '|' + d.ejercicio;
    const n = Number((String(d.numeroDetectado).match(/(\d+)(?!.*\d)/) || [])[1]);
    if (n) maxEmitida[k] = Math.max(maxEmitida[k] || 0, n);
  }
  const marcar = (d, codigo, texto) => {
    if ((d.incidencias || '').includes(codigo)) return false;
    d.incidencias = [d.incidencias, codigo + ': ' + texto].filter(Boolean).join('; ');
    d.actualizado = now();
    return true;
  };

  for (const d of DB.documentos) {
    if (d.revisado || !['emitida', 'recibida'].includes(d.sentido)) continue;
    r.revisados++;

    // 1) Numeración propia del cliente archivada como gasto.
    const rx = SERIES_EMITIDA[alias(d)];
    // (Si alguien ya confirmó a mano que es un gasto, no se vuelve a preguntar.)
    if (d.sentido === 'recibida' && d.sentidoConfirmado !== 'recibida' && rx && rx.test(clave(d.nombre))) {
      const n = Number((d.nombre.match(/(\d+)(?=\s*\(|\.\w+$|$)/) || d.nombre.match(/(\d{3,})/) || [])[1]);
      const tope = maxEmitida[d.cliente + '|' + d.ejercicio];
      if (!tope || (n && n <= tope + 40)) {
        if (marcar(d, 'sentido_dudoso', 'tiene la numeración propia del cliente pero está archivada como recibida')) r.sentido++;
      }
    }

    // 2) Justificantes de pago archivados como factura.
    if (/^ticket de pago redsys/i.test(d.nombre)) {
      if (marcar(d, 'no_es_factura', 'es un justificante de pago, no una factura: no sirve para deducir IVA')) r.noFactura++;
    }

    // 3) La fecha que pone el PDF cae en otro trimestre.
    // (Un PDF con varias facturas no: cada una tiene su fecha y su trimestre.)
    if ((d.extension || '') !== 'pdf' || d.paginasPdf || /discrepante/.test(d.incidencias || '')) continue;
    const donde = rutaDeDocumento(d);
    if (donde.error) continue;
    let datos;
    try { datos = leerFactura(extraerTexto(fs.readFileSync(donde.ruta))); } catch { continue; }
    if (!datos.conTexto || !datos.fecha || datos.fecha.como === 'dudosa') continue;
    const f = datos.fecha.valor;
    const anio = Number(f.slice(0, 4));
    // La fecha del PDF sirve además para colocarlo en el calendario del archivo,
    // aunque el trimestre coincida con su carpeta.
    if (!d.fechaDocumento && (!anioDelNombre(d.nombre) || anioDelNombre(d.nombre) === anio)) {
      d.fechaDocumento = f; d.fechaOrigen = 'pdf'; d.actualizado = now(); r.fechadas = (r.fechadas || 0) + 1;
    }
    const tri = Math.floor((Number(f.slice(5, 7)) - 1) / 3) + 1 + 'T';
    // Una fecha de otro año que el nombre no respalda suele ser de otra cosa.
    if (anio !== Number(d.ejercicio) && datos.fecha.como !== 'etiqueta') continue;
    // Si el propio nombre lleva año y el PDF lo contradice, manda el nombre:
    // real, un proveedor de un cliente imprime en todas sus facturas la misma
    // fecha de 2020 (su alta), y no es la de la factura.
    const anioNom = anioDelNombre(d.nombre);
    if (anioNom && anioNom !== anio) continue;
    if (anio !== Number(d.ejercicio) || tri !== d.trimestre) {
      if (marcar(d, 'trimestre_discrepante_pdf', `el PDF dice ${f} (${tri} ${anio}) y está archivada en ${d.trimestre} ${d.ejercicio}` + NOTA_PERIODO[d.sentido])) {
        d.fechaDocumento = d.fechaDocumento || f;
        r.periodo++;
      }
    }
  }
  refrescarFechas();
  saveDB(DB);
  return r;
}

// Corrige la clasificación de un documento (y de su factura) tras revisarlo.
// Solo cambia los datos del programa: el fichero sigue donde estaba.
// Perfil de formato aprendido (ver lib/perfiles.js): al corregir el número, la
// fecha o el total de una factura de un proveedor con NIF, se apunta qué
// etiqueta llevaba ese dato en su texto. Las siguientes de ese proveedor se
// leen con ella.
function aprenderFormato(antes, despues) {
  if (despues.paginas) return;
  const nif = String(despues.nifContraparte || '').toUpperCase();
  if (!/^[A-Z0-9]{9}$/.test(nif)) return;
  const cambios = [];
  if (despues.numero && despues.numero !== antes.numero) cambios.push(['numero', despues.numero]);
  if (despues.fecha && despues.fecha !== antes.fecha) cambios.push(['fecha', despues.fecha]);
  if (IMPORTE.r2(despues.total) !== IMPORTE.r2(antes.total)) cambios.push(['total', despues.total]);
  if (!cambios.length) return;
  const d = DB.documentos.find((x) => x.id === despues.documentoId);
  const donde = d ? rutaDeDocumento(d) : null;
  if (!donde || !donde.ruta) return;
  const buf = fs.readFileSync(donde.ruta);
  const texto = OCR ? OCR.textoDe(buf, d.nombre, d.sha256).texto : /\.pdf$/i.test(d.nombre) ? extraerTexto(buf) : '';
  if (!texto) return;
  const pf = (DB.perfilesFormato = DB.perfilesFormato && typeof DB.perfilesFormato === 'object' ? DB.perfilesFormato : {});
  const p = pf[nif] || { nombre: despues.contraparte || null, veces: 0 };
  let aprendido = false;
  for (const [campo, valor] of cambios) {
    const e = PERFILES.etiquetaDe(texto, valor, campo);
    if (e) { p[campo] = e; aprendido = true; }
  }
  if (!aprendido) return;
  p.veces = (p.veces || 0) + 1;
  p.actualizado = now();
  pf[nif] = p;
}

function corregirDocumento(id, body) {
  const d = DB.documentos.find((x) => x.id === id);
  if (!d) throw new Error('Documento no encontrado.');
  const cambios = {};
  if (body.cliente !== undefined) {
    const s = DB.sujetos.find((x) => x.id === body.cliente || x.aliasArchivo === body.cliente);
    if (!s) throw new Error('Cliente no válido.');
    cambios.cliente = s.aliasArchivo || s.nombre; cambios.sujetoId = s.id;
  }
  if (body.ejercicio !== undefined) {
    const e = Number(body.ejercicio);
    if (!Number.isInteger(e) || e < 2000 || e > new Date().getFullYear() + 1) throw new Error('Ejercicio no válido.');
    cambios.ejercicio = e;
  }
  if (body.trimestre !== undefined) {
    if (!['1T', '2T', '3T', '4T'].includes(body.trimestre)) throw new Error('Trimestre no válido.');
    cambios.trimestre = body.trimestre;
  }
  if (body.sentido !== undefined) {
    if (!['emitida', 'recibida', 'hacienda', 'no-factura'].includes(body.sentido)) throw new Error('Tipo no válido.');
    cambios.sentido = body.sentido;
  }
  // Pasa a Hacienda a mano (p. ej. descartado como «es un impuesto» en
  // Revisar): se lee con las plantillas para saber qué es (modelo, pago,
  // notificación…) y, si el documento dice claro su periodo y nadie ha indicado
  // otro, se coloca en el trimestre que declara.
  if (cambios.sentido === 'hacienda' && !d.hacienda) {
    try {
      const donde = rutaDeDocumento(d);
      if (donde.ruta) {
        const buf = fs.readFileSync(donde.ruta);
        const leido = OCR ? OCR.textoDe(buf, d.nombre, d.sha256) : { texto: /\.pdf$/i.test(d.nombre) ? extraerTexto(buf) : '', ocr: false };
        const texto = leido.texto;
        const hz = texto ? HACIENDA.analizar(texto, { nifsClientes: DB.sujetos.map((x) => (x.nif || '').toUpperCase()).filter(Boolean) }) : null;
        if (hz && hz.esHacienda && !hz.requiereOcr) {
          cambios.hacienda = hz;
          // Un año leído con OCR solo se cree si está entre los del archivo
          // (la misma regla que al importar).
          const rango = leido.ocr ? rangoDeAnios(DB.documentos.filter((x) => !x.leidoOcr && !x.duplicadoDe).map((x) => Number(x.ejercicio))) : null;
          const anioCreible = !leido.ocr || (rango && hz.colocacion.ejercicio >= rango[0] && hz.colocacion.ejercicio <= rango[1]);
          if (body.ejercicio === undefined && body.trimestre === undefined && hz.seguro && hz.seguro.periodo && anioCreible
            && hz.colocacion.ejercicio && hz.colocacion.trimestre) {
            cambios.ejercicio = hz.colocacion.ejercicio;
            cambios.trimestre = hz.colocacion.trimestre;
          }
        }
      }
    } catch { /* se queda en Hacienda sin más datos */ }
  }
  const antes = `${d.cliente} ${d.ejercicio} ${d.trimestre} ${d.sentido}`;
  // Para poder deshacerlo desde Trazabilidad: solo los campos que se tocan.
  const antesCampos = {};
  for (const k of ['cliente', 'sujetoId', 'ejercicio', 'trimestre', 'sentido', 'hacienda']) {
    antesCampos[k] = d[k] === undefined ? null : d[k];
  }
  const antesRevisado = d.revisado || false;
  const facturasAntes = DB.facturas.filter((f) => f.documentoId === d.id).map((f) => ({ ...f }));
  // «Solo el tipo» (revisión rápida de Revisar): decide si es emitida o gasto y
  // quita SOLO ese aviso. Si le quedan otros (trimestre dudoso, duplicado,
  // abono…), no se da por revisado y siguen saliendo en Revisar.
  let marcarRevisado = !!body.revisado;
  const anotar = marcarRevisado || body.soloSentido === true;
  if (body.soloSentido === true) {
    antesCampos.incidencias = d.incidencias === undefined ? null : d.incidencias;
    antesCampos.sentidoConfirmado = d.sentidoConfirmado === undefined ? null : d.sentidoConfirmado;
    // Lo decidido a mano no lo vuelve a poner en duda «Buscar problemas en los PDF».
    cambios.sentidoConfirmado = cambios.sentido || d.sentido;
    const quedan = String(d.incidencias || '').split(/;\s*/).filter((x) => x && !/^(sentido_dudoso|tipo_por_confirmar)/.test(x));
    d.incidencias = quedan.join('; ');
    cambios.incidencias = d.incidencias;
    if (!quedan.length && !d.duplicadoDe && !d.revisionManual) marcarRevisado = true;
  }
  Object.assign(d, cambios);
  // «Es un abono» / «No es un abono» (Revisar): el signo de sus importes.
  if (body.abono === true || body.abono === false) {
    const signo = body.abono ? -1 : 1;
    for (const f of DB.facturas.filter((x) => x.documentoId === d.id)) {
      f.base = signo * Math.abs(f.base || 0);
      f.total = signo * Math.abs(f.total || 0);
      if (Array.isArray(f.desglose)) f.desglose = f.desglose.map((p) => ({ ...p, base: signo * Math.abs(p.base || 0) }));
      f.abono = body.abono;
      f.actualizado = now();
    }
    d.abono = body.abono;
    d.incidencias = String(d.incidencias || '').split(/;\s*/).filter((x) => x && !/^abono_dudoso/.test(x)).join('; ');
  }
  recolocarFichero(d);
  if (marcarRevisado) {
    d.revisado = true;
    d.revisadoEl = now();
    d.revisionManual = false;
  }
  let movActual = null;
  if (anotar) {
    const despues = `${d.cliente} ${d.ejercicio} ${d.trimestre} ${d.sentido}`;
    d.historial = [...(d.historial || []), { fecha: now(), antes, despues, nota: String(body.nota || '').slice(0, 300) }];
    movActual = registrarMovimiento({
      tipo: 'correccion', documentoId: d.id, nombre: d.nombre, rutaRelativa: d.rutaRelativa,
      texto: (antes === despues ? `${marcarRevisado ? 'Revisado' : 'Tipo confirmado'} y dejado como estaba: ${despues}` : `${antes} → ${despues}`)
        + (marcarRevisado ? '' : ' (sigue en Revisar por otros avisos)'),
      motivo: String(body.nota || ''),
      antes: { ...antesCampos, revisado: antesRevisado }, despues: { ...cambios, revisado: d.revisado || false },
      facturasAntes,
    });
  }
  d.actualizado = now();
  refrescarFechas([d]);

  // La factura asociada sigue al documento.
  const facturas = DB.facturas.filter((f) => f.documentoId === d.id);
  // Se quitan solo si deja de ser factura AHORA («Está bien» sobre un PDF con
  // varias que ya estaba en «no es factura» no borra las de sus páginas).
  if (cambios.sentido && cambios.sentido !== antesCampos.sentido && (d.sentido === 'no-factura' || d.sentido === 'hacienda')) {
    DB.facturas = DB.facturas.filter((f) => f.documentoId !== d.id);
  } else if (!facturas.length && ['emitida', 'recibida'].includes(d.sentido) && d.paginasPdf) {
    // Un PDF con varias facturas: nada de una sola para todo el PDF. Solo si
    // ESTA corrección lo vuelve factura se recuperan las de sus páginas, y solo
    // del movimiento que las quitó (el último que lo pasó de factura a
    // no-factura/Hacienda); si no, se avisa.
    const esFactura = (s) => s === 'emitida' || s === 'recibida';
    const mov = cambios.sentido && !esFactura(antesCampos.sentido)
      ? [...(DB.movimientos || [])].reverse().find((m) => m.documentoId === d.id && m.antes && m.despues
        && esFactura(m.antes.sentido) && ['no-factura', 'hacienda'].includes(m.despues.sentido))
      : null;
    const recuperar = mov && !mov.deshecho && Array.isArray(mov.facturasAntes)
      ? mov.facturasAntes.filter((f) => f.paginas && !DB.facturas.some((x) => x.id === f.id)) : [];
    if (recuperar.length) {
      const ref = mov.antes; // cómo iba el documento cuando se quitaron
      const notas = [];
      for (const g of recuperar) {
        const f = { ...g, rutaRelativa: d.rutaRelativa, actualizado: now() };
        // Siguen al documento solo si iban igual que él (la misma regla de abajo).
        if (ref.sujetoId && f.sujetoId === ref.sujetoId) f.sujetoId = d.sujetoId;
        const mismoPeriodo = String(f.ejercicio) === String(ref.ejercicio) && f.trimestre === ref.trimestre;
        if (mismoPeriodo) { f.ejercicio = d.ejercicio; f.trimestre = d.trimestre; }
        if (f.sentido === ref.sentido) f.sentido = d.sentido;
        if (f.sentido !== g.sentido || f.trimestre !== g.trimestre || String(f.ejercicio) !== String(g.ejercicio)) {
          f.concepto = (f.sentido === 'emitida' ? 'Emitida ' : 'Recibida ') + f.trimestre + ' ' + f.ejercicio;
        }
        DB.facturas.push(f);
        if (String(f.ejercicio) !== String(d.ejercicio) || f.trimestre !== d.trimestre || f.sentido !== d.sentido) {
          const pags = f.paginas.desde === f.paginas.hasta ? 'pág. ' + f.paginas.desde : 'págs. ' + f.paginas.desde + '-' + f.paginas.hasta;
          notas.push('factura_otro_periodo: ' + pags + (f.numero ? ' (nº ' + String(f.numero).slice(0, 40) + ')' : '')
            + ' va en ' + f.trimestre + ' ' + f.ejercicio + ' como ' + f.sentido + ' (el PDF está en ' + d.trimestre + ' ' + d.ejercicio + ')');
        }
      }
      // Para que deshacer esta corrección las vuelva a quitar.
      if (movActual) movActual.recuperadas = recuperar.map((f) => f.id);
      const nuevas = notas.filter((n) => !String(d.incidencias || '').includes(n));
      if (nuevas.length) d.incidencias = [d.incidencias, ...nuevas].filter(Boolean).join('; ');
      if (notas.length) d.revisado = false;
    } else if (!/no se saben sus facturas por páginas/.test(d.incidencias || '')) {
      d.incidencias = [d.incidencias, 'factura_dudosa: no se saben sus facturas por páginas, vuelve a importarlo entero'].filter(Boolean).join('; ');
      d.revisado = false;
    }
  } else if (!facturas.length && ['emitida', 'recibida'].includes(d.sentido)) {
    // Pasa a ser factura: se crea su registro, sin importe hasta que se lea.
    DB.facturas.push(coerceRecord('facturas', {
      sujetoId: d.sujetoId, numero: d.numeroDetectado || '',
      fecha: d.fechaDocumento || `${d.ejercicio}-${String((Number(d.trimestre[0]) - 1) * 3 + 1).padStart(2, '0')}-01`,
      fechaEstimada: !d.fechaDocumento,
      concepto: (d.sentido === 'emitida' ? 'Emitida ' : 'Recibida ') + d.trimestre + ' ' + d.ejercicio,
      base: 0, iva: 21, total: 0, estado: 'pendiente', sentido: d.sentido,
      ejercicio: d.ejercicio, trimestre: d.trimestre, documentoId: d.id,
      rutaRelativa: d.rutaRelativa, contraparte: d.contraparte || null,
      importePendienteExtraccion: true,
    }, null));
  } else {
    for (const f of facturas) {
      // En un PDF con varias facturas, cada una sigue al documento solo si iba
      // igual que él; el periodo (año y trimestre) se mueve entero o nada.
      const mismoPeriodo = !f.paginas || (String(f.ejercicio) === String(antesCampos.ejercicio) && f.trimestre === antesCampos.trimestre);
      if (cambios.sujetoId && (!f.paginas || f.sujetoId === antesCampos.sujetoId)) f.sujetoId = cambios.sujetoId;
      if ((cambios.ejercicio || cambios.trimestre) && mismoPeriodo) { f.ejercicio = d.ejercicio; f.trimestre = d.trimestre; }
      if (cambios.sentido && (!f.paginas || f.sentido === antesCampos.sentido)) f.sentido = cambios.sentido;
      if (cambios.trimestre || cambios.ejercicio || cambios.sentido) {
        f.concepto = (f.sentido === 'emitida' ? 'Emitida ' : 'Recibida ') + f.trimestre + ' ' + f.ejercicio;
      }
      f.actualizado = now();
    }
  }
  saveDB(DB);
  return d;
}

// ---------------------------------------------------------------------------
// Trazabilidad: todo movimiento queda escrito, con lo de antes y lo de después
// ---------------------------------------------------------------------------
const MOVS_MAX = 20000;

// `antes`/`despues` guardan SOLO los campos tocados, para poder deshacer sin
// resucitar datos viejos de otros campos.
function registrarMovimiento(m) {
  const mov = {
    id: uid(), fecha: now(),
    tipo: m.tipo,                       // duplicado | no-factura | periodo | sentido | clasificacion | correccion | importacion | borrado | importes
    automatico: !!m.automatico,
    lote: m.lote || null,
    documentoId: m.documentoId || null,
    nombre: m.nombre || '',
    rutaRelativa: m.rutaRelativa || '',
    texto: m.texto || '',
    motivo: m.motivo || '',
    antes: m.antes || null,
    despues: m.despues || null,
    facturasAntes: m.facturasAntes || null,
    reversible: m.reversible !== false,
    deshecho: false,
  };
  DB.movimientos.push(mov);
  if (DB.movimientos.length > MOVS_MAX) DB.movimientos = DB.movimientos.slice(-MOVS_MAX);
  return mov;
}

// Lo importado u ordenado vive en Cliente/Año/Trimestre/Tipo: si cambia algo
// de eso, el fichero se mueve con él (sin tumbar la corrección si no puede).
function recolocarFichero(d) {
  try {
    const nueva = IMPORTAR.recolocar(d);
    if (!nueva) return;
    d.rutaRelativa = nueva;
    for (const f of DB.facturas) if (f.documentoId === d.id) f.rutaRelativa = nueva;
  } catch (e) {
    console.error('  [!] No se pudo mover ' + d.rutaRelativa + ': ' + e.message);
  }
}

function deshacerMovimiento(id) {
  const mov = DB.movimientos.find((m) => m.id === id);
  if (!mov) throw new Error('Movimiento no encontrado.');
  if (mov.deshecho) throw new Error('Ese movimiento ya se deshizo.');
  if (!mov.reversible) throw new Error('Este movimiento no se puede deshacer desde aquí.');
  const d = DB.documentos.find((x) => x.id === mov.documentoId);
  if (!d) throw new Error('El documento ya no existe.');
  for (const [k, v] of Object.entries(mov.antes || {})) {
    if (v === undefined || v === null) delete d[k]; else d[k] = v;
  }
  if (mov.facturasAntes) {
    const eran = new Set(mov.facturasAntes.map((f) => f.id));
    const recuperadas = new Set(mov.recuperadas || []);
    DB.facturas = DB.facturas.filter((f) => f.documentoId !== d.id || (f.paginas && !eran.has(f.id) && !recuperadas.has(f.id)));
    for (const f of mov.facturasAntes) DB.facturas.push(f);
  }
  recolocarFichero(d);
  d.actualizado = now();
  refrescarFechas([d]);
  mov.deshecho = true;
  mov.deshechoEl = now();
  registrarMovimiento({
    tipo: 'deshacer', documentoId: d.id, nombre: d.nombre, rutaRelativa: d.rutaRelativa,
    texto: `Deshecho: ${mov.texto}`, reversible: false,
  });
  saveDB(DB);
  return mov;
}

function movimientos(q = {}) {
  let lista = DB.movimientos.slice().reverse();
  if (q.tipo) lista = lista.filter((m) => m.tipo === q.tipo);
  if (q.documentoId) lista = lista.filter((m) => m.documentoId === q.documentoId);
  if (q.desde) lista = lista.filter((m) => m.fecha >= q.desde);
  if (q.hasta) lista = lista.filter((m) => m.fecha <= q.hasta + 'T23:59:59.999Z');
  if (q.busca) {
    const s = String(q.busca).toLowerCase();
    lista = lista.filter((m) => (m.nombre + ' ' + m.texto + ' ' + m.motivo).toLowerCase().includes(s));
  }
  const total = lista.length;
  const limite = Math.min(Number(q.limite) || 200, 1000);
  return { total, movimientos: lista.slice(0, limite) };
}

// ---------------------------------------------------------------------------
// Clasificación automática por bloques
// ---------------------------------------------------------------------------
// El programa propone; una persona aprueba el bloque entero. Cada bloque dice
// qué cambia, por qué, y se puede deshacer documento a documento.
const BLOQUES = {
  duplicado: {
    titulo: 'Copias repetidas del mismo fichero',
    explicacion: 'Byte a byte son el mismo documento que otro ya archivado. Se marcan como copia para que no cuenten dos veces. El fichero no se borra.',
    seguridad: 'seguro',
  },
  'no-factura': {
    titulo: 'No son facturas',
    explicacion: 'Justificantes de pago (Redsys) y similares. No sirven para deducir IVA: pasan a «No es factura» y dejan de contar como gasto.',
    seguridad: 'seguro',
  },
  sentido: {
    titulo: 'Facturas propias archivadas como gasto',
    explicacion: 'Llevan la numeración del propio cliente: son ingresos, no gastos. Dejarlo mal resta ingresos en el IVA.',
    seguridad: 'revisar',
  },
  'periodo-emitida': {
    titulo: 'Emitidas en otro trimestre',
    explicacion: 'La fecha del PDF cae en otro trimestre. Una factura emitida se declara en el trimestre de su fecha, así que se mueven.',
    seguridad: 'revisar',
  },
  'periodo-recibida': {
    titulo: 'Recibidas archivadas en otro trimestre',
    explicacion: 'La fecha del PDF es de otro trimestre. En gastos puede ser correcto (si llegó tarde, se deduce después), así que esto solo se aplica si el despacho lo decide.',
    seguridad: 'opcional',
  },
  clasificacion: {
    titulo: 'Sin clasificar: propuesta del programa',
    explicacion: 'Se les asigna el tipo y el trimestre que indica su contenido. Solo aparecen aquí los que el programa da por seguros.',
    seguridad: 'revisar',
  },
};

const resumenDoc = (d) => `${d.cliente || '?'} · ${d.ejercicio || '?'} ${d.trimestre || '?'} · ${d.sentido || '?'}`;

function propuestasRevision() {
  const items = { duplicado: [], 'no-factura': [], sentido: [], 'periodo-emitida': [], 'periodo-recibida': [], clasificacion: [] };

  for (const d of DB.documentos) {
    const avisos = avisosDeDocumento(d);
    if (!avisos.length) continue;
    const base = { documentoId: d.id, nombre: d.nombre, rutaRelativa: d.rutaRelativa || '', antesTexto: resumenDoc(d) };

    if (avisos.includes('duplicado')) {
      items.duplicado.push({ ...base, despuesTexto: 'copia repetida, no cuenta', motivo: 'idéntica a ' + (d.duplicadoDe || 'otro documento') });
      continue;
    }
    if (avisos.includes('no-factura')) {
      items['no-factura'].push({ ...base, despuesTexto: 'no es factura', motivo: (d.incidencias.match(/no_es_factura: ([^;]*)/) || [])[1] || '' });
      continue;
    }
    if (avisos.includes('sentido')) {
      items.sentido.push({ ...base, despuesTexto: resumenDoc({ ...d, sentido: 'emitida' }), motivo: 'numeración propia del cliente' });
      continue;
    }
    if (avisos.includes('periodo')) {
      const m = (d.incidencias || '').match(/trimestre_discrepante_pdf: el PDF dice (\d{4}-\d{2}-\d{2}) \((\dT) (\d{4})\)/);
      if (!m) continue;
      const destino = { ...d, ejercicio: Number(m[3]), trimestre: m[2] };
      const bloque = d.sentido === 'emitida' ? 'periodo-emitida' : 'periodo-recibida';
      items[bloque].push({
        ...base, despuesTexto: resumenDoc(destino),
        motivo: `el PDF está fechado el ${m[1].split('-').reverse().join('/')}`,
        datos: { ejercicio: Number(m[3]), trimestre: m[2], fecha: m[1] },
      });
      continue;
    }
    if (avisos.includes('revisar')) {
      const p = proponerClasificacion(d);
      if (p) items.clasificacion.push({ ...base, despuesTexto: resumenDoc({ ...d, ...p }), motivo: p.motivo, datos: p });
    }
  }

  return Object.entries(BLOQUES)
    .filter(([id]) => items[id].length)
    .map(([id, b]) => ({ id, ...b, total: items[id].length, items: items[id].slice(0, 500) }));
}

// Para un documento sin clasificar: qué se puede afirmar con seguridad.
// Se exige fecha fiable y un tipo claro; si no, se queda para revisión humana.
function proponerClasificacion(d) {
  const f = fechaEfectivaDe(d);
  if (!f.valor) return null;
  const anio = Number(f.valor.slice(0, 4));
  const tri = Math.floor((Number(f.valor.slice(5, 7)) - 1) / 3) + 1 + 'T';
  if (d.ejercicio && anio !== Number(d.ejercicio)) return null;
  const rx = SERIES_EMITIDA[clave(d.cliente || '')];
  const propio = rx && rx.test(clave(d.nombre || ''));
  const sentido = propio ? 'emitida' : d.sentido === 'recibida' ? 'recibida' : null;
  if (!sentido) return null;
  return {
    ejercicio: anio, trimestre: tri, sentido,
    motivo: `fecha ${f.valor.split('-').reverse().join('/')} (${f.origen === 'nombre' ? 'del nombre' : 'del documento'})` +
      (propio ? ' y numeración propia del cliente' : ''),
  };
}

// Aplica un bloque entero (o los documentos que se indiquen).
function aplicarBloque(bloqueId, ids) {
  const bloque = propuestasRevision().find((b) => b.id === bloqueId);
  if (!bloque) throw new Error('Ese bloque ya no tiene nada pendiente.');
  const pedidos = ids && ids.length ? new Set(ids) : null;
  const lote = uid();
  const r = { bloque: bloqueId, aplicados: 0, errores: [], lote };

  for (const item of bloque.items) {
    if (pedidos && !pedidos.has(item.documentoId)) continue;
    const d = DB.documentos.find((x) => x.id === item.documentoId);
    if (!d) { r.errores.push({ nombre: item.nombre, error: 'ya no existe' }); continue; }
    const facturasAntes = DB.facturas.filter((f) => f.documentoId === d.id).map((f) => ({ ...f }));
    const campos = ['ejercicio', 'trimestre', 'sentido', 'tipo', 'esCopia', 'revisado', 'revisadoEl', 'revisionManual'];
    const antes = {};
    for (const k of campos) antes[k] = d[k] === undefined ? null : d[k];

    try {
      if (bloqueId === 'duplicado') {
        d.esCopia = true;
        DB.facturas = DB.facturas.filter((f) => f.documentoId !== d.id);
      } else if (bloqueId === 'no-factura') {
        d.sentido = 'no-factura';
        DB.facturas = DB.facturas.filter((f) => f.documentoId !== d.id);
      } else if (bloqueId === 'sentido') {
        aplicarCambio(d, { sentido: 'emitida' });
      } else if (bloqueId.startsWith('periodo')) {
        aplicarCambio(d, { ejercicio: item.datos.ejercicio, trimestre: item.datos.trimestre }, item.datos.fecha);
      } else if (bloqueId === 'clasificacion') {
        aplicarCambio(d, { ejercicio: item.datos.ejercicio, trimestre: item.datos.trimestre, sentido: item.datos.sentido });
      }
      d.revisado = true; d.revisadoEl = now(); d.revisionManual = false; d.actualizado = now();
      d.historial = [...(d.historial || []), { fecha: now(), antes: item.antesTexto, despues: item.despuesTexto, nota: 'automático: ' + item.motivo }];
      refrescarFechas([d]);
      registrarMovimiento({
        tipo: bloqueId.split('-')[0] === 'periodo' ? 'periodo' : bloqueId,
        automatico: true, lote, documentoId: d.id, nombre: d.nombre, rutaRelativa: d.rutaRelativa,
        texto: `${item.antesTexto} → ${item.despuesTexto}`,
        motivo: item.motivo, antes, despues: { ejercicio: d.ejercicio, trimestre: d.trimestre, sentido: d.sentido, esCopia: d.esCopia || false },
        facturasAntes,
      });
      r.aplicados++;
    } catch (e) {
      Object.assign(d, antes);
      r.errores.push({ nombre: item.nombre, error: e.message });
    }
  }
  saveDB(DB);
  return r;
}

// Cambia los campos del documento y arrastra su factura (periodo, sentido, fecha).
function aplicarCambio(d, cambios, fecha) {
  const antes = { ejercicio: d.ejercicio, trimestre: d.trimestre, sentido: d.sentido };
  Object.assign(d, cambios);
  for (const f of DB.facturas.filter((x) => x.documentoId === d.id)) {
    // (En un PDF con varias facturas, solo las que iban igual que el documento;
    // el periodo, año y trimestre juntos.)
    const mismoPeriodo = !f.paginas || (String(f.ejercicio) === String(antes.ejercicio) && f.trimestre === antes.trimestre);
    if ((cambios.ejercicio || cambios.trimestre) && mismoPeriodo) { f.ejercicio = d.ejercicio; f.trimestre = d.trimestre; }
    if (cambios.sentido && (!f.paginas || f.sentido === antes.sentido)) f.sentido = cambios.sentido;
    if (fecha && !f.paginas) { f.fecha = fecha; f.fechaEstimada = false; }
    f.concepto = (f.sentido === 'emitida' ? 'Emitida ' : 'Recibida ') + f.trimestre + ' ' + f.ejercicio;
    f.actualizado = now();
  }
  if (fecha) { d.fechaDocumento = fecha; d.fechaOrigen = 'pdf'; }
}

// Lectura de escaneos con el OCR de Windows (lo leído se guarda en data/ocr).
const OCR = require('./lib/ocr').crear({ DATA_DIR });

const IMPORTAR = require('./lib/importar').crear({
  get DB() { return DB; },
  saveDB, coerceRecord, uid, now, DATA_DIR, OCR,
  raizImportadas: () => IMPORT_DIR,
});

// Lo que entra por Importar (o al ordenar una carpeta) queda en la trazabilidad
// y en el calendario del archivo.
function anotarImportados(r, automatico = false) {
  const lote = uid();
  for (const imp of r.importados || []) {
    const d = DB.documentos.find((x) => x.id === imp.documentoId || x.id === imp.id);
    if (!d) continue;
    registrarMovimiento({
      tipo: 'importacion', lote, documentoId: d.id, nombre: d.nombre, rutaRelativa: d.rutaRelativa, automatico,
      texto: `Entra en el archivo: ${resumenDoc(d)}`,
      motivo: imp.forzado ? 'se importó pese al aviso' : automatico ? 'colocada sola al ordenar la carpeta' : '', reversible: false,
    });
  }
  refrescarFechas();
  saveDB(DB);
}

// «Ordenar una carpeta nueva»: sustituye todo lo del programa (con copia).
const ORDENAR = require('./lib/ordenar').crear({
  getDB: () => DB,
  // (Una copia de antes de quitar la demo la traería de vuelta: se quita otra vez.)
  reemplazarDB: (nuevo) => { saveDB(nuevo); DB = nuevo; olvidarIndice(); IMPORTAR.olvidarPerfil(); quitarDemo(); },
  saveDB, coerceRecord, uid, now, ROOT, DATA_DIR, IMPORT_DIR, COPIAS_DIR, IMPORTAR, registrarMovimiento, OCR, apuntar,
  alImportar: (r) => anotarImportados(r, true),
});
IMPORTAR.limpiarAntiguos();

// Sincronización con la API del servidor local de la oficina.
// Contrato esperado: GET {apiBaseUrl}/ficheros  ->  [{ nombre, tipo?, sujetoNif?, contenidoBase64? , url? , tamano? }]
async function sincronizar() {
  const { apiBaseUrl, apiKey } = configEfectiva();
  if (!apiBaseUrl) throw new Error('Falta la URL de la API: ponla en el archivo .env (GF_API_URL) o en el apartado Configuración.');
  const url = apiBaseUrl.replace(/\/$/, '') + '/ficheros';
  const headers = { Accept: 'application/json' };
  if (apiKey) headers.Authorization = 'Bearer ' + apiKey;

  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  let lista;
  try {
    const r = await fetch(url, { headers, signal: ctrl.signal });
    if (!r.ok) {
      const seApuntaASiMismo = new URL(url).port === String(PORT);
      throw new Error('La API respondió ' + r.status + ' ' + r.statusText + '. ' + (seApuntaASiMismo
        ? 'Esa dirección es la de este mismo programa: ahí no hay ningún /ficheros. Pon la del servidor de archivos de la oficina.'
        : 'Comprueba que esa dirección expone GET /ficheros.'));
    }
    lista = await r.json();
  } finally { clearTimeout(t); }

  if (!Array.isArray(lista)) throw new Error('La API debe devolver una lista JSON de ficheros.');

  let creados = 0;
  for (const item of lista) {
    if (!item || !item.nombre) continue;
    const sujeto = item.sujetoNif ? DB.sujetos.find((s) => s.nif && s.nif.toLowerCase() === String(item.sujetoNif).toLowerCase()) : null;
    // Primero se descarta lo repetido: si no, cada pasada dejaria una copia
    // huerfana del fichero en data/uploads y la carpeta creceria sin fin.
    const yaExiste = DB.documentos.find((d) => d.origen === 'servidor-local' && d.nombre === item.nombre && d.sujetoId === (sujeto ? sujeto.id : null));
    if (yaExiste) continue;
    let ruta = null, tamano = Number(item.tamano) || 0;
    if (item.contenidoBase64) {
      const buf = Buffer.from(item.contenidoBase64, 'base64');
      ruta = uid() + '_' + item.nombre.replace(/[^\w.\- ]+/g, '_');
      fs.writeFileSync(path.join(UPLOAD_DIR, ruta), buf);
      tamano = buf.length;
    }
    DB.documentos.push(coerceRecord('documentos', {
      sujetoId: sujeto ? sujeto.id : null,
      nombre: item.nombre,
      tipo: item.tipo || path.extname(item.nombre).slice(1) || 'archivo',
      origen: 'servidor-local',
      urlRemota: item.url || null,
      ruta, tamano,
    }));
    creados++;
  }
  DB.config.sincronizado = now();
  saveDB(DB);
  return { creados, recibidos: lista.length };
}

async function probarConexion() {
  const { apiBaseUrl, apiKey } = configEfectiva();
  if (!apiBaseUrl) throw new Error('Introduce la URL de la API (o definela en .env como GF_API_URL).');
  const headers = {};
  if (apiKey) headers.Authorization = 'Bearer ' + apiKey;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 8000);
  try {
    const r = await fetch(apiBaseUrl.replace(/\/$/, '') + '/ping', { headers, signal: ctrl.signal }).catch(() => null)
      || await fetch(apiBaseUrl, { headers, signal: ctrl.signal });
    return { ok: r.ok, status: r.status };
  } finally { clearTimeout(t); }
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
const server = http.createServer(atender);

async function atender(req, res) {
  const u = new URL(req.url, 'http://localhost');
  const parts = u.pathname.split('/').filter(Boolean); // ej: ['api','sujetos','<id>']
  if (parts[0] === 'api' && req.method !== 'GET' && req.method !== 'HEAD') res.accionHistorial = { metodo: req.method, parts };

  // Cabeceras básicas de seguridad para todo lo que sirve el programa.
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');

  // Sin esto, una web cuyo dominio pase a apuntar a 127.0.0.1 (DNS rebinding)
  // pasaría por «petición local» y por «mismo origen» a la vez.
  // Se compara el nombre sin el puerto: con PORT=80 el navegador manda «localhost» a secas.
  if (SOLO_LOCAL && !hostLocal(req)) {
    res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Dirección no permitida. Entra por http://localhost:' + PORT);
  }

  if (!accesoPermitido(req)) {
    res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="Gestion de fichas", charset="UTF-8"', 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('Acceso restringido.');
  }

  // Las peticiones que cambian datos deben venir de la propia página: así otra
  // web abierta en el mismo navegador no puede lanzar acciones por detrás.
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.headers.origin) {
    const host = req.headers.host || '';
    if (req.headers.origin !== 'http://' + host && req.headers.origin !== 'https://' + host) {
      return sendJSON(res, 403, { error: 'Origen no permitido.' });
    }
  }

  // Mientras se ordena o se recupera una carpeta, nada más cambia datos.
  if (ORDENAR.bloqueaEscrituras() && req.method !== 'GET' && req.method !== 'HEAD' && !String(req.url).startsWith('/api/ordenar/')) {
    return sendJSON(res, 409, { error: 'Se está ordenando una carpeta: espera a que termine.' });
  }

  try {
    // Guia de instalacion: vive en la raiz, no en public/
    if (u.pathname === '/ayuda') {
      return fs.readFile(path.join(ROOT, 'DEPENDENCIAS.html'), (err, data) => {
        if (err) return sendText(res, 404, 'No encontrado');
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(data);
      });
    }
    if (parts[0] !== 'api') return serveStatic(req, res, u.pathname);

    // ---- Endpoints especiales ------------------------------------------------
    if (parts[1] === 'stats') return sendJSON(res, 200, stats());
    if (parts[1] === 'grafo') return sendJSON(res, 200, buildGraph());

    if (parts[1] === 'config') {
      // Campos que hoy vienen del .env: se muestran bloqueados y la clave se enmascara.
      const bloqueados = Object.keys(CLAVES_ENV).filter((k) => process.env[CLAVES_ENV[k]]);
      const paraUI = () => {
        const c = configEfectiva();
        if (process.env[CLAVES_ENV.apiKey]) c.apiKey = '••••••••  (definida en .env)';
        return { ...c, _bloqueadosPorEnv: bloqueados };
      };
      if (req.method === 'GET') return sendJSON(res, 200, paraUI());
      if (req.method === 'PUT') {
        const body = await readBody(req);
        // Lo que manda el .env no se guarda en db.json: evita persistir la mascara.
        for (const k of bloqueados) delete body[k];
        // La clave NUNCA se guarda en db.json, venga de donde venga: ese fichero
        // viaja dentro del paquete que se entrega al cliente. Su sitio es el .env.
        delete body.apiKey;
        delete body._bloqueadosPorEnv;
        const antes = JSON.stringify(DB.config);
        DB.config = { ...DB.config, ...body };
        if (JSON.stringify(DB.config) === antes) res.accionHistorial = null; // nada cambió
        olvidarIndice(); // si cambia la carpeta del archivo, el índice ya no vale
        saveDB(DB);
        return sendJSON(res, 200, paraUI());
      }
    }

    // ---- Actualizaciones del programa ----------------------------------------
    if (parts[1] === 'actualizacion') {
      if (!parts[2] && req.method === 'GET') return sendJSON(res, 200, ACTUALIZAR.estado());
      if (parts[2] === 'buscar' && req.method === 'POST') {
        try { await ACTUALIZAR.buscar(); } catch (e) { return sendJSON(res, 200, { ...ACTUALIZAR.estado(), errorComprobacion: e.message }); }
        return sendJSON(res, 200, ACTUALIZAR.estado());
      }
      // Desde un fichero «.actualizacion» (sin internet). Primero se comprueba
      // (firma y versión) para enseñar qué es; luego, si se confirma, se instala.
      if (parts[2] === 'fichero' && req.method === 'POST') {
        if (!esLocal(req)) return sendJSON(res, 403, { error: 'Solo se puede actualizar desde el propio ordenador del programa.' });
        const body = await readBody(req);
        const bytes = Buffer.from(String(body.contenidoBase64 || ''), 'base64');
        let r;
        try {
          if (body.comprobar) return sendJSON(res, 200, ACTUALIZAR.comprobarFichero(bytes));
          r = await ACTUALIZAR.instalarDesdeFichero(bytes);
        } catch (e) {
          return sendJSON(res, 400, { error: e.message });
        }
        if (!r.instalada) return sendJSON(res, 200, r);
        const reinicia = process.env.GF_LANZADOR === '1';
        sendJSON(res, 200, { ...r, reinicia });
        if (reinicia) setTimeout(() => { try { saveDB(DB); } catch (e) { console.error('  [!] ' + e.message); } process.exit(3); }, 400);
        return;
      }
      // Instalar y volver atrás cambian el programa de este equipo: solo desde él.
      if ((parts[2] === 'instalar' || parts[2] === 'volver') && req.method === 'POST') {
        if (!esLocal(req)) return sendJSON(res, 403, { error: 'Solo se puede actualizar desde el propio ordenador del programa.' });
        let r;
        try {
          if (parts[2] === 'volver') {
            r = ACTUALIZAR.volverAtras();
          } else {
            const b = await ACTUALIZAR.buscar();
            if (!b.configurado) return sendJSON(res, 400, { error: 'Las actualizaciones no están configuradas (GF_ACTUALIZACIONES_URL en el archivo .env).' });
            if (!b.disponible) return sendJSON(res, 200, { instalada: false, mensaje: 'Ya tienes la última versión (' + b.actual + ').' });
            r = await ACTUALIZAR.instalar(b.manifiesto);
          }
        } catch (e) {
          return sendJSON(res, 400, { error: e.message });
        }
        const reinicia = process.env.GF_LANZADOR === '1';
        sendJSON(res, 200, { ...r, reinicia });
        // Con el lanzador delante, salir con 3 es «vuelve a arrancarme».
        if (reinicia) setTimeout(() => { try { saveDB(DB); } catch (e) { console.error('  [!] ' + e.message); } process.exit(3); }, 400);
        return;
      }
    }

    if (parts[1] === 'sincronizar' && req.method === 'POST') {
      const r = await sincronizar();
      return sendJSON(res, 200, r);
    }
    if (parts[1] === 'probar-conexion' && req.method === 'POST') {
      const r = await probarConexion();
      return sendJSON(res, 200, r);
    }

    if (parts[1] === 'upload' && req.method === 'POST') {
      const body = await readBody(req); // { sujetoId, nombre, tipo, contenidoBase64 }
      if (!body.contenidoBase64 || !body.nombre) return sendJSON(res, 400, { error: 'Faltan nombre o contenido.' });
      const buf = Buffer.from(body.contenidoBase64, 'base64');
      const ruta = uid() + '_' + String(body.nombre).replace(/[^\w.\- ]+/g, '_');
      fs.writeFileSync(path.join(UPLOAD_DIR, ruta), buf);
      const rec = coerceRecord('documentos', {
        sujetoId: body.sujetoId || null, nombre: body.nombre,
        tipo: body.tipo || path.extname(body.nombre).slice(1) || 'archivo',
        origen: 'subida-manual', ruta, tamano: buf.length,
      });
      DB.documentos.push(rec);
      saveDB(DB);
      return sendJSON(res, 201, rec);
    }

    if (parts[1] === 'download' && parts[2]) {
      const doc = DB.documentos.find((d) => d.id === parts[2]);
      if (!doc || !doc.ruta) return sendText(res, 404, 'Documento sin archivo local');
      const full = path.join(UPLOAD_DIR, doc.ruta);
      if (!fs.existsSync(full)) return sendText(res, 404, 'Archivo no encontrado');
      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': 'attachment; filename="' + encodeURIComponent(doc.nombre) + '"',
      });
      return fs.createReadStream(full).pipe(res);
    }

    // ---- Informe fiscal: lo declarado y pagado a Hacienda, por trimestre ------
    if (parts[1] === 'hacienda' && parts[2] === 'resumen' && req.method === 'GET') {
      const q = Object.fromEntries(u.searchParams);
      const docs = DB.documentos.filter((d) => d.sentido === 'hacienda' && d.hacienda && !d.duplicadoDe
        && (!q.cliente || d.sujetoId === q.cliente));
      const nombres = new Map(DB.sujetos.map((x) => [(x.nif || '').toUpperCase(), x.aliasArchivo || x.nombre]));
      let filas = HACIENDA.resumenFiscal(docs.map((d) => ({ ...d.hacienda, ejercicio: d.ejercicio, trimestre: d.trimestre })))
        .filter((f) => !q.ejercicio || String(f.ejercicio) === String(q.ejercicio))
        .map((f) => ({ ...f, cliente: nombres.get(String(f.nif || '').toUpperCase()) || f.nif || '(sin cliente)' }));
      const detalle = docs.map((d) => ({
        id: d.id, nombre: d.nombre, cliente: d.cliente, ejercicio: d.ejercicio, trimestre: d.trimestre,
        tipo: d.hacienda.tipo, subtipo: d.hacienda.subtipo || null, modelo: d.hacienda.modelo || null,
        resultado: d.hacienda.resultado || null, importe: d.hacienda.importe ?? null, etiqueta: d.hacienda.etiqueta || d.nombre,
      })).filter((x) => !q.ejercicio || String(x.ejercicio) === String(q.ejercicio));
      if (q.formato === 'csv') {
        const celda = (v) => '"' + String(v == null ? '' : typeof v === 'number' ? String(v).replace('.', ',') : v).replace(/"/g, '""') + '"';
        const cab = ['Cliente', 'NIF', 'Ejercicio', 'Trimestre', 'Modelos', 'A ingresar', 'A devolver', 'Pagado', 'Regularizaciones', 'Sanciones', 'Modelos sin pago', 'Pagos sin modelo'];
        const rows = [cab.map(celda).join(';')];
        for (const f of filas) {
          rows.push([f.cliente, f.nif, f.ejercicio, f.trimestre,
            Object.entries(f.modelos).map(([m, x]) => `${m} ${x.resultado || ''}${x.importe != null ? ' ' + String(x.importe).replace('.', ',') : ''}`.trim()).join(' | '),
            f.aIngresar, f.aDevolver, f.pagado, f.regularizaciones, f.sanciones, f.modelosSinPago.join(' '), f.pagosSinModelo.join(' ')].map(celda).join(';'));
        }
        apuntarSiSaleBien(res, 'exportar', 'Descargado el informe fiscal (CSV).');
        res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="informe-fiscal.csv"' });
        return res.end('\ufeff' + rows.join('\r\n'));
      }
      return sendJSON(res, 200, { filas, detalle, documentos: docs.length });
    }

    if (parts[1] === 'informes' && parts[2] && parts[3] === 'datos') {
      const inf = DB.informes.find((i) => i.id === parts[2]);
      if (!inf) return sendJSON(res, 404, { error: 'Informe no encontrado' });
      return sendJSON(res, 200, datosInforme(inf));
    }

    // Excel factura por factura (+ hoja de resumen), ZIP con los ficheros o un
    // solo PDF con todas. `export` sin más sigue dando el Excel.
    if (parts[1] === 'informes' && parts[2] && ['export', 'excel', 'zip', 'pdf'].includes(parts[3]) && u.searchParams.get('formato') !== 'csv') {
      const inf = DB.informes.find((i) => i.id === parts[2]);
      if (!inf) return sendJSON(res, 404, { error: 'Informe no encontrado' });
      const formato = parts[3] === 'export' ? 'excel' : parts[3];
      apuntarSiSaleBien(res, 'exportar', `Exportado el informe «${inf.titulo || 'Informe'}» (${formato.toUpperCase()}).`);
      return await exportarFacturas(res, formato, facturasDeInforme(inf), { titulo: inf.titulo || 'Informe', resumen: datosInforme(inf) });
    }
    // Lo filtrado en la pestaña Facturas.
    if (parts[1] === 'facturas' && parts[2] === 'exportar' && req.method === 'POST') {
      const body = await readBody(req);
      const ids = new Set(Array.isArray(body.ids) ? body.ids.map(String) : []);
      const lista = DB.facturas.filter((f) => ids.has(f.id));
      apuntarSiSaleBien(res, 'exportar', `Exportadas ${lista.length} factura(s) de la pestaña Facturas (${String(body.formato || 'excel').toUpperCase()}).`);
      return await exportarFacturas(res, String(body.formato || ''), lista, { titulo: String(body.titulo || 'Facturas').slice(0, 80) });
    }

    // El resumen por cliente en CSV, como antes (export?formato=csv).
    if (parts[1] === 'informes' && parts[2] && parts[3] === 'export') {
      const inf = DB.informes.find((i) => i.id === parts[2]);
      if (!inf) return sendText(res, 404, 'Informe no encontrado');
      const d = datosInforme(inf);
      const celda = (v) => {
        if (typeof v === 'number') v = String(v).replace('.', ',');
        return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
      };
      const rows = [d.columnas.map((c) => celda(c.label)).join(';')];
      for (const f of d.filas) rows.push(d.columnas.map((c) => celda(f[c.key])).join(';'));
      if (d.nota) rows.push('', celda(d.nota));
      apuntarSiSaleBien(res, 'exportar', `Exportado el informe «${inf.titulo || 'Informe'}» (CSV).`);
      const csv = '﻿' + rows.join('\r\n');
      res.writeHead(200, {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename="informe_' + (inf.titulo || inf.id).replace(/[^\w]+/g, '_') + '.csv"',
      });
      return res.end(csv);
    }

    // ---- Explorador de archivo (vista ERP) ---------------------------------
    if (parts[1] === 'archivo' && parts[2] === 'arbol') {
      return sendJSON(res, 200, construirArbol());
    }

    // ¿Puede el programa abrir los PDF? Se responde con números, no con un sí.
    if (parts[1] === 'archivo' && parts[2] === 'estado') {
      const e = estadoArchivo();
      if (!e.existe || e.encontrados === 0) e.candidatos = candidatosDeArchivo();
      return sendJSON(res, 200, e);
    }
    // Probar una carpeta antes de guardarla.
    if (parts[1] === 'archivo' && parts[2] === 'comprobar' && req.method === 'POST') {
      const body = await readBody(req);
      return sendJSON(res, 200, estadoArchivo(String(body.ruta || '')));
    }
    // Buscarla sola por los sitios donde suele estar.
    if (parts[1] === 'archivo' && parts[2] === 'buscar-carpeta' && req.method === 'POST') {
      return sendJSON(res, 200, { candidatos: candidatosDeArchivo() });
    }
    // Saber si un documento se puede abrir ANTES de abrir una pestaña en blanco.
    if (parts[1] === 'archivo' && parts[2] === 'localizar' && parts[3]) {
      const doc = DB.documentos.find((d) => d.id === parts[3]);
      const donde = rutaDeDocumento(doc);
      return sendJSON(res, 200, donde.error
        ? { ok: false, codigo: donde.codigo, error: donde.error }
        : { ok: true, nombre: doc.nombre, tipo: (doc.tipo || '').toLowerCase() });
    }

    if (parts[1] === 'archivo' && parts[2] === 'abrir' && req.method === 'POST') {
      // Abrir lanza el visor en ESTE ordenador: desde otro equipo no tiene
      // sentido (se abriría en la pantalla de otra persona).
      if (!esLocal(req)) return sendJSON(res, 403, { error: 'Desde otro equipo usa «Ver», que lo abre en tu navegador.' });
      const body = await readBody(req);
      if (body.documentoId) {
        const doc = DB.documentos.find((d) => d.id === body.documentoId);
        const donde = rutaDeDocumento(doc);
        if (donde.error) return sendJSON(res, 400, { ok: false, error: donde.error });
        const r = abrirEnElSistema(donde.ruta, body.soloCarpeta);
        return sendJSON(res, r.ok ? 200 : 400, r);
      }
      const r = abrirEnElSistema(body.ruta, body.soloCarpeta, body.rutaRelativa);
      return sendJSON(res, r.ok ? 200 : 400, r);
    }

    // Ver un documento dentro del navegador (funciona también desde otro equipo).
    if (parts[1] === 'archivo' && parts[2] === 'ver' && parts[3]) {
      const doc = DB.documentos.find((d) => d.id === parts[3]);
      const donde = rutaDeDocumento(doc);
      if (donde.error) return sendText(res, 404, donde.error);
      return enviarFichero(res, donde.ruta, doc.nombre);
    }

    // ---- Importar facturas ---------------------------------------------------
    // Ordenar una carpeta nueva: lee carpetas del disco y sustituye todos los
    // datos, así que solo desde este ordenador y solo con JSON (una web ajena
    // no puede mandar JSON sin permiso del navegador).
    if (parts[1] === 'ordenar') {
      if (req.method === 'GET' && parts[2] === 'estado') return sendJSON(res, 200, ORDENAR.estado());
      if (req.method !== 'POST') return sendJSON(res, 405, { error: 'Método no permitido.' });
      if (!esLocal(req)) return sendJSON(res, 403, { error: 'Ordenar una carpeta solo se puede hacer desde el propio ordenador del programa.' });
      if (!/^application\/json/i.test(String(req.headers['content-type'] || ''))) return sendJSON(res, 415, { error: 'Petición no válida.' });
      const body = await readBody(req);
      try {
        if (parts[2] === 'elegir') return sendJSON(res, 200, await ORDENAR.elegirCarpeta());
        if (parts[2] === 'analizar') return sendJSON(res, 200, ORDENAR.analizar(body.ruta));
        if (parts[2] === 'ordenar') return sendJSON(res, 200, ORDENAR.ordenar(body));
        if (parts[2] === 'recuperar') return sendJSON(res, 200, ORDENAR.recuperar(body.cual === 'original' ? 'original' : 'anterior'));
        if (parts[2] === 'abrir') return sendJSON(res, 200, ORDENAR.abrirCarpetaOrdenada());
      } catch (e) {
        return sendJSON(res, e.status || 500, { error: e.message });
      }
      return sendJSON(res, 404, { error: 'Acción desconocida.' });
    }

    if (parts[1] === 'importar') {
      if (parts[2] === 'analizar' && req.method === 'POST') {
        const body = await readBody(req);
        // Los escaneos se leen antes con el OCR (si falla, se analizan sin él).
        const generacion = ORDENAR.generacion();
        // Un PDF con varias facturas juntas se separa en una por PDF.
        await IMPORTAR.preparar(body);
        // Escaneos: OCR, las páginas de una misma factura juntas y las fotos con
        // varios tickets separadas (un ticket por fila). Sin OCR: como antes.
        body.archivos = await SEPARAR.leerEscaneos(body.archivos, OCR, { nifsClientes: DB.sujetos.map((s) => (s.nif || '').toUpperCase()).filter(Boolean) });
        // El OCR puede tardar: si entretanto se ordenó (o se está ordenando) otra
        // carpeta, o se recuperó la anterior, no se escribe nada en los datos nuevos.
        if (ORDENAR.bloqueaEscrituras() || ORDENAR.generacion() !== generacion) {
          return sendJSON(res, 409, { error: 'Mientras se leían estos escaneos se cambió la carpeta de trabajo: vuelve a soltarlos.' });
        }
        return sendJSON(res, 200, IMPORTAR.analizar(body));
      }
      if (parts[2] === 'confirmar' && req.method === 'POST') {
        const r = IMPORTAR.confirmar(await readBody(req));
        anotarImportados(r);
        return sendJSON(res, 200, r);
      }
      if (parts[2] === 'descartar' && req.method === 'POST') return sendJSON(res, 200, IMPORTAR.descartar(await readBody(req)));
      // «Separar por páginas»: el PDF en espera se cambia por una fila por página.
      if (parts[2] === 'separar' && req.method === 'POST') {
        const body = await readBody(req);
        try {
          const generacion = ORDENAR.generacion();
          const archivos = await IMPORTAR.partesDe(body.lote, body.token);
          try { await OCR.prepararSubida(archivos); } catch { /* sin OCR */ }
          if (ORDENAR.bloqueaEscrituras() || ORDENAR.generacion() !== generacion) {
            return sendJSON(res, 409, { error: 'Mientras se separaba se cambió la carpeta de trabajo: vuelve a intentarlo.' });
          }
          const r = IMPORTAR.analizar({ lote: body.lote, archivos, sinSeparar: true, originales: archivos.originales });
          IMPORTAR.descartar({ lote: body.lote, tokens: [body.token] });
          return sendJSON(res, 200, { ...r, quitado: body.token });
        } catch (e) {
          return sendJSON(res, e.status || 500, { error: e.message });
        }
      }
      if (parts[2] === 'pendientes' && req.method === 'GET') return sendJSON(res, 200, IMPORTAR.pendientes());
      if (parts[2] === 'clientes' && req.method === 'GET') return sendJSON(res, 200, IMPORTAR.clientes());
      if (parts[2] === 'ver' && parts[3] && parts[4]) {
        const f = IMPORTAR.ficheroEnEspera(parts[3], parts[4], u.searchParams.get('entero') === '1');
        if (!f) return sendText(res, 404, 'No está en espera.');
        if (f.documentoId) {
          const r = rutaDeDocumento(DB.documentos.find((d) => d.id === f.documentoId));
          if (r.ruta) return enviarFichero(res, r.ruta, path.basename(r.ruta));
        }
        return enviarFichero(res, f.ruta, f.nombre);
      }
      return sendJSON(res, 404, { error: 'Acción de importación desconocida.' });
    }

    if (parts[1] === 'historial' && req.method === 'GET') return sendJSON(res, 200, leerHistorial(Object.fromEntries(u.searchParams)));

    // ---- Revisión ------------------------------------------------------------
    if (parts[1] === 'movimientos') {
      if (parts[2] && parts[3] === 'deshacer' && req.method === 'POST') {
        return sendJSON(res, 200, deshacerMovimiento(parts[2]));
      }
      if (req.method === 'GET') return sendJSON(res, 200, movimientos(Object.fromEntries(u.searchParams)));
      return sendJSON(res, 404, { error: 'Acción desconocida.' });
    }

    // ¿Lee escaneos este equipo? (OCR de Windows con español.) Lo usa Importar para avisar.
    if (parts[1] === 'ocr' && parts[2] === 'estado' && req.method === 'GET') {
      return sendJSON(res, 200, OCR ? await OCR.estado() : { ok: false, motivo: 'no-windows' });
    }
    if (parts[1] === 'revision') {
      if (parts[2] === 'leer-importes' && req.method === 'POST') {
        const r = leerImportes();
        let proveedores;
        try { proveedores = leerProveedores(); } catch (e) { proveedores = { error: e.message }; }
        return sendJSON(res, 200, { ...r, proveedores });
      }
      if (parts[2] === 'auditar' && req.method === 'POST') return sendJSON(res, 200, auditarConPdf());
      if (parts[2] === 'propuestas' && req.method === 'GET') return sendJSON(res, 200, propuestasRevision());
      if (parts[2] === 'aplicar' && req.method === 'POST') {
        const body = await readBody(req);
        return sendJSON(res, 200, aplicarBloque(String(body.bloque || ''), body.ids));
      }
      if (parts[2] === 'documento' && parts[3] && req.method === 'POST') {
        return sendJSON(res, 200, corregirDocumento(parts[3], await readBody(req)));
      }
      if (parts[2] === 'factura' && parts[3] && req.method === 'POST') {
        const f = DB.facturas.find((x) => x.id === parts[3]);
        if (!f) return sendJSON(res, 404, { error: 'Factura no encontrada.' });
        const body = await readBody(req);
        const idx = DB.facturas.indexOf(f);
        const nombre = typeof body.contraparte === 'string' ? { contraparte: body.contraparte.replace(/\s+/g, ' ').trim().slice(0, 120) || null } : {};
        // Sin importes en la petición (tabla hoja por hoja): solo la fecha y de
        // quién es. No confirma los importes ni exige que cuadren.
        if (body.base === undefined && body.total === undefined) {
          DB.facturas[idx] = coerceRecord('facturas', {
            ...(body.fecha ? { fecha: body.fecha, fechaEstimada: false } : {}),
            ...(body.numero != null ? { numero: body.numero } : {}),
            ...nombre,
          }, f);
          saveDB(DB);
          return sendJSON(res, 200, DB.facturas[idx]);
        }
        DB.facturas[idx] = coerceRecord('facturas', {
          base: body.base, iva: body.iva, irpf: body.irpf || 0, ...nombre,
          ...(body.desglose !== undefined ? { desglose: body.desglose } : {}),
          ...(body.total != null && body.total !== '' ? { total: body.total } : {}),
          ...(body.fecha ? { fecha: body.fecha, fechaEstimada: false } : {}),
          ...(body.numero != null ? { numero: body.numero } : {}),
          importeConfirmado: true, importeOrigen: f.importeOrigen || 'manual',
        }, f);
        const g = DB.facturas[idx];
        // Recargo de equivalencia: si solo cuadra con el de su tipo de IVA, es eso.
        if (!IMPORTE.cuadra(g) && !g.recargo && IMPORTE.recargoDe(g.iva) && IMPORTE.cuadra({ ...g, recargo: IMPORTE.recargoDe(g.iva) })) g.recargo = IMPORTE.recargoDe(g.iva);
        if (!IMPORTE.cuadra(g)) {
          DB.facturas[idx] = f;
          const tipos = g.desglose ? IMPORTE.tiposTexto(g) : g.iva;
          return sendJSON(res, 400, { error: `Los importes no cuadran: ${g.base} + ${tipos}% IVA − ${g.irpf}% IRPF no da ${g.total}.` });
        }
        // Lo corregido a mano enseña dónde estaba cada dato en ese formato.
        try { aprenderFormato(f, g); } catch { /* aprender no puede tumbar la corrección */ }
        saveDB(DB);
        return sendJSON(res, 200, g);
      }
      return sendJSON(res, 404, { error: 'Acción de revisión desconocida.' });
    }

    if (parts[1] === 'copia' && req.method === 'POST') {
      const sello = now().replace(/[:.]/g, '-');
      const f = path.join(COPIAS_DIR, 'db-manual-' + sello + '.json');
      fs.copyFileSync(DB_FILE, f);
      if (fs.existsSync(HISTORIAL_FILE)) fs.copyFileSync(HISTORIAL_FILE, path.join(COPIAS_DIR, 'historial-manual-' + sello + '.jsonl'));
      return sendJSON(res, 200, { ok: true, fichero: path.basename(f), carpeta: COPIAS_DIR });
    }

    // ---- CRUD genérico -----------------------------------------------------
    const col = parts[1];
    if (!COLLECTIONS.includes(col)) return sendJSON(res, 404, { error: 'Recurso desconocido: ' + col });
    const id = parts[2];

    if (req.method === 'GET' && !id) {
      let list = DB[col].slice();
      for (const [k, v] of u.searchParams.entries()) list = list.filter((r) => String(r[k]) === v);
      return sendJSON(res, 200, list);
    }
    if (req.method === 'GET' && id) {
      const rec = DB[col].find((r) => r.id === id);
      return rec ? sendJSON(res, 200, rec) : sendJSON(res, 404, { error: 'No encontrado' });
    }
    if (req.method === 'POST' && !id) {
      const body = await readBody(req);
      if (col === 'documentos') { delete body.ruta; delete body.rutaRelativa; delete body.almacen; } // lo decide el programa
      const rec = coerceRecord(col, body, null);
      DB[col].push(rec);
      saveDB(DB);
      return sendJSON(res, 201, rec);
    }
    if ((req.method === 'PUT' || req.method === 'PATCH') && id) {
      const body = await readBody(req);
      // Se busca DESPUÉS de leer el cuerpo: mientras tanto los datos pueden
      // haberse sustituido (ordenar o recuperar una carpeta).
      const idx = DB[col].findIndex((r) => r.id === id);
      if (idx === -1) return sendJSON(res, 404, { error: 'No encontrado' });
      if (col === 'documentos') {
        delete body.ruta; // la pone el servidor al subir
        delete body.rutaRelativa; delete body.almacen; // dónde está el fichero lo decide el programa
      }
      DB[col][idx] = coerceRecord(col, body, DB[col][idx]);
      saveDB(DB);
      return sendJSON(res, 200, DB[col][idx]);
    }
    if (req.method === 'DELETE' && id) {
      const idx = DB[col].findIndex((r) => r.id === id);
      if (idx === -1) return sendJSON(res, 404, { error: 'No encontrado' });
      if (res.accionHistorial) res.accionHistorial.extra = arrastraAlBorrar(col, id);
      cascadeDelete(col, id);
      const [removed] = DB[col].splice(idx, 1);
      saveDB(DB);
      return sendJSON(res, 200, removed);
    }

    return sendJSON(res, 405, { error: 'Método no permitido' });
  } catch (err) {
    // Los errores de validación (datos que envía la página) son 400; el resto, 500.
    const codigo = err.status || (/no v[aá]lid|falta|no encontrad|no existe/i.test(err.message || '') ? 400 : 500);
    if (codigo === 500) console.error('  [error] ' + req.method + ' ' + req.url + ': ' + (err.stack || err));
    // Si ya se estaba enviando (un ZIP a medias), no se puede contestar otra
    // cosa: se corta esa descarga y el programa sigue.
    if (res.headersSent) { try { res.destroy(); } catch { /* ya cerrada */ } return; }
    return sendJSON(res, codigo, { error: err.message || String(err) });
  }
}

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error('\n  [X] El puerto ' + PORT + ' ya está en uso. ¿El programa ya estaba abierto?\n');
    process.exit(4);
  }
  console.error('\n  [X] ' + e.message + '\n');
  process.exit(1);
});

// En modo local se escucha también en IPv6 (::1). Windows resuelve "localhost"
// primero a ::1 y, si ahí no hay nadie, tarda ~2 s en probar 127.0.0.1: cada
// petición del pipeline de Python iba a paso de tortuga.
if (SOLO_LOCAL) {
  const seis = http.createServer(atender);
  seis.on('error', () => { /* equipo sin IPv6: da igual */ });
  seis.listen(PORT, '::1');
}

// Hasta la 1.1.3 los abonos se importaban en POSITIVO y sumaban como una
// factura más. Una vez (al pasar a esta versión) se mira el texto de las
// facturas en positivo: las que dicen ser un abono o traen el total en negativo
// van a Revisar «¿Abono?», sin tocar sus importes hasta que alguien lo confirme.
// Se hace poco a poco, sin parar el programa.
async function repasarAbonosAntiguos() {
  if (DB.config.abonosRepasados) return;
  let marcadas = 0, sinAcceso = 0;
  const lista = DB.facturas.filter((f) => Number(f.total) > 0 && f.abono !== true && !f.paginas);
  for (const f of lista) {
    await new Promise((r) => setImmediate(r));
    const d = DB.documentos.find((x) => x.id === f.documentoId);
    if (!d || d.paginasPdf || d.abono === false || d.abono === true || /abono_dudoso/.test(d.incidencias || '')) continue;
    const donde = rutaDeDocumento(d);
    if (donde.error) { if (['sin-carpeta', 'carpeta-no-existe'].includes(donde.codigo)) sinAcceso++; continue; }
    let ab = null;
    try {
      const buf = fs.readFileSync(donde.ruta);
      const texto = OCR ? OCR.textoDe(buf, d.nombre, d.sha256).texto : (/\.pdf$/i.test(d.nombre) ? extraerTexto(buf) : '');
      ab = texto ? leerAbono(texto) : null;
    } catch { continue; }
    if (!ab) continue;
    d.incidencias = [String(d.incidencias || ''), 'abono_dudoso: importado antes de la 1.1.4 en positivo; ' + ab.como].filter(Boolean).join('; ');
    d.revisado = false;
    marcadas++;
  }
  // Si la carpeta del archivo no estaba (unidad de red sin conectar), se repite al abrirlo otra vez.
  if (!sinAcceso) DB.config.abonosRepasados = now();
  try { saveDB(DB); } catch (e) { console.error('  [!] ' + e.message); return; }
  if (marcadas) console.log('  ' + marcadas + ' factura(s) de antes de la 1.1.4 parecen abonos y van en positivo: están en Revisar «¿Abono?».');
  if (marcadas) apuntar('revisar', `${marcadas} factura(s) de antes de la 1.1.4 parecen abonos y van en positivo: pasan a Revisar «¿Abono?».`);
}

server.listen(PORT, HOST, () => {
  apuntarEnUso();
  setInterval(apuntarEnUso, 30 * 1000).unref();
  console.log('\n  Gestión de fichas — Asesoría Albereda 36, S.L.');
  console.log('  ------------------------------------------------');
  console.log('  Servidor:   http://localhost:' + PORT);
  console.log('  Acceso:     ' + (SOLO_LOCAL ? 'solo este ordenador' : 'red (' + HOST + '), con contraseña'));
  console.log('  Datos:      ' + DB_FILE);
  console.log('  Importadas: ' + IMPORT_DIR);
  console.log('  Copias:     ' + COPIAS_DIR);
  console.log('  Versión:    ' + ACTUALIZAR.versionInstalada() + '\n');
  anotarArranque();

  setTimeout(() => { repasarAbonosAntiguos().catch((e) => console.error('  [!] Repaso de abonos: ' + e.message)); }, 8000).unref();
  // Treinta segundos en marcha: la versión recién instalada ya es la buena y
  // el lanzador no la retirará si más tarde hay otro fallo.
  const versionDeArranque = ACTUALIZAR.versionInstalada();
  setTimeout(() => {
    try {
      if (ACTUALIZAR.confirmarArranque(versionDeArranque)) console.log('  Versión ' + versionDeArranque + ' confirmada.');
    } catch (e) { console.error('  No se pudo confirmar la versión: ' + e.message); }
  }, 30000).unref();
  // Mirar si hay versión nueva al poco de arrancar y cada 6 horas: si la
  // hay, la pantalla lo avisa; se instala sola la próxima vez que se abra.
  const mirar = () => ACTUALIZAR.buscar().catch(() => {});
  setTimeout(mirar, 15000).unref();
  setInterval(mirar, 6 * 60 * 60 * 1000).unref();
});
