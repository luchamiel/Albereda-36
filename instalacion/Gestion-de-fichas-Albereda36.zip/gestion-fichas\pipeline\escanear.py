"""Escaneo del archivo real -> Inventario normalizado.

SOLO LECTURA sobre la carpeta del cliente. Ni un solo open('w') apunta ahi.
"""
from __future__ import annotations

import hashlib
import sys
from collections import Counter, defaultdict
from pathlib import Path

import patrones
from modelo import Documento, Inventario, TipoDoc
from normalizar import clasificar_ruta

# Ruido del sistema de ficheros que nunca es un documento.
IGNORAR = {"thumbs.db", "desktop.ini", ".ds_store"}


def _es_ruido(nombre: str) -> bool:
    return nombre.lower() in IGNORAR or nombre.startswith("~$")


def sha256_de(ruta: Path, bloque: int = 65536) -> str | None:
    """Hash por bloques: 1185 archivos, nada se carga entero en memoria."""
    h = hashlib.sha256()
    try:
        with ruta.open("rb") as fh:
            for trozo in iter(lambda: fh.read(bloque), b""):
                h.update(trozo)
    except OSError:
        return None
    return h.hexdigest()


def escanear(raiz: Path, calcular_hash: bool = True,
             verbose: bool = True) -> Inventario:
    """Recorre la raiz y construye el inventario clasificado."""
    inv = Inventario(raiz=str(raiz))
    n = 0
    for ruta in sorted(raiz.rglob("*")):
        if not ruta.is_file() or _es_ruido(ruta.name):
            continue
        n += 1
        if verbose and n % 200 == 0:
            print(f"  ... {n} archivos", file=sys.stderr)

        rel = ruta.relative_to(raiz).as_posix()
        try:
            stat = ruta.stat()
        except OSError:
            continue

        clasif = clasificar_ruta(rel, ruta.name)
        patron, meta = patrones.clasificar(ruta.name)

        doc = Documento(
            ruta_relativa=rel,
            nombre=ruta.name,
            extension=ruta.suffix.lower().lstrip("."),
            tamano=stat.st_size,
            sha256=sha256_de(ruta) if calcular_hash else None,
            patron_detectado=patron,
            numero=meta.get("num"),
            serie=meta.get("serie"),
            contraparte=meta.get("contraparte"),
            nif=meta.get("nif"),
            **{k: v for k, v in clasif.items()},
        )
        if stat.st_size == 0:
            doc.incidencias.append("archivo_vacio")
            doc.revision_manual = True
        inv.documentos.append(doc)

    if calcular_hash:
        marcar_duplicados(inv)
    if verbose:
        print(f"  {len(inv)} archivos escaneados.", file=sys.stderr)
    return inv


def marcar_duplicados(inv: Inventario) -> int:
    """Deduplica por SHA-256 del CONTENIDO, jamas por nombre.

    Canonico = el ejemplar cuyo trimestre viene de la FECHA (mas fiable);
    en empate, el de ruta mas corta. El resto se marca, nunca se borra.
    """
    grupos: dict[str, list[Documento]] = defaultdict(list)
    for d in inv.documentos:
        if d.sha256:
            grupos[d.sha256].append(d)

    marcados = 0
    for _, docs in grupos.items():
        if len(docs) < 2:
            continue
        docs.sort(key=lambda x: (x.origen_trimestre != "fecha",
                                 len(x.ruta_relativa)))
        canonico = docs[0]
        for d in docs[1:]:
            d.duplicado_de = canonico.ruta_relativa
            d.computa_en_libro_iva = False  # no inflar la base imponible
            d.incidencias.append("duplicado_por_contenido")
            marcados += 1
    return marcados


def estadisticas(inv: Inventario) -> dict:
    """Conteos reales para el informe y para verificar el escaneo."""
    unicos = {d.sha256 for d in inv.documentos if d.sha256}
    return {
        "total": len(inv),
        "unicos_por_contenido": len(unicos) if unicos else None,
        "duplicados": sum(1 for d in inv.documentos if d.duplicado_de),
        "computan_en_libro_iva": sum(1 for d in inv.documentos
                                     if d.computa_en_libro_iva),
        "revision_manual": sum(1 for d in inv.documentos if d.revision_manual),
        "con_incidencias": sum(1 for d in inv.documentos if d.incidencias),
        "por_cliente": dict(Counter(d.cliente or "(sin cliente)"
                                    for d in inv.documentos).most_common()),
        "por_ejercicio": dict(sorted(Counter(
            str(d.ejercicio or "?") for d in inv.documentos).items())),
        "por_trimestre": dict(sorted(Counter(
            d.trimestre or "(sin trimestre)" for d in inv.documentos).items())),
        "por_tipo": dict(Counter(d.tipo_doc for d in inv.documentos).most_common()),
        "por_extension": dict(Counter(d.extension
                                      for d in inv.documentos).most_common()),
        "origen_trimestre": dict(Counter(
            d.origen_trimestre or "(ninguno)" for d in inv.documentos).most_common()),
        "sin_patron": sum(1 for d in inv.documentos
                          if d.patron_detectado == "sin_patron"),
    }


def resumen_texto(inv: Inventario) -> str:
    """Resumen legible para consola."""
    st = estadisticas(inv)
    L = ["ESCANEO DEL ARCHIVO", "=" * 60,
         f"Archivos            : {st['total']}",
         f"Unicos por contenido: {st['unicos_por_contenido']}",
         f"Duplicados marcados : {st['duplicados']}",
         f"Computan en IVA     : {st['computan_en_libro_iva']}",
         f"Revision manual     : {st['revision_manual']}",
         f"Sin patron de nombre: {st['sin_patron']}", ""]
    for titulo, datos in (("POR CLIENTE", st["por_cliente"]),
                          ("POR EJERCICIO", st["por_ejercicio"]),
                          ("POR TRIMESTRE", st["por_trimestre"]),
                          ("POR TIPO", st["por_tipo"]),
                          ("ORIGEN DEL TRIMESTRE", st["origen_trimestre"])):
        L.append(titulo)
        for k, v in datos.items():
            L.append(f"  {str(k):28s} {v:5d}")
        L.append("")
    return "\n".join(L)
