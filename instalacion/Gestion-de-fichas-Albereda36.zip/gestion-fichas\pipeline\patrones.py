# -*- coding: utf-8 -*-
"""
Catalogo de patrones de nombre de archivo — Asesoria Albereda 36, S.L.

Construido y VALIDADO contra los 1185 archivos reales del archivo
de la asesoria (la carpeta que indique GF_RUTA_ARCHIVO en el .env).

Reglas de uso:
  - La lista PATRONES esta ORDENADA de mas especifico a mas generico.
    Se evalua en CASCADA y gana el PRIMERO que casa. No reordenar sin
    volver a medir la cobertura.
  - El ultimo patron ("sin_patron") es un catch-all que NUNCA falla.
  - Grupos con nombre normalizados: num, anio, mes, dia, fecha, hora, nif,
    serie, contraparte, concepto, tipo, trimestre, indice, ext.
  - Solo biblioteca estandar (re).

Cobertura medida sobre los 1185 archivos reales:
  - 1185 / 1185 (100,00 %) casan con algun patron del catalogo.
  -  845 / 1185 ( 71,31 %) casan con un patron ESPECIFICO del que se
     extraen metadatos fiscalmente utiles (num / anio / fecha / serie / NIF).
  -  340 / 1185 ( 28,69 %) caen en patrones GENERICOS: el archivo queda
     identificado y archivable, pero SIN metadatos fiables en el nombre
     (hay que abrir el PDF o usar la carpeta contenedora).
  -    0 / 1185 ( 0,00 %) quedan como "sin_patron".
"""

import re

# Sufijo de copia/duplicado que Windows, Chrome y Gmail anaden al final:
#   " (1)"   "(2)"   "[1]"   " - copia"   " (29)(1)"
DUP = r"(?:\s*\(\d+\)|\s*\[\d+\]|\s*-\s*copia|\s*\(\d+\)\(\d+\))?"

# Extension. Se captura siempre en el grupo <ext>.
EXT = r"\.(?P<ext>pdf|PDF|jpg|jpeg|png|zip|rar|xlsx|xls|xsig)$"

# Meses en texto (incluye las erratas reales del archivo: "OCTIBRE").
MES_TEXTO = (r"(?:enero|febrero|marzo|abril|mayo|junio|julio|agosto|"
             r"septiembre|setiembre|octubre|octibre|noviembre|diciembre)")

D = DUP
E = EXT
MES = MES_TEXTO

PATRONES = [
    # ------------------------------------------------------------------
    # A. IDENTIFICADORES FISCALES / OFICIALES  (maxima fiabilidad)
    # ------------------------------------------------------------------
    ("aeat_nif_anio_serie",
     r"^(?P<nif>[A-Z]\d{8})_(?P<anio>20\d{2})_(?P<serie>[A-Z]\d{5}[A-Z])-(?P<num>\d+)" + D + E),
    ("prov_nif_pais_nif_num_fecha",
     r"^(?P<nif>[A-Z]\d{8})_[A-Z]{3}_(?P<nif_cliente>\d{8}[A-Z])_[A-Z]{3}_(?P<num>\d+)_(?P<fecha>\d{8})" + D + E),
    ("nalanda_pobr",
     r"^(?P<emisor>\d{10})_(?P<doc>pobr\d+)_(?P<fecha>\d{8})" + D + E),
    ("nalanda_informe_obra",
     r"^pInfObra(?P<num>\d+)_(?P<fecha>\d{8})" + D + E),
    ("colegio_coacv_anio_num",
     r"^(?P<serie>COACV)-(?P<anio>20\d{2})-(?P<num>\d{5})" + D + E),

    # ------------------------------------------------------------------
    # B. FACTURAS EMITIDAS (ingresos del cliente)
    # ------------------------------------------------------------------
    ("emitida_serie_correlativa",
     r"^Factura[ _-](?P<serie>\d{1,2})-(?P<num>\d{6})" + D + E),
    ("emitida_fecha_num_obra",
     r"^(?:Emitida_)?(?P<anio>20\d{2})_(?P<mes>\d{2})_(?P<dia>\d{2})_(?:Factura(?:\s+Emitida)?\s+)?(?P<num>\d{3,4})_(?:Factura\s+)?(?P<contraparte>.+?)" + D + E),
    ("emitida_num_anio_contraparte",
     r"^(?P<serie>R?)(?P<num>\d{3})-(?P<anio>20\d{2})_\s*(?P<contraparte>.+?)" + D + E),
    ("emitida_factura_anio_num_fecha",
     r"^Factura\s+(?P<anio>20\d{2})-(?P<num>\d{3})\s*\((?P<fecha>\d{1,2}-\d{1,2}-\d{2})\)\s*(?P<contraparte>[^.]*?)" + D + E),
    ("emitida_num_aa_contraparte",
     r"^(?P<num>\d{3})-(?P<anio>2[0-9])(?:\s+(?P<contraparte>[^.]+?))?" + D + E),
    ("emitida_num_fecha_larga",
     r"^[Ff]actura\s+(?P<num>\d{3})-(?P<fecha>\d{1,2}-\d{1,2}-20\d{2})\s*(?P<contraparte>[^.]*?)" + D + E),
    ("emitida_factura_obra_visado",
     r"^(?:Attached file_\s*_)?Factura\s+(?P<anio>20\d{2})_(?P<serie>[A-Z])_(?P<num>\d{3,4})\s+Obra\s+N[\u00ba\u00b0o]\s*(?P<contraparte>\d+\s*-\s*[^.]+?)(?:\.pdf_)?" + D + E),
    ("emitida_fac_num_fechacompacta",
     r"^FAC-(?P<num>\d{3})[-_](?P<fecha>\d{8})" + D + E),
    ("emitida_emi_serie_num",
     r"^EMI_(?P<serie>[A-Z])_(?P<num>\d{1,4})" + D + E),
    ("emitida_factura_serie_num_contraparte_fecha",
     r"^Factura\s+(?P<serie>[A-Z])\s+(?P<num>\d{6,8})\s+(?P<contraparte>[^\d]+?)\s+(?P<fecha>\d{2}_\d{2}_\d{4})" + D + E),
    ("emitida_num_factura_contraparte_fecha",
     r"^(?P<num>\d{4})[_ ]FACTURA[_ ](?P<contraparte>[A-Za-z_ ]+?)[_ ](?P<fecha>\d{2}[_ ]\d{2}[_ ]\d{4})" + D + E),
    ("emitida_cype",
     r"^(?:Formato_)?Factura[ _](?:(?P<num>\d{1,4})_)?Ventas_Cype_Pdf(?:_VF_(?P<serie>\d+)_(?P<num2>\d+))?" + D + E),
    ("emitida_factura_num_contraparte",
     r"^Factura\s+(?P<num>\d{4,8})\s*-\s*(?P<contraparte>[^.]+?)" + D + E),
    ("prov_factura_serie_anio_num",
     r"^Factura_(?P<serie>[A-Z]{2})_(?P<anio>2[0-9])_(?P<num>\d{1,4})" + D + E),

    # ------------------------------------------------------------------
    # C. PROVEEDORES CON CODIFICACION PROPIA (facturas recibidas)
    # ------------------------------------------------------------------
    ("prov_1822st_mes_anio",
     r"^(?P<serie>1822ST)(?P<mes>\d{2})(?P<anio>20\d{2})" + D + E),
    ("prov_factura_mes_anio",
     r"^Facturas?_(?P<mes>\d{1,2})-(?P<anio>2[0-9])" + D + E),
    ("prov_ames_num_mesanio",
     r"^(?P<serie>AMES)(?P<num>\d{11})-(?P<mes>\d{2})(?P<anio>\d{2})" + D + E),
    ("prov_plenoil_hash",
     r"^plenoil_facturas(?P<num>[0-9a-f]{11,13})" + D + E),
    ("prov_ctav_num",
     r"^factura_(?P<serie>CTAV)_(?P<num>\d{10})" + D + E),
    ("prov_factura_anio_serie_num",
     r"^factura(?P<anio>20\d{2})(?P<serie>[A-Z])(?P<num>\d{6})" + D + E),
    ("prov_factura_anio_num_serie",
     r"^Factura(?P<anio>20\d{2})(?P<num>\d{3})-(?P<serie>[A-Z]\d{1,4})" + D + E),
    ("prov_fi_anio_num",
     r"^(?P<serie>FI)(?P<anio>2[0-9])(?P<num>\d{7})" + D + E),
    ("prov_exp_anio_num",
     r"^(?P<serie>EXP)(?P<anio>2[0-9])(?P<num>\d{6})" + D + E),
    ("prov_serie_anio_num",
     r"^(?P<serie>[A-Z]{1,2})(?P<anio>2[0-9])(?P<num>\d{6})" + D + E),
    ("prov_fv_codigo_fechahora",
     r"^FV_(?P<serie>FK\d{2})(?P<num>\d{6})_(?P<fecha>\d{8})(?P<hora>\d{5,7})" + D + E),
    ("prov_fra_num_num_nif",
     r"^FRA_(?P<num>\d{5})_(?P<serie>\d{6})_(?P<nif>\d{8}[A-Z])" + D + E),
    ("prov_fra_anio_serie_num",
     r"^FRA(?P<anio>20\d{2})-(?P<serie>[A-Z])-(?P<num>\d{1,4})" + D + E),
    ("prov_invoice_hex_num",
     r"^Invoice-(?P<serie>[0-9A-Z]{8})-(?P<num>\d{4})" + D + E),
    ("prov_num_guion_factura",
     r"^(?P<num>\d{6,8})-factura" + D + E),
    ("prov_factura_web_anio_num",
     r"^factura-(?P<serie>WEB)-(?P<anio>20\d{2})-(?P<num>\d{4})" + D + E),
    ("prov_factura_num_fecha",
     r"^factura(?P<num>\d{4,6})_(?P<fecha>\d{8})" + D + E),
    ("prov_invoice_num_num",
     r"^invoice_(?P<num>\d{6,10})_(?P<serie>\d{4,8})" + D + E),
    ("prov_invoice_fecha",
     r"^Invoice_0?(?P<fecha>2\d{7})" + D + E),
    ("prov_turnover_num",
     r"^Turnover_(?P<num>\d{9})_(?P<serie>[A-Z]\d{15})" + D + E),
    ("prov_anio_serie_num",
     r"^(?P<anio>20\d{2})-(?P<serie>[A-Z]{2,4}\d?)-(?P<num>\d{6,9})" + D + E),
    ("prov_factura_serie_xxxx",
     r"^Factura_(?P<serie>[A-Z]{6,8})(?P<num>\d{3})X{2,4}" + D + E),
    ("prov_bem_proforma",
     r"^_BEM_FACTPROFORM_(?P<fecha>\d{2}-\d{2}-20\d{2})_(?P<hora>\d{2}-\d{2}-\d{2})_(?P<num>\d{8})_(?P<contraparte>.+?)" + D + E),
    ("prov_ref_almohadilla",
     r"^#(?P<serie>\d{7})#_(?P<num>\d{9})_(?P<num2>\d{9})" + D + E),
    ("prov_suministro_20d",
     r"^(?P<num>\d{20})" + D + E),
    ("prov_scan_serie_num_fechahora",
     r"^(?P<serie>\d{2})_(?P<num>\d{5})_(?P<fecha>\d{8})_(?P<hora>\d{6})" + D + E),
    ("prov_num_sca_col_fechahora",
     r"^(?P<num>\d{7})_(?P<serie>SCA_COL)_(?P<fecha>\d{8})_(?P<hora>\d{6})" + D + E),
    ("prov_codigo_alfanumerico",
     r"^(?P<serie>[A-Z]{2,6})_?(?P<num>\d{2}_?\d{4,15})(?:\s+(?P<contraparte>[A-Z][^.]*?))?" + D + E),
    ("prov_num_9d",
     r"^(?P<num>\d{9})" + D + E),
    ("foto_galeria_10d",
     r"^(?P<num>10\d{8})\.(?P<ext>jpg|jpeg|png)$"),
    ("prov_num_10d",
     r"^(?P<num>\d{10})" + D + r"\.(?P<ext>pdf|PDF)$"),
    ("prov_anio_num_num_firmado",
     r"^(?P<anio>20\d{2})-(?P<serie>\d{2})-(?P<num>\d{4})" + D + E),

    # ------------------------------------------------------------------
    # D. DOCUMENTOS QUE NO SON FACTURA (PRL, Nalanda, subcontratas, laboral)
    #    Sirven para NO cargarlos como facturas en la app.
    # ------------------------------------------------------------------
    ("doc_prl_subcontrata",
     r"^(?P<concepto>.*?(?:acreditaci\w+|subcontrat\w*|\bprl\b|epis|plan de seguridad|"
     r"aptitud m\w+|p[o\u00f3O\u00d3]?liza|seg\.?\s*soc|al corriente|cotizaci\w+|nalanda|"
     r"prevenci\w+|riesgos laborales|certificado de contratistas|compromiso|adhesi\w+|"
     r"inscripci\w+|autorizacion maquinaria|certificado personal|jefe de obr).*?)"
     r"[\s.,-]*(?P<fecha>\d{1,2}-\d{1,3}-\d{2,4}|\d{2}-\d{4}|\d{6})?[\s.,]*" + D + E),
    ("doc_recibo_autonomo",
     r"^(?:Rec\.?\s*aut\w*\s*)?(?P<mes>\d{2})-(?P<anio>20\d{2})\s*(?:[Aa]ut\w*)?" + D + E),
    ("doc_correo_reenviado",
     r"^Correo de (?P<contraparte>[^-]+?)\s*-\s*Fwd_\s*(?P<concepto>.+?)" + D + E),
    ("doc_ticket_redsys",
     r"^Ticket de pago (?P<contraparte>Redsys)(?P<num>\d*)" + D + E),

    # ------------------------------------------------------------------
    # E. LOTES AGREGADOS (un PDF = muchas facturas) Y COMPRIMIDOS
    #    Marcar SIEMPRE como anomalia "requiere_despiece".
    # ------------------------------------------------------------------
    ("lote_taxonomia_tipo",
     r"^(?P<concepto>FACTURAS?|FRAS\.?|EMITIDAS|RECIBIDAS|INGRESOS|GASTOS)[\s.,_]*"
     r"(?P<tipo>RECIBIDAS|EMITIDAS|INGRESOS|GASTOS|CEMENTOS|SALTOKI|ALBEREDA)[\s.,_]*"
     r"(?P<trimestre>[1-4][Tt](?:\s*[1-4][Tt])?)?[\s.,]*(?P<anio>20\d{2})?\s*(?P<resto>[^.]*?)" + D + E),
    ("lote_taxonomia_periodo",
     r"^(?P<concepto>FACTURAS?|FRAS\.?|EMITIDAS|RECIBIDAS|INGRESOS|GASTOS)[\s.,_]*"
     r"(?P<tipo>[A-Za-z]+)?[\s.,]*(?:(?P<trimestre>[1-4][Tt](?:\s*[1-4][Tt])?)|(?P<anio>20\d{2})(?!\d))"
     r"[\s.,]*(?P<resto>[^.]*?)" + D + E),
    ("lote_taxonomia_desnudo",
     r"^(?P<concepto>FACTURAS?|FRAS\.?|EMITIDAS|RECIBIDAS|INGRESOS|GASTOS)\s*" + D + E),
    ("lote_proveedor_trimestre",
     r"^(?P<contraparte>[A-Za-z][A-Za-z ]+?)\s+(?P<trimestre>[1-4][Tt])\s*(?P<indice>\d{1,2})?\s*(?:\((?P<copia>\d+)\))?\.(?P<ext>pdf|PDF)$"),
    ("comprimido_trimestre",
     r"^(?P<trimestre>[1-4](?:[Tt\u00ba\u00b0oO]|er)?\s*(?:Trimestre)?)\s*(?P<anio>20\d{2})?\.(?P<ext>zip|rar)$"),
    ("comprimido_generico",
     r"^(?P<nombre>.+?)" + D + r"\.(?P<ext>zip|rar)$"),

    # ------------------------------------------------------------------
    # F. FECHAS SUELTAS COMO NOMBRE (tipico de "GASTOS" de Maxi)
    # ------------------------------------------------------------------
    ("fecha_dmY_larga",
     r"^(?P<dia>\d{1,2})-(?P<mes>\d{1,2})-(?P<anio>20\d{2})" + D + E),
    # OJO: orden de campos AMBIGUO, ver nota al final del fichero.
    ("fecha_triple_2d_ambigua",
     r"^(?P<a>\d{1,2})-(?P<b>\d{1,2})-(?P<c>\d{1,2})(?:[-._ ](?P<indice>\d{1,2}))?" + D + E),

    # ------------------------------------------------------------------
    # G. ESCANEOS Y FOTOS (fecha de captura, NO fecha de factura)
    # ------------------------------------------------------------------
    ("scan_adobe_fecha",
     r"^Adobe Scan (?P<dia>\d{1,2}) (?P<mes>[a-z\u00e1\u00e9\u00ed\u00f3\u00fa]{3,10}) (?P<anio>20\d{2})" + D + E),
    ("scan_escaneado_fechahora",
     r"^Escaneado_(?P<fecha>\d{8})-(?P<hora>\d{4})" + D + E),
    ("scan_pdfscanner",
     r"^PDF Scanner (?P<fecha>\d{2}-\d{2}-\d{2})(?:\s+(?P<hora>[\d.]+))?" + D + E),
    ("scan_img_fechahora",
     r"^IMG_?(?P<fecha>\d{8})_(?P<hora>\d{6,9})" + D + E),
    ("foto_whatsapp",
     r"^WhatsApp Image (?P<fecha>20\d{2}-\d{2}-\d{2}) at (?P<hora>[\d.]+)" + D + E),
    ("foto_photo_fechahora",
     r"^PHOTO-(?P<fecha>20\d{2}-\d{2}-\d{2})-(?P<hora>\d{2}-\d{2}-\d{2})" + D + E),
    ("scan_fecha_hora_puntos",
     r"^(?P<fecha>20\d{2}-\d{2}-\d{2}) (?P<hora>[\d.]+)" + D + E),
    ("scan_imagen_indice",
     r"^Imagen \((?P<indice>\d{1,3})\)" + D + E),

    # ------------------------------------------------------------------
    # H. GENERICOS (identifican el archivo, NO dan metadatos fiscales)
    # ------------------------------------------------------------------
    ("uuid_v4",
     r"^(?P<num>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})" + D + E),
    ("generico_document_indice",
     r"^(?:document|doc|invoice)\s*(?:\((?P<indice>\d+)\))?" + D + E),
    ("prov_contraparte_mes_texto",
     r"^(?P<contraparte>[A-Za-z\u00c1\u00c9\u00cd\u00d3\u00da\u00d1\u00e1\u00e9\u00ed\u00f3\u00fa\u00f1 .]+?)[ _](?P<mes>" + MES + r")" + D + E),
    ("prov_contraparte_factura_num",
     r"^(?P<contraparte>[A-Za-z\u00c1\u00c9\u00cd\u00d3\u00da\u00d1][^\d]*?)[\s-]+[Ff]actura\s+(?P<num>\d{6,12})" + D + E),
    ("prov_nombre_fecha_ddmmyy",
     r"^(?P<contraparte>\D+?) (?P<fecha>\d{6})(?:\s+(?P<resto>[\d.]+))?" + D + E),
    ("prov_nombre_mesanio",
     r"^(?P<contraparte>\D+?) (?P<mes>\d{2})(?P<anio>\d{2})" + D + E),
    ("factura_texto_num",
     r"^Facturas?[ _]?(?P<contraparte>[A-Za-z][A-Za-z .]*?)?\s*(?P<num>\d{1,7})?\s*(?:\((?P<copia>\d+)\))?" + D + E),
    ("prov_num_nombre",
     r"^(?P<num>\d{3,6})\s+(?P<contraparte>[A-Z\u00c1\u00c9\u00cd\u00d3\u00da\u00d1][^.]*?)" + D + E),
    ("prov_nombre_num",
     r"^(?P<contraparte>\D+?)[ _-]+(?P<num>\d{1,10})\s*(?P<resto>[^.]*?)" + D + E),
    ("numero_suelto",
     r"^(?P<num>\d{1,8})" + D + E),
    ("codigo_solo_letras",
     r"^(?-i:(?P<serie>[A-Z]{6,12}))" + D + E),
    ("nombre_libre_texto",
     r"^(?P<contraparte>[^\d]+?)" + D + E),

    # ------------------------------------------------------------------
    # I. CATCH-ALL. Nunca falla. Si algo llega aqui, es un nombre nuevo
    #    que hay que estudiar y anadir mas arriba.
    # ------------------------------------------------------------------
    ("sin_patron", r"^(?P<nombre>.*)$"),
]

# Compilacion unica. IGNORECASE porque el archivo real mezcla
# "Factura"/"factura"/"FACTURA" y ".pdf"/".PDF" sin criterio.
PATRONES_COMPILADOS = [(nombre, re.compile(rx, re.IGNORECASE))
                       for nombre, rx in PATRONES]


def clasificar(nombre_archivo):
    """Devuelve (nombre_patron, dict_metadatos). Nunca lanza ni devuelve None."""
    for nombre, rx in PATRONES_COMPILADOS:
        m = rx.match(nombre_archivo)
        if m:
            datos = {k: v for k, v in m.groupdict().items() if v}
            return nombre, datos
    return "sin_patron", {"nombre": nombre_archivo}


# ----------------------------------------------------------------------
# AVISO CRITICO SOBRE "fecha_triple_2d_ambigua" (97 archivos, 8,19 %)
# ----------------------------------------------------------------------
# El patron captura tres numeros a-b-c pero el ORDEN CAMBIA segun la
# carpeta. Verificado archivo a archivo contra el trimestre contenedor:
#
#   ./2024 Maxi/1T/GASTOS                 (13 arch.)  -> AA-DD-M
#                                          "24-13-1.pdf"  = 13/01/2024
#   ./2024 Maxi/{2T,3T,4T}/GASTOS         (38 arch.)  -> DD-M-AA
#                                          "11-5-24.pdf"  = 11/05/2024
#   ./2025 Maxi/2025 1T/1T 2025/GASTOS    (16 arch.)  -> DD-M-AA
#                                          "14-3-25.pdf"  = 14/03/2025
#   ./2025 Maxi/{2025 2T,2025 3T}/Gastos  (30 arch.)  -> AA-M-DD
#                                          "25-7-31.pdf"  = 31/07/2025
#
# NO deducir la fecha solo del nombre. Resolver con el trimestre de la
# carpeta contenedora y descartar la combinacion que caiga fuera de el.
ORDEN_FECHA_POR_CARPETA = {
    "2024 Maxi/1T": "AA-DD-M",
    "2024 Maxi/2T 2024": "DD-M-AA",
    "2024 Maxi/3T 2024": "DD-M-AA",
    "2024 Maxi/4T 2024": "DD-M-AA",
    "2025 Maxi/2025 1T": "DD-M-AA",
    "2025 Maxi/2025 2T": "AA-M-DD",
    "2025 Maxi/2025 3T": "AA-M-DD",
    "2025 Maxi/2025 4T": "DD-M-AAAA",  # ya lo cubre fecha_dmY_larga
}
