"""Normalizacion de la taxonomia caotica del archivo real a un modelo canonico.

Cada constante lleva al lado el ejemplo REAL de carpeta o archivo del que sale,
para que la gestoria pueda anadir casos sin tocar la logica.

ORDEN DE APLICACION (no alterar):
  1 normalizar cadena -> 2 colapsar anidamiento -> 3 cliente -> 4 ejercicio
  -> 5 tipo por carpeta -> 6 tipo por nombre -> 7 trimestre por FECHA
  -> 8 trimestre por carpeta -> 9 proveedor -> 10 excepciones
"""
from __future__ import annotations

import re
import unicodedata
from datetime import date

from config import CLIENTES, EJERCICIOS_VALIDOS, RAR_RAIZ
from modelo import TipoDoc

# ---------------------------------------------------------------- PASO 1
_ORDINALES = str.maketrans({"º": "", "°": "", "ª": ""})
_SEPARADORES = re.compile(r"[\s_+\-.,]+")


def clave(s: str) -> str:
    """Normaliza para COMPARAR. Nunca para escribir en disco.

    '2o Trimestre' -> '2 trimestre' ; 'Mias' -> 'mias'
    """
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.translate(_ORDINALES).casefold()
    return _SEPARADORES.sub(" ", s).strip()


def clave_pegada(s: str) -> str:
    """Clave sin espacios: captura 'facturasemitidas', 'recibidas2t'."""
    return clave(s).replace(" ", "")


# PASO 1b -- sufijos de descarga: 'facturasemitidas (1)' -> 'facturasemitidas'
SUFIJO_DESCARGA = re.compile(r"\s*\(\d{1,2}\)(?=\.[^.]+$|$)")


def limpiar_sufijo(nombre: str) -> str:
    return SUFIJO_DESCARGA.sub("", nombre)


# ---------------------------------------------------------------- PASO 3
NIVEL1 = re.compile(r"^(?P<anio>20\d{2})\s+(?P<cliente>alfonso|maxi|urbano)$")


def detectar_cliente(partes: list[str]) -> str | None:
    """El cliente sale SIEMPRE del primer segmento. Unico campo 100% fiable."""
    if not partes:
        return None
    m = NIVEL1.match(clave(partes[0]))
    if m:
        return CLIENTES[m.group("cliente")]["nombre"]
    return None


# ---------------------------------------------------------------- PASO 4
ANIO4 = re.compile(r"(?<!\d)(20\d{2})(?!\d)")


def detectar_ejercicio(partes: list[str]) -> int | None:
    for p in partes:
        m = ANIO4.search(clave(p))
        if m:
            a = int(m.group(1))
            if a in EJERCICIOS_VALIDOS:
                return a
    return None


# ---------------------------------------------------------------- PASO 5
# Sinonimos REALES encontrados en el archivo. Se comparan sobre clave_pegada.
SINONIMOS_EMITIDA = (
    "emitidas",          # "EMITIDAS 1T 21"
    "realizadas",        # "2022 Alfonso/1er trimestre/Realizadas"
    "mias",              # "2022 Alfonso/3er Trimestre/Mias"
    "ingresos",          # "2024 Maxi/1T/INGRESOS" y "Ingresos"
    "facturasemitidas",  # "2025 Urbano/2025 2T/facturasemitidas"
)
SINONIMOS_RECIBIDA = (
    "recibidas",    # "Recibidas 1t 2021", "Recibidas2t 21"
    "melashacen",   # "2022 Alfonso/1er trimestre/ME las hacen"
    "gastos",       # "GASTOS" y "Gastos"
)

# TRAMPA LEXICA: "Facturas Enero 25" NO son emitidas. Son lotes de RECIBIDAS
# escaneadas (verificado: febrero 0/11 y marzo 0/21 emitidas).
FACTURAS_MES = re.compile(r"^facturas(?P<mes>[a-z]+)\d{0,4}$")

MESES = {"enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5,
         "junio": 6, "julio": 7, "agosto": 8, "septiembre": 9,
         "setiembre": 9, "octubre": 10, "noviembre": 11, "diciembre": 12}


def detectar_tipo_por_carpeta(partes: list[str]) -> tuple[str | None, int | None]:
    """Devuelve (tipo, mes_carpeta). La carpeta MANDA sobre el nombre."""
    for p in reversed(partes):
        k = clave_pegada(p)
        if k == "aenviar":  # "2021 Alfonso/A ENVIAR"
            return TipoDoc.RECOPILATORIO.value, None
        m = FACTURAS_MES.match(k)
        if m and m.group("mes") in MESES:
            return TipoDoc.RECIBIDA.value, MESES[m.group("mes")]
        for s in SINONIMOS_EMITIDA:
            if k.startswith(s):
                return TipoDoc.EMITIDA.value, None
        for s in SINONIMOS_RECIBIDA:
            if k.startswith(s):
                return TipoDoc.RECIBIDA.value, None
    return None, None


# ---------------------------------------------------------------- PASO 6
# Series propias POR CLIENTE. Nunca globales: 'Factura 3-000624.pdf' en Urbano
# es una RECIBIDA, no una emitida (la serie de Urbano es '2025-NNN').
SERIES_EMITIDA = {
    # '000' obligatorio: 'Factura-1-240481' es de un proveedor de Maxi.
    # Ojo: 'Factura 1-000367' (2022) tambien casa y NO es de Alfonso (su
    # numeracion de 2022 va del 1 al 87); ahi manda la carpeta de recibidas.
    "Alfonso": re.compile(r"^factura 1 000\d{3}"),
    "Maxi": re.compile(r"^r?\d{3} 20\d{2} "),
    "Urbano": re.compile(r"^factura 20\d{2} \d{3}"),
}


def detectar_tipo_por_nombre(nombre: str, cliente: str | None) -> str | None:
    if not cliente:
        return None
    rx = SERIES_EMITIDA.get(cliente)
    if rx and rx.match(clave(nombre)):
        return TipoDoc.EMITIDA.value
    return None


# NIF de cada cliente, para identificarlo cuando no hay carpeta (buzon).
_NIF_CLIENTE = {v["nif"]: v["nombre"] for v in CLIENTES.values() if v["nif"]}


def detectar_cliente_por_nombre(nombre: str) -> tuple[str | None, str]:
    """Deduce el cliente SOLO del nombre. Imprescindible para el buzon, donde
    el archivo llega suelto y no hay carpeta de la que tirar.

    Devuelve (cliente, origen).
    """
    k = clave(nombre)
    for cli, rx in SERIES_EMITIDA.items():
        if rx.match(k):
            return cli, "serie_propia"
    for nif, cli in _NIF_CLIENTE.items():
        if nif and nif.lower() in k.replace(" ", ""):
            return cli, "nif_en_el_nombre"
    return None, ""


# ---------------------------------------------------------------- PASO 7
# Fechas del nombre, por fiabilidad decreciente.
FECHA_PAREN = re.compile(r"\((?P<d>\d{1,2})-(?P<m>\d{1,2})-(?P<a>\d{2})\)")
FECHA_ISO = re.compile(
    r"(?<!\d)(?P<a>20\d{2})[-_]?(?P<m>0[1-9]|1[0-2])[-_]?"
    r"(?P<d>0[1-9]|[12]\d|3[01])(?!\d)")
FECHA_DMY = re.compile(r"(?<!\d)(?P<d>\d{1,2})-(?P<m>\d{1,2})-(?P<a>20\d{2})(?!\d)")
MES_ANIO = re.compile(r"(?<!\d)(?P<m>0[1-9]|1[0-2])-(?P<a>\d{2})(?!\d)")

# La fecha de estos NO es la de devengo: es de escaneo, descarga o envio.
PREFIJOS_FECHA_NO_DOCUMENTAL = (
    "adobe scan", "escaneado", "whatsapp image", "img ", "photo ", "download ",
)


def _fecha(a: int, m: int, d: int) -> date | None:
    if a < 100:
        a += 2000
    if a not in EJERCICIOS_VALIDOS or not (1 <= m <= 12) or not (1 <= d <= 31):
        return None
    try:
        return date(a, m, d)
    except ValueError:
        return None


def extraer_fecha(nombre: str) -> tuple[date | None, bool]:
    """Devuelve (fecha, es_documental). es_documental=False si es de captura."""
    k = clave(nombre)
    documental = not any(k.startswith(p.strip())
                         for p in PREFIJOS_FECHA_NO_DOCUMENTAL)
    for rx in (FECHA_PAREN, FECHA_ISO, FECHA_DMY):
        m = rx.search(nombre)
        if m:
            f = _fecha(int(m.group("a")), int(m.group("m")), int(m.group("d")))
            if f:
                return f, documental
    m = MES_ANIO.search(nombre)
    if m:
        f = _fecha(int(m.group("a")), int(m.group("m")), 1)
        if f:
            return f, documental
    return None, documental


def trimestre_de(f: date) -> str:
    return f"{(f.month - 1) // 3 + 1}T"


# ---------------------------------------------------------------- PASO 8
# Un solo regex para TODOS los formatos reales de trimestre.
# El lookbehind evita que '2025 1T' capture el '5' de '2025'.
TRIMESTRE = re.compile(
    r"(?<![0-9])(?P<n>[1-4])\s*(?:t(?![a-z])|er trimestre|o trimestre|"
    r"do trimestre|trimestre)")


def detectar_trimestre_por_carpeta(partes: list[str]) -> str | None:
    for p in reversed(partes):
        k = ANIO4.sub(" ", clave(p))  # quitar el ano antes de buscar
        m = TRIMESTRE.search(k)
        if m:
            return f"{m.group('n')}T"
    return None


# ---------------------------------------------------------------- PASO 2
def tokens_periodo(nombre: str) -> tuple[int | None, str | None]:
    k = clave(nombre)
    ma = ANIO4.search(k)
    anio = int(ma.group(1)) if ma and int(ma.group(1)) in EJERCICIOS_VALIDOS else None
    mt = TRIMESTRE.search(ANIO4.sub(" ", k))
    tri = f"{mt.group('n')}T" if mt else None
    return anio, tri


def colapsar_anidamiento(partes: list[str]) -> tuple[list[str], bool]:
    """Colapsa '4T 2024/4T 2024' y '2025 1T/1T 2025' (tokens invertidos).

    Compara por TUPLA (ejercicio, trimestre), no por igualdad literal.
    """
    out: list[str] = []
    colapsado = False
    for p in partes:
        if (out and tokens_periodo(p) == tokens_periodo(out[-1])
                and tokens_periodo(p) != (None, None)):
            colapsado = True
            continue  # el hijo es redundante: no consume nivel
        out.append(p)
    return out, colapsado


# ---------------------------------------------------------------- PASO 9
PROVEEDORES = {"avatel": "AVATEL", "beedigital": "BEEDIGITAL", "yoigo": "YOIGO"}
PORTAL_ORANGE = re.compile(r"^facturas (?P<prov>[a-z]+) (?P<nif>[0-9a-z]{9}) ")
PORTAL_GOOGLE = re.compile(r"^google payments document center download")


def detectar_proveedor(partes: list[str]) -> str | None:
    for p in reversed(partes):
        k = clave(p)
        kp = clave_pegada(p)
        if kp in PROVEEDORES:
            return PROVEEDORES[kp]
        m = PORTAL_ORANGE.match(k)
        if m:
            return m.group("prov").upper()
        if PORTAL_GOOGLE.match(k):
            return "GOOGLE"
    return None


# ---------------------------------------------------------------- PASO 10
RAMA_PRL = ("nalanda",)
SUBTIPOS_PRL = (
    ("acreditacion subcontrata", "acreditacion"),
    ("cert al corriente", "certificado_corriente_pago"),
    ("poliza", "poliza_seguro"),
    ("compromiso", "prl"),
    ("entrega y adhesion", "prl"),
    ("plan de seguridad", "prl"),
    ("informe datos de cotizacion", "seguridad_social"),
)
# Tolera la errata real 'Rec. autononom 03-2025.pdf'
REC_AUTONOMO = re.compile(r"^rec ?auton[o]?n?om")


def es_rama_prl(partes: list[str]) -> bool:
    return any(clave_pegada(p) in RAMA_PRL for p in partes)


def subtipo_prl(nombre: str) -> str | None:
    k = clave(nombre)
    if REC_AUTONOMO.match(k):
        return "recibo_autonomo"
    for aguja, sub in SUBTIPOS_PRL:
        if aguja in k:
            return sub
    return None


# ---------------------------------------------------------------- ORQUESTADOR
def clasificar_ruta(ruta_relativa: str, nombre: str) -> dict:
    """Aplica los 10 pasos y devuelve el diccionario de clasificacion."""
    partes_raw = [p for p in ruta_relativa.replace("\\", "/").split("/") if p][:-1]
    partes, colapsado = colapsar_anidamiento(partes_raw)

    r: dict = {"incidencias": [], "confianza": 0.0}
    if colapsado:
        r["incidencias"].append("anidamiento_duplicado_colapsado")

    # 3 y 4
    r["cliente"] = detectar_cliente(partes)
    r["ejercicio"] = detectar_ejercicio(partes)

    # 3c - sin carpeta (buzon de entrada): el cliente sale del propio nombre.
    if not r["cliente"]:
        cli, origen = detectar_cliente_por_nombre(nombre)
        if cli:
            r["cliente"] = cli
            r["incidencias"].append(f"cliente_deducido_del_nombre: {origen}")

    # 3b - comprimidos sueltos en la raiz, ya resueltos por cabecera RAR5.
    if not partes and nombre in RAR_RAIZ:
        cli, eje, tri = RAR_RAIZ[nombre]
        r.update({"cliente": cli, "ejercicio": eje, "trimestre": tri,
                  "tipo_doc": TipoDoc.COMPRIMIDO.value,
                  "origen_tipo": "extension", "origen_trimestre": "tabla",
                  "confianza": 1.0, "computa_en_libro_iva": False})
        r["incidencias"].append("rar_raiz_ya_extraido_en_carpeta_del_trimestre")
        return r

    ext = nombre.rsplit(".", 1)[-1].lower() if "." in nombre else ""
    k_nombre = clave(nombre)

    # 10 - ramas especiales que ganan a todo
    if ext in ("rar", "zip"):
        r["tipo_doc"] = TipoDoc.COMPRIMIDO.value
        r["origen_tipo"] = "extension"
    elif ext in ("xlsx", "xls") and ("emitidas" in k_nombre or "recibidas" in k_nombre):
        r["tipo_doc"] = TipoDoc.LIBRO_REGISTRO.value
        r["origen_tipo"] = "extension"
    elif k_nombre.startswith("correo de albereda36"):
        r["tipo_doc"] = TipoDoc.CORREO.value
        r["origen_tipo"] = "nombre"
    elif "factproform" in k_nombre or "proforma" in k_nombre:
        r["tipo_doc"] = TipoDoc.PROFORMA.value
        r["origen_tipo"] = "nombre"
    elif es_rama_prl(partes):
        r["tipo_doc"] = TipoDoc.PRL.value
        r["origen_tipo"] = "rama"
        r["subtipo"] = subtipo_prl(nombre)
        # Nivel 4 aqui es OBRA, no proveedor.
        if len(partes) >= 3:
            r["obra"] = partes[2]
    else:
        # 5 -> 6
        tipo, mes = detectar_tipo_por_carpeta(partes)
        r["mes_carpeta_origen"] = mes
        # La serie propia del cliente gana a la trampa "Facturas <mes>".
        # Real: '2025 Urbano/2025 1T/Facturas Enero 25/Factura 2025-036 (01-02-25).pdf'
        # la EMITE Urbano (su NIF como emisor, "CLIENTE: Combitec"), aunque la
        # carpeta sugiera recibidas. Verificado en el PDF: 10 casos (036 a 045).
        if (tipo == TipoDoc.RECIBIDA.value and mes is not None
                and detectar_tipo_por_nombre(nombre, r["cliente"]) == TipoDoc.EMITIDA.value):
            tipo = TipoDoc.EMITIDA.value
            r["incidencias"].append("serie_propia_en_carpeta_de_recibidas")
        if tipo:
            r["tipo_doc"] = tipo
            r["origen_tipo"] = "carpeta"
            r["confianza"] += 0.5
        else:
            tipo = detectar_tipo_por_nombre(nombre, r["cliente"])
            if tipo:
                r["tipo_doc"] = tipo
                r["origen_tipo"] = "nombre"
                r["confianza"] += 0.3
            else:
                r["tipo_doc"] = TipoDoc.DESCONOCIDO.value

    # 7 -> 8 : trimestre. La FECHA gana siempre.
    f, documental = extraer_fecha(nombre)
    tri_carpeta = detectar_trimestre_por_carpeta(partes)

    # 10b - La documentacion de PRL es de VIGENCIA, no de devengo: no se le
    # fuerza trimestre ni se le deja pisar el ejercicio de la carpeta.
    # Real: 'NALANDA/NORUEGA/1331673201_pobr5656899_20231127.pdf' es de 2023
    # pero pertenece al expediente 2025 de Urbano.
    if r["tipo_doc"] == TipoDoc.PRL.value:
        if f:
            r["fecha_documento"] = f.isoformat()
        r["trimestre"] = None
        r["origen_trimestre"] = None
        r["computa_en_libro_iva"] = False
        r["confianza"] = round(min(1.0, r["confianza"] + 0.5), 2)
        return r

    if f and documental:
        r["fecha_documento"] = f.isoformat()
        r["trimestre"] = trimestre_de(f)
        r["origen_trimestre"] = "fecha"
        r["confianza"] += 0.5
        # Sin carpeta (buzon), el ejercicio tambien sale de la fecha.
        if not r["ejercicio"]:
            r["ejercicio"] = f.year
        elif r["ejercicio"] and f.year != r["ejercicio"]:
            r["incidencias"].append(
                "ejercicio_discrepante: carpeta=%s fecha=%s" % (r["ejercicio"], f.year))
            r["ejercicio"] = f.year
        if tri_carpeta and tri_carpeta != r["trimestre"]:
            r["incidencias"].append(
                "trimestre_discrepante: carpeta=%s fecha=%s"
                % (tri_carpeta, r["trimestre"]))
    else:
        if f and not documental:
            r["fecha_captura"] = f.isoformat()
            r["incidencias"].append("fecha_del_nombre_es_de_captura_no_de_devengo")
        r["trimestre"] = tri_carpeta
        r["origen_trimestre"] = "carpeta" if tri_carpeta else None
        if tri_carpeta:
            r["confianza"] += 0.25

    # 6b - CARPETA DE TRIMESTRE PLANA (caso Urbano: sus carpetas no separan
    # emitidas de recibidas). Si estamos dentro de un trimestre identificado
    # y el nombre NO casa la serie propia del cliente, es una RECIBIDA: las
    # facturas del cliente siguen su serie, lo demas son de proveedor.
    # Confianza baja e incidencia, para que quede auditable.
    if r["tipo_doc"] == TipoDoc.DESCONOCIDO.value and r.get("trimestre") \
            and r.get("cliente"):
        r["tipo_doc"] = TipoDoc.RECIBIDA.value
        r["origen_tipo"] = "inferido_carpeta_plana"
        r["confianza"] += 0.15
        r["incidencias"].append("tipo_inferido: carpeta plana sin emitidas/recibidas")

    # 9
    r["proveedor"] = detectar_proveedor(partes)

    # 13 - fallback: no inventar nada
    sin_datos = (r["tipo_doc"] == TipoDoc.DESCONOCIDO.value or not r.get("trimestre"))
    exentos = (TipoDoc.PRL.value, TipoDoc.RECOPILATORIO.value,
               TipoDoc.LIBRO_REGISTRO.value, TipoDoc.COMPRIMIDO.value,
               TipoDoc.CORREO.value)
    if sin_datos and r["tipo_doc"] not in exentos:
        r["revision_manual"] = True
        r["incidencias"].append("sin_trimestre_o_sin_tipo")

    r["computa_en_libro_iva"] = (
        r["tipo_doc"] in (TipoDoc.EMITIDA.value, TipoDoc.RECIBIDA.value)
        and bool(r.get("trimestre")))
    r["confianza"] = round(min(1.0, r["confianza"]), 2)
    return r
