"""Carga del inventario en la app "Gestion de fichas" (http://localhost:4360).

Solo urllib.request de la stdlib. NO requests.

Decisiones de mapeo (justificadas en el contrato real de server.js):

 * 3 SUJETOS, no 6. Un sujeto por CLIENTE (Alfonso, Maxi, Urbano), no por
   cliente-ano: 'sujetos' es la unica coleccion con 'nif' (server.js:148) y ese
   nif es la clave de emparejamiento de /api/sincronizar (server.js:262). Con
   NIF repetidos, el .find() emparejaria con el primero: error silencioso.
 * EL EJERCICIO NO ES UNA ENTIDAD: va como campo extra. coerceRecord es
   ADITIVO, no lista blanca (server.js:136 hace {...base, ...data}), asi que
   los campos extra sobreviven y ademas quedan consultables con el filtro
   generico (server.js:391):  GET /api/documentos?ejercicio=2025&trimestre=4T
 * grupos.campos DEBE declarar toda clave que escribamos en sujetos.datos.
   El formulario del frontend se construye solo con grupo.campos (app.js:301) y
   reconstruye 'datos' unicamente con lo renderizado (app.js:319): una clave no
   declarada SE BORRA la primera vez que alguien edite el sujeto a mano.
 * ruta = None y la ruta real en 'rutaOrigen'. Una ruta inventada haria que el
   borrado en cascada intentase fs.unlinkSync sobre ella (server.js:197).
 * origen = 'archivo-albereda36', nunca 'servidor-local': la deduplicacion de
   /api/sincronizar solo mira origen === 'servidor-local' (server.js:270), asi
   que nunca pisara lo que cargue el pipeline.
 * IMPORTES A CERO y declarados como tales. Ojo al falso amigo: enviar total: 0
   NO fija 0, recalcula desde base e iva, porque server.js:162 usa
   `Number(rec.total) || ...` y 0 es falsy.
 * SECUENCIAL, nunca concurrente: cada escritura reserializa la base entera con
   writeFileSync + renameSync (server.js:72-77).
"""
from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from config import API_BASE, CARPETA_TRABAJO, CLIENTES
from modelo import Inventario, Documento

# base64 infla 4/3 y el tope de readBody son 50 MB (server.js:101).
# Al superarlo el servidor hace req.destroy(): no llega un 413, llega un corte.
MAX_BYTES_SUBIDA = 35 * 1024 * 1024

# documentos.tipo se pinta en la tabla (app.js:412): se aprovecha para que el
# sentido sea visible sin tocar el frontend.
TIPO_APP = {
    "emitida": "factura-emitida",
    "recibida": "factura-recibida",
    "prl": "prl-subcontrata",
    "libro_registro": "resumen-contable",
    "recopilatorio": "resumen-contable",
    "comprimido": "comprimido",
    "correo": "correo",
    "proforma": "proforma",
    "desconocido": "escaneo-sin-clasificar",
    "otro": "escaneo-sin-clasificar",
}
SENTIDO = {"emitida": "emitida", "recibida": "recibida"}

# Claves que escribimos en sujetos.datos. DEBEN declararse en grupos.campos.
CAMPOS_GRUPO = [
    {"key": "ejercicios", "label": "Ejercicios en archivo", "type": "text"},
    {"key": "facturasEmitidas", "label": "Nº facturas emitidas", "type": "text"},
    {"key": "facturasRecibidas", "label": "Nº facturas recibidas", "type": "text"},
    {"key": "documentos", "label": "Documentos en archivo", "type": "text"},
    {"key": "origenArchivo", "label": "Carpeta de origen", "type": "text"},
]
GRUPO_PIPELINE = "Autónomos trimestrales"

PRIMER_DIA = {"1T": "01-01", "2T": "04-01", "3T": "07-01", "4T": "10-01"}


# ---------------------------------------------------------------- transporte
class ErrorApp(RuntimeError):
    pass


class ErrorEscrituraDudosa(ErrorApp):
    """Un POST fallo al persistir, pero puede haberse aplicado en memoria.

    server.js:401-402 hace DB[col].push(rec) ANTES del saveDB, asi que si el
    saveDB revienta con EPERM el registro YA esta en memoria y se guardara con
    la siguiente escritura que si funcione. Reintentar el POST a ciegas crea un
    duplicado: hay que volver a consultar antes de decidir.
    """


def _peticion(base: str, ruta: str, metodo: str = "GET",
              cuerpo: dict | None = None, reintentos: int = 3):
    """Peticion JSON con reintentos. Los errores de la app salen como 500."""
    url = base.rstrip("/") + ruta
    datos = None
    cabeceras = {"Accept": "application/json"}
    if cuerpo is not None:
        # Nunca enviar b'': un cuerpo vacio se resuelve como {} y crea
        # un registro basura (server.js:105).
        datos = json.dumps(cuerpo, ensure_ascii=False).encode("utf-8")
        cabeceras["Content-Type"] = "application/json"

    ultimo = None
    for intento in range(reintentos):
        req = urllib.request.Request(url, data=datos, headers=cabeceras,
                                     method=metodo)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                crudo = r.read().decode("utf-8")
                return json.loads(crudo) if crudo else {}
        except urllib.error.HTTPError as e:
            try:
                detalle = json.loads(e.read().decode("utf-8")).get("error", "")
            except Exception:
                detalle = ""
            # En Windows, saveDB (writeFileSync + renameSync, server.js:72-77)
            # falla de forma intermitente con EPERM/EBUSY cuando el antivirus o
            # el indexador tienen abierto db.json.tmp.
            transitorio = any(x in detalle for x in ("EPERM", "EBUSY", "EEXIST"))
            if transitorio and metodo == "POST":
                raise ErrorEscrituraDudosa(
                    f"POST {ruta} -> HTTP {e.code} {detalle}") from e
            if transitorio and intento < reintentos - 1:
                time.sleep(0.3 * (2 ** intento))
                continue
            raise ErrorApp(f"{metodo} {ruta} -> HTTP {e.code} {detalle}") from e
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            # ConnectionRefused = la app no esta levantada: no hay nada escrito,
            # es seguro reintentar (y acabar avisando de que arranque el server).
            rechazada = isinstance(e, ConnectionRefusedError) or isinstance(
                getattr(e, "reason", None), ConnectionRefusedError)
            # REGLA ABSOLUTA: un POST NO se reintenta a ciegas jamas. El
            # servidor mete el registro en memoria antes de persistir
            # (server.js:401), asi que un timeout o un socket cortado despues
            # de que lo aceptara dejaria el registro dentro; reintentar crearia
            # un fantasma. Quien llama debe volver a consultar.
            if metodo == "POST" and not rechazada:
                raise ErrorEscrituraDudosa(
                    f"POST {ruta} -> fallo de transporte: {e}") from e
            ultimo = e
            if intento < reintentos - 1:
                time.sleep(0.5 * (2 ** intento))
    raise ErrorApp(
        f"No se puede conectar con {base}.\n"
        f"  Arranca primero la app:  node server.js  (en gestion-fichas/)\n"
        f"  Detalle: {ultimo}")


# ---------------------------------------------------------------- estado
def _ruta_estado() -> Path:
    return CARPETA_TRABAJO / "carga_app.json"


def _cargar_estado() -> dict:
    p = _ruta_estado()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"sujetos": {}, "documentos": {}, "facturas": {}, "grupo": None}


def _guardar_estado(estado: dict) -> None:
    _ruta_estado().parent.mkdir(parents=True, exist_ok=True)
    _ruta_estado().write_text(json.dumps(estado, indent=2, ensure_ascii=False),
                              encoding="utf-8")


# ---------------------------------------------------------------- pasos
def comprobar_api(base: str = API_BASE) -> dict:
    """GET /api/stats. Tambien fuerza la siembra de db.json."""
    return _peticion(base, "/api/stats")


def sincronizar_grupo(base: str, simular: bool, estado: dict) -> str | None:
    """Crea o reutiliza el grupo, DECLARANDO los campos personalizados.

    Sin esta declaracion, el frontend borraria sujetos.datos al primer editado.
    """
    cuerpo = {"nombre": GRUPO_PIPELINE,
              "descripcion": "Clientes cargados desde el archivo Albereda36",
              "campos": CAMPOS_GRUPO}
    if simular:
        # La simulacion no toca la red: debe poder correrse con la app apagada.
        print(f"  [SIM] POST/PUT grupo '{GRUPO_PIPELINE}' con "
              f"{len(CAMPOS_GRUPO)} campos declarados")
        return None
    grupos = _peticion(base, "/api/grupos")
    existente = next((g for g in grupos if g.get("nombre") == GRUPO_PIPELINE), None)
    if existente:
        r = _peticion(base, f"/api/grupos/{existente['id']}", "PUT",
                      {**existente, **cuerpo})
    else:
        r = _peticion(base, "/api/grupos", "POST", cuerpo)
    estado["grupo"] = r["id"]
    return r["id"]


def _resumen_cliente(inv: Inventario, cliente: str) -> dict:
    docs = [d for d in inv.documentos if d.cliente == cliente and not d.duplicado_de]
    ejercicios = sorted({d.ejercicio for d in docs if d.ejercicio})
    return {
        "ejercicios": ", ".join(str(e) for e in ejercicios),
        "facturasEmitidas": str(sum(1 for d in docs if d.tipo_doc == "emitida")),
        "facturasRecibidas": str(sum(1 for d in docs if d.tipo_doc == "recibida")),
        "documentos": str(len(docs)),
        "origenArchivo": f"Albereda36 / *{cliente}",
    }


def sincronizar_sujetos(base: str, inv: Inventario, grupo_id: str | None,
                        simular: bool, estado: dict) -> dict:
    """Exactamente 3 sujetos, uno por cliente. Idempotente por NIF/nombre."""
    existentes = [] if simular else _peticion(base, "/api/sujetos")
    mapa: dict[str, str] = {}
    for datos_cli in CLIENTES.values():
        nombre = datos_cli["nombre"]
        if not any(d.cliente == nombre for d in inv.documentos):
            continue
        cuerpo = {
            "grupoId": grupo_id,
            "nombre": datos_cli["razon_social"] or nombre,
            # NIF en mayusculas y sin separadores: la comparacion de
            # server.js:262 es exacta en minusculas.
            "nif": (datos_cli["nif"] or "").upper().replace("-", "").replace(" ", ""),
            "notas": f"Cliente del archivo Albereda36 (carpetas '* {nombre}').",
            "datos": _resumen_cliente(inv, nombre),
            "aliasArchivo": nombre,          # campo extra, sobrevive
        }
        previo = next((s for s in existentes
                       if s.get("aliasArchivo") == nombre
                       or (cuerpo["nif"] and s.get("nif") == cuerpo["nif"])), None)
        if simular:
            print(f"  [SIM] {'PUT' if previo else 'POST'} sujeto {nombre}")
            continue
        if previo:
            r = _peticion(base, f"/api/sujetos/{previo['id']}", "PUT",
                          {**previo, **cuerpo})
        else:
            r = _peticion(base, "/api/sujetos", "POST", cuerpo)
        mapa[nombre] = r["id"]
    estado["sujetos"].update(mapa)
    return mapa


def _cuerpo_documento(d: Documento, sujeto_id: str | None, raiz: Path) -> dict:
    return {
        "sujetoId": sujeto_id,
        "nombre": d.nombre,
        "tipo": TIPO_APP.get(d.tipo_doc, "escaneo-sin-clasificar"),
        "origen": "archivo-albereda36",   # nunca 'servidor-local'
        "tamano": d.tamano,
        "ruta": None,                     # el binario NO se copia aqui
        # --- campos extra: persisten por el spread y son consultables ---
        # Sin "rutaOrigen": la app abre por ruta relativa, y la absoluta
        # delataba la carpeta personal del equipo donde se cargo.
        "rutaRelativa": d.ruta_relativa,
        "cliente": d.cliente,
        "ejercicio": d.ejercicio,
        "trimestre": d.trimestre,
        "sentido": SENTIDO.get(d.tipo_doc, "no-factura"),
        "extension": d.extension,
        "sha256": d.sha256,
        "contraparte": d.contraparte,
        "proveedor": d.proveedor,
        "numeroDetectado": d.numero,
        "fechaDocumento": d.fecha_documento,
        "confianza": d.confianza,
        "duplicadoDe": d.duplicado_de,
        "revisionManual": d.revision_manual,
        "incidencias": " | ".join(d.incidencias),
    }


def sincronizar_documentos(base: str, inv: Inventario, raiz: Path,
                           sujetos: dict, simular: bool, estado: dict) -> dict:
    """Un documento por archivo. Idempotente consultando por sha256."""
    docs = inv.documentos
    res = {"creados": 0, "actualizados": 0, "omitidos": 0, "errores": 0,
           "respetados": 0}
    # Lo que ya hay en la app, de una sola vez (y no una consulta por fichero).
    existentes = {} if simular else {
        x.get("rutaRelativa"): x for x in _peticion(base, "/api/documentos")
        if x.get("rutaRelativa")}

    for i, d in enumerate(docs, 1):
        if simular:
            res["creados"] += 1
            if i <= 3:
                print(f"  [SIM] POST documento {d.nombre} "
                      f"({d.cliente} {d.ejercicio} {d.trimestre})")
            continue

        cuerpo = _cuerpo_documento(d, sujetos.get(d.cliente or ""), raiz)
        try:
            # Idempotencia: el filtro generico permite buscar por campo extra.
            # La identidad es la RUTA, no el sha256: los 31 duplicados por
            # contenido comparten hash y se pisarian unos a otros, perdiendo
            # 31 registros. El sha256 se guarda como dato, no como clave.
            previo = existentes.get(d.ruta_relativa)
            previo_id = previo["id"] if previo else None
            if previo and previo.get("revisado"):
                # Alguien lo corrigio a mano en "Revisar": no se toca.
                estado["documentos"][d.ruta_relativa] = previo_id
                res["respetados"] += 1
            elif previo_id:
                # Los avisos que pone la app al leer los PDF no los genera el
                # pipeline: se conservan en vez de borrarse.
                propios = [p for p in str(previo.get("incidencias") or "").split("; ")
                           if p.split(":")[0] in ("trimestre_discrepante_pdf",
                                                  "sentido_dudoso", "no_es_factura")]
                if propios:
                    cuerpo = {**cuerpo, "incidencias": "; ".join(
                        [x for x in [cuerpo["incidencias"], *propios] if x])}
                _peticion(base, f"/api/documentos/{previo_id}", "PUT", cuerpo)
                estado["documentos"][d.ruta_relativa] = previo_id
                res["actualizados"] += 1
            else:
                try:
                    r = _peticion(base, "/api/documentos", "POST", cuerpo)
                    nuevo_id = r["id"]
                except ErrorEscrituraDudosa:
                    # Comprobar si el registro llego a entrar en memoria.
                    q = urllib.parse.urlencode({"rutaRelativa": d.ruta_relativa})
                    hallados = _peticion(base, f"/api/documentos?{q}")
                    if not hallados:
                        raise
                    nuevo_id = hallados[0]["id"]
                estado["documentos"][d.ruta_relativa] = nuevo_id
                res["creados"] += 1
        except ErrorApp as e:
            res["errores"] += 1
            print(f"  ERROR {d.ruta_relativa}: {e}", file=sys.stderr)

        if i % 100 == 0:
            print(f"  ... {i}/{len(docs)} documentos", file=sys.stderr)
            _guardar_estado(estado)   # checkpoint: 1185 escrituras son largas
    return res


def _fecha_factura(d: Documento) -> tuple[str, bool]:
    """Fecha SIEMPRE explicita: omitirla sellaria todo con la fecha de carga."""
    if d.fecha_documento:
        return d.fecha_documento, False
    if d.ejercicio and d.trimestre in PRIMER_DIA:
        return f"{d.ejercicio}-{PRIMER_DIA[d.trimestre]}", True
    return "1970-01-01", True


def es_facturable(d: Documento) -> bool:
    """Solo genera factura lo que tiene numero fiable y computa en el libro."""
    return bool(d.computa_en_libro_iva and d.numero and not d.duplicado_de
                and d.tipo_doc in ("emitida", "recibida")
                and d.extension in ("pdf", "jpg", "jpeg", "xsig"))


def sincronizar_facturas(base: str, inv: Inventario, sujetos: dict,
                         simular: bool, estado: dict) -> dict:
    """Factura solo cuando el nombre da un numero fiable. Importes a 0."""
    candidatos = [d for d in inv.documentos if es_facturable(d)]
    res = {"creados": 0, "actualizados": 0, "errores": 0, "respetadas": 0,
           "sin_numero_fiable": len(inv.facturas()) - len(candidatos)}
    facturas_app = {} if simular else {
        x.get("rutaRelativa"): x for x in _peticion(base, "/api/facturas")
        if x.get("rutaRelativa")}
    revisados = set() if simular else {
        x.get("rutaRelativa") for x in _peticion(base, "/api/documentos")
        if x.get("revisado")}

    for i, d in enumerate(candidatos, 1):
        fecha, estimada = _fecha_factura(d)
        concepto = (f"{d.tipo_doc.capitalize()} {d.trimestre} {d.ejercicio}"
                    + (f" · {d.contraparte}" if d.contraparte else ""))
        cuerpo = {
            "sujetoId": sujetos.get(d.cliente or ""),
            "numero": str(d.numero),
            "fecha": fecha,
            "concepto": concepto[:120],
            "base": 0, "iva": 21,     # total se recalcula: 0 es falsy
            "estado": "pendiente",    # enum de cobro, NO de sentido
            # --- extra ---
            "sentido": d.tipo_doc,
            "ejercicio": d.ejercicio,
            "trimestre": d.trimestre,
            "documentoId": estado["documentos"].get(d.ruta_relativa),
            "rutaRelativa": d.ruta_relativa,
            "contraparte": d.contraparte,
            "importePendienteExtraccion": True,
            "fechaEstimada": estimada,
        }
        if simular:
            res["creados"] += 1
            if i <= 3:
                print(f"  [SIM] POST factura {d.numero} ({fecha}) {concepto}")
            continue
        try:
            # La identidad es la ruta; sin esto, perder el fichero de estado
            # duplicaria las 714 facturas.
            previo = facturas_app.get(d.ruta_relativa)
            previo_id = previo["id"] if previo else None
            if previo_id and d.ruta_relativa in revisados:
                res["respetadas"] += 1
            elif previo_id:
                # Al actualizar NUNCA se mandan importes ni estado de cobro:
                # borrarian lo leido de los PDF o confirmado a mano.
                parcial = {k: v for k, v in cuerpo.items()
                           if k not in ("base", "iva", "estado",
                                        "importePendienteExtraccion")}
                if previo.get("fechaEstimada") is False and not estimada:
                    parcial.pop("fecha", None)
                _peticion(base, f"/api/facturas/{previo_id}", "PUT", parcial)
                estado["facturas"][d.ruta_relativa] = previo_id
                res["actualizados"] += 1
            else:
                try:
                    r = _peticion(base, "/api/facturas", "POST", cuerpo)
                    nuevo_id = r["id"]
                except ErrorEscrituraDudosa:
                    q = urllib.parse.urlencode({"rutaRelativa": d.ruta_relativa})
                    hallados = _peticion(base, f"/api/facturas?{q}")
                    if not hallados:
                        raise
                    nuevo_id = hallados[0]["id"]
                estado["facturas"][d.ruta_relativa] = nuevo_id
                res["creados"] += 1
        except ErrorApp as e:
            res["errores"] += 1
            print(f"  ERROR factura {d.ruta_relativa}: {e}", file=sys.stderr)
        if i % 100 == 0:
            _guardar_estado(estado)
    return res


def subir_binarios(base: str, inv: Inventario, raiz: Path, sujetos: dict,
                   simular: bool) -> dict:
    """Sube el binario real via POST /api/upload. OPCIONAL y lento.

    Duplica los ficheros dentro de data/uploads. Solo con --subir-binarios.
    """
    import base64
    docs = [d for d in inv.documentos if not d.duplicado_de]
    res = {"subidos": 0, "omitidos_por_tamano": 0, "errores": 0}
    for d in docs:
        if d.tamano > MAX_BYTES_SUBIDA:
            res["omitidos_por_tamano"] += 1
            print(f"  OMITIDO por tamano ({d.tamano/1e6:.1f} MB): {d.nombre}",
                  file=sys.stderr)
            continue
        if simular:
            res["subidos"] += 1
            continue
        origen = raiz / d.ruta_relativa
        try:
            contenido = base64.b64encode(origen.read_bytes()).decode("ascii")
            _peticion(base, "/api/upload", "POST", {
                "nombre": d.nombre, "tipo": d.extension,
                "sujetoId": sujetos.get(d.cliente or ""),
                "contenidoBase64": contenido})
            res["subidos"] += 1
        except (OSError, ErrorApp) as e:
            res["errores"] += 1
            print(f"  ERROR subiendo {d.nombre}: {e}", file=sys.stderr)
    return res


def sincronizar_informes(base: str, inv: Inventario, sujetos: dict,
                         simular: bool) -> dict:
    """Un informe por (cliente, ejercicio, trimestre)."""
    cortes: dict = {}
    for d in inv.documentos:
        if d.cliente and d.ejercicio and d.trimestre and not d.duplicado_de:
            k = (d.cliente, d.ejercicio, d.trimestre)
            cortes.setdefault(k, {"emitida": 0, "recibida": 0, "otros": 0})
            clave = d.tipo_doc if d.tipo_doc in ("emitida", "recibida") else "otros"
            cortes[k][clave] += 1

    res = {"creados": 0, "actualizados": 0, "errores": 0}
    for (cli, eje, tri), cuenta in sorted(cortes.items()):
        sid = sujetos.get(cli)
        if not sid and not simular:
            continue
        cuerpo = {
            "titulo": f"Resumen {tri} {eje} · {cli}",
            "tipo": "trimestral",
            "periodo": f"{tri}-{eje}",   # campo NATIVO (server.js:168)
            "sujetoIds": [sid] if sid else [],
            "campos": ["nombre", "nif", "numEmitidas", "baseEmitidas",
                       "ivaRepercutido", "numRecibidas", "baseRecibidas",
                       "ivaSoportado", "resultadoIva", "sinImporte",
                       "porConfirmar"],
            "estado": "borrador",        # enum sin tilde
            "observaciones": (
                f"{cuenta['emitida']} emitidas, {cuenta['recibida']} recibidas, "
                f"{cuenta['otros']} otros documentos. Importes pendientes de "
                f"extraer del contenido del PDF."),
            "ejercicio": eje, "trimestre": tri,
            "clienteArchivo": cli,
        }
        if simular:
            res["creados"] += 1
            continue
        try:
            # Idempotente por periodo + cliente: 'periodo' es campo NATIVO
            # (server.js:168) y 'clienteArchivo' es extra, ambos filtrables.
            q = urllib.parse.urlencode({"periodo": cuerpo["periodo"],
                                        "clienteArchivo": cli})
            previos = _peticion(base, f"/api/informes?{q}")
            if previos:
                sin_campos = {k: v for k, v in cuerpo.items()
                              if k not in ("campos", "estado")}
                _peticion(base, f"/api/informes/{previos[0]['id']}", "PUT",
                          {**previos[0], **sin_campos})
                res["actualizados"] += 1
            else:
                try:
                    _peticion(base, "/api/informes", "POST", cuerpo)
                except ErrorEscrituraDudosa:
                    if not _peticion(base, f"/api/informes?{q}"):
                        raise
                res["creados"] += 1
        except ErrorApp as e:
            res["errores"] += 1
            print(f"  ERROR informe {cli} {tri} {eje}: {e}", file=sys.stderr)
    return res


# ---------------------------------------------------------------- orquestador
def cargar(inv: Inventario, raiz: Path, base: str = API_BASE,
           simular: bool = True, con_binarios: bool = False,
           limite: int | None = None) -> dict:
    """Ejecuta la carga completa en el orden correcto."""
    if limite:
        # Recortar aqui y no por paso: si no, se crearian facturas que apuntan
        # a documentos no cargados (documentoId a None).
        inv = Inventario(raiz=inv.raiz, documentos=inv.documentos[:limite])
        print(f"AVISO: --limite {limite}. Solo se cargan los {limite} primeros "
              f"documentos y lo que dependa de ellos.")

    print(f"CARGA EN LA APP  ({'SIMULACION' if simular else 'REAL'})  {base}")
    print("=" * 66)

    if not simular:
        try:
            st = comprobar_api(base)
            print(f"  app viva. Estado actual: {st.get('documentos', 0)} documentos, "
                  f"{st.get('sujetos', 0)} sujetos.")
        except ErrorApp as e:
            print(f"\n{e}", file=sys.stderr)
            return {"error": str(e)}
        print("  AVISO: haz copia de data/ antes de una carga real. "
              "No hay transaccion ni endpoint de lote.")

    estado = _cargar_estado()

    print("\n[1/5] Grupo y campos personalizados")
    grupo_id = sincronizar_grupo(base, simular, estado)

    print("[2/5] Sujetos (uno por cliente)")
    sujetos = sincronizar_sujetos(base, inv, grupo_id, simular, estado)
    if simular:
        sujetos = {c["nombre"]: f"sim-{c['nombre']}" for c in CLIENTES.values()}

    print(f"[3/5] Documentos ({len(inv)} archivos, secuencial)")
    r_docs = sincronizar_documentos(base, inv, raiz, sujetos, simular, estado)
    print(f"      creados={r_docs['creados']} actualizados={r_docs['actualizados']} "
          f"respetados(revisados a mano)={r_docs['respetados']} "
          f"errores={r_docs['errores']}")

    print("[4/5] Facturas (solo con numero fiable)")
    r_fac = sincronizar_facturas(base, inv, sujetos, simular, estado)
    print(f"      creados={r_fac['creados']} actualizados={r_fac['actualizados']} "
          f"respetadas={r_fac['respetadas']} errores={r_fac['errores']}")

    print("[5/5] Informes trimestrales")
    r_inf = sincronizar_informes(base, inv, sujetos, simular)
    print(f"      creados={r_inf['creados']} "
          f"actualizados={r_inf['actualizados']} errores={r_inf['errores']}")

    r_bin = None
    if con_binarios:
        print("\n[extra] Subiendo binarios (lento, duplica ficheros)")
        r_bin = subir_binarios(base, inv, raiz, sujetos, simular)
        print(f"      subidos={r_bin['subidos']} "
              f"omitidos_por_tamano={r_bin['omitidos_por_tamano']}")

    if not simular:
        _guardar_estado(estado)
        print(f"\n  Estado guardado en {_ruta_estado()}")
        print("  Una segunda ejecucion ACTUALIZA, no duplica.")
    else:
        print("\n  (SIMULACION: no se ha enviado ni una peticion de escritura)")

    return {"documentos": r_docs, "facturas": r_fac, "informes": r_inf,
            "binarios": r_bin}
