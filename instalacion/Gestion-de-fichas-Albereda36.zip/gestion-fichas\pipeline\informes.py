"""Informes: libro de IVA, resumen trimestral, por proveedor e incompletos.

Los importes (base, IVA, total) van VACIOS a proposito. Salen del contenido
del PDF, que este pipeline todavia no lee. Nunca se inventa una cifra.
"""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path

from config import CSV_ENCODING, CSV_SEP
from modelo import Inventario

COLS_LIBRO = ["trimestre", "fecha", "numero", "serie", "contraparte", "nif",
              "proveedor", "base_imponible", "cuota_iva", "total",
              "archivo", "confianza", "incidencias"]


def libro_iva(inv: Inventario, cliente: str, ejercicio: int,
              tipo: str) -> list[list]:
    """Libro de facturas emitidas o recibidas de un ejercicio."""
    docs = [d for d in inv.documentos
            if d.cliente == cliente and d.ejercicio == ejercicio
            and d.tipo_doc == tipo and d.computa_en_libro_iva
            and not d.duplicado_de]
    docs.sort(key=lambda d: (d.trimestre or "", d.fecha_documento or "",
                             d.numero or ""))
    filas = []
    for d in docs:
        filas.append([d.trimestre or "", d.fecha_documento or "",
                      d.numero or "", d.serie or "", d.contraparte or "",
                      d.nif or "", d.proveedor or "",
                      "", "", "",  # importes: pendientes de leer el PDF
                      d.nombre, d.confianza, " | ".join(d.incidencias)])
    return filas


def resumen_trimestral(inv: Inventario) -> list[list]:
    """Tabla cliente x ejercicio x trimestre x tipo (conteos)."""
    cont: dict = defaultdict(Counter)
    for d in inv.documentos:
        if d.duplicado_de or not d.cliente:
            continue
        cont[(d.cliente, d.ejercicio or "?", d.trimestre or "-")][d.tipo_doc] += 1
    filas = [["cliente", "ejercicio", "trimestre", "emitidas", "recibidas",
              "otros", "total"]]
    for (cli, eje, tri) in sorted(cont, key=lambda k: (k[0], str(k[1]), k[2])):
        c = cont[(cli, eje, tri)]
        emi, rec = c.get("emitida", 0), c.get("recibida", 0)
        tot = sum(c.values())
        filas.append([cli, eje, tri, emi, rec, tot - emi - rec, tot])
    return filas


def resumen_por_proveedor(inv: Inventario, cliente: str | None = None) -> list[list]:
    c: Counter = Counter()
    for d in inv.documentos:
        if d.duplicado_de or d.tipo_doc != "recibida":
            continue
        if cliente and d.cliente != cliente:
            continue
        c[(d.cliente, d.proveedor or "(sin identificar)")] += 1
    filas = [["cliente", "proveedor", "facturas"]]
    for (cli, prov), n in sorted(c.items(), key=lambda x: (-x[1], x[0])):
        filas.append([cli, prov, n])
    return filas


def documentos_incompletos(inv: Inventario) -> list[list]:
    """Lo que exige mano humana antes de cerrar un trimestre."""
    filas = [["cliente", "ejercicio", "trimestre", "tipo", "archivo",
              "confianza", "motivo"]]
    for d in inv.documentos:
        if not (d.revision_manual or d.incidencias):
            continue
        filas.append([d.cliente or "", d.ejercicio or "", d.trimestre or "",
                      d.tipo_doc, d.ruta_relativa, d.confianza,
                      " | ".join(d.incidencias)])
    return filas


# ---------------------------------------------------------------- salida
def exportar_csv(filas: list[list], destino: Path,
                 cabecera: list[str] | None = None) -> Path:
    destino.parent.mkdir(parents=True, exist_ok=True)
    with destino.open("w", newline="", encoding=CSV_ENCODING) as fh:
        w = csv.writer(fh, delimiter=CSV_SEP)
        if cabecera:
            w.writerow(cabecera)
        w.writerows(filas)
    return destino


def tabla_texto(filas: list[list], max_filas: int = 60) -> str:
    """Tabla ASCII alineada para leer en consola."""
    if not filas:
        return "(sin datos)"
    datos = [[str(c) for c in f] for f in filas[:max_filas]]
    anchos = [max(len(f[i]) for f in datos) for i in range(len(datos[0]))]
    L = []
    for i, f in enumerate(datos):
        L.append("  ".join(c.ljust(anchos[j]) for j, c in enumerate(f)))
        if i == 0:
            L.append("-" * (sum(anchos) + 2 * (len(anchos) - 1)))
    if len(filas) > max_filas:
        L.append(f"... y {len(filas) - max_filas} filas mas")
    return "\n".join(L)


def grafico_ascii(pares: list[tuple], ancho: int = 40) -> str:
    """Barras horizontales para el resumen en consola."""
    if not pares:
        return "(sin datos)"
    mx = max(v for _, v in pares) or 1
    etiqueta = max(len(str(k)) for k, _ in pares)
    L = []
    for k, v in pares:
        barra = "#" * max(1, int(v / mx * ancho))
        L.append(f"  {str(k).ljust(etiqueta)}  {barra} {v}")
    return "\n".join(L)
