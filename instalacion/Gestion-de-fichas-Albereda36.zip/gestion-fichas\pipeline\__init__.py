"""Pipeline de gestion de archivos - Asesoria Albereda 36, S.L."""

__version__ = "1.0.0"
