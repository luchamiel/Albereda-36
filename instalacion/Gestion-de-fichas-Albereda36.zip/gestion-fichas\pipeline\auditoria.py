"""Auditoria del archivo real: que esta mal HOY.

Lo que este modulo encuentra es lo que hoy la gestoria detecta a ojo (o no
detecta). Nada de esto modifica el archivo del cliente: solo informa.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
import zipfile
from collections import defaultdict
from pathlib import Path

from modelo import Inventario

NS_SS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


# ---------------------------------------------------------------- duplicados
def duplicados_por_contenido(inv: Inventario) -> list[list[str]]:
    """Grupos de rutas con SHA-256 identico. El primero es el canonico."""
    grupos: dict[str, list[str]] = defaultdict(list)
    for d in inv.documentos:
        if d.sha256:
            grupos[d.sha256].append(d.ruta_relativa)
    return [sorted(v) for v in grupos.values() if len(v) > 1]


# ---------------------------------------------------------------- discrepancias
def discrepancias(inv: Inventario) -> list[dict]:
    """Documentos archivados en un trimestre o ejercicio que su fecha desmiente.

    Son EXACTAMENTE los que descuadrarian un modelo 303 si se declarase por
    la carpeta en vez de por la fecha de la factura.
    """
    out = []
    for d in inv.documentos:
        for inc in d.incidencias:
            if inc.startswith(("trimestre_discrepante", "ejercicio_discrepante")):
                out.append({"ruta": d.ruta_relativa, "cliente": d.cliente,
                            "fecha": d.fecha_documento, "incidencia": inc,
                            "archivado_en": f"{d.ejercicio} {d.trimestre}"})
    return out


# ---------------------------------------------------------------- comprimidos
def comprimidos(raiz: Path) -> list[dict]:
    """Estado de cada .zip/.rar: ya extraido, parcial o SIN EXTRAER.

    Un comprimido sin extraer con facturas dentro bloquea el cierre del
    ejercicio: esos documentos no existen en ningun otro sitio.
    """
    out = []
    for ruta in sorted(raiz.rglob("*")):
        if ruta.suffix.lower() not in (".zip", ".rar") or not ruta.is_file():
            continue
        reg = {"ruta": ruta.relative_to(raiz).as_posix(),
               "tamano": ruta.stat().st_size, "estado": "?",
               "dentro": 0, "extraidos": 0, "faltan": []}
        if ruta.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(ruta) as z:
                    nombres = [n for n in z.namelist() if not n.endswith("/")]
            except (zipfile.BadZipFile, OSError):
                reg["estado"] = "ILEGIBLE"
                out.append(reg)
                continue
            reg["dentro"] = len(nombres)
            # Buscar en el arbol del padre, no solo entre hermanos directos:
            # 'facturasemitidas.zip' se extrajo en la subcarpeta homonima.
            hermanos = {p.name for p in ruta.parent.rglob("*") if p.is_file()}
            faltan = [n for n in nombres if Path(n).name not in hermanos]
            reg["extraidos"] = len(nombres) - len(faltan)
            reg["faltan"] = faltan[:10]
            reg["estado"] = ("ya_extraido" if not faltan
                             else "parcial" if reg["extraidos"] else "SIN_EXTRAER")
        else:
            # La stdlib NO lee RAR. Se leen cadenas de la cabecera RAR5 para
            # saber que hay dentro. La extraccion real es MANUAL con WinRAR.
            nombres = nombres_en_rar(ruta)
            reg["dentro"] = len(nombres)
            hermanos = {p.name for p in ruta.parent.rglob("*") if p.is_file()}
            faltan = [n for n in nombres if Path(n).name not in hermanos]
            reg["extraidos"] = len(nombres) - len(faltan)
            reg["faltan"] = faltan[:10]
            if not nombres:
                reg["estado"] = "OPACO_revisar_a_mano"
            elif not faltan:
                reg["estado"] = "ya_extraido"
            elif reg["extraidos"]:
                reg["estado"] = "parcial"
            else:
                reg["estado"] = "SIN_EXTRAER"
        out.append(reg)
    return out


RAR_NOMBRE = re.compile(rb"[\x20-\x7e]{6,}")


def nombres_en_rar(ruta: Path) -> list[str]:
    """Extrae nombres legibles de la cabecera RAR5 sin dependencias externas."""
    try:
        crudo = ruta.read_bytes()
    except OSError:
        return []
    vistos, out = set(), []
    for m in RAR_NOMBRE.finditer(crudo):
        s = m.group().decode("ascii", "ignore")
        if "/" in s and re.search(r"\.(pdf|jpe?g|png|xlsx?|xsig)$", s, re.I):
            if s not in vistos:
                vistos.add(s)
                out.append(s)
    return out


# ---------------------------------------------------------------- huerfanos
def huerfanos(inv: Inventario) -> list[dict]:
    """Documentos que exigen ojo humano: sin trimestre o sin tipo."""
    return [{"ruta": d.ruta_relativa, "cliente": d.cliente,
             "tipo": d.tipo_doc, "motivo": " | ".join(d.incidencias)}
            for d in inv.documentos if d.revision_manual]


def inferidos(inv: Inventario) -> list[dict]:
    """Los clasificados por inferencia: correctos casi siempre, pero revisables."""
    return [{"ruta": d.ruta_relativa, "tipo": d.tipo_doc,
             "confianza": d.confianza}
            for d in inv.documentos if d.origen_tipo == "inferido_carpeta_plana"]


# ---------------------------------------------------------------- xlsx stdlib
def leer_xlsx(ruta: Path, max_filas: int = 5000) -> list[list[str]]:
    """Lee un .xlsx SIN openpyxl: un xlsx es un zip con XML dentro.

    Sirve para abrir los libros de IVA que la gestoria ya lleva a mano y
    cruzarlos contra los PDF reales.
    """
    try:
        with zipfile.ZipFile(ruta) as z:
            compartidas: list[str] = []
            if "xl/sharedStrings.xml" in z.namelist():
                raiz = ET.fromstring(z.read("xl/sharedStrings.xml"))
                for si in raiz.findall(f"{NS_SS}si"):
                    compartidas.append("".join(t.text or ""
                                               for t in si.iter(f"{NS_SS}t")))
            hojas = [n for n in z.namelist()
                     if n.startswith("xl/worksheets/sheet")]
            if not hojas:
                return []
            raiz = ET.fromstring(z.read(sorted(hojas)[0]))
            filas = []
            for fila in raiz.iter(f"{NS_SS}row"):
                celdas = []
                for c in fila.findall(f"{NS_SS}c"):
                    v = c.find(f"{NS_SS}v")
                    txt = "" if v is None else (v.text or "")
                    if c.get("t") == "s" and txt.isdigit():
                        idx = int(txt)
                        txt = compartidas[idx] if idx < len(compartidas) else ""
                    celdas.append(txt)
                filas.append(celdas)
                if len(filas) >= max_filas:
                    break
            return filas
    except (zipfile.BadZipFile, ET.ParseError, OSError, KeyError):
        return []


def libros_registro(inv: Inventario, raiz: Path) -> list[dict]:
    """Localiza los .xlsx de libro de IVA y los abre."""
    out = []
    for d in inv.documentos:
        if d.tipo_doc != "libro_registro":
            continue
        filas = leer_xlsx(raiz / d.ruta_relativa)
        out.append({"ruta": d.ruta_relativa, "filas": len(filas),
                    "cabecera": filas[0][:8] if filas else [],
                    "muestra": filas[1][:8] if len(filas) > 1 else []})
    return out


# ---------------------------------------------------------------- informe
def informe(inv: Inventario, raiz: Path) -> str:
    """Informe de auditoria legible, priorizado por gravedad."""
    dup = duplicados_por_contenido(inv)
    disc = discrepancias(inv)
    comp = comprimidos(raiz)
    huer = huerfanos(inv)
    infer = inferidos(inv)
    libros = libros_registro(inv, raiz)

    sin_extraer = [c for c in comp if c["estado"] in ("SIN_EXTRAER", "OPACO_revisar_a_mano")]

    L = ["INFORME DE AUDITORIA DEL ARCHIVO", "=" * 70,
         f"Raiz: {raiz}", f"Documentos: {len(inv)}", ""]

    L += ["[1] BLOQUEANTE - COMPRIMIDOS SIN EXTRAER", "-" * 70]
    if sin_extraer:
        for c in sin_extraer:
            L.append(f"  {c['ruta']}  ({c['tamano']:,} bytes, estado={c['estado']})")
            L.append(f"      contiene {c['dentro']} documentos, faltan {len(c['faltan'])}")
            for n in c["faltan"][:5]:
                L.append(f"        - {n}")
            L.append("      ACCION: extraer a mano con WinRAR. La stdlib no lee RAR.")
    else:
        L.append("  (ninguno)")
    L.append("")

    L += ["[2] ALTO - ARCHIVADO EN EL PERIODO EQUIVOCADO", "-" * 70,
          "  Estos descuadrarian el modelo 303 si se declarasen por carpeta.",
          f"  Total: {len(disc)}", ""]
    for d in disc[:25]:
        L.append(f"  {d['ruta']}")
        L.append(f"      {d['incidencia']}  (fecha real: {d['fecha']})")
    if len(disc) > 25:
        L.append(f"  ... y {len(disc) - 25} mas (ver el CSV)")
    L.append("")

    L += ["[3] ALTO - DUPLICADOS POR CONTENIDO", "-" * 70,
          f"  {sum(len(g) - 1 for g in dup)} redundantes en {len(dup)} grupos.",
          "  Contarlos dos veces inflaria la base imponible.", ""]
    for g in dup[:12]:
        L.append(f"  canonico: {g[0]}")
        for r in g[1:]:
            L.append(f"      dup:  {r}")
    if len(dup) > 12:
        L.append(f"  ... y {len(dup) - 12} grupos mas (ver el CSV)")
    L.append("")

    L += ["[4] MEDIO - EXIGEN REVISION HUMANA", "-" * 70,
          f"  Total: {len(huer)}", ""]
    for h in huer[:20]:
        L.append(f"  {h['ruta']}")
        L.append(f"      {h['motivo']}")
    L.append("")

    L += ["[5] INFORMATIVO - TIPO INFERIDO (carpeta plana)", "-" * 70,
          f"  {len(infer)} documentos clasificados como RECIBIDA por descarte,",
          "  porque su carpeta no separa emitidas de recibidas y su nombre",
          "  no casa la serie propia del cliente. Revisar por muestreo.", ""]

    L += ["[6] INFORMATIVO - COMPRIMIDOS YA EXTRAIDOS", "-" * 70]
    for c in comp:
        if c["estado"] not in ("SIN_EXTRAER", "OPACO_revisar_a_mano"):
            L.append(f"  {c['ruta']}: {c['estado']} "
                     f"({c['extraidos']}/{c['dentro']})")
    L.append("")

    L += ["[7] LIBROS DE REGISTRO DE LA GESTORIA (.xlsx leidos sin openpyxl)",
          "-" * 70]
    for lb in libros:
        L.append(f"  {lb['ruta']}: {lb['filas']} filas")
        L.append(f"      cabecera: {lb['cabecera']}")
        L.append(f"      muestra : {lb['muestra']}")
    if not libros:
        L.append("  (ninguno)")
    L.append("")
    return "\n".join(L)
