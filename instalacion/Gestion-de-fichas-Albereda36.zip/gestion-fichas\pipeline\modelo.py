"""Modelo canonico de datos del archivo de la asesoria.

Un Documento es CUALQUIER archivo del fondo documental. No todo documento es
una factura: hay documentacion de PRL, recopilatorios, correos, libros de
registro y firmas electronicas. El campo `computa_en_libro_iva` es el que
decide si una fila entra en el libro de IVA.
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Iterator


class TipoDoc(str, Enum):
    """Naturaleza del documento."""
    EMITIDA = "emitida"              # factura que emite el cliente (ingreso)
    RECIBIDA = "recibida"            # factura que recibe el cliente (gasto)
    RECOPILATORIO = "recopilatorio"  # dosier agregado: NO computa, duplicaria
    PRL = "prl"                      # prevencion, subcontratas, acreditaciones
    LIBRO_REGISTRO = "libro_registro"  # los .xlsx que lleva la gestoria
    CORREO = "correo"                # impresion de email
    PROFORMA = "proforma"            # no deducible
    COMPRIMIDO = "comprimido"        # .zip / .rar
    OTRO = "otro"
    DESCONOCIDO = "desconocido"


# Tipos que NUNCA deben sumar en el libro de IVA.
NO_COMPUTAN = {
    TipoDoc.RECOPILATORIO, TipoDoc.PRL, TipoDoc.LIBRO_REGISTRO,
    TipoDoc.CORREO, TipoDoc.PROFORMA, TipoDoc.COMPRIMIDO,
    TipoDoc.OTRO, TipoDoc.DESCONOCIDO,
}


@dataclass
class Documento:
    """Un archivo del fondo, ya clasificado."""
    # --- identidad ---
    ruta_relativa: str
    nombre: str
    extension: str
    tamano: int
    sha256: str | None = None

    # --- clasificacion taxonomica ---
    cliente: str | None = None
    ejercicio: int | None = None
    trimestre: str | None = None          # "1T".."4T"
    tipo_doc: str = TipoDoc.DESCONOCIDO.value
    subtipo: str | None = None            # rectificativa, acreditacion, poliza...
    proveedor: str | None = None
    obra: str | None = None               # NALANDA: nivel 4 es obra, no proveedor
    mes_carpeta_origen: int | None = None

    # --- metadatos extraidos del nombre ---
    numero: str | None = None
    serie: str | None = None
    fecha_documento: str | None = None    # ISO. Fecha de devengo.
    fecha_captura: str | None = None      # ISO. Fecha de escaneo/descarga: NO es devengo.
    contraparte: str | None = None
    nif: str | None = None
    patron_detectado: str | None = None

    # --- trazabilidad de la decision ---
    origen_trimestre: str | None = None   # 'fecha' | 'carpeta' | 'tabla' | None
    origen_tipo: str | None = None        # 'carpeta' | 'nombre' | 'rama'
    confianza: float = 0.0                # 0..1
    computa_en_libro_iva: bool = False
    duplicado_de: str | None = None       # ruta_relativa del ejemplar canonico
    revision_manual: bool = False
    incidencias: list[str] = field(default_factory=list)

    # ------------------------------------------------------------------
    def clave_canonica(self) -> str:
        """Nombre de archivo normalizado para la carpeta de salida.

        Formato: <ejercicio><trimestre>_<tipo>_<numero|contraparte>_<original>
        Se conserva SIEMPRE el nombre original al final: nunca se pierde la
        trazabilidad con el archivo del cliente.
        """
        partes = []
        if self.ejercicio and self.trimestre:
            partes.append(f"{self.ejercicio}{self.trimestre}")
        partes.append({"emitida": "EMI", "recibida": "REC"}.get(self.tipo_doc, "DOC"))
        if self.numero:
            partes.append(str(self.numero))
        elif self.contraparte:
            partes.append(str(self.contraparte)[:24].strip())
        partes.append(self.nombre)
        return "_".join(p for p in partes if p)

    def ruta_canonica(self) -> Path:
        """Subruta destino dentro de la carpeta de salida."""
        cli = self.cliente or "_SIN_CLIENTE"
        eje = str(self.ejercicio) if self.ejercicio else "_SIN_EJERCICIO"
        if self.tipo_doc == TipoDoc.PRL.value:
            return Path(cli) / eje / "_DOCUMENTACION" / (self.subtipo or "prl")
        if self.tipo_doc == TipoDoc.RECOPILATORIO.value:
            return Path(cli) / eje / "_RECOPILATORIOS"
        if not self.trimestre or self.tipo_doc == TipoDoc.DESCONOCIDO.value:
            return Path(cli) / eje / "_SIN_CLASIFICAR"
        carpeta_tipo = {"emitida": "EMITIDAS", "recibida": "RECIBIDAS"}.get(
            self.tipo_doc, "OTROS")
        base = Path(cli) / eje / self.trimestre / carpeta_tipo
        return base / self.proveedor if self.proveedor else base

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Documento":
        campos = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in campos})


@dataclass
class Inventario:
    """Coleccion de documentos + utilidades de serializacion."""
    documentos: list[Documento] = field(default_factory=list)
    raiz: str = ""

    def __len__(self) -> int:
        return len(self.documentos)

    def __iter__(self) -> Iterator[Documento]:
        return iter(self.documentos)

    def filtrar(self, **criterios: Any) -> list[Documento]:
        """filtrar(cliente='Maxi', ejercicio=2025, trimestre='4T')"""
        out = []
        for d in self.documentos:
            if all(getattr(d, k, None) == v for k, v in criterios.items()):
                out.append(d)
        return out

    def facturas(self) -> list[Documento]:
        """Solo lo que computa en el libro de IVA (sin duplicados)."""
        return [d for d in self.documentos
                if d.computa_en_libro_iva and not d.duplicado_de]

    # ------------------------------------------------------------------
    def guardar_json(self, destino: Path) -> None:
        destino.parent.mkdir(parents=True, exist_ok=True)
        payload = {"raiz": self.raiz,
                   "total": len(self.documentos),
                   "documentos": [d.to_dict() for d in self.documentos]}
        destino.write_text(json.dumps(payload, indent=2, ensure_ascii=False),
                           encoding="utf-8")

    @classmethod
    def cargar_json(cls, origen: Path) -> "Inventario":
        data = json.loads(origen.read_text(encoding="utf-8"))
        return cls(raiz=data.get("raiz", ""),
                   documentos=[Documento.from_dict(x) for x in data["documentos"]])

    def guardar_csv(self, destino: Path, encoding: str = "utf-8-sig",
                    sep: str = ";") -> None:
        destino.parent.mkdir(parents=True, exist_ok=True)
        if not self.documentos:
            destino.write_text("", encoding=encoding)
            return
        cols = list(self.documentos[0].to_dict().keys())
        with destino.open("w", newline="", encoding=encoding) as fh:
            w = csv.DictWriter(fh, fieldnames=cols, delimiter=sep,
                               extrasaction="ignore")
            w.writeheader()
            for d in self.documentos:
                fila = d.to_dict()
                fila["incidencias"] = " | ".join(fila.get("incidencias") or [])
                w.writerow(fila)
