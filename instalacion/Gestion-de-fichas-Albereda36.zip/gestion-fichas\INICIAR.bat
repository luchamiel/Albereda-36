@echo off
chcp 65001 >nul
title Gestion de fichas - Asesoria Albereda 36
cd /d "%~dp0"

echo.
echo   ================================================
echo     GESTION DE FICHAS - Asesoria Albereda 36
echo   ================================================
echo.

REM ---- Comprobar que Node esta instalado ----------------------------
where node >nul 2>nul
if errorlevel 1 (
    echo   [X] No se encuentra Node.js en este equipo.
    echo.
    echo   Es el unico programa que hace falta instalar. Es gratuito.
    echo.
    echo   1. Abre esta direccion:   https://nodejs.org/es/download
    echo   2. Descarga la version "LTS" para Windows.
    echo   3. Instalala pulsando Siguiente en todo.
    echo   4. Reinicia el ordenador.
    echo   5. Vuelve a abrir este archivo.
    echo.
    echo   Tienes las instrucciones con imagenes en DEPENDENCIAS.html
    echo.
    start "" "%~dp0DEPENDENCIAS.html"
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('node --version') do set NODEVER=%%v
echo   [OK] Node.js %NODEVER% detectado.

REM ---- Averiguar el puerto leyendo el .env --------------------------
REM No se puede dejar el 4360 fijo aqui: si el .env dice otro, el .bat
REM vigilaria un puerto y el servidor arrancaria en otro.
set PUERTO=4360
for /f "usebackq delims=" %%p in (`node "%~dp0_puerto.js"`) do set PUERTO=%%p
echo   [OK] Puerto configurado: %PUERTO%

REM ---- Comprobar que el programa no este ya abierto -----------------
netstat -ano | findstr ":%PUERTO%" | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 (
    echo   [!] El programa YA estaba abierto. Abriendo la ventana...
    start "" http://localhost:%PUERTO%
    ping -n 4 127.0.0.1 >nul
    exit /b 0
)

echo   [OK] Arrancando el programa...
echo.

REM ---- Arrancar el servidor y abrir el navegador --------------------
REM El lanzador busca version nueva, la instala si la hay, arranca el
REM servidor y lo cuida. Este .bat no se actualiza nunca: Windows lo lee
REM a trozos mientras lo ejecuta y cambiarlo en marcha lo romperia.
start "Gestion de fichas (programa)" /min cmd /c "node lib\lanzador.js > servidor.log 2>&1"

echo   Esperando a que arranque...
echo   (si hay una version nueva del programa, se instala ahora)
set /a INTENTOS=0
:ESPERAR
set /a INTENTOS+=1
ping -n 2 127.0.0.1 >nul
powershell -NoProfile -Command "try{(New-Object Net.Sockets.TcpClient).Connect('localhost',%PUERTO%);exit 0}catch{exit 1}" >nul 2>nul
if errorlevel 1 (
    if %INTENTOS% LSS 45 goto ESPERAR
    echo.
    echo   [X] El programa no ha arrancado. Mira el archivo servidor.log
    echo.
    if exist "%~dp0servidor.log" type "%~dp0servidor.log"
    echo.
    pause
    exit /b 1
)

start "" http://localhost:%PUERTO%

echo.
echo   ================================================
echo     LISTO. El programa esta abierto en:
echo     http://localhost:%PUERTO%
echo   ================================================
echo.
echo   Esta ventana ya se puede cerrar: el programa sigue abierto.
echo   Para CERRAR el programa: en la barra de tareas, cierra la
echo   ventana minimizada "Gestion de fichas (programa)".
echo.
pause >nul
