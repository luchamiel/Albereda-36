# Pipeline de gestión de archivos — Asesoría Albereda 36, S.L.

Scripts de Python que ordenan el fondo documental real del despacho:
**1.185 archivos** repartidos en 88 carpetas, con una taxonomía que hoy no es
consistente. Sin dependencias: solo biblioteca estándar de Python 3.13.

> **El archivo del cliente se abre SIEMPRE en solo lectura.** Hay una red de
> seguridad (`config.asegurar_fuera_de_datos`) que aborta cualquier escritura
> que apunte dentro de `Albereda36/`. Todo lo que se genera va a `_trabajo/`.

---

## Arranque

```bash
cd "gestion-fichas"
python -m pipeline escanear     # crea el inventario
python -m pipeline auditar      # informe de lo que está mal
python -m pipeline --help       # todos los comandos
```

No hace falta instalar nada.

---

## El problema que resuelve

Lo mismo se llama de seis maneras distintas según la carpeta:

| Concepto | Nombres reales encontrados |
|---|---|
| Facturas emitidas | `EMITIDAS 1T 21`, `Realizadas`, `Mias`, `INGRESOS`, `facturasemitidas` |
| Facturas recibidas | `Recibidas2t 21`, `ME las hacen`, `GASTOS`, `Gastos` |
| Trimestre | `1T`, `2T 2024`, `2024 4t`, `1er trimestre`, `2º Trimestre`, `4º Trimestre.rar` |

Y además:

- **Anidamientos duplicados**: `2024 Maxi/4T 2024/4T 2024/`, `2025 Maxi/2025 1T/1T 2025/`.
  Se colapsan comparando la tupla *(ejercicio, trimestre)*, no el texto — porque
  en unos casos los tokens van invertidos.
- **La carpeta miente sobre el trimestre.** `2024 Urbano/2024 3T/` contiene
  facturas de febrero a julio. **Manda la fecha del nombre del archivo**, no la
  carpeta, y la discrepancia se registra en vez de silenciarse.
- **Trampas léxicas**: `A ENVIAR` no son emitidas, son dosieres recopilatorios
  que duplicarían los importes; `Facturas Enero 25` no son emitidas pese al
  nombre, son lotes de recibidas escaneadas.
- **`NALANDA/`** no son facturas: es documentación de PRL y subcontratas. No
  tiene trimestre y no computa en el libro de IVA.

---

## Modelo canónico

```
Cliente / Ejercicio / Trimestre / {EMITIDAS|RECIBIDAS|OTROS} / [proveedor] / archivo
Cliente / Ejercicio / _DOCUMENTACION / <subtipo>        (PRL: sin trimestre)
Cliente / Ejercicio / _RECOPILATORIOS
Cliente / Ejercicio / _SIN_CLASIFICAR                   (nunca se inventa nada)
```

Cada documento guarda **de dónde salió cada dato** (`origen_tipo`,
`origen_trimestre`, `confianza` 0..1) para que la auditoría sea explicable.

### Orden de clasificación

1. Normalizar la cadena (sin tildes, sin `º`, minúsculas)
2. Colapsar anidamientos duplicados
3. Cliente (del primer segmento; en el buzón, de la serie o del NIF del nombre)
4. Ejercicio
5. Tipo **por carpeta** — la carpeta gana sobre el nombre
6. Tipo **por nombre** (series propias por cliente) si 5 falló
7. Trimestre **por fecha del nombre** ← fuente prioritaria
8. Trimestre por carpeta como respaldo
9. Proveedor
10. Ramas especiales (PRL, correo, proforma, libro de registro, comprimido)

---

## Flujo completo

```
   ┌─ ENTRADA ──────────┐   ┌─ FONDO ─────────┐   ┌─ SALIDA ─────────────┐
   │ _trabajo/_ENTRADA/ │   │ Albereda36/     │   │ _trabajo/_SALIDA/    │
   │ PDFs sueltos       │   │ SOLO LECTURA    │   │ Cliente/Año/Trim/    │
   │        │           │   │        │        │   │   EMITIDAS/          │
   │        ▼           │   │        ▼        │   │   RECIBIDAS/         │
   │  clasificar        │──▶│   inventario    │──▶│   RELACION.csv       │
   │  ¿duplicado?       │   │   .json / .csv  │   │   RESUMEN.txt        │
   │  ¿clasificable?    │   │        │        │   │   MANIFIESTO.json    │
   └────────────────────┘   │        ▼        │   │   + .zip             │
                            │   auditoría     │   └──────────────────────┘
                            │   informes      │
                            │   app :4360     │
                            └─────────────────┘
```

---

## Comandos

### `escanear` — construye el inventario

```bash
python -m pipeline escanear            # con hash (detecta duplicados)
python -m pipeline escanear --sin-hash # más rápido, SIN detección de duplicados
```

Genera `_trabajo/inventario.json` y `_trabajo/inventario.csv`.

### `auditar` — qué está mal hoy

```bash
python -m pipeline auditar
```

Informe priorizado: comprimidos sin extraer (bloqueante), archivado en el
periodo equivocado, duplicados por contenido, documentos que exigen revisión
humana, y lectura de los libros `.xlsx` de la gestoría (sin `openpyxl`).

### `demo-entrada` + `entrada` — simulación de entrada

```bash
python -m pipeline demo-entrada -n 11   # llena el buzón con los 3 casos
python -m pipeline entrada --simular    # dice qué haría, no copia nada
python -m pipeline entrada --aplicar    # archiva de verdad
```

> **Para el día a día está la pestaña 📥 Importar del programa**: hace lo mismo
> sin Python, desde el navegador, y además registra las facturas en la app. Este
> buzón queda como herramienta de apoyo.

Cuatro rutas de decisión: **archivado**, **duplicado** (ya está en el fondo, por
SHA-256), **número repetido** (distinto fichero con un número de factura emitida
que ya existe para ese cliente y año: se aparta para revisar) y **sin clasificar**
(se aparta y se explica qué falta).

Con `--aplicar` el buzón **se vacía**: lo procesado pasa a
`_ENTRADA/_PROCESADOS/<fecha>/` y lo apartado a `_ENTRADA/_SIN_CLASIFICAR/`, así
que una segunda pasada no vuelve a archivar nada.

Para lotes sin pistas en el nombre, `_trabajo/_ENTRADA/pista.json`:

```json
{"cliente": "Maxi", "ejercicio": 2025, "trimestre": "4T"}
```

### `salida` — preparar un trimestre para entregar

```bash
python -m pipeline cortes               # ver qué trimestres hay
python -m pipeline salida --cliente Maxi --ejercicio 2025 --trimestre 4T --simular
python -m pipeline salida --cliente Maxi --ejercicio 2025 --trimestre 4T --aplicar --zip
```

Copia los documentos renombrados a la clave canónica (conservando el nombre
original al final) y genera `RELACION.csv`, `RESUMEN.txt` y `MANIFIESTO.json`
con los hashes. Si el número de archivos copiados no cuadra, falla ruidosamente.

### `informe`

```bash
python -m pipeline informe --tipo trimestral
python -m pipeline informe --tipo libro-iva --cliente Alfonso --ejercicio 2021
python -m pipeline informe --tipo proveedor --cliente Maxi
python -m pipeline informe --tipo incompletos
```

CSV con BOM y separador `;` — Excel en español los abre sin romper tildes ni ñ.

### `cargar-app` — vuelca el inventario en la app

```bash
node server.js &                              # arranca la app primero
python -m pipeline cargar-app --simular       # funciona con la app apagada
python -m pipeline cargar-app --aplicar       # carga real (~105 s)
python -m pipeline cargar-app --aplicar --subir-binarios   # además sube los PDF
```

> Solo hace falta para la **carga inicial** o tras reordenar el archivo a mano.
> Las facturas nuevas entran por la pestaña 📥 Importar.

Crea **3 sujetos** (uno por cliente, no por cliente-año: `nif` es la clave de
emparejamiento de `/api/sincronizar`), **1.185 documentos**, **714 facturas**
(solo las que tienen número fiable) y **24 informes** trimestrales.

**Es idempotente**: una segunda ejecución actualiza, no duplica — incluso si se
borra el fichero de estado, porque busca por `rutaRelativa` vía la API.

El ejercicio, el trimestre y el sentido van como **campos extra**. `coerceRecord`
es aditivo (`{...base, ...data}`), así que persisten, y el filtro genérico los
hace consultables sin tocar el servidor:

```
GET /api/documentos?ejercicio=2025&trimestre=4T   -> 137
GET /api/documentos?cliente=Maxi                  -> 388
GET /api/documentos?sentido=emitida               -> 311
GET /api/documentos?revisionManual=true           ->   3
```

**Respeta el trabajo hecho en la app**: no toca los documentos marcados como
revisados, no pisa importes, estado ni fechas confirmadas, conserva los avisos
de revisión y no cambia los campos de los informes.

El binario **no se copia**: se guarda solo `rutaRelativa`, que la app resuelve
contra `GF_RUTA_ARCHIVO`. Así no se duplican 398 MB, el programa sigue
funcionando si el archivo cambia de disco, y el borrado en cascada nunca
intenta un `unlink` sobre el archivo del cliente.

### `todo`

```bash
python -m pipeline todo    # escanear + auditar + resumen trimestral
```

---

## Módulos

| Archivo | Qué hace |
|---|---|
| `config.py` | Rutas, clientes, constantes y la **red de seguridad** |
| `modelo.py` | `Documento`, `Inventario`, `TipoDoc` y las rutas canónicas |
| `normalizar.py` | Las reglas de taxonomía (el corazón) |
| `patrones.py` | Catálogo de regex de nombres de archivo, en cascada |
| `escanear.py` | Recorrido, hash SHA-256 y deduplicación |
| `auditoria.py` | Anomalías + lectura de `.xlsx` sin dependencias |
| `entrada.py` | Buzón de entrada y su simulación |
| `salida.py` | Carpeta de entrega, manifiesto y ZIP |
| `informes.py` | Libro de IVA, resúmenes, tablas y gráfico ASCII |
| `cargar_app.py` | Volcado en la app :4360 (idempotente, solo `urllib`) |
| `cli.py` | Los comandos |

---

## Qué NO hace todavía

- **El pipeline no lee el contenido del PDF.** Eso lo hace la app
  (`lib/pdftexto.js` + `lib/datosfactura.js`, en ⚠ Revisar → Importes), que
  solo propone importes cuando base + IVA − IRPF = total y siempre como
  «por confirmar».
- **Los escaneos sin texto (≈220 de 1.039 PDF de factura) no tienen OCR**:
  el importe se teclea.
- **No abre `.rar`.** La biblioteca estándar no puede. La auditoría dice cuáles
  hay que extraer a mano con WinRAR. No añadir `rarfile`.
- Los `.jpg` de móvil sin metadatos en el nombre requieren vista humana.

### Siguiente paso natural

Cruzar los importes confirmados contra los libros `.xlsx` que la gestoría ya
lleva a mano.
