# Gestión de fichas — Asesoría Albereda 36, S.L.

Programa **local** para gestionar el archivo de facturas del despacho: archivo por
cliente, año y trimestre, entrada de facturas nuevas, revisión, importes, informes
tipo modelo 303 y fichas de clientes. Todo vive en el equipo del despacho, sin nube
y sin dependencias externas.

> Guía para quien lo usa: `DEPENDENCIAS.html` (también en el programa, botón **? Ayuda**).

## Arranque

Doble clic en **`INICIAR.bat`**. Comprueba Node, lee el puerto del `.env`, arranca
`lib/lanzador.js` (que busca versión nueva, arranca el servidor y lo cuida) y abre
el navegador. A mano: `node lib/lanzador.js`, o `node server.js` sin actualizaciones.

- Requiere **Node.js 18 o superior**. Sin `npm install`: cero dependencias.
- Configuración en **`.env`** (plantilla: `.env.example`). Solo se lee al arrancar.

| Variable | Para qué | Por defecto |
|---|---|---|
| `GF_RUTA_ARCHIVO` | Carpeta del archivo de facturas del cliente (solo lectura). Si se deja vacía se elige desde *Configuración* y se guarda en `db.json` | `../Albereda36` |
| `PORT` | Puerto | `4360` |
| `GF_CARPETA_IMPORTADAS` | Dónde se guardan las facturas que entran por Importar | `data/archivo` |
| `GF_HOST` | Dirección en la que escucha. Cualquier valor que no sea local exige contraseña | `127.0.0.1` (y `::1`) |
| `GF_CLAVE_ACCESO` | Contraseña (HTTP Basic, ≥ 8 caracteres) si `GF_HOST` abre a la red | — |
| `GF_API_URL` / `GF_API_KEY` | Servidor de archivos de la oficina (opcional, aún no existe) | — |
| `GF_ACTUALIZACIONES_URL` | Carpeta del canal de actualizaciones (https). Para GitHub: `https://api.github.com/repos/USUARIO/REPO/contents/actualizaciones` | — (sin actualizaciones) |
| `GF_ACTUALIZACIONES_TOKEN` | Clave de solo lectura del canal (token de GitHub con *Contents: Read-only* sobre ese único repositorio) | — |

## Datos

| Ruta | Contenido |
|---|---|
| `data/db.json` | Base de datos (escritura atómica `.tmp` + rename) |
| `data/copias/` | Copia diaria automática de `db.json` (se guardan 30) |
| `data/archivo/` | Facturas importadas: `Cliente/Año/Trimestre/Emitidas\|Recibidas\|Otros/` |
| `data/archivo/_papelera/` | Importadas que se borraron desde el programa |
| `data/entrada/` | Importaciones analizadas sin confirmar (se borran a los 14 días) |
| `data/uploads/` | Documentos sueltos subidos a mano |

**El archivo original del cliente nunca se modifica**: el programa solo lo lee.
Corregir un documento en *Revisar* cambia sus datos, no mueve el fichero.

## Pestañas

1. **Inicio** — pendientes del día (importaciones, avisos, importes) y cifras.
2. **📁 Archivo** — explorador Cliente › Año › Trimestre › Tipo › Mes › Semana › Día.
   Los niveles de calendario salen de `fechaEfectiva` (fecha del PDF, del nombre o de
   la factura; nunca la estimada del trimestre), y lo que no tiene fecha fiable cae en
   *(sin fecha exacta)*. Cada carpeta del árbol lleva su `filtro`, y la pantalla
   selecciona con él: servidor y navegador no pueden discrepar. Búsqueda por nombre,
   número, proveedor o importe. *Ver*, *Carpeta* y *Ficha* (con *Corregir*).
3. **📥 Importar** — arrastrar PDF → propuesta por fichero → revisar → importar.
4. **⚠ Revisar** — arriba, los **bloques** que el programa resuelve solo
   (`GET /api/revision/propuestas`): copias repetidas y no-facturas (`seguro`, no tocan
   ninguna cifra), serie propia archivada como gasto y emitidas fuera de trimestre
   (`revisar`), gastos fuera de trimestre (`opcional`, puede ser correcto). Se aprueban
   enteros con `POST /api/revision/aplicar`. Debajo, lo que exige criterio humano.
   Pestaña *Importes*: leídos del PDF por confirmar, y sin importe.
5. **🕘 Trazabilidad** — `DB.movimientos`: cada cambio con su antes/después, si fue
   automático o de una persona, el motivo y el lote. Filtros, CSV y *Deshacer*
   (`POST /api/movimientos/:id/deshacer`, restaura campos y facturas).
6. **Facturas** — filtros por tipo, cliente, año, trimestre y estado del importe;
   sumas de base, cuota e importe; exportación a Excel de lo filtrado.
7. **Clientes** — fichas; el NIF identifica sus facturas al importar.
8. **Informes** — por periodo (`3T-2025`, `2025`…): base e IVA de emitidas y
   recibidas, resultado del IVA y avisos de importes sin confirmar.
9. **Documentos · Grupos · Mapa · Configuración**. La carpeta de las facturas es lo
   primero de *Configuración*: *Buscarla por mí* la localiza sola y *Comprobar* dice
   cuántos de los documentos aparecen dentro.

## Dónde están las facturas

El programa se entrega sin saberlo: cambia de ordenador. Sin esa carpeta no abre ni un
PDF, así que el fallo se cuenta en vez de esconderse.

- `GET /api/archivo/estado` responde con números: cuántos de los documentos se
  encuentran, y candidatas si no hay ninguno. `POST /api/archivo/comprobar` hace lo
  mismo con una carpeta que aún no se ha guardado.
- `POST /api/archivo/buscar-carpeta` mira en los sitios habituales (la carpeta del
  programa, Descargas, Documentos, Escritorio, OneDrive, D:, E:) hasta 3 niveles y
  puntúa cada candidata por cuántas carpetas de primer nivel del archivo contiene.
- Si la ruta guardada no aparece, se busca el fichero **por su nombre** dentro de la
  carpeta del archivo (`indiceDelArchivo`, 30 s de caché); entre varias copias gana la
  que más tramos comparte con la ruta original. Así una carpeta renombrada no rompe nada.
- Cuando aun así no aparece, `porQueNoAparece()` dice qué hacer, no solo que falló.
- En pantalla: aviso naranja permanente mientras falte la carpeta, y `Ver` consulta
  `GET /api/archivo/localizar/{id}` **antes** de abrir nada, para no dejar una pestaña
  en blanco con un error técnico.

El visor (`.visor`) abre el documento pegado a la derecha y deja la lista usable: es lo
que permite bajar por los importes leyendo cada PDF sin cambiar de pantalla.

## Cómo decide la importación (`lib/`)

| Módulo | Qué hace |
|---|---|
| `lib/patrones.json` | Catálogo de 84 formatos de nombre. **Generado** desde `pipeline/patrones.py` (no editar a mano). Mismo patrón que Python en los 1.185 nombres reales |
| `lib/clasificador.js` | Cliente (serie propia o NIF), fecha → año y trimestre, emitida/recibida, y lo aprendido del propio archivo |
| `lib/pdftexto.js` | Texto de los PDF sin dependencias (Flate, ASCII85, WinAnsi, tabla ToUnicode de cada fuente siguiendo `Tf`). Lee 820 de los 1.039 PDF de factura del archivo; el resto son escaneos sin texto |
| `lib/datosfactura.js` | Fecha, número, NIF (con dígito de control) e importes. Un importe solo se propone si cuadra: base × (1 + IVA − IRPF) = total |
| `lib/importar.js` | Espera, avisos (duplicado exacto, número repetido, serie que no sigue la numeración), confirmación y archivado |

Reglas que conviene conocer:

- **Emitida solo con serie propia** del cliente *y* numeración coherente (la
  `1-000367` no es de Alfonso: su numeración de 2022 va del 1 al 87).
- Desde el texto del PDF **no se decide** si es emitida o recibida (las facturas a
  dos columnas mezclan el orden): lo que no tiene serie propia se propone como
  recibida y se pide confirmarlo.
- Si el nombre lleva año y el PDF da una fecha de otro año, manda el nombre.
- Nada con aviso grave se importa sin marcar «Importar igualmente».

Para regenerar el catálogo tras tocar `pipeline/patrones.py`, ver el historial del
proyecto: se exporta cada patrón cambiando `(?P<` por `(?<` y `\w` por
`[\p{L}\p{N}_]` (flags `iu`), y se comprueba la paridad sobre los nombres reales.

## Actualizaciones

El cliente instala el programa **una vez**. Después, cada versión nueva le llega sola.

- **Qué viaja:** solo código. `lib/actualizar.js` tiene la lista cerrada de lo que un
  paquete puede escribir (`server.js`, `lib/`, `public/`, `pipeline/`, docs).
  `data/`, `.env` e `INICIAR.bat` no están, y un paquete con una sola ruta fuera de la
  lista se rechaza entero antes de escribir nada.
- **Firma:** Ed25519 (de serie en Node). Se firma `gestion-fichas|versión|sha256 del
  paquete`, así que no vale ni retocar el paquete ni presentar uno viejo como nuevo. La
  pública va en `lib/firma-publica.js`; la privada, fuera del proyecto, en
  `%USERPROFILE%\.gestion-fichas\firma-privada.pem`. **Si se pierde la privada, hay que
  reinstalar a mano en el cliente**: guárdala también en el gestor de contraseñas.
- **Cuándo se instala:** al abrir el programa, antes de arrancar el servidor (nadie está a
  medio trabajo). Con el programa abierto, se comprueba a los 15 s y cada 6 h; si hay
  versión nueva sale un aviso con *Instalar ahora*.
- **Si sale mal:** antes de escribir se guarda la versión actual en
  `data/actualizacion/copias/` (se guardan 3) y una copia de `db.json`. La versión nueva
  queda *pendiente de confirmar* hasta llevar 30 s en marcha; si el servidor se cae antes,
  el lanzador la retira, vuelve a la anterior y la marca como descartada (no reintenta en
  bucle). En *Configuración* se puede volver atrás a mano.
- **Sin conexión:** se sigue con la versión que hay. Un error del canal nunca impide abrir.
- **`INICIAR.bat` no se actualiza nunca:** Windows lee los `.bat` a trozos mientras los
  ejecuta, y reescribir uno en marcha lo rompe. Por eso toda la lógica está en el lanzador.
- **Códigos de salida del servidor:** 3 = reiníciame (tras instalar), 4 = puerto ocupado,
  5 = base de datos ilegible. Ni 4 ni 5 se confunden con una versión rota.
- **Instalación a medias** (corte de luz, antivirus que bloquea un fichero): `package.json`
  se escribe el último y la marca de pendiente solo lleva `completa` cuando está todo
  escrito. Si falla una escritura se deshace en el acto; si queda a medias, el lanzador la
  deshace antes de arrancar (sin necesitar conexión) y lo incompleto no se confirma nunca.
- **Volver atrás** va a la versión de la que se vino (`estado.instalaciones`), no a la copia
  con el número más alto.
- **Publicar y el ZIP** pasan por el mismo detector de claves (`herramientas/secretos.js`).

### Publicar una versión

```
node herramientas/publicar.js 1.1.1 "Qué cambia, en una frase" --subir
```

Sube la versión en `package.json`, empaqueta exactamente los ficheros que el cliente
aceptará, lo firma, comprueba que la firma valida con la pública del programa y deja
`ultima.json` + `gestion-fichas-1.1.1.gfpaq` en
`../gestion-fichas-actualizaciones/actualizaciones/` (un repositorio **privado**); con
`--subir` hace el commit y el push. `herramientas/` no va nunca al cliente.
La clave se crea una sola vez con `node herramientas/publicar.js clave`.

## Pipeline de Python (opcional)

`pipeline/` escanea y audita el archivo completo y lo vuelca en el programa
(`python -m pipeline cargar-app --aplicar`). Al actualizar **respeta el trabajo
hecho en el programa**: no toca documentos marcados como revisados, nunca manda
importes ni estado de cobro, conserva los avisos puestos al leer los PDF y no
cambia las columnas elegidas en los informes. Detalles en `pipeline/README.md`.

## API interna

```
GET/POST            /api/{grupos|sujetos|facturas|documentos|informes}
GET/PUT/DELETE      /api/{coleccion}/{id}
GET  /api/stats                       GET  /api/grafo
GET/PUT /api/config
GET  /api/archivo/arbol               GET  /api/archivo/ver/{documentoId}
GET  /api/archivo/estado              GET  /api/archivo/localizar/{documentoId}
POST /api/archivo/comprobar {ruta}    POST /api/archivo/buscar-carpeta
POST /api/archivo/abrir {documentoId, soloCarpeta}      (solo desde este equipo)
POST /api/importar/analizar {archivos:[{nombre, contenidoBase64}], lote?, comun?}
POST /api/importar/confirmar {lote, items:[…]}          POST /api/importar/descartar {lote, tokens?}
GET  /api/importar/pendientes         GET  /api/importar/ver/{lote}/{token}
POST /api/revision/auditar            POST /api/revision/leer-importes
GET  /api/revision/propuestas         POST /api/revision/aplicar {bloque, ids?}
GET  /api/movimientos?tipo=&desde=&hasta=&busca=&limite=
POST /api/movimientos/{id}/deshacer
POST /api/revision/documento/{id} {cliente?, ejercicio?, trimestre?, sentido?, revisado, nota}
POST /api/revision/factura/{id} {base, iva, irpf, total}
GET  /api/informes/{id}/datos         GET  /api/informes/{id}/export   (CSV para Excel)
POST /api/copia                       (copia manual de db.json)
GET  /api/actualizacion               POST /api/actualizacion/buscar
POST /api/actualizacion/instalar      POST /api/actualizacion/volver   (solo desde este equipo)
POST /api/sincronizar                 POST /api/probar-conexion
```

Las peticiones que cambian datos se rechazan si vienen de otra web (cabecera
`Origin` distinta). En modo local, además, solo se atiende a `localhost`, `127.0.0.1` y
`[::1]` en la cabecera `Host`: así una web cuyo dominio pase a apuntar a este equipo (DNS
rebinding) no puede leer ni cambiar nada. `GF_API_KEY` nunca se guarda en `db.json`.

**La base de datos no se sustituye nunca por la de ejemplo** salvo que `db.json` no exista.
Si existe y no se puede leer (bloqueada, a medias), se reintenta y, si no, el programa se
para con el código 5 sin tocarla y dice dónde están las copias.

### Contrato del servidor de archivos de la oficina (cuando exista)

```
GET {GF_API_URL}/ficheros            Authorization: Bearer {GF_API_KEY}
200 → [{ "nombre", "tipo", "sujetoNif"?, "contenidoBase64"?, "url"?, "tamano"? }]
```
