"""ENTRADA de archivos: el buzon donde la gestoria suelta lo que llega.

Simula el dia a dia: llega un PDF suelto, el pipeline decide de quien es, de
que trimestre y de que tipo, y lo archiva en su sitio canonico. Si no puede
decidirlo, lo dice y lo aparta; nunca adivina en silencio.

modo="simular" -> no copia nada, solo explica que haria.
modo="aplicar" -> copia al archivo canonico y VACIA el buzon: cada fichero
                  procesado pasa a _ENTRADA/_PROCESADOS/<fecha>/, asi una
                  segunda pasada no lo vuelve a archivar.

Para el dia a dia del despacho, lo previsto es la pestana "Importar" del
programa, que hace esto mismo sin Python y registra las facturas en la app.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime
import shutil
from dataclasses import dataclass, asdict
from pathlib import Path

import patrones
from config import asegurar_fuera_de_datos
from escanear import sha256_de
from modelo import Documento, Inventario, TipoDoc
from normalizar import clasificar_ruta


@dataclass
class ResultadoEntrada:
    archivo: str
    decision: str          # archivado | duplicado | numero_repetido | sin_clasificar
    destino: str | None
    motivo: str
    cliente: str | None = None
    ejercicio: int | None = None
    trimestre: str | None = None
    tipo_doc: str | None = None
    confianza: float = 0.0


def _pista(buzon: Path) -> dict:
    """_ENTRADA/pista.json permite forzar cliente/ejercicio de un lote.

    Ejemplo: {"cliente": "Maxi", "ejercicio": 2025}
    """
    p = buzon / "pista.json"
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def procesar_entrada(buzon: Path, destino: Path, inventario: Inventario,
                     modo: str = "simular") -> list[ResultadoEntrada]:
    """Clasifica y archiva lo que haya en el buzon."""
    if modo not in ("simular", "aplicar"):
        raise ValueError("modo debe ser 'simular' o 'aplicar'")
    asegurar_fuera_de_datos(buzon)
    asegurar_fuera_de_datos(destino)
    buzon.mkdir(parents=True, exist_ok=True)
    sin_clasificar = buzon / "_SIN_CLASIFICAR"
    pista = _pista(buzon)

    # Hashes ya conocidos: detectar que el archivo ya esta en el fondo.
    conocidos = {d.sha256: d.ruta_relativa
                 for d in inventario.documentos if d.sha256}
    if not conocidos and inventario.documentos:
        # Silencio peligroso: sin hashes NO se pueden detectar duplicados.
        print("AVISO: el inventario no tiene hashes (se genero con --sin-hash).\n"
              "       No se detectaran duplicados. Regenera con:  "
              "python -m pipeline escanear", file=sys.stderr)

    # Numeros de factura ya archivados: (cliente, tipo, ejercicio, numero).
    # Un fichero distinto con el mismo numero es, casi siempre, la misma
    # factura escaneada o descargada otra vez.
    def _num(n):
        m = re.search(r"(\d+)(?!.*\d)", str(n or ""))
        if not m:
            return None
        return ("R" if str(n).upper().startswith("R") else "") + str(int(m.group(1)))

    usados = {}
    for d in inventario.documentos:
        k = _num(d.numero)
        if k and d.cliente and d.ejercicio and d.tipo_doc == TipoDoc.EMITIDA.value:
            usados[(d.cliente, d.tipo_doc, d.ejercicio, k)] = d.ruta_relativa

    procesados = buzon / "_PROCESADOS" / datetime.now().strftime("%Y-%m-%d_%H%M%S")

    def _retirar(f: Path) -> None:
        """Saca del buzon lo ya procesado (solo en modo aplicar)."""
        if modo != "aplicar":
            return
        procesados.mkdir(parents=True, exist_ok=True)
        shutil.move(str(f), str(_sin_colision(procesados / f.name)))

    resultados: list[ResultadoEntrada] = []
    for f in sorted(buzon.iterdir()):
        if not f.is_file() or f.name == "pista.json":
            continue

        h = sha256_de(f)
        if h and h in conocidos:
            resultados.append(ResultadoEntrada(
                archivo=f.name, decision="duplicado", destino=None,
                motivo=f"ya existe en el archivo: {conocidos[h]}"))
            _retirar(f)
            continue

        # Se clasifica como si estuviera en la raiz: solo cuenta el nombre.
        clasif = clasificar_ruta(f.name, f.name)
        patron, meta = patrones.clasificar(f.name)

        # El ejercicio puede venir en la propia serie ('041-2025_...').
        if not clasif.get("ejercicio") and meta.get("anio"):
            try:
                clasif["ejercicio"] = int(meta["anio"])
                clasif["incidencias"].append("ejercicio_desde_la_serie")
            except (TypeError, ValueError):
                pass

        # La pista del lote rellena lo que el nombre no da.
        for campo in ("cliente", "ejercicio", "trimestre"):
            if not clasif.get(campo) and pista.get(campo):
                clasif[campo] = pista[campo]
                clasif["incidencias"].append(f"{campo}_desde_pista_json")

        doc = Documento(
            ruta_relativa=f.name, nombre=f.name,
            extension=f.suffix.lower().lstrip("."), tamano=f.stat().st_size,
            sha256=h, patron_detectado=patron, numero=meta.get("num"),
            contraparte=meta.get("contraparte"), nif=meta.get("nif"),
            **clasif)

        clasificable = bool(doc.cliente and doc.ejercicio and doc.trimestre
                            and doc.tipo_doc not in (TipoDoc.DESCONOCIDO.value,))
        if not clasificable:
            faltan = [c for c in ("cliente", "ejercicio", "trimestre")
                      if not getattr(doc, c)]
            motivo = ("no se puede determinar: " + ", ".join(faltan)) if faltan \
                else "tipo de documento indeterminado"
            if modo == "aplicar":
                sin_clasificar.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), str(_sin_colision(sin_clasificar / f.name)))
            resultados.append(ResultadoEntrada(
                archivo=f.name, decision="sin_clasificar",
                destino=str(sin_clasificar / f.name), motivo=motivo,
                cliente=doc.cliente, ejercicio=doc.ejercicio,
                trimestre=doc.trimestre, tipo_doc=doc.tipo_doc,
                confianza=doc.confianza))
            continue

        clave_num = (doc.cliente, doc.tipo_doc, doc.ejercicio, _num(doc.numero))
        if clave_num[3] and clave_num in usados:
            if modo == "aplicar":
                sin_clasificar.mkdir(parents=True, exist_ok=True)
                shutil.move(str(f), str(_sin_colision(sin_clasificar / f.name)))
            resultados.append(ResultadoEntrada(
                archivo=f.name, decision="numero_repetido",
                destino=str(sin_clasificar / f.name),
                motivo=(f"el numero {doc.numero} de {doc.ejercicio} ya existe: "
                        f"{usados[clave_num]}. Comprueba si es la misma factura."),
                cliente=doc.cliente, ejercicio=doc.ejercicio,
                trimestre=doc.trimestre, tipo_doc=doc.tipo_doc,
                confianza=doc.confianza))
            continue

        sub = destino / doc.ruta_canonica()
        final = sub / doc.clave_canonica()
        if modo == "aplicar":
            sub.mkdir(parents=True, exist_ok=True)
            final = _sin_colision(final)
            shutil.copy2(f, final)
            _retirar(f)
        if clave_num[3]:
            usados[clave_num] = f"{f.name} (en esta misma pasada)"
        resultados.append(ResultadoEntrada(
            archivo=f.name, decision="archivado", destino=str(final),
            motivo=f"clasificado por {doc.origen_tipo}/{doc.origen_trimestre}",
            cliente=doc.cliente, ejercicio=doc.ejercicio,
            trimestre=doc.trimestre, tipo_doc=doc.tipo_doc,
            confianza=doc.confianza))
    return resultados


def _sin_colision(ruta: Path) -> Path:
    """Evita pisar un archivo existente anadiendo -2, -3..."""
    if not ruta.exists():
        return ruta
    for i in range(2, 500):
        cand = ruta.with_name(f"{ruta.stem}-{i}{ruta.suffix}")
        if not cand.exists():
            return cand
    raise RuntimeError(f"demasiadas colisiones para {ruta}")


def _pdf_minimo(texto: str) -> bytes:
    """PDF valido minimo, generado con la stdlib. Solo para la demo."""
    cuerpo = (f"BT /F1 12 Tf 60 760 Td ({texto[:70]}) Tj ET").encode("latin-1",
                                                                     "replace")
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
        b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
        b"<< /Length " + str(len(cuerpo)).encode() + b" >>\nstream\n" + cuerpo
        + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + o + b"\nendobj\n"
    inicio_xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n".encode() + b"0000000000 65535 f \n"
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    out += (f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\n"
            f"startxref\n{inicio_xref}\n%%EOF\n").encode()
    return bytes(out)


# Casos de demo: cubren las tres rutas de decision del buzon.
# Los nombres imitan los formatos REALES de cada cliente.
DEMO_NUEVOS = [
    ("Factura 2025-061 (12-09-25).pdf", "Urbano - emitida, trimestre por fecha"),
    ("Factura 2025-062 (28-09-25).pdf", "Urbano - emitida, trimestre por fecha"),
    ("041-2025_TALLERES VEGA SL.pdf", "Maxi - emitida, serie propia NNN-AAAA"),
    ("R007-2025_SERGIO MOLINA.pdf", "Maxi - rectificativa (prefijo R)"),
    ("Factura 1-000410.pdf", "Alfonso - emitida, serie 1-NNNNNN"),
    ("Factura_10-25.pdf", "proveedor - mes-anio en el nombre"),
    ("A96933510_2025_F02000R-88123.pdf", "recibida - NIF_anio_serie"),
    ("escaneo movil 4471.pdf", "IMPOSIBLE de clasificar: sin ninguna pista"),
    ("documento.pdf", "IMPOSIBLE de clasificar: nombre generico"),
]


def crear_buzon_demo(buzon: Path, inventario: Inventario, raiz: Path,
                     n: int = 12) -> list[str]:
    """Prepara el buzon para demostrar las TRES rutas de decision.

    - documentos nuevos que se archivan solos (PDF de demo generados aqui),
    - documentos que ya estan en el fondo -> duplicado (copias reales),
    - documentos imposibles de clasificar -> apartados para revision.

    Los PDF nuevos son sinteticos y llevan su origen escrito dentro: no se
    inventan facturas del cliente, solo se imita el FORMATO de sus nombres.
    """
    asegurar_fuera_de_datos(buzon)   # el unlink de abajo es irreversible
    buzon.mkdir(parents=True, exist_ok=True)
    for viejo in buzon.iterdir():
        if viejo.is_file():
            viejo.unlink()

    puestos: list[str] = []
    for nombre, descripcion in DEMO_NUEVOS[:max(0, n - 2)]:
        (buzon / nombre).write_bytes(
            _pdf_minimo(f"DEMO - {descripcion}"))
        puestos.append(f"{nombre}   [{descripcion}]")

    # Dos duplicados de verdad: copias literales de archivos del fondo.
    reales = [d for d in inventario.documentos
              if not d.duplicado_de and d.extension == "pdf"][:2]
    for d in reales:
        origen = raiz / d.ruta_relativa
        if origen.exists():
            shutil.copy2(origen, buzon / d.nombre)
            puestos.append(f"{d.nombre}   [copia real -> debe salir DUPLICADO]")
    return puestos


def informe_entrada(resultados: list[ResultadoEntrada], modo: str) -> str:
    """Informe legible de la pasada."""
    por = {"archivado": [], "duplicado": [], "numero_repetido": [], "sin_clasificar": []}
    for r in resultados:
        por[r.decision].append(r)

    L = [f"BUZON DE ENTRADA  (modo: {modo})", "=" * 70,
         f"Archivos procesados : {len(resultados)}",
         f"  archivados        : {len(por['archivado'])}",
         f"  duplicados        : {len(por['duplicado'])}",
         f"  numero repetido   : {len(por['numero_repetido'])}",
         f"  sin clasificar    : {len(por['sin_clasificar'])}", ""]
    if modo == "simular":
        L += ["  (SIMULACION: no se ha copiado ni un solo archivo)", ""]

    for titulo, clave in (("ARCHIVADOS", "archivado"),
                          ("DUPLICADOS (ya estaban en el fondo)", "duplicado"),
                          ("NUMERO REPETIDO (apartados en _SIN_CLASIFICAR)", "numero_repetido"),
                          ("SIN CLASIFICAR (requieren decision humana)",
                           "sin_clasificar")):
        L += [titulo, "-" * 70]
        if not por[clave]:
            L.append("  (ninguno)")
        for r in por[clave]:
            L.append(f"  {r.archivo}")
            if r.destino and clave == "archivado":
                L.append(f"      -> {Path(r.destino).parent}")
                L.append(f"      {r.cliente} {r.ejercicio} {r.trimestre} "
                         f"{r.tipo_doc} (confianza {r.confianza})")
            else:
                L.append(f"      {r.motivo}")
        L.append("")
    if modo == "aplicar":
        L += ["El buzon queda vacio: lo procesado esta en _ENTRADA/_PROCESADOS/.",
              "Para el uso diario esta la pestana Importar del programa.", ""]
    return "\n".join(L)


def guardar_informe(resultados: list[ResultadoEntrada], destino: Path) -> None:
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text(json.dumps([asdict(r) for r in resultados],
                                  indent=2, ensure_ascii=False),
                       encoding="utf-8")
