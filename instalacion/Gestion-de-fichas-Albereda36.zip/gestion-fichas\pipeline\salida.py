"""SALIDA de archivos: preparar un trimestre para enviar o presentar.

Construye _SALIDA/<cliente>/<ejercicio>/<trimestre>/ con los documentos
renombrados a la clave canonica, mas la relacion en CSV, un resumen legible
y un manifiesto con los hashes (trazabilidad de lo que se ha entregado).

NUNCA escribe dentro del archivo del cliente: solo copia desde el.
"""
from __future__ import annotations

import json
import shutil
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from config import CSV_ENCODING, CSV_SEP, asegurar_fuera_de_datos
from modelo import Inventario, Documento


@dataclass
class ResultadoSalida:
    cliente: str
    ejercicio: int
    trimestre: str
    destino: str
    esperados: int = 0
    copiados: int = 0
    colisiones: int = 0
    ausentes: list[str] = field(default_factory=list)
    modo: str = "simular"


def preparar_salida(inventario: Inventario, raiz: Path, cliente: str,
                    ejercicio: int, trimestre: str, destino_base: Path,
                    modo: str = "simular",
                    incluir_duplicados: bool = False) -> ResultadoSalida:
    """Reune el corte cliente/ejercicio/trimestre en una carpeta de entrega."""
    if modo not in ("simular", "aplicar"):
        raise ValueError("modo debe ser 'simular' o 'aplicar'")
    asegurar_fuera_de_datos(destino_base)

    docs = [d for d in inventario.documentos
            if d.cliente == cliente and d.ejercicio == ejercicio
            and d.trimestre == trimestre
            and (incluir_duplicados or not d.duplicado_de)]

    destino = destino_base / cliente / str(ejercicio) / trimestre
    res = ResultadoSalida(cliente=cliente, ejercicio=ejercicio,
                          trimestre=trimestre, destino=str(destino),
                          esperados=len(docs), modo=modo)

    manifiesto = []
    for d in docs:
        origen = raiz / d.ruta_relativa
        if not origen.exists():
            res.ausentes.append(d.ruta_relativa)
            continue
        carpeta = destino / _carpeta_tipo(d)
        final = carpeta / d.clave_canonica()
        if modo == "aplicar":
            carpeta.mkdir(parents=True, exist_ok=True)
            final2 = _sin_colision(final)
            if final2 != final:
                res.colisiones += 1
            shutil.copy2(origen, final2)
            final = final2
        res.copiados += 1
        manifiesto.append({"origen": d.ruta_relativa,
                           "destino": final.name,
                           "sha256": d.sha256,
                           "tipo": d.tipo_doc,
                           "fecha": d.fecha_documento,
                           "numero": d.numero})

    if modo == "aplicar":
        destino.mkdir(parents=True, exist_ok=True)
        _escribir_relacion(docs, destino / "RELACION.csv")
        (destino / "RESUMEN.txt").write_text(
            resumen_texto(res, docs), encoding="utf-8")
        (destino / "MANIFIESTO.json").write_text(
            json.dumps(manifiesto, indent=2, ensure_ascii=False),
            encoding="utf-8")

    # Verificacion dura: si no cuadra, que se note.
    if modo == "aplicar" and res.copiados + len(res.ausentes) != res.esperados:
        raise RuntimeError(
            f"descuadre: esperados={res.esperados} copiados={res.copiados} "
            f"ausentes={len(res.ausentes)}")
    return res


def _carpeta_tipo(d: Documento) -> str:
    return {"emitida": "EMITIDAS", "recibida": "RECIBIDAS"}.get(d.tipo_doc, "OTROS")


def _sin_colision(ruta: Path) -> Path:
    if not ruta.exists():
        return ruta
    for i in range(2, 500):
        cand = ruta.with_name(f"{ruta.stem}-{i}{ruta.suffix}")
        if not cand.exists():
            return cand
    raise RuntimeError(f"demasiadas colisiones para {ruta}")


def _escribir_relacion(docs: list[Documento], destino: Path) -> None:
    import csv
    cols = ["tipo_doc", "numero", "fecha_documento", "contraparte", "nif",
            "proveedor", "nombre", "ruta_relativa", "confianza", "incidencias"]
    with destino.open("w", newline="", encoding=CSV_ENCODING) as fh:
        w = csv.writer(fh, delimiter=CSV_SEP)
        w.writerow(cols)
        for d in sorted(docs, key=lambda x: (x.tipo_doc,
                                             x.fecha_documento or "",
                                             x.numero or "")):
            w.writerow([d.tipo_doc, d.numero or "", d.fecha_documento or "",
                        d.contraparte or "", d.nif or "", d.proveedor or "",
                        d.nombre, d.ruta_relativa, d.confianza,
                        " | ".join(d.incidencias)])


def resumen_texto(res: ResultadoSalida, docs: list[Documento]) -> str:
    emitidas = [d for d in docs if d.tipo_doc == "emitida"]
    recibidas = [d for d in docs if d.tipo_doc == "recibida"]
    otros = [d for d in docs if d.tipo_doc not in ("emitida", "recibida")]
    con_inc = [d for d in docs if d.incidencias]

    L = [f"ENTREGA {res.cliente} · {res.ejercicio} · {res.trimestre}",
         "=" * 60,
         f"Documentos          : {res.esperados}",
         f"  emitidas          : {len(emitidas)}",
         f"  recibidas         : {len(recibidas)}",
         f"  otros             : {len(otros)}",
         f"Con incidencias     : {len(con_inc)}", ""]
    if res.ausentes:
        L += ["ATENCION - no encontrados en origen:"] + \
             [f"  {a}" for a in res.ausentes] + [""]
    if con_inc:
        L += ["REVISAR:"]
        for d in con_inc[:20]:
            L.append(f"  {d.nombre}: {' | '.join(d.incidencias)}")
        L.append("")
    L += ["NOTA: los importes (base, IVA, total) no se rellenan todavia.",
          "      Requieren leer el contenido del PDF (fase siguiente)."]
    return "\n".join(L)


def empaquetar(carpeta: Path, destino_zip: Path) -> Path:
    """Comprime la carpeta de entrega con la stdlib."""
    destino_zip.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destino_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(carpeta.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(carpeta).as_posix())
    return destino_zip


def cortes_disponibles(inventario: Inventario) -> list[tuple]:
    """Lista los (cliente, ejercicio, trimestre) que se pueden entregar."""
    vistos = {}
    for d in inventario.documentos:
        if d.cliente and d.ejercicio and d.trimestre and not d.duplicado_de:
            k = (d.cliente, d.ejercicio, d.trimestre)
            vistos[k] = vistos.get(k, 0) + 1
    return sorted((c, e, t, n) for (c, e, t), n in vistos.items())
