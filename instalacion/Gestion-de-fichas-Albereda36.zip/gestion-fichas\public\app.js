'use strict';

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
async function api(method, path, body) {
  const opt = { method, headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch('/api/' + path, opt);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || ('Error ' + r.status));
  return data;
}
const get = (p) => api('GET', p);

function toast(msg, isErr) {
  const box = document.getElementById('toast');
  const t = document.createElement('div');
  t.className = 'toast-item' + (isErr ? ' err' : '');
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

// Crea un elemento a partir de HTML. Se usa <template> y no <div>: dentro de
// un <div> el navegador descarta las etiquetas <tr>, <td> y <thead> sueltas, y
// las tablas se quedaban vacías.
function h(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const eur = (n) => (Number(n) || 0).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
const fdate = (s) => s ? new Date(s).toLocaleDateString('es-ES') : '—';

// ---------------------------------------------------------------------------
// Modal genérico basado en especificación de campos
// ---------------------------------------------------------------------------
function openModal({ title, fields, values = {}, onSave, saveLabel = 'Guardar' }) {
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg"></div>');
  const modal = h(`<div class="modal"><header><strong>${esc(title)}</strong><button class="btn-ghost" data-x>✕</button></header><div class="body"></div><footer><button class="btn" data-cancel>Cancelar</button><button class="btn btn-accent" data-save>${esc(saveLabel)}</button></footer></div>`);
  const body = modal.querySelector('.body');

  for (const f of fields) {
    if (f.type === 'group2') { // dos campos en fila
      const wrap = h('<div class="grid-2"></div>');
      f.fields.forEach((sf) => wrap.appendChild(fieldNode(sf, values[sf.name])));
      body.appendChild(wrap);
    } else {
      body.appendChild(fieldNode(f, values[f.name]));
    }
  }

  function fieldNode(f, val) {
    const wrap = h('<div class="field"></div>');
    wrap.appendChild(h(`<label>${esc(f.label)}${f.required ? ' *' : ''}</label>`));
    let input;
    if (f.type === 'textarea') {
      input = h('<textarea></textarea>'); input.value = val || '';
    } else if (f.type === 'select') {
      input = h('<select></select>');
      (f.options || []).forEach((o) => {
        const op = h(`<option value="${esc(o.value)}">${esc(o.label)}</option>`);
        if (String(o.value) === String(val ?? f.default ?? '')) op.selected = true;
        input.appendChild(op);
      });
    } else if (f.type === 'checks') {
      input = h('<div class="checks"></div>');
      const sel = new Set(Array.isArray(val) ? val.map(String) : []);
      (f.options || []).forEach((o) => {
        const lb = h(`<label><input type="checkbox" value="${esc(o.value)}"> ${esc(o.label)}</label>`);
        if (sel.has(String(o.value))) lb.querySelector('input').checked = true;
        input.appendChild(lb);
      });
    } else if (f.type === 'subfields') {
      input = buildSubfields(val || []);
    } else if (f.type === 'file') {
      input = h('<input type="file">');
    } else {
      input = h(`<input type="${f.type || 'text'}">`);
      if (val != null) input.value = val;
      if (f.step) input.step = f.step;
      // Sugerencias al escribir (se puede poner otra cosa).
      if (Array.isArray(f.suggestions) && f.suggestions.length) {
        const id = 'dl-' + f.name;
        wrap.appendChild(h(`<datalist id="${id}">${f.suggestions.map((s) => `<option value="${esc(s)}">`).join('')}</datalist>`));
        input.setAttribute('list', id);
      }
    }
    input.dataset.name = f.name;
    input._spec = f;
    wrap.appendChild(input);
    if (f.hint) wrap.appendChild(h(`<div class="hint">${esc(f.hint)}</div>`));
    return wrap;
  }

  function buildSubfields(rows) {
    const box = h('<div class="subfields"></div>');
    const list = h('<div class="sf-list"></div>');
    const add = (r = {}) => list.appendChild(h(
      `<div class="subfield-row"><input placeholder="clave" value="${esc(r.key || '')}" data-k><input placeholder="etiqueta visible" value="${esc(r.label || '')}" data-l><button type="button" class="btn btn-sm btn-danger" data-del>✕</button></div>`));
    (rows || []).forEach(add);
    box.appendChild(list);
    const btn = h('<button type="button" class="btn btn-sm">+ Campo personalizado</button>');
    btn.onclick = () => add();
    list.addEventListener('click', (e) => { if (e.target.dataset.del !== undefined) e.target.closest('.subfield-row').remove(); });
    box.appendChild(btn);
    box._read = () => [...list.querySelectorAll('.subfield-row')].map((row) => ({
      key: row.querySelector('[data-k]').value.trim(),
      label: row.querySelector('[data-l]').value.trim() || row.querySelector('[data-k]').value.trim(),
      type: 'text',
    })).filter((x) => x.key);
    return box;
  }

  function collect() {
    const out = {};
    body.querySelectorAll('[data-name]').forEach((input) => {
      const f = input._spec;
      if (f.type === 'checks') out[f.name] = [...input.querySelectorAll('input:checked')].map((i) => i.value);
      else if (f.type === 'subfields') out[f.name] = input._read();
      else if (f.type === 'number') out[f.name] = input.value === '' ? null : Number(input.value);
      else if (f.type === 'file') out[f.name] = input.files[0] || null;
      else out[f.name] = input.value;
    });
    return out;
  }

  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  modal.querySelector('[data-x]').onclick = close;
  modal.querySelector('[data-cancel]').onclick = close;
  bg.onclick = (e) => { if (e.target === bg) close(); };
  modal.querySelector('[data-save]').onclick = async () => {
    try { await onSave(collect(), close); } catch (err) { toast(err.message, true); }
  };

  bg.appendChild(modal);
  root.appendChild(bg);
  const first = body.querySelector('input, select, textarea');
  if (first) first.focus();
}

function confirmar(msg, fn) {
  openModal({
    title: 'Confirmar', saveLabel: 'Sí, continuar',
    fields: [{ name: '_', type: 'textarea', label: msg }],
    values: {}, onSave: async (_v, close) => { close(); await fn(); },
  });
  // reemplaza el textarea por texto plano
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (ta) { const p = h(`<p>${esc(msg)}</p>`); ta.replaceWith(p); }
}

// ---------------------------------------------------------------------------
// Vistas
// ---------------------------------------------------------------------------
const view = document.getElementById('view');
let CACHE = {};

async function refreshCache() {
  const [grupos, sujetos, facturas, documentos, informes, config, st] = await Promise.all([
    get('grupos'), get('sujetos'), get('facturas'), get('documentos'), get('informes'), get('config'), get('stats'),
  ]);
  CACHE = { grupos, sujetos, facturas, documentos, informes, config, st };
  CACHE.facturaDeDoc = new Map(facturas.filter((f) => f.documentoId).map((f) => [f.documentoId, f]));
  CACHE.facturasDeDoc = agruparPorDoc(facturas);
  pintarCabecera();
}
const facturasDe = (id) => (CACHE.facturasDeDoc && CACHE.facturasDeDoc.get(id)) || [];
function agruparPorDoc(facturas) {
  const m = new Map();
  for (const f of facturas) if (f.documentoId) { if (!m.has(f.documentoId)) m.set(f.documentoId, []); m.get(f.documentoId).push(f); }
  return m;
}

// Contadores de las pestañas y el botón de sincronizar (solo si hay API).
function pintarCabecera() {
  const st = CACHE.st || {};
  const badge = (id, n) => { const b = document.getElementById(id); if (!b) return; b.hidden = !n; b.textContent = n > 999 ? '999+' : n; };
  badge('badge-importar', st.importacionesEnEspera || 0);
  badge('badge-revisar', (st.avisosPendientes || 0) + (st.importePorConfirmar || 0));
  const marca = document.querySelector('.brand small');
  if (marca && st.version) marca.textContent = 'Asesoría Albereda 36, S.L. · versión ' + st.version;
  const sync = document.getElementById('sync-state');
  const btn = document.getElementById('btn-sync');
  sync.hidden = btn.hidden = !st.apiConfigurada;
  sync.textContent = st.sincronizado ? 'Sincronizado ' + new Date(st.sincronizado).toLocaleString('es-ES') : 'Sin sincronizar';
}

const nombreGrupo = (id) => (CACHE.grupos.find((g) => g.id === id) || {}).nombre || '—';
const nombreSujeto = (id) => (CACHE.sujetos.find((s) => s.id === id) || {}).nombre || '(sin cliente)';

// ---- Datos comunes de archivo -------------------------------------------
const TRIMS = ['1T', '2T', '3T', '4T'];
const TIPOS_DOC = [
  { v: 'emitida', l: 'Emitida (ingreso)' },
  { v: 'recibida', l: 'Recibida (gasto)' },
  { v: 'hacienda', l: 'Hacienda (impuestos)' },
  { v: 'otro', l: 'Otro documento' },
];
const clientesArchivo = () => CACHE.sujetos.map((s) => ({ id: s.id, alias: s.aliasArchivo || s.nombre, nombre: s.nombre }));
const aliasDeId = (id) => (clientesArchivo().find((c) => c.id === id) || {}).alias || '';
const opciones = (lista, sel, vacio) =>
  (vacio !== undefined ? `<option value="">${esc(vacio)}</option>` : '') +
  lista.map((o) => `<option value="${esc(o.v)}"${String(o.v) === String(sel ?? '') ? ' selected' : ''}>${esc(o.l)}</option>`).join('');
const num = (v) => (v === '' || v == null || Number.isNaN(Number(v)) ? null : Number(v));
// Importes escritos a la española: «1.500» son mil quinientos y «1.234,56» o
// «1234,56» llevan coma decimal. Antes «1.500» se quedaba en 1,50 €.
const aImporte = (v) => {
  let s = String(v ?? '').replace(/[\s€]/g, '');
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  return s;
};
const aPct = (v) => String(v ?? '').replace(/[\s%]/g, '').replace(',', '.');
// Las mismas cuentas que el servidor (lib/importe.js): redondeo simétrico (un
// abono redondea como su factura), el desglose solo vale si sus bases suman la
// base, y el recargo de equivalencia suma al total pero no es IVA.
const r2 = (n) => { const x = Number(n) || 0; return Math.sign(x) * Math.round(Math.abs(x) * 100 + 1e-7) / 100 || 0; };
const RECARGO_DE = { 21: 5.2, 10: 1.4, 4: 0.5, 5: 0.62, 2: 0.26 };
const partesDe = (b, iva, desglose) => (Array.isArray(desglose) && desglose.length > 1
  && (b == null || Math.abs(desglose.reduce((a, p) => a + (Number(p.base) || 0), 0) - b) <= 0.01)
  ? desglose : null);
const cuotaDe = (b, iva, desglose) => r2((partesDe(b, iva, desglose) || [{ base: b || 0, iva: iva || 0 }])
  .reduce((a, p) => a + (Number(p.base) || 0) * (Number(p.iva) || 0) / 100, 0));
const recargoDe = (b, iva, desglose, re) => {
  if (!re) return 0;
  const d = partesDe(b, iva, desglose);
  return r2(d ? d.reduce((a, p) => a + (Number(p.base) || 0) * (RECARGO_DE[Number(p.iva)] || 0) / 100, 0) : (b || 0) * re / 100);
};
const totalDe = (b, iva, irpf, desglose, re) => r2((b || 0) + cuotaDe(b, iva, desglose) + recargoDe(b, iva, desglose, re) - (b || 0) * (irpf || 0) / 100);
// Un abono va en negativo; con varios tipos de IVA (desglose) la cuota se suma
// tipo a tipo. Si solo cuadra con el recargo de equivalencia de su tipo, cuadra.
const cuadra = (b, iva, irpf, t, desglose, re) => {
  const ok = (r) => Math.abs(totalDe(b, iva, irpf, desglose, r) - t) <= Math.max(0.05, Math.abs(t) * 0.001);
  return ok(re || 0) || (!re && !!RECARGO_DE[Number(iva)] && ok(RECARGO_DE[Number(iva)]));
};

// Avisos de un documento, en lenguaje de despacho.
function avisosDoc(d) {
  if (d.revisado) return [];
  const out = [];
  if (d.duplicadoDe) out.push({ cod: 'duplicado', corto: 'duplicado', texto: 'Es una copia idéntica de ' + d.duplicadoDe, cls: 'aviso-dup' });
  if (d.revisionManual) out.push({ cod: 'revisar', corto: 'revisar', texto: 'No se pudo saber el tipo o el trimestre.' });
  for (const parte of String(d.incidencias || '').split(/;\s*|\s\|\s/)) {
    const [codigo, ...resto] = parte.split(':');
    const det = resto.join(':').trim();
    if (codigo === 'trimestre_discrepante') {
      const m = det.match(/carpeta=(\S+)\s+fecha=(\S+)/);
      out.push({ cod: 'periodo', corto: 'trimestre dudoso', texto: m ? `La fecha del nombre es del ${m[2]} y está en la carpeta del ${m[1]}.` : 'La fecha no cuadra con la carpeta.' });
    } else if (codigo === 'ejercicio_discrepante') {
      const m = det.match(/carpeta=(\S+)\s+fecha=(\S+)/);
      out.push({ cod: 'periodo', corto: 'año dudoso', texto: m ? `La fecha es de ${m[2]} y está en la carpeta de ${m[1]}.` : 'El año no cuadra con la carpeta.' });
    } else if (codigo === 'trimestre_discrepante_pdf') {
      out.push({ cod: 'periodo', corto: 'trimestre dudoso', texto: det.charAt(0).toUpperCase() + det.slice(1) + '.' });
    } else if (codigo === 'sentido_dudoso') {
      out.push({ cod: 'sentido', corto: '¿emitida?', texto: 'Tiene la numeración propia del cliente pero está archivada como gasto.' });
    } else if (codigo === 'tipo_por_confirmar') {
      out.push({ cod: 'sentido', corto: '¿gasto o ingreso?', texto: 'Se colocó al ordenar la carpeta sin saber seguro si es un gasto o un ingreso: confírmalo.' });
    } else if (codigo === 'abono_dudoso') {
      out.push({ cod: 'abono', corto: '¿abono?', texto: /antes de la 1\.1\.4/.test(det)
        ? 'Parece un abono (' + det + '), pero suma en positivo. Si lo es, pulsa «Es abono» y pasa a negativo; si no, «No es abono».'
        : 'Parece un abono (' + det + '): está en negativo. Confírmalo o pulsa «No es abono».' });
    } else if (codigo === 'no_es_factura') {
      out.push({ cod: 'no-factura', corto: 'no es factura', texto: 'Es un justificante de pago, no una factura: no sirve para deducir IVA.' });
    } else if (codigo === 'factura_dudosa') {
      out.push({ cod: 'paginas', corto: 'factura dudosa', texto: 'PDF con varias facturas, ' + det.charAt(0).toLowerCase() + det.slice(1) + '. Ábrelo con «Ver»: la tabla de debajo enseña cada factura.' });
    } else if (codigo === 'factura_otro_periodo') {
      out.push({ cod: 'paginas', corto: 'otra fecha', texto: 'PDF con varias facturas: la ' + det + '. Cuenta en el IVA en su trimestre.' });
    }
  }
  return out;
}

// ---- La tabla hoja por hoja de debajo del visor -------------------------------
// Cada hoja del PDF (o la foto) se lee por separado y es una fila: fecha, quién,
// base, IVA, IRPF y total, que se pueden corregir ahí mismo. Si una hoja lleva
// varios tipos de IVA, cada tipo es una línea más («＋ IVA»). Una hoja que solo
// continúa la factura de la anterior sale debajo de ella y no suma. Debajo, el
// resumen desplegable (la flecha): la suma de todas las hojas por tipo de IVA
// —0, 4, 10 y 21 %—, el IRPF y el total. Cada cifra que se cambia arriba cambia
// el resumen al momento. La última columna es la doble revisión: ✓ si base ×
// tipo da el total y no hubo dudas al leer la hoja; si no, en rojo y por qué.
const TIPOS_TABLA = [0, 4, 10, 21];
function partesIva(base, iva, desglose) {
  if (Array.isArray(desglose) && desglose.length) return desglose.map((p) => ({ base: Number(p.base) || 0, iva: Number(p.iva) || 0 }));
  if (base === '' || base == null || !Number.isFinite(Number(base))) return [];
  return [{ base: Number(base), iva: Number(iva) || 0 }];
}
// filas: [{ clave, desde, hasta, numero, fecha, contraparte, base, iva, irpf, recargo, desglose, total, dudas, aviso }]
// alCambiar(clave, datos, cuadra): se llama al terminar de corregir una fila (puede
// devolver una promesa; si falla, su mensaje sale en la fila). Sin él, solo se mira.
function tablaHojas(filas, { alPagina, actual, alCambiar } = {}) {
  const fmt = (n) => (Number(n) || 0).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const enCaja = (n) => (n == null || n === '' || !Number.isFinite(Number(n)) ? '' : r2(n).toFixed(2).replace('.', ','));
  const leeNum = (v) => num(aImporte(v));
  // El modelo: lo que hay escrito ahora en cada fila.
  const M = filas.slice().sort((a, b) => a.desde - b.desde).map((f) => {
    const partes = partesIva(f.base, f.iva, f.desglose);
    const b = num(f.base), t = num(f.total);
    return {
      clave: f.clave, desde: f.desde, hasta: f.hasta || f.desde, numero: f.numero || '', fecha: f.fecha || '', contraparte: f.contraparte || '',
      partes: partes.length ? partes : [{ base: null, iva: f.iva == null || f.iva === '' ? 21 : Number(f.iva) || 0 }],
      irpf: num(f.irpf) || 0, recargo: num(f.recargo) || 0, total: t,
      // El total sigue a la base y al IVA mientras cuadre (o no haya); uno leído
      // que no cuadra se deja como está hasta que alguien lo toque.
      totalAuto: t == null || !Number(t) || (b != null && cuadra(b, Number(f.iva) || 0, num(f.irpf) || 0, t, f.desglose, num(f.recargo) || 0)),
      dudas: f.dudas || [], aviso: f.aviso || '', nota: '', tocada: false,
    };
  });
  const cuentas = (m) => {
    const con = m.partes.filter((p) => p.base != null);
    const base = con.length ? r2(con.reduce((a, p) => a + p.base, 0)) : null;
    const mayor = con.slice().sort((a, b) => Math.abs(b.base) - Math.abs(a.base))[0] || m.partes[0];
    const desglose = con.length > 1 ? con.map((p) => ({ base: p.base, iva: p.iva })) : null;
    return { base, iva: mayor.iva, desglose, calculado: base == null ? null : totalDe(base, mayor.iva, m.irpf, desglose, m.recargo) };
  };
  const motivosDe = (m) => {
    const c = cuentas(m), out = [];
    if (c.base == null || m.total == null || !Number(m.total)) out.push('sin importes');
    else if (!cuadra(c.base, c.iva, m.irpf, m.total, c.desglose, m.recargo)) out.push('no cuadra: con esa base y ese IVA el total sería ' + fmt(c.calculado));
    if (!m.tocada) for (const d of m.dudas) out.push(d);
    if (m.aviso) out.push(m.aviso);
    const raros = m.partes.filter((p) => p.base != null && !TIPOS_TABLA.includes(p.iva)).map((p) => p.iva + ' %');
    if (raros.length) out.push('tipo raro: ' + raros.join(', '));
    return out;
  };
  const ro = alCambiar ? '' : ' disabled';
  const selIva = (v, i) => `<select data-t="iva" data-i="${i}"${ro}>${[...new Set([...TIPOS_TABLA, Number(v) || 0])].sort((a, b) => a - b).map((t) => `<option value="${t}"${t === (Number(v) || 0) ? ' selected' : ''}>${String(t).replace('.', ',')} %</option>`).join('')}</select>`;
  const el = h(`<div class="tabla-pdf"><table>
    <thead><tr><th>Hoja</th><th>Nº factura</th><th>Fecha</th><th>Cliente / proveedor</th><th class="num">Base</th><th>IVA</th><th class="num">IRPF %</th><th class="num">Total</th><th>Revisión</th></tr></thead>
    <tbody></tbody></table>
    <details class="resumen-pdf"><summary></summary><div class="resumen-cuerpo"></div></details></div>`);
  const tbody = el.querySelector('tbody');
  const filaDe = (c) => M.find((m) => String(m.clave) === String(c));

  const pintarFilas = () => {
    tbody.innerHTML = M.map((m) => {
      const p0 = m.partes[0];
      const otras = m.partes.slice(1).map((p, k) => `<tr class="sub" data-c="${esc(m.clave)}" data-p="${m.desde}">
        <td></td><td colspan="3" class="hint">↳ otro tipo de IVA en esta hoja</td>
        <td class="num"><input data-t="base" data-i="${k + 1}" inputmode="decimal" value="${enCaja(p.base)}"${ro}></td><td>${selIva(p.iva, k + 1)}</td>
        <td></td><td></td><td>${alCambiar ? `<button type="button" class="btn-mini" data-quitar="${k + 1}" title="Quitar este tipo de IVA">✕</button>` : ''}</td></tr>`).join('');
      const siguen = [];
      for (let p = m.desde + 1; p <= m.hasta; p++) siguen.push(`<tr class="sigue" data-p="${p}" title="Ir a la hoja ${p}"><td>${p}</td><td colspan="8" class="hint">↳ sigue la factura de la hoja ${m.desde} (no suma otra vez)</td></tr>`);
      return `<tr class="hoja${actual === m.desde ? ' actual' : ''}" data-c="${esc(m.clave)}" data-p="${m.desde}">
        <td title="Ir a la hoja ${m.desde}">${m.desde}</td><td>${esc(m.numero || '—')}</td>
        <td><input type="date" data-t="fecha" value="${esc(String(m.fecha || '').slice(0, 10))}"${ro}></td>
        <td><input data-t="contraparte" value="${esc(m.contraparte)}" title="${esc(m.contraparte)}"${ro}></td>
        <td class="num"><input data-t="base" data-i="0" inputmode="decimal" value="${enCaja(p0.base)}"${ro}></td><td>${selIva(p0.iva, 0)}</td>
        <td class="num"><input data-t="irpf" inputmode="decimal" value="${m.irpf ? String(m.irpf).replace('.', ',') : ''}" placeholder="0"${ro}></td>
        <td class="num"><input data-t="total" inputmode="decimal" class="total" value="${enCaja(m.total)}"${ro}></td>
        <td class="rev"></td></tr>${otras}${siguen.join('')}`;
    }).join('');
    refrescar();
  };
  // Lo que no rehace las cajas (para no perder el cursor): la columna de
  // revisión de cada fila y el resumen.
  const refrescar = () => {
    const sum = { base: 0, total: 0, irpf: 0, recargo: 0, malas: 0, hojas: 0, porTipo: new Map() };
    for (const m of M) {
      const c = cuentas(m), mot = motivosDe(m);
      const tr = tbody.querySelector(`tr.hoja[data-c="${CSS.escape(String(m.clave))}"]`);
      if (tr) {
        tr.classList.toggle('mal', mot.length > 0);
        tr.querySelector('.rev').innerHTML = (mot.length ? '<span class="rev-mal">⚠ ' + esc(mot.join(' · ')) + '</span>' : '<span class="rev-ok">✓ cuadra</span>')
          + (m.nota ? ` <span class="${m.notaMal ? 'rev-mal' : 'hint'}">${esc(m.nota)}</span>` : '')
          + (alCambiar ? ' <button type="button" class="btn-mini" data-mas title="Esta hoja lleva otro tipo de IVA más">＋ IVA</button>' : '');
      }
      if (mot.length) sum.malas++;
      sum.hojas += m.hasta - m.desde + 1;
      sum.base += c.base || 0; sum.total += m.total || 0;
      sum.irpf += r2((c.base || 0) * m.irpf / 100);
      sum.recargo += recargoDe(c.base, c.iva, c.desglose, m.recargo);
      for (const p of m.partes) {
        if (p.base == null) continue;
        const x = sum.porTipo.get(p.iva) || { base: 0, cuota: 0 };
        x.base += p.base; x.cuota += r2(p.base * p.iva / 100);
        sum.porTipo.set(p.iva, x);
      }
    }
    const cuotas = [...sum.porTipo.values()].reduce((a, x) => a + x.cuota, 0);
    const tipos = [...sum.porTipo.keys()].sort((a, b) => a - b);
    el.querySelector('summary').innerHTML = `<b>Resumen</b> · ${M.length} factura${M.length === 1 ? '' : 's'} en ${sum.hojas} hoja${sum.hojas === 1 ? '' : 's'}`
      + ` · Base <b>${fmt(sum.base)}</b> · IVA <b>${fmt(cuotas)}</b>${sum.irpf ? ` · IRPF <b>−${fmt(sum.irpf)}</b>` : ''} · Total <b>${fmt(sum.total)} €</b>`
      + (sum.malas ? ` · <span class="rev-mal">${sum.malas} para revisar</span>` : '');
    const calculado = r2(sum.base + cuotas + sum.recargo - sum.irpf);
    el.querySelector('.resumen-cuerpo').innerHTML = `<table>
      <thead><tr><th>Tipo de IVA</th><th class="num">Base</th><th class="num">Cuota de IVA</th></tr></thead><tbody>
      ${tipos.map((t) => `<tr><td>${t ? String(t).replace('.', ',') + ' %' : '0 % (exento)'}</td><td class="num">${fmt(sum.porTipo.get(t).base)}</td><td class="num">${fmt(sum.porTipo.get(t).cuota)}</td></tr>`).join('') || '<tr><td colspan="3" class="hint">Todavía no hay importes.</td></tr>'}
      </tbody><tfoot>
      <tr><td>Suma</td><td class="num">${fmt(sum.base)}</td><td class="num">${fmt(cuotas)}</td></tr>
      ${sum.recargo ? `<tr><td colspan="2">Recargo de equivalencia</td><td class="num">${fmt(sum.recargo)}</td></tr>` : ''}
      ${sum.irpf ? `<tr><td colspan="2">Retención de IRPF</td><td class="num">−${fmt(sum.irpf)}</td></tr>` : ''}
      <tr class="gran"><td colspan="2">Total de las hojas</td><td class="num">${fmt(sum.total)} €</td></tr>
      ${Math.abs(calculado - r2(sum.total)) > 0.05 ? `<tr><td colspan="2" class="rev-mal">Base + IVA${sum.irpf ? ' − IRPF' : ''} daría ${fmt(calculado)} €: alguna hoja no cuadra</td><td></td></tr>` : ''}
      </tfoot></table>`;
  };
  const avisar = (m) => {
    if (!alCambiar) return;
    const c = cuentas(m);
    const ok = c.base != null && m.total != null && cuadra(c.base, c.iva, m.irpf, m.total, c.desglose, m.recargo);
    m.nota = ''; m.notaMal = false;
    let r;
    try { r = alCambiar(m.clave, { fecha: m.fecha, contraparte: m.contraparte, base: c.base, iva: c.iva, irpf: m.irpf, desglose: c.desglose, total: m.total, recargo: m.recargo }, ok); } catch (e) { r = Promise.reject(e); }
    Promise.resolve(r).then((txt) => { m.nota = typeof txt === 'string' ? txt : ''; m.notaMal = false; refrescar(); },
      (e) => { m.nota = (e && e.message) || 'no se pudo guardar'; m.notaMal = true; refrescar(); });
  };
  // Escribir: el modelo y el resumen cambian al momento.
  tbody.addEventListener('input', (e) => {
    const c = e.target, tr = c.closest('tr[data-c]');
    const m = tr && filaDe(tr.dataset.c);
    if (!m || !c.dataset.t) return;
    const k = c.dataset.t, i = Number(c.dataset.i) || 0;
    m.tocada = true;
    if (k === 'fecha') m.fecha = c.value;
    else if (k === 'contraparte') m.contraparte = c.value;
    else if (k === 'base') m.partes[i].base = leeNum(c.value);
    else if (k === 'iva') { m.partes[i].iva = Number(c.value) || 0; m.recargo = 0; }
    else if (k === 'irpf') m.irpf = num(aPct(c.value)) || 0;
    else if (k === 'total') { m.total = leeNum(c.value); m.totalAuto = false; }
    // Como en el resto del programa: al cambiar base, IVA o IRPF el total se
    // recalcula, salvo que se haya escrito a mano.
    if (['base', 'iva', 'irpf'].includes(k) && m.totalAuto) {
      const cu = cuentas(m);
      m.total = cu.calculado;
      const caja = tbody.querySelector(`tr.hoja[data-c="${CSS.escape(String(m.clave))}"] [data-t="total"]`);
      if (caja) caja.value = enCaja(m.total);
    }
    refrescar();
  });
  // Al salir de la caja (o elegir en un desplegable): se guarda.
  tbody.addEventListener('change', (e) => {
    const tr = e.target.closest('tr[data-c]');
    const m = tr && filaDe(tr.dataset.c);
    if (m && e.target.dataset.t) avisar(m);
  });
  let enPagina = actual || null;
  tbody.addEventListener('click', (e) => {
    const tr = e.target.closest('tr[data-p]');
    if (!tr) return;
    const m = tr.dataset.c && filaDe(tr.dataset.c);
    if (m && e.target.closest('[data-mas]')) {
      // Otro tipo de IVA en la hoja: el que no esté ya puesto.
      const libre = [21, 10, 4, 0].find((t) => !m.partes.some((p) => p.iva === t));
      m.partes.push({ base: null, iva: libre == null ? 21 : libre });
      pintarFilas();
      const caja = [...tbody.querySelectorAll(`tr.sub[data-c="${CSS.escape(String(m.clave))}"] [data-t="base"]`)].pop();
      if (caja) caja.focus();
      return;
    }
    if (m && e.target.closest('[data-quitar]')) {
      m.partes.splice(Number(e.target.closest('[data-quitar]').dataset.quitar), 1);
      m.tocada = true;
      if (m.totalAuto) m.total = cuentas(m).calculado;
      pintarFilas();
      avisar(m);
      return;
    }
    const p = Number(tr.dataset.p);
    if (alPagina && p !== enPagina) { enPagina = p; alPagina(p); }
  });
  pintarFilas();
  return el;
}
// Las filas de la tabla para un documento ya archivado: sus facturas, cada una
// en su hoja (un PDF de una sola factura, o una foto, es una fila).
function filasPdfDeDoc(d) {
  const fs = CACHE.facturasDeDoc && CACHE.facturasDeDoc.get(d.id) || [];
  const conPaginas = fs.some((f) => f.paginas);
  return fs.filter((f) => !conPaginas || f.paginas).map((f) => {
    const otro = [Number(f.ejercicio) !== Number(d.ejercicio) || f.trimestre !== d.trimestre ? 'va en ' + f.trimestre + ' ' + f.ejercicio : null,
      f.sentido !== d.sentido ? (f.sentido === 'emitida' ? 'es emitida' : 'es gasto') : null].filter(Boolean).join(', ');
    return {
      clave: f.id, desde: f.paginas ? f.paginas.desde : 1, hasta: f.paginas ? f.paginas.hasta : 1,
      numero: f.numero, fecha: f.fechaEstimada ? '' : f.fecha, contraparte: f.contraparte,
      base: f.importePendienteExtraccion ? '' : f.base, iva: f.iva, irpf: f.irpf, recargo: f.recargo, desglose: f.desglose, total: f.importePendienteExtraccion ? '' : f.total,
      dudas: d.revisado ? [] : f.dudas || [], aviso: otro && !d.revisado ? otro : '',
    };
  });
}
// Guardar lo corregido en la tabla de un documento archivado. Los importes solo
// si cuadran (el servidor tampoco los aceptaría); la fecha y el nombre, siempre.
async function guardarFilaArchivada(clave, v, cuadraBien) {
  const f = (CACHE.facturas || []).find((x) => x.id === clave);
  if (!f) throw new Error('la factura ya no está');
  const cuerpo = { contraparte: v.contraparte };
  if (v.fecha) cuerpo.fecha = v.fecha;
  if (cuadraBien) Object.assign(cuerpo, { base: v.base, iva: v.iva, irpf: v.irpf || 0, total: v.total, desglose: v.desglose });
  const g = await api('POST', 'revision/factura/' + clave, cuerpo);
  CACHE.facturas[CACHE.facturas.indexOf(f)] = g;
  CACHE.facturaDeDoc = new Map(CACHE.facturas.filter((x) => x.documentoId).map((x) => [x.documentoId, x]));
  CACHE.facturasDeDoc = agruparPorDoc(CACHE.facturas);
  CACHE.tablaTocada = true;
  return cuadraBien ? 'guardado' : 'los importes no se guardan hasta que cuadren';
}
// En un visor (iframe): ir a una página del PDF.
function irAPagina(ifr, base, n) { ifr.setAttribute('src', base + (base.includes('?') ? '&' : '?') + 'p=' + n + '#page=' + n); }

function descripcionDoc(d) {
  const tipo = { emitida: 'emitida', recibida: 'recibida', hacienda: 'Hacienda', 'no-factura': 'otro' }[d.sentido] || '—';
  return `${esc(d.cliente || '—')} · ${esc(d.ejercicio || '—')} ${esc(d.trimestre || '')} · ${tipo}`;
}

// ---- Panel ----------------------------------------------------------------
function irA(tab, pre) {
  if (pre) pre();
  const b = document.querySelector(`#tabs button[data-tab="${tab}"]`);
  if (b) b.click();
}

function renderPanel() {
  const s = CACHE.st;
  view.innerHTML = '';
  view.appendChild(h('<h1>Inicio</h1>'));
  view.appendChild(h('<p class="sub">El despacho de un vistazo. Los datos no salen de este ordenador.</p>'));

  // --- Qué hay pendiente hoy ---
  const tareas = [];
  if (s.importacionesEnEspera) tareas.push({ n: s.importacionesEnEspera, t: 'facturas analizadas esperando a que las confirmes', tab: 'importar', b: 'Terminar importación' });
  if (s.avisosPendientes) tareas.push({ n: s.avisosPendientes, t: 'documentos con algo que revisar (duplicados, trimestre dudoso…)', tab: 'revisar', b: 'Revisar', pre: () => { REV.vista = 'clasificacion'; } });
  if (s.importePorConfirmar) tareas.push({ n: s.importePorConfirmar, t: 'importes leídos de los PDF pendientes de confirmar', tab: 'revisar', b: 'Confirmar importes', pre: () => { REV.vista = 'importes'; REV.filtroImp = 'pdf'; } });
  if (s.sinImporte) tareas.push({ n: s.sinImporte, t: 'facturas sin importe (escaneos o PDF sin datos legibles)', tab: 'revisar', b: 'Completar', pre: () => { REV.vista = 'importes'; REV.filtroImp = 'sin'; } });
  const caja = h('<div class="tareas"></div>');
  if (!tareas.length) caja.appendChild(h('<div class="tarea ok"><b>✓ Todo al día.</b><span>No hay nada pendiente de revisar.</span></div>'));
  for (const t of tareas) {
    const fila = h(`<div class="tarea"><b>${t.n.toLocaleString('es-ES')}</b><span>${esc(t.t)}</span></div>`);
    const b = h(`<button class="btn btn-sm btn-accent">${esc(t.b)} →</button>`);
    b.onclick = () => irA(t.tab, t.pre);
    fila.appendChild(b);
    caja.appendChild(fila);
  }
  view.appendChild(h('<h2 class="h2">Pendiente</h2>'));
  view.appendChild(caja);

  view.appendChild(h('<h2 class="h2">Cifras</h2>'));
  view.appendChild(h(`<div class="cards">
    <div class="card"><div class="n">${s.documentos.toLocaleString('es-ES')}</div><div class="l">Documentos en el archivo</div></div>
    <div class="card"><div class="n">${s.facturas.toLocaleString('es-ES')}</div><div class="l">Facturas</div></div>
    <div class="card"><div class="n">${s.sujetos}</div><div class="l">Clientes</div></div>
    <div class="card"><div class="n">${eur(s.totalFacturado)}</div><div class="l">Facturado (emitidas con importe)</div></div>
    <div class="card"><div class="n">${eur(s.totalGastos)}</div><div class="l">Gastos (recibidas con importe)</div></div>
    <div class="card"><div class="n">${eur(s.pendienteCobro)}</div><div class="l">Pendiente de cobro</div></div>
  </div>`));
  if (s.sinImporte || s.importePorConfirmar) {
    view.appendChild(h(`<p class="hint">Las cifras solo suman las facturas que tienen importe. ${s.sinImporte ? `Faltan ${s.sinImporte.toLocaleString('es-ES')} por completar. ` : ''}${s.importePorConfirmar ? `${s.importePorConfirmar.toLocaleString('es-ES')} son lecturas automáticas aún sin confirmar.` : ''}</p>`));
  }

  view.appendChild(h('<h2 class="h2">Cómo se trabaja</h2>'));
  view.appendChild(h(`<div class="steps">
    <div class="step"><b>1 · Entran facturas nuevas</b><small>En <b>📥 Importar</b>, arrastra los PDF. El programa propone cliente, trimestre, tipo e importes, y avisa si alguna ya estaba o repite número.</small></div>
    <div class="step"><b>2 · Se revisa lo dudoso</b><small>En <b>⚠ Revisar</b> están los duplicados, las facturas en un trimestre que no les toca y los importes por confirmar.</small></div>
    <div class="step"><b>3 · Se consulta y se presenta</b><small>En <b>📁 Archivo</b> se busca cualquier documento; en <b>Facturas</b> y <b>Informes</b> se sacan los listados para Excel.</small></div>
  </div>`));
}

// ---- Descargas que tardan (Excel, ZIP, PDF único) --------------------------
// Se piden con fetch para poder decir qué pasa: «Preparando…» mientras el
// programa junta las facturas y, si algo falla, el motivo en vez de una
// pestaña en blanco.
async function descargar(url, opciones, queEs) {
  const aviso = document.createElement('div');
  aviso.className = 'toast-item';
  aviso.textContent = `Preparando ${queEs}… puede tardar si son muchas facturas.`;
  document.getElementById('toast').appendChild(aviso);
  try {
    const r = await fetch(url, opciones);
    if (!r.ok) {
      const e = await r.json().catch(() => ({}));
      throw new Error(e.error || 'Error ' + r.status);
    }
    const blob = await r.blob();
    const cd = r.headers.get('Content-Disposition') || '';
    const m = cd.match(/filename\*=UTF-8''([^;]+)/) || cd.match(/filename="?([^";]+)/);
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = m ? decodeURIComponent(m[1]) : 'descarga';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    const fuera = Number(r.headers.get('X-GF-Fuera') || 0);
    const pags = r.headers.get('X-GF-Paginas');
    toast(pags ? `PDF listo: ${r.headers.get('X-GF-Facturas')} facturas, ${pags} páginas.${fuera ? ` ${fuera} no se han podido incluir: están al final del índice.` : ''}` : `Descargado: ${a.download}`);
  } catch (e) {
    toast('No se pudo descargar: ' + e.message, true);
  } finally {
    aviso.remove();
  }
}
const descargarInforme = (i, formato) => descargar('/api/informes/' + i.id + '/' + formato, {}, { excel: 'el Excel', zip: 'el ZIP con las facturas', pdf: 'el PDF con todas las facturas' }[formato]);
const descargarFacturas = (lista, formato, titulo) => descargar('/api/facturas/exportar', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ formato, titulo, ids: lista.map((f) => f.id) }),
}, { excel: 'el Excel', zip: 'el ZIP con las facturas', pdf: 'el PDF con todas las facturas' }[formato]);

// ---- Tabla genérica ------------------------------------------------------
// CSV para Excel en español: BOM + punto y coma + decimales con coma.
function descargarCSV(nombre, columnas, filas) {
  const celda = (v) => {
    if (typeof v === 'number') v = String(v).replace('.', ',');
    else if (/^[=+\-@\t\r]/.test(String(v == null ? '' : v)) && !/^[-+]?\d[\d.,]*$/.test(String(v))) v = "'" + v; // que Excel no lo ejecute como fórmula (un importe negativo sí pasa)
    return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  };
  const txt = '﻿' + [columnas.map((c) => celda(c.label)).join(';'),
    ...filas.map((r) => columnas.map((c) => celda(c.csv ? c.csv(r) : c.get(r))).join(';'))].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([txt], { type: 'text/csv;charset=utf-8' }));
  a.download = nombre;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

function tableView({ title, sub, columns, rows, onNew, newLabel, filters, exportName, limite, extras }) {
  view.innerHTML = '';
  view.appendChild(h(`<h1>${esc(title)}</h1>`));
  if (sub) view.appendChild(h(`<p class="sub">${esc(sub)}</p>`));

  const bar = h('<div class="toolbar"></div>');
  const left = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const search = h('<input type="search" placeholder="Buscar…">');
  left.appendChild(search);
  (filters || []).forEach((f) => left.appendChild(f.el));
  bar.appendChild(left);
  const derecha = h('<div style="display:flex;gap:8px"></div>');
  let actual = [];
  if (exportName) {
    const x = h('<button class="btn">⬇ Excel (lo filtrado)</button>');
    x.onclick = () => descargarCSV(exportName, columns, actual);
    derecha.appendChild(x);
  }
  // Otras descargas de lo que se está viendo (ZIP, PDF único…).
  for (const e of extras || []) {
    const b = h(`<button class="btn" title="${esc(e.title || '')}">${esc(e.label)}</button>`);
    b.onclick = () => { if (!actual.length) return toast('No hay nada que descargar con ese filtro.', true); e.fn(actual); };
    derecha.appendChild(b);
  }
  if (onNew) { const b = h(`<button class="btn btn-accent">+ ${esc(newLabel)}</button>`); b.onclick = onNew; derecha.appendChild(b); }
  bar.appendChild(derecha);
  view.appendChild(bar);

  const resumen = h('<div class="exp-resumen"></div>');
  view.appendChild(resumen);
  const host = h('<div></div>');
  view.appendChild(host);
  let mostrar = limite || Infinity;

  function draw() {
    const q = search.value.toLowerCase().trim();
    let list = rows();
    (filters || []).forEach((f) => { list = f.apply(list); });
    if (q) list = list.filter((r) => columns.some((c) => String(c.get(r) ?? '').toLowerCase().includes(q)));
    actual = list;
    resumen.innerHTML = `<span><b>${list.length.toLocaleString('es-ES')}</b> registros</span>` +
      columns.filter((c) => c.sumar).map((c) => `<span>${esc(c.label)}: <b>${eur(list.reduce((a, r) => a + (Number(c.get(r)) || 0), 0))}</b></span>`).join('');
    if (!list.length) { host.innerHTML = ''; host.appendChild(h('<div class="empty">Sin registros.</div>')); return; }
    const t = h('<table></table>');
    t.appendChild(h('<thead><tr>' + columns.map((c) => `<th>${esc(c.label)}</th>`).join('') + '<th></th></tr></thead>'));
    const tb = h('<tbody></tbody>');
    list.slice(0, mostrar).forEach((r) => {
      const tr = h('<tr></tr>');
      columns.forEach((c) => { const td = h('<td></td>'); td.innerHTML = c.render ? c.render(r) : esc(c.get(r)); tr.appendChild(td); });
      const act = h('<td><div class="row-actions"></div></td>');
      const ra = act.querySelector('.row-actions');
      (r._actions || []).forEach((a) => { const b = h(`<button class="btn btn-sm ${a.cls || ''}">${esc(a.label)}</button>`); b.onclick = a.fn; ra.appendChild(b); });
      tr.appendChild(act);
      tb.appendChild(tr);
    });
    t.appendChild(tb);
    host.innerHTML = ''; host.appendChild(t);
    if (list.length > mostrar) {
      const mas = h(`<button class="btn" style="margin-top:10px">Mostrar ${Math.min(200, list.length - mostrar)} más (quedan ${list.length - mostrar})</button>`);
      mas.onclick = () => { mostrar += 200; draw(); };
      host.appendChild(mas);
    }
  }
  search.oninput = () => { mostrar = limite || Infinity; draw(); };
  (filters || []).forEach((f) => f.el.onchange = () => { mostrar = limite || Infinity; draw(); });
  draw();
}

// ---- Grupos -------------------------------------------------------------
function renderGrupos() {
  const rows = () => CACHE.grupos.map((g) => ({
    ...g,
    _actions: [
      { label: 'Editar', fn: () => formGrupo(g) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar el grupo "${g.nombre}"? Los sujetos quedarán sin grupo.`, async () => { await api('DELETE', 'grupos/' + g.id); await reload('grupos'); }) },
    ],
  }));
  tableView({
    title: 'Grupos', sub: 'Archivo de sujetos. Cada grupo puede tener campos personalizados que se usan al crear sujetos.',
    newLabel: 'Nuevo grupo', onNew: () => formGrupo(),
    columns: [
      { label: 'Nombre', get: (r) => r.nombre },
      { label: 'Descripción', get: (r) => r.descripcion },
      { label: 'Campos personalizados', get: (r) => (r.campos || []).map((c) => c.label).join(', ') || '—' },
      { label: 'Sujetos', get: (r) => CACHE.sujetos.filter((s) => s.grupoId === r.id).length },
    ],
    rows,
  });
}
function formGrupo(g) {
  openModal({
    title: g ? 'Editar grupo' : 'Nuevo grupo',
    fields: [
      { name: 'nombre', label: 'Nombre del grupo', required: true },
      { name: 'descripcion', label: 'Descripción', type: 'textarea' },
      { name: 'campos', label: 'Campos personalizados del grupo', type: 'subfields', hint: 'Se mostrarán como campos extra al dar de alta un sujeto de este grupo.' },
    ],
    values: g || {},
    onSave: async (v, close) => {
      if (!v.nombre) throw new Error('El nombre es obligatorio.');
      if (g) await api('PUT', 'grupos/' + g.id, v); else await api('POST', 'grupos', v);
      close(); toast('Grupo guardado'); await reload('grupos');
    },
  });
}

// ---- Sujetos ----------------------------------------------------------
function renderSujetos() {
  const sel = h('<select><option value="">Todos los grupos</option>' + CACHE.grupos.map((g) => `<option value="${g.id}">${esc(g.nombre)}</option>`).join('') + '</select>');
  const filtroGrupo = { el: sel, apply: (list) => sel.value ? list.filter((r) => r.grupoId === sel.value) : list };

  const rows = () => CACHE.sujetos.map((s) => ({
    ...s,
    _actions: [
      { label: 'Editar', fn: () => formSujeto(s) },
      { label: 'Ficha', fn: () => fichaSujeto(s) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar a "${s.nombre}" y sus facturas asociadas?`, async () => { await api('DELETE', 'sujetos/' + s.id); await reload('sujetos'); }) },
    ],
  }));
  tableView({
    title: 'Clientes', sub: 'Las fichas de los clientes del despacho. El NIF sirve para reconocer sus facturas al importarlas.',
    newLabel: 'Nuevo cliente', onNew: () => formSujeto(),
    filters: [filtroGrupo],
    columns: [
      { label: 'Nombre', get: (r) => r.nombre },
      { label: 'NIF', get: (r) => r.nif },
      { label: 'Grupo', get: (r) => nombreGrupo(r.grupoId), render: (r) => `<span class="tag">${esc(nombreGrupo(r.grupoId))}</span>` },
      { label: 'Email', get: (r) => r.email },
      { label: 'Teléfono', get: (r) => r.telefono },
      { label: 'Facturado', get: (r) => CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'emitida').reduce((a, f) => a + (f.total || 0), 0), render: (r) => eur(CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'emitida').reduce((a, f) => a + (f.total || 0), 0)) },
      { label: 'Gastos', get: (r) => CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'recibida').reduce((a, f) => a + (f.total || 0), 0), render: (r) => eur(CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'recibida').reduce((a, f) => a + (f.total || 0), 0)) },
    ],
    rows,
  });
}
// «4T-26»: el trimestre que toca, para lo que se crea nuevo. Del 1 al 20 del
// primer mes de un trimestre (el plazo de presentar el anterior), el anterior.
function trimestreDeHoy() {
  const d = new Date();
  let t = Math.floor(d.getMonth() / 3) + 1, y = d.getFullYear();
  if (d.getMonth() % 3 === 0 && d.getDate() <= 20) { t -= 1; if (!t) { t = 4; y -= 1; } }
  return t + 'T-' + String(y).slice(2);
}
function formSujeto(s) {
  const grupoOpts = [{ value: '', label: 'Sin grupo' }, ...CACHE.grupos.map((g) => ({ value: g.id, label: g.nombre }))];
  const build = (grupoId) => {
    const grupo = grupoId ? CACHE.grupos.find((g) => g.id === grupoId) : null;
    const extra = (grupo && grupo.campos || []).map((c) => ({ name: 'datos.' + c.key, label: c.label + ' (grupo ' + grupo.nombre + ')' }));
    const flat = {};
    Object.assign(flat, s || {});
    if (s && s.datos) for (const k in s.datos) flat['datos.' + k] = s.datos[k];
    if (!s && !flat.grupoId && grupo) flat.grupoId = grupo.id;
    openModal({
      title: s ? 'Editar sujeto' : 'Nuevo sujeto',
      fields: [
        { name: 'grupoId', label: 'Grupo', type: 'select', options: grupoOpts, hint: 'Cambia el grupo y vuelve a abrir para ver sus campos personalizados.' },
        { name: 'nombre', label: 'Nombre / Razón social', required: true },
        { type: 'group2', fields: [{ name: 'nif', label: 'NIF / DNI' }, { name: 'telefono', label: 'Teléfono' }] },
        { name: 'email', label: 'Email', type: 'email' },
        { name: 'direccion', label: 'Dirección' },
        ...extra,
        { name: 'notas', label: 'Notas / anotación manuscrita', type: 'textarea' },
      ],
      values: flat,
      onSave: async (v, close) => {
        const datos = {};
        for (const k in v) if (k.startsWith('datos.')) { datos[k.slice(6)] = v[k]; delete v[k]; }
        v.datos = datos;
        if (!v.nombre) throw new Error('El nombre es obligatorio.');
        if (s) await api('PUT', 'sujetos/' + s.id, v); else await api('POST', 'sujetos', v);
        close(); toast('Sujeto guardado'); await reload('sujetos');
      },
    });
  };
  build(s ? s.grupoId : (CACHE.grupos[0] || {}).id);
}
function fichaSujeto(s) {
  const facturas = CACHE.facturas.filter((f) => f.sujetoId === s.id);
  const docs = CACHE.documentos.filter((d) => d.sujetoId === s.id);
  const datosExtra = Object.entries(s.datos || {}).map(([k, v]) => `<div><b>${esc(k)}:</b> ${esc(v)}</div>`).join('') || '<span class="hint">Sin campos personalizados.</span>';
  openModal({
    title: 'Ficha · ' + s.nombre, saveLabel: 'Cerrar',
    fields: [{ name: '_', type: 'textarea', label: '' }],
    values: {}, onSave: (_v, close) => close(),
  });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (ta) ta.replaceWith(h(`<div>
    <p><b>NIF:</b> ${esc(s.nif) || '—'} &nbsp; <b>Grupo:</b> ${esc(nombreGrupo(s.grupoId))}</p>
    <p><b>Email:</b> ${esc(s.email) || '—'} &nbsp; <b>Tel:</b> ${esc(s.telefono) || '—'}</p>
    <p><b>Dirección:</b> ${esc(s.direccion) || '—'}</p>
    <h4>Campos del grupo</h4>${datosExtra}
    <h4>Facturas (${facturas.length})</h4>${facturas.map((f) => `<div>${esc(f.numero)} · ${fdate(f.fecha)} · ${eur(f.total)} · ${esc(f.estado)}</div>`).join('') || '<span class="hint">Sin facturas.</span>'}
    <h4>Documentos (${docs.length})</h4>${docs.map((d) => `<div>${esc(d.nombre)} <span class="hint">(${esc(d.origen)})</span></div>`).join('') || '<span class="hint">Sin documentos.</span>'}
    <h4>Notas</h4><div>${esc(s.notas) || '<span class="hint">—</span>'}</div>
  </div>`));
}

// ---- Facturas -------------------------------------------------------
function estadoImporte(f) {
  if (!(f.total > 0)) return { cls: 'vencida', t: 'sin importe' };
  if (f.importeOrigen === 'pdf' && !f.importeConfirmado) return { cls: 'pendiente', t: 'leído, sin confirmar' };
  return { cls: 'pagada', t: 'confirmado' };
}

// Lo elegido en Facturas se recuerda al volver a la pestaña o al guardar algo.
const FACT = { periodo: '', orden: 'recientes' };

function renderFacturas() {
  const selTipo = h('<select><option value="">Emitidas y recibidas</option><option value="emitida">Emitidas (ingresos)</option><option value="recibida">Recibidas (gastos)</option></select>');
  const selCli = h('<select><option value="">Todos los clientes</option>' + CACHE.sujetos.map((s) => `<option value="${s.id}">${esc(s.aliasArchivo || s.nombre)}</option>`).join('') + '</select>');
  const periodo = (f) => ({ anio: String(f.ejercicio || (f.fecha || '').slice(0, 4)), tri: f.trimestre || (f.fecha ? Math.floor((Number(f.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T' : '') });
  // Un periodo se escribe «2026-T2». La lista sale de las facturas que hay,
  // del más reciente al más antiguo, con cuántas tiene cada uno.
  const clavePer = (f) => { const p = periodo(f); return p.anio && p.tri ? `${p.anio}-T${p.tri[0]}` : p.anio || ''; };
  const cuenta = new Map();
  for (const f of CACHE.facturas) {
    const p = periodo(f);
    if (!p.anio) continue;
    cuenta.set(p.anio, (cuenta.get(p.anio) || 0) + 1);
    if (p.tri) cuenta.set(clavePer(f), (cuenta.get(clavePer(f)) || 0) + 1);
  }
  const anios = [...cuenta.keys()].filter((k) => /^\d{4}$/.test(k)).sort().reverse();
  let opcionesPer = '<option value="">Todos los periodos</option>';
  for (const a of anios) {
    opcionesPer += `<optgroup label="${a}"><option value="${a}">${a} · año entero (${cuenta.get(a)})</option>`
      + ['4', '3', '2', '1'].filter((t) => cuenta.has(`${a}-T${t}`)).map((t) => `<option value="${a}-T${t}">${a}-T${t} (${cuenta.get(`${a}-T${t}`)})</option>`).join('') + '</optgroup>';
  }
  const selPer = h(`<select title="Periodo: año y trimestre">${opcionesPer}</select>`);
  if ([...selPer.options].some((o) => o.value === FACT.periodo)) selPer.value = FACT.periodo; else FACT.periodo = '';
  const selOrden = h(`<select title="Orden de la lista">
    <option value="recientes">Más recientes primero</option>
    <option value="antiguas">Más antiguas primero</option>
    <option value="archivo">Por nombre del archivo (A → Z)</option>
    <option value="archivo-desc">Por nombre del archivo (Z → A)</option>
  </select>`);
  selOrden.value = FACT.orden;
  const archivoDe = (f) => (CACHE.documentos.find((d) => d.id === f.documentoId) || {}).nombre || '';
  const claveOrden = (f) => `${clavePer(f)}|${f.fecha || ''}`;
  const ordenar = (l) => {
    const o = selOrden.value;
    const cmpArchivo = (a, b) => archivoDe(a).localeCompare(archivoDe(b), 'es', { numeric: true, sensitivity: 'base' });
    return l.slice().sort(o === 'antiguas' ? (a, b) => claveOrden(a).localeCompare(claveOrden(b))
      : o === 'archivo' ? cmpArchivo
        : o === 'archivo-desc' ? (a, b) => cmpArchivo(b, a)
          : (a, b) => claveOrden(b).localeCompare(claveOrden(a)));
  };
  const selImp = h('<select><option value="">Cualquier importe</option><option value="confirmado">Importe confirmado</option><option value="pdf">Leído, sin confirmar</option><option value="sin">Sin importe</option></select>');
  const filtros = [
    { el: selTipo, apply: (l) => selTipo.value ? l.filter((r) => r.sentido === selTipo.value) : l },
    { el: selCli, apply: (l) => selCli.value ? l.filter((r) => r.sujetoId === selCli.value) : l },
    { el: selPer, apply: (l) => { FACT.periodo = selPer.value; return !selPer.value ? l : l.filter((r) => (selPer.value.length === 4 ? periodo(r).anio : clavePer(r)) === selPer.value); } },
    { el: selImp, apply: (l) => {
      if (!selImp.value) return l;
      const k = { confirmado: 'confirmado', pdf: 'leído, sin confirmar', sin: 'sin importe' }[selImp.value];
      return l.filter((r) => estadoImporte(r).t === k);
    } },
    // El orden va el último: se aplica a lo que haya quedado tras filtrar.
    { el: selOrden, apply: (l) => { FACT.orden = selOrden.value; return ordenar(l); } },
  ];
  const tituloDescarga = () => 'Facturas' + (selPer.value ? ' ' + selPer.value : '');
  const rows = () => CACHE.facturas.map((f) => ({
    ...f,
    _actions: [
      ...(f.documentoId ? [{ label: 'Ver', fn: () => verDocumento(f.documentoId) }] : []),
      { label: 'Editar', fn: () => formFactura(f) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar la factura ${f.numero || ''}? El documento del archivo no se borra.`, async () => { await api('DELETE', 'facturas/' + f.id); await reload('facturas'); }) },
    ],
  }));
  tableView({
    title: 'Facturas', sub: 'Todas las facturas del despacho. Filtra por cliente y trimestre y descarga el listado para el modelo 303 o el libro de IVA.',
    newLabel: 'Nueva factura', onNew: () => formFactura(), filters: filtros,
    exportName: 'facturas.csv', limite: 200,
    extras: [
      { label: '⬇ Excel completo', title: 'Una fila por factura, con sus datos y su fichero', fn: (l) => descargarFacturas(l, 'excel', tituloDescarga()) },
      { label: '⬇ ZIP', title: 'Los ficheros de las facturas filtradas, en carpetas, con su Excel', fn: (l) => descargarFacturas(l, 'zip', tituloDescarga()) },
      { label: '⬇ PDF único', title: 'Todas las facturas filtradas seguidas en un solo PDF, con índice', fn: (l) => descargarFacturas(l, 'pdf', tituloDescarga()) },
    ],
    columns: [
      { label: 'Nº', get: (r) => r.numero },
      { label: 'Cliente', get: (r) => aliasDeId(r.sujetoId) || nombreSujeto(r.sujetoId) },
      { label: 'Tipo', get: (r) => r.sentido, render: (r) => r.sentido === 'emitida' ? '<span class="tag ok">emitida</span>' : '<span class="tag">recibida</span>' },
      { label: 'Fecha', get: (r) => r.fecha, render: (r) => fdate(r.fecha) + (r.fechaEstimada ? ' <span class="hint" title="Fecha aproximada: primer día del trimestre">≈</span>' : '') },
      { label: 'Periodo', get: (r) => clavePer(r), render: (r) => `<span style="white-space:nowrap">${esc(clavePer(r))}</span>` },
      { label: 'Archivo', get: (r) => archivoDe(r), render: (r) => `<span class="hint" style="display:inline-block;max-width:190px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:bottom" title="${esc(archivoDe(r))}">${esc(archivoDe(r))}</span>` },
      { label: 'Empresa', get: (r) => r.contraparte || '', render: (r) => `<span style="display:inline-block;min-width:170px">${esc(r.contraparte || '')}</span>` },
      { label: 'CIF / NIF', get: (r) => r.nifContraparte || (CACHE.documentos.find((d) => d.id === r.documentoId) || {}).nifContraparte || '' },
      { label: 'C.P.', get: (r) => r.cpContraparte || (CACHE.documentos.find((d) => d.id === r.documentoId) || {}).cpContraparte || '' },
      { label: 'Base', get: (r) => r.base, render: (r) => eur(r.base), sumar: true, csv: (r) => r.base },
      { label: 'IVA %', get: (r) => r.iva },
      { label: 'Cuota IVA', get: (r) => +(r.base * r.iva / 100).toFixed(2), render: (r) => eur(r.base * r.iva / 100), sumar: true },
      { label: 'IRPF %', get: (r) => r.irpf || 0 },
      { label: 'Total', get: (r) => r.total, render: (r) => eur(r.total), sumar: true, csv: (r) => r.total },
      { label: 'Importe', get: (r) => estadoImporte(r).t, render: (r) => `<span class="tag ${estadoImporte(r).cls}">${estadoImporte(r).t}</span>` },
      { label: 'Cobro/pago', get: (r) => r.estado, render: (r) => `<span class="tag ${r.estado}">${esc(r.estado)}</span>` },
    ],
    rows,
  });
}
// Los conceptos del «Informe» de la asesoría y los que ya se hayan puesto.
const CONCEPTOS_INFORME = ['COMPRAS MERCADERIAS', 'ARRENDAMIENTOS Y CANONES', 'REPARACIONES Y CONSERVACION', 'SERVICIOS PROFESIONALES',
  'SUMINISTROS', 'SUELDOS Y SALARIOS', 'SEGURIDAD SOCIAL EMPRESA', 'TRANSPORTES', 'PRIMAS DE SEGUROS', 'SERVICIOS BANCARIOS',
  'PUBLICIDAD Y PROPAGANDA', 'OTROS SERVICIOS', 'TRIBUTOS', 'VENTAS', 'PRESTACION DE SERVICIOS'];
function conceptosContables() {
  return [...new Set([...CONCEPTOS_INFORME, ...(CACHE.facturas || []).map((x) => x.conceptoContable).filter(Boolean)])];
}
function formFactura(f) {
  openModal({
    title: f ? 'Editar factura' : 'Nueva factura',
    fields: [
      { name: 'sujetoId', label: 'Cliente', type: 'select', options: CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre + (s.nif ? ' · ' + s.nif : '') })) },
      { type: 'group2', fields: [
        { name: 'sentido', label: 'Tipo', type: 'select', options: [{ value: 'emitida', label: 'Emitida (ingreso)' }, { value: 'recibida', label: 'Recibida (gasto)' }] },
        { name: 'estado', label: 'Cobro / pago', type: 'select', options: [{ value: 'pendiente', label: 'Pendiente' }, { value: 'pagada', label: 'Pagada' }, { value: 'vencida', label: 'Vencida' }] },
      ] },
      { type: 'group2', fields: [{ name: 'numero', label: 'Número', required: true }, { name: 'fecha', label: 'Fecha', type: 'date' }] },
      { name: 'concepto', label: 'Concepto' },
      { type: 'group2', fields: [
        { name: 'conceptoContable', label: 'Concepto en el Excel', suggestions: conceptosContables(), hint: 'COMPRAS MERCADERIAS, SUMINISTROS… Si se deja vacío, sale el que más se ha puesto a ese proveedor.' },
        { name: 'numeroRegistro', label: 'Nº de registro (Nºfra.rec.)' },
      ] },
      { name: 'contraparte', label: 'Empresa (proveedor o destinatario)' },
      { type: 'group2', fields: [{ name: 'nifContraparte', label: 'CIF / NIF de esa empresa' }, { name: 'cpContraparte', label: 'Código postal' }] },
      { type: 'group2', fields: [{ name: 'base', label: 'Base imponible (€)', type: 'number', step: '0.01' }, { name: 'iva', label: 'IVA %', type: 'number', step: '0.01' }] },
      { name: 'irpf', label: 'Retención IRPF %', type: 'number', step: '0.01', hint: 'El total se calcula solo: base + IVA − IRPF.' },
    ],
    values: f || { iva: 21, irpf: 0, sentido: 'emitida', fecha: new Date().toISOString().slice(0, 10) },
    onSave: async (v, close) => {
      if (!v.numero) throw new Error('El número es obligatorio.');
      // Si se toca el importe a mano, queda confirmado por quien lo toca.
      v.importeConfirmado = true;
      // Lo escrito aquí sobre la empresa manda: el programa no lo vuelve a leer.
      v.proveedorLeido = true;
      v.nifContraparte = String(v.nifContraparte || '').toUpperCase().replace(/[\s.-]/g, '');
      if (v.fecha) {
        v.ejercicio = Number(v.fecha.slice(0, 4));
        v.trimestre = Math.floor((Number(v.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T';
        v.fechaEstimada = false;
      }
      if (f) await api('PUT', 'facturas/' + f.id, v); else await api('POST', 'facturas', v);
      close(); toast('Factura guardada'); await reload('facturas');
    },
  });
}

// ---- Documentos ----------------------------------------------------
function renderDocumentos() {
  const rows = () => CACHE.documentos.map((d) => ({
    ...d,
    _actions: [
      ...(d.ruta ? [{ label: 'Descargar', fn: () => window.open('/api/download/' + d.id) }] : []),
      { label: 'Reasignar', fn: () => formDoc(d) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar el documento "${d.nombre}"?`, async () => { await api('DELETE', 'documentos/' + d.id); await reload('documentos'); }) },
    ],
  }));
  tableView({
    title: 'Documentos', sub: 'Archivos subidos manualmente o importados del servidor local de la oficina.',
    newLabel: 'Subir documento', onNew: () => subirDoc(),
    columns: [
      { label: 'Nombre', get: (r) => r.nombre },
      { label: 'Tipo', get: (r) => r.tipo },
      { label: 'Sujeto', get: (r) => r.sujetoId ? nombreSujeto(r.sujetoId) : '—' },
      { label: 'Origen', get: (r) => r.origen, render: (r) => `<span class="tag">${esc(r.origen)}</span>` },
      { label: 'Tamaño', get: (r) => r.tamano, render: (r) => r.tamano ? (r.tamano / 1024).toFixed(1) + ' KB' : '—' },
      { label: 'Fecha', get: (r) => r.creado, render: (r) => fdate(r.creado) },
    ],
    rows,
  });
}
function subirDoc() {
  openModal({
    title: 'Subir documento',
    fields: [
      { name: 'file', label: 'Archivo', type: 'file', required: true },
      { name: 'sujetoId', label: 'Asociar a sujeto', type: 'select', options: [{ value: '', label: '— Ninguno —' }, ...CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre }))] },
    ],
    values: {},
    onSave: async (v, close) => {
      if (!v.file) throw new Error('Selecciona un archivo.');
      const b64 = await fileToB64(v.file);
      await api('POST', 'upload', { nombre: v.file.name, tipo: v.file.name.split('.').pop(), sujetoId: v.sujetoId || null, contenidoBase64: b64 });
      close(); toast('Documento subido'); await reload('documentos');
    },
  });
}
function formDoc(d) {
  openModal({
    title: 'Reasignar documento',
    fields: [
      { name: 'nombre', label: 'Nombre' },
      { name: 'sujetoId', label: 'Sujeto', type: 'select', options: [{ value: '', label: '— Ninguno —' }, ...CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre }))] },
    ],
    values: d,
    onSave: async (v, close) => { await api('PUT', 'documentos/' + d.id, { ...d, ...v, sujetoId: v.sujetoId || null }); close(); await reload('documentos'); },
  });
}
function fileToB64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1]);
    r.onerror = () => rej(new Error('No se pudo leer «' + file.name + '»' + (r.error && r.error.name ? ' (' + r.error.name + ')' : '')));
    r.readAsDataURL(file);
  });
}

// ---- Informes -----------------------------------------------------
const CAMPOS_INFORME = [
  { value: 'nombre', label: 'Nombre' }, { value: 'nif', label: 'NIF' },
  { value: 'numEmitidas', label: 'Nº de facturas emitidas' }, { value: 'baseEmitidas', label: 'Base imponible emitidas' },
  { value: 'ivaRepercutido', label: 'IVA repercutido' }, { value: 'irpfRetenido', label: 'IRPF retenido' },
  { value: 'totalFacturado', label: 'Total facturado' },
  { value: 'numRecibidas', label: 'Nº de facturas recibidas' }, { value: 'baseRecibidas', label: 'Base imponible recibidas' },
  { value: 'ivaSoportado', label: 'IVA soportado' }, { value: 'resultadoIva', label: 'Resultado IVA (repercutido − soportado)' },
  { value: 'sinImporte', label: 'Facturas sin importe' }, { value: 'porConfirmar', label: 'Importes por confirmar' },
  { value: 'email', label: 'Email' }, { value: 'telefono', label: 'Teléfono' }, { value: 'direccion', label: 'Dirección' },
];
const CAMPOS_303 = ['nombre', 'nif', 'numEmitidas', 'baseEmitidas', 'ivaRepercutido', 'numRecibidas', 'baseRecibidas', 'ivaSoportado', 'resultadoIva', 'sinImporte', 'porConfirmar'];
function renderInformes() {
  const rows = () => CACHE.informes.map((i) => ({
    ...i,
    _actions: [
      { label: 'Editar', fn: () => formInforme(i) },
      { label: 'Ver / gráfico', fn: () => verInforme(i) },
      { label: 'Excel', fn: () => descargarInforme(i, 'excel') },
      { label: 'ZIP facturas', fn: () => descargarInforme(i, 'zip') },
      { label: 'PDF único', fn: () => descargarInforme(i, 'pdf') },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar el informe "${i.titulo}"?`, async () => { await api('DELETE', 'informes/' + i.id); await reload('informes'); }) },
    ],
  }));
  tableView({
    title: 'Informes', sub: 'Flujo de informes: lectura de información, preparación de datos y resultado.',
    newLabel: 'Nuevo informe', onNew: () => formInforme(),
    columns: [
      { label: 'Título', get: (r) => r.titulo },
      { label: 'Tipo', get: (r) => r.tipo },
      { label: 'Periodo / brand', get: (r) => r.periodo },
      { label: 'Sujetos', get: (r) => r.sujetoIds.length },
      { label: 'Campos', get: (r) => r.campos.join(', ') },
      { label: 'Estado', get: (r) => r.estado, render: (r) => `<span class="tag ${r.estado}">${esc(r.estado)}</span>` },
    ],
    rows,
  });
  const barra = view.querySelector('.toolbar > div:last-child');
  if (barra) {
    const b = h('<button class="btn">🏛️ Informe fiscal (Hacienda)</button>');
    b.onclick = () => verInformeFiscal();
    barra.prepend(b);
  }
}

// Lo declarado y lo pagado a Hacienda por cliente y trimestre, leído de los
// documentos de la carpeta Hacienda (modelos, pagos, liquidaciones, sanciones).
async function verInformeFiscal(ejercicio) {
  let d;
  try { d = await get('hacienda/resumen' + (ejercicio ? '?ejercicio=' + encodeURIComponent(ejercicio) : '')); } catch (e) { return toast(e.message, true); }
  const anios = [...new Set(d.filas.map((f) => f.ejercicio).filter(Boolean))].sort().reverse();
  openModal({ title: 'Informe fiscal · Hacienda', saveLabel: 'Cerrar', fields: [{ name: '_', type: 'textarea', label: '' }], values: {}, onSave: (_v, c) => c() });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (!ta) return;
  ta.closest('.modal').classList.add('modal-ancho');
  // (Todo escapado: estos datos se pueden escribir a mano en un documento.)
  const modelos = (f) => Object.entries(f.modelos).map(([m, x]) => esc(`${m}${x.resultado ? ' ' + ({ ingresar: 'ingresar', devolver: 'devolver', cero: 'cero', domiciliado: 'domic.', compensar: 'compensar' }[x.resultado] || x.resultado) : ''}${x.importe != null ? ' ' + eur(x.importe) : ''}`)).join('<br>') || '—';
  const avisos = (f) => [
    ...f.modelosSinPago.map((m) => `modelo ${esc(m)} sin justificante de pago`),
    ...f.pagosSinModelo.map((m) => `pago ${esc(m)} sin su modelo`),
  ].join('<br>');
  const qs = (fmt) => '/api/hacienda/resumen?' + [fmt ? 'formato=csv' : '', ejercicio ? 'ejercicio=' + encodeURIComponent(ejercicio) : ''].filter(Boolean).join('&');
  const n = h(`<div>
    <p class="hint">Sale de ${d.documentos} documentos de la carpeta Hacienda. Lo anual (390, 190, Renta, comprobaciones del año) va en el 4T.</p>
    <div style="display:flex;gap:8px;align-items:center;margin:8px 0">
      <select data-anio><option value="">Todos los años</option>${anios.map((a) => `<option ${String(a) === String(ejercicio || '') ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select>
      <a class="btn btn-sm btn-accent" href="${qs(true)}">⬇ Excel (CSV)</a>
    </div>
    ${d.filas.length ? `<div class="tabla-scroll"><table><thead><tr><th>Cliente</th><th>Periodo</th><th>Modelos</th><th>A ingresar</th><th>A devolver</th><th>Pagado</th><th>Regularizaciones</th><th>Sanciones</th><th>Avisos</th></tr></thead><tbody>
      ${d.filas.map((f) => `<tr><td>${esc(f.cliente)}</td><td>${esc(f.trimestre || '')} ${esc(f.ejercicio || '')}</td><td>${modelos(f)}</td>
        <td class="num">${eur(f.aIngresar)}</td><td class="num">${eur(f.aDevolver)}</td><td class="num">${eur(f.pagado)}</td>
        <td class="num">${f.regularizaciones ? eur(f.regularizaciones) : ''}</td><td class="num">${f.sanciones ? eur(f.sanciones) : ''}</td><td class="hint">${avisos(f)}</td></tr>`).join('')}
    </tbody></table></div>` : '<div class="empty">Todavía no hay documentos de Hacienda en el archivo. Se reconocen solos al importar u ordenar una carpeta.</div>'}
  </div>`);
  ta.replaceWith(n);
  n.querySelector('[data-anio]').onchange = (e) => { document.querySelector('.modal-bg:last-child').remove(); verInformeFiscal(e.target.value); };
}
function formInforme(i) {
  openModal({
    title: i ? 'Editar informe' : 'Nuevo informe',
    fields: [
      { name: 'titulo', label: 'Título', required: true },
      { type: 'group2', fields: [
        { name: 'tipo', label: 'Tipo', type: 'select', options: ['general', 'trimestral', 'anual', 'IVA', 'IRPF'].map((x) => ({ value: x, label: x })) },
        { name: 'periodo', label: 'Periodo / brand inversión' },
      ] },
      { name: 'estado', label: 'Estado', type: 'select', options: [{ value: 'borrador', label: 'Borrador' }, { value: 'revision', label: 'En revisión' }, { value: 'completado', label: 'Completado' }] },
      { name: 'campos', label: 'Columnas del Excel', type: 'checks', options: CAMPOS_INFORME, hint: 'Las cifras se calculan solo con las facturas del periodo indicado arriba (por ejemplo 3T-2025, o 2025 para el año entero).' },
      { name: 'sujetoIds', label: 'Clientes incluidos', type: 'checks', options: CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre + (s.nif ? ' · ' + s.nif : '') })) },
      { name: 'observaciones', label: 'Observaciones / información consultada', type: 'textarea' },
    ],
    values: i || { tipo: 'trimestral', periodo: CACHE.config.brandInversion || trimestreDeHoy(), campos: CAMPOS_303, sujetoIds: CACHE.sujetos.map((s) => s.id) },
    onSave: async (v, close) => {
      if (!v.titulo) throw new Error('El título es obligatorio.');
      if (i) await api('PUT', 'informes/' + i.id, v); else await api('POST', 'informes', v);
      close(); toast('Informe guardado'); await reload('informes');
    },
  });
}
async function verInforme(i) {
  let d;
  try { d = await get('informes/' + i.id + '/datos'); } catch (e) { return toast(e.message, true); }
  const DINERO = new Set(['baseEmitidas', 'ivaRepercutido', 'irpfRetenido', 'totalFacturado', 'baseRecibidas', 'ivaSoportado', 'resultadoIva']);
  const fmt = (k, v) => (DINERO.has(k) ? eur(v) : esc(v ?? ''));
  const barras = (clave, titulo) => {
    const max = Math.max(1, ...d.filas.map((f) => Math.abs(f[clave] || 0)));
    return `<h4>${esc(titulo)}</h4>` + (d.filas.map((f) => `<div class="barra-fila"><span>${esc(f.nombre)}</span>
      <i style="width:${Math.round(Math.abs(f[clave] || 0) / max * 220)}px;${clave === 'baseRecibidas' ? 'background:#3a7bd5' : ''}"></i><small>${eur(f[clave] || 0)}</small></div>`).join('') || '<span class="hint">Sin clientes.</span>');
  };
  openModal({ title: 'Informe · ' + i.titulo, saveLabel: 'Cerrar', fields: [{ name: '_', type: 'textarea', label: '' }], values: {}, onSave: (_v, c) => c() });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (ta) ta.replaceWith(h(`<div>
    <p><b>Periodo:</b> ${esc(d.periodo)} &nbsp; <b>Estado:</b> ${esc(i.estado)}</p>
    ${d.nota ? `<div class="aviso-caja">${esc(d.nota)}</div>` : ''}
    ${barras('baseEmitidas', 'Base imponible emitida (ingresos)')}
    ${barras('baseRecibidas', 'Base imponible recibida (gastos)')}
    <h4>Datos</h4><div class="tabla-scroll"><table><thead><tr>${d.columnas.map((c) => `<th>${esc(c.label)}</th>`).join('')}</tr></thead>
    <tbody>${d.filas.map((f) => '<tr>' + d.columnas.map((c) => `<td class="${DINERO.has(c.key) ? 'num' : ''}">${fmt(c.key, f[c.key])}</td>`).join('') + '</tr>').join('')}</tbody></table></div>
    <p style="margin-top:10px"><b>Observaciones:</b> ${esc(i.observaciones) || '—'}</p>
    <p class="hint">El Excel trae una fila por factura (y una hoja con este resumen). El ZIP lleva los ficheros en carpetas; el PDF único, todas las facturas seguidas con un índice delante.</p>
    <p style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-sm btn-accent" data-d="excel">⬇ Excel factura por factura</button>
      <button class="btn btn-sm" data-d="zip">⬇ ZIP con las facturas</button>
      <button class="btn btn-sm" data-d="pdf">⬇ Un solo PDF</button>
      <a class="btn btn-sm" href="/api/informes/${i.id}/export?formato=csv">Resumen (CSV)</a>
    </p>
  </div>`));
  document.querySelectorAll('.modal-bg:last-child [data-d]').forEach((b) => { b.onclick = () => descargarInforme(i, b.dataset.d); });
}

// ---- Explorador de archivo (vista ERP) ----------------------------
let EXP_RUTA = [];        // ej. ['Cliente','2025','4T','Emitidas']
let EXP_ARBOL = null;
let EXP_BUSQUEDA = '';

const NIVELES = ['Cliente', 'Año', 'Trimestre', 'Tipo', 'Mes', 'Semana', 'Día'];
const ICONOS = { Emitidas: '📤', Recibidas: '📥', Hacienda: '🏛️', Otros: '📎' };

const bytes = (b) => !b ? '—'
  : b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB';

function nodoEnRuta(arbol, ruta) {
  let n = arbol;
  for (const paso of ruta) {
    const sig = (n.hijos || []).find((h) => h.nombre === paso);
    if (!sig) return n;
    n = sig;
  }
  return n;
}

// ¿Este documento pertenece a esa carpeta? El criterio viene del propio árbol
// (`filtro`), así que el servidor y esta pantalla nunca pueden discrepar.
function cumpleFiltro(d, f) {
  if (!f) return true;
  switch (f.campo) {
    case 'cliente': return (d.cliente || null) === f.valor;
    case 'ejercicio': return (d.ejercicio || null) === f.valor;
    case 'trimestre': return (d.trimestre || null) === f.valor;
    case 'sentido': return f.valor === 'otros'
      ? !['emitida', 'recibida', 'hacienda'].includes(d.sentido)
      : d.sentido === f.valor;
    case 'mes': return (d.fechaEfectiva || '').slice(0, 7) === f.valor;
    case 'sinFecha': return !d.fechaEfectiva;
    case 'fecha': return !!d.fechaEfectiva && d.fechaEfectiva >= f.desde && d.fechaEfectiva <= f.hasta;
    default: return true;
  }
}

// Documentos que cuelgan de la ruta actual.
function docsDeRuta(arbol, ruta) {
  const filtros = [];
  let n = arbol;
  for (const paso of ruta) {
    const sig = (n.hijos || []).find((h) => h.nombre === paso);
    if (!sig) break;
    filtros.push(sig.filtro);
    n = sig;
  }
  return CACHE.documentos.filter((d) => filtros.every((f) => cumpleFiltro(d, f)));
}

async function renderArchivo() {
  const turno = ++NAV;
  if (!EXP_ARBOL) {
    try { EXP_ARBOL = await get('archivo/arbol'); }
    catch (e) { if (turno === NAV) view.innerHTML = `<div class="empty">No se pudo leer el archivo: ${esc(e.message)}</div>`; return; }
    if (turno !== NAV) return;
  }
  view.innerHTML = '';
  const cabArch = h('<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><h1>Archivo</h1></div>');
  const bOrdenar = h('<button class="btn">📂 Ordenar una carpeta nueva</button>');
  bOrdenar.onclick = abrirOrdenarCarpeta;
  cabArch.appendChild(bOrdenar);
  view.appendChild(cabArch);
  view.appendChild(h('<p class="sub">Todos los documentos del despacho, en carpetas: cliente › año › trimestre › emitidas, gastos o Hacienda › mes › semana › día. «Ver» abre el documento aquí mismo; «Carpeta», su carpeta en Windows.</p>'));

  // --- barra de búsqueda global ---
  const barra = h('<div class="exp-barra"></div>');
  const buscar = h(`<input type="search" placeholder="Buscar en los ${CACHE.documentos.length.toLocaleString('es-ES')} documentos por nombre, número, proveedor o importe…">`);
  buscar.value = EXP_BUSQUEDA;
  const limpiar = h('<button class="btn">Limpiar</button>');
  barra.append(buscar, limpiar);
  view.appendChild(barra);

  buscar.oninput = () => { EXP_BUSQUEDA = buscar.value.trim(); pintar(); };
  limpiar.onclick = () => { EXP_BUSQUEDA = ''; EXP_RUTA = []; renderArchivo(); };

  const cuerpo = h('<div></div>');
  view.appendChild(cuerpo);

  function pintar() {
    cuerpo.innerHTML = '';

    // --- migas de pan ---
    const migas = h('<div class="migas"></div>');
    const inicio = h('<button>📁 Archivo</button>');
    inicio.onclick = () => { EXP_RUTA = []; pintar(); };
    migas.appendChild(inicio);
    EXP_RUTA.forEach((paso, i) => {
      migas.appendChild(h('<span class="sep">›</span>'));
      const b = h(`<button>${esc(paso)}</button>`);
      b.onclick = () => { EXP_RUTA = EXP_RUTA.slice(0, i + 1); pintar(); };
      migas.appendChild(b);
    });
    cuerpo.appendChild(migas);

    // --- modo búsqueda: tabla plana sobre todo el archivo ---
    if (EXP_BUSQUEDA) {
      const q = EXP_BUSQUEDA.toLowerCase();
      const qNum = num(EXP_BUSQUEDA.replace(/\./g, '').replace(',', '.'));
      const hits = CACHE.documentos.filter((d) => {
        const fs = facturasDe(d.id);
        return (d.nombre || '').toLowerCase().includes(q) ||
          String(d.numeroDetectado || '').toLowerCase().includes(q) ||
          (d.proveedor || '').toLowerCase().includes(q) ||
          (d.contraparte || '').toLowerCase().includes(q) ||
          fs.some((f) => String(f.numero || '').toLowerCase().includes(q) && q.length >= 3) ||
          (qNum != null && fs.some((f) => Math.abs(f.total - qNum) < 0.005 || Math.abs(f.base - qNum) < 0.005));
      });
      cuerpo.appendChild(h(`<div class="exp-resumen"><span><b>${hits.length}</b> resultados para “${esc(EXP_BUSQUEDA)}”</span></div>`));
      cuerpo.appendChild(tablaDocs(hits.slice(0, 300)));
      if (hits.length > 300) cuerpo.appendChild(h(`<p class="sub">Mostrando los primeros 300 de ${hits.length}. Afina la búsqueda.</p>`));
      return;
    }

    const nodo = nodoEnRuta(EXP_ARBOL, EXP_RUTA);
    const docs = docsDeRuta(EXP_ARBOL, EXP_RUTA);

    cuerpo.appendChild(h(`<div class="exp-resumen">
      <span><b>${nodo.docs}</b> documentos</span>
      <span><b>${bytes(nodo.bytes)}</b></span>
      ${EXP_RUTA.length < NIVELES.length ? `<span>Siguiente nivel: <b>${NIVELES[EXP_RUTA.length]}</b></span>` : ''}
    </div>`));

    // --- carpetas del nivel actual ---
    if (nodo.hijos && nodo.hijos.length) {
      const rejilla = h('<div class="carpetas"></div>');
      for (const hijo of nodo.hijos) {
        const ico = ICONOS[hijo.nombre] || '📁';
        const c = h(`<div class="carpeta"><div class="ico">${ico}</div>
          <div class="txt"><div class="nom">${esc(hijo.nombre)}</div>
          <div class="sub">${hijo.docs} doc · ${bytes(hijo.bytes)}</div></div></div>`);
        c.onclick = () => { EXP_RUTA = [...EXP_RUTA, hijo.nombre]; pintar(); };
        rejilla.appendChild(c);
      }
      cuerpo.appendChild(rejilla);
    }

    // --- documentos: a partir del tipo ya se ven aquí mismo, además de en
    //     las subcarpetas de mes, semana y día ---
    if (!nodo.hijos.length || EXP_RUTA.length >= 4) {
      cuerpo.appendChild(docs.length ? tablaDocs(docs)
        : h('<div class="vacio-exp">Esta carpeta no tiene documentos.</div>'));
    }
  }

  pintar();
}

function tablaDocs(docs) {
  const t = h(`<table class="doc-tabla"><thead><tr>
    <th>Documento</th><th>Nº</th><th>Fecha</th><th>Contraparte</th>
    <th>Importe</th><th>Estado</th><th></th></tr></thead></table>`);
  const tb = h('<tbody></tbody>');
  for (const d of docs) {
    const avisos = avisosDoc(d).map((a) => `<span class="aviso-inc ${a.cls || ''}" title="${esc(a.texto)}">${esc(a.corto)}</span>`);
    if (d.revisado) avisos.push('<span class="tag ok" title="Revisado a mano">revisado</span>');
    if (d.origen === 'importacion') avisos.push('<span class="tag">importado</span>');
    const todas = facturasDe(d.id);
    const f = todas.length > 1 ? { total: todas.reduce((a, x) => a + (Number(x.total) || 0), 0), importeOrigen: todas.some((x) => x.importeOrigen === 'pdf' && !x.importeConfirmado) ? 'pdf' : null, importeConfirmado: false } : todas[0];
    const hac = d.hacienda;
    const importe = hac ? (hac.importe != null ? eur(hac.importe) : '<span class="hint">—</span>') + ` <span class="hint" title="${esc(hac.etiqueta || '')}">${esc(hac.tipo === 'modelo' ? 'mod. ' + (hac.modelo || '') : hac.tipo || '')}</span>`
      : todas.length > 1 ? eur(f.total) + ` <span class="hint" title="Un PDF con varias facturas: la suma">(${todas.length} facturas)</span>`
      : !f ? '<span class="hint">—</span>'
      : f.total > 0 ? eur(f.total) + (f.importeOrigen === 'pdf' && !f.importeConfirmado ? ' <span class="hint" title="Leído del PDF, sin confirmar">*</span>' : '')
        : '<span class="hint">sin importe</span>';

    const tr = h(`<tr>
      <td class="doc-nom">${esc(d.nombre)}</td>
      <td>${esc(d.numeroDetectado || '—')}</td>
      <td>${d.fechaDocumento ? fdate(d.fechaDocumento) : f && !f.fechaEstimada ? fdate(f.fecha) : '—'}</td>
      <td>${esc(d.contraparte || d.proveedor || (f && f.contraparte) || '—')}${d.nifContraparte || d.cpContraparte ? `<div class="hint">${esc([d.nifContraparte, d.cpContraparte ? 'CP ' + d.cpContraparte : ''].filter(Boolean).join(' · '))}</div>` : ''}</td>
      <td style="white-space:nowrap">${importe}</td>
      <td>${avisos.join(' ') || '<span class="tag ok">correcto</span>'}</td>
    </tr>`);
    const acc = h('<td><div class="acciones"></div></td>');
    const cont = acc.querySelector('.acciones');

    const bVer = h('<button class="btn btn-sm btn-accent" title="Verlo aquí, en el navegador">Ver</button>');
    bVer.onclick = () => verDocumento(d.id);
    const bCarpeta = h('<button class="btn btn-sm" title="Abrir la carpeta en el Explorador de Windows">Carpeta</button>');
    bCarpeta.onclick = () => abrirDoc(d, true);
    const bInfo = h('<button class="btn btn-sm">Ficha</button>');
    bInfo.onclick = () => fichaDocumento(d);
    cont.append(bVer, bCarpeta, bInfo);
    tr.appendChild(acc);
    tb.appendChild(tr);
  }
  t.appendChild(tb);
  return t;
}

// ---- Ver el documento ------------------------------------------------------
// El programa se instala en otro ordenador, donde la carpeta de las facturas
// está en otro sitio. Antes de abrir una pestaña en blanco se pregunta al
// servidor si el fichero aparece; si no, se dice qué hay que hacer.
let ARCHIVO_ESTADO = null;

async function estadoDelArchivo(recargar) {
  if (!ARCHIVO_ESTADO || recargar) {
    try { ARCHIVO_ESTADO = await get('archivo/estado'); } catch { ARCHIVO_ESTADO = null; }
  }
  return ARCHIVO_ESTADO;
}

async function verDocumento(id, nombre) {
  let r;
  try { r = await get('archivo/localizar/' + encodeURIComponent(id)); }
  catch (e) { return toast(e.message, true); }
  if (!r.ok) {
    ARCHIVO_ESTADO = null;
    pintarAvisoArchivo();
    return avisoNoSeAbre(r.error);
  }
  abrirVisor(id, nombre || r.nombre);
}

function avisoNoSeAbre(mensaje) {
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg"></div>');
  const m = h(`<div class="modal"><header><strong>No se puede abrir el documento</strong><button class="btn-ghost" data-x>✕</button></header>
    <div class="body"><p style="line-height:1.55;margin:0">${esc(mensaje)}</p></div>
    <footer><button class="btn" data-cerrar>Cerrar</button><button class="btn btn-accent" data-cfg>Ir a Configuración</button></footer></div>`);
  const cerrar = () => bg.remove();
  m.querySelector('[data-x]').onclick = cerrar;
  m.querySelector('[data-cerrar]').onclick = cerrar;
  m.querySelector('[data-cfg]').onclick = () => { cerrar(); irA('config'); };
  bg.onclick = (e) => { if (e.target === bg) cerrar(); };
  bg.appendChild(m);
  root.appendChild(bg);
}

// Visor al lado: se lee el PDF y se escriben los importes sin cambiar de
// pantalla, que es lo que hace falta para corregir muchas facturas seguidas.
let VISOR = null;
function abrirVisor(id, nombre) {
  const src = '/api/archivo/ver/' + encodeURIComponent(id);
  if (!VISOR) {
    VISOR = h(`<aside class="visor">
      <header>
        <b class="visor-nom"></b>
        <span class="visor-acc">
          <a class="btn btn-sm" target="_blank" rel="noopener">Pestaña aparte</a>
          <button class="btn btn-sm" data-ancho title="Más ancho / más estrecho">⇔</button>
          <button class="btn btn-sm" data-x title="Cerrar el visor">✕</button>
        </span>
      </header>
      <iframe title="Documento"></iframe>
      <div class="visor-tabla"></div>
    </aside>`);
    VISOR.querySelector('[data-x]').onclick = cerrarVisor;
    VISOR.querySelector('[data-ancho]').onclick = () => { VISOR.classList.toggle('ancho'); delete VISOR.dataset.anchoAuto; };
    document.body.appendChild(VISOR);
    document.body.classList.add('con-visor');
  }
  VISOR.querySelector('.visor-nom').textContent = nombre || 'Documento';
  VISOR.querySelector('a').href = src;
  VISOR.querySelector('iframe').src = src;
  // La tabla hoja por hoja debajo (pulsar una fila lleva a su hoja).
  const caja = VISOR.querySelector('.visor-tabla');
  caja.innerHTML = '';
  const d = (CACHE.documentos || []).find((x) => x.id === id);
  const filas = d ? filasPdfDeDoc(d) : [];
  caja.hidden = !filas.length;
  if (filas.length) caja.appendChild(tablaHojas(filas, { alPagina: (n) => irAPagina(VISOR.querySelector('iframe'), src, n), alCambiar: guardarFilaArchivada }));
  // (Con la tabla, el visor se abre ancho: caben todas sus columnas; al pasar a
  // un documento sin tabla vuelve a como estaba.)
  if (filas.length) { if (!VISOR.classList.contains('ancho')) VISOR.dataset.anchoAuto = '1'; VISOR.classList.add('ancho'); }
  else if (VISOR.dataset.anchoAuto) { VISOR.classList.remove('ancho'); delete VISOR.dataset.anchoAuto; }
}
function cerrarVisor() {
  if (VISOR) VISOR.remove();
  VISOR = null;
  document.body.classList.remove('con-visor');
  // Si se corrigió algo en la tabla, la pantalla de debajo se pone al día.
  if (CACHE.tablaTocada && !document.querySelector('.modal-bg')) { CACHE.tablaTocada = false; reload('facturas'); }
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && VISOR && !document.querySelector('.modal-bg')) cerrarVisor(); });

// Aviso permanente mientras el programa no sepa dónde están las facturas:
// sin él, «Ver» falla una y otra vez sin que nadie sepa por qué.
async function pintarAvisoArchivo() {
  const caja = document.getElementById('aviso-archivo');
  if (!caja) return;
  const e = await estadoDelArchivo(true);
  if (!e || !e.total || (e.existe && e.encontrados > 0)) { caja.hidden = true; caja.innerHTML = ''; return; }
  const texto = !e.configurada
    ? 'El programa todavía no sabe dónde están las facturas en este ordenador, así que los botones «Ver» y «Carpeta» no pueden abrir nada.'
    : !e.existe
      ? 'La carpeta del archivo configurada no existe en este ordenador: ' + e.ruta
      : 'Ninguno de los ' + e.total.toLocaleString('es-ES') + ' documentos aparece dentro de ' + e.ruta + '.';
  caja.hidden = false;
  caja.innerHTML = '';
  const b = h(`<div class="aviso-archivo"><span>📂 <b>Falta la carpeta de las facturas.</b> ${esc(texto)}</span></div>`);
  const acc = h('<span class="aviso-acc"></span>');
  const bCfg = h('<button class="btn btn-sm btn-accent">Elegir la carpeta</button>');
  bCfg.onclick = () => irA('config');
  acc.appendChild(bCfg);
  b.appendChild(acc);
  caja.appendChild(b);
}

async function abrirDoc(d, soloCarpeta) {
  if (!d.rutaRelativa && !d.ruta) return toast('Este documento no tiene archivo asociado.', true);
  try {
    const r = await api('POST', 'archivo/abrir', { documentoId: d.id, soloCarpeta: !!soloCarpeta });
    toast(soloCarpeta ? 'Abriendo la carpeta…' : 'Abriendo el documento…');
    return r;
  } catch (e) { toast(e.message, true); }
}

function fichaDocumento(d) {
  const todas = facturasDe(d.id);
  const f = todas.length === 1 ? todas[0] : null;
  openModal({ title: d.nombre, saveLabel: 'Corregir clasificación',
    fields: [{ name: '_', type: 'textarea', label: '' }], values: {},
    onSave: (_v, c) => { c(); corregirDoc(d); } });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (!ta) return;
  const fila = (k, v) => v || v === 0 ? `<tr><td style="color:#6b7280">${esc(k)}</td><td><b>${esc(v)}</b></td></tr>` : '';
  const avisos = avisosDoc(d);
  ta.replaceWith(h(`<div>
    <table style="box-shadow:none;border:1px solid var(--line)"><tbody>
      ${fila('Cliente', d.cliente)}
      ${fila('Ejercicio', d.ejercicio)}
      ${fila('Trimestre', d.trimestre)}
      ${fila('Tipo', { emitida: 'Emitida (ingreso)', recibida: 'Recibida (gasto)', hacienda: 'Hacienda', 'no-factura': 'Otro documento' }[d.sentido] || d.sentido)}
      ${d.hacienda ? fila('Hacienda', d.hacienda.etiqueta) + fila('Resultado', { ingresar: 'A ingresar', devolver: 'A devolver', cero: 'Sin actividad / cero', domiciliado: 'Domiciliado', compensar: 'A compensar' }[d.hacienda.resultado] || '')
        + fila('Importe', d.hacienda.importe != null ? eur(d.hacienda.importe) : '') + fila('Presentado / fecha', d.hacienda.fecha ? fdate(d.hacienda.fecha) : '')
        + fila('Referencia', d.hacienda.referencia) + fila('NRC', d.hacienda.nrc) + fila('CSV', d.hacienda.csv) : ''}
      ${fila('Número', d.numeroDetectado)}
      ${fila('Fecha del documento', d.fechaDocumento ? fdate(d.fechaDocumento) : '')}
      ${fila('Empresa', d.contraparte || d.proveedor)}
      ${fila('CIF / NIF', d.nifContraparte)}
      ${fila('Código postal', d.cpContraparte)}
      ${f ? fila('Base', eur(f.base)) + fila('IVA', f.iva + ' %') + (f.irpf ? fila('IRPF', f.irpf + ' %') : '') + fila('Total', eur(f.total)) + fila('Importe', estadoImporte(f).t) : ''}
      ${todas.length > 1 ? fila('Facturas', todas.length + ' en este PDF (con «Ver», la tabla de debajo)') + fila('Base (suma)', eur(todas.reduce((a, x) => a + (Number(x.base) || 0), 0))) + fila('Total (suma)', eur(todas.reduce((a, x) => a + (Number(x.total) || 0), 0))) : ''}
      ${fila('Tamaño', bytes(d.tamano))}
      ${fila('Origen', { importacion: 'Importado ' + (d.importado ? fdate(d.importado) : ''), 'archivo-albereda36': 'Archivo inicial' }[d.origen] || d.origen)}
      ${fila('Duplicado de', d.duplicadoDe)}
    </tbody></table>
    ${avisos.length ? `<div class="aviso-caja"><b>A revisar:</b><ul>${avisos.map((a) => `<li>${esc(a.texto)}</li>`).join('')}</ul></div>` : ''}
    ${(d.historial || []).length ? `<p style="margin-top:10px"><b>Cambios hechos a mano:</b></p><ul class="hint">${d.historial.map((x) => `<li>${fdate(x.fecha)}: ${esc(x.antes)} → ${esc(x.despues)}${x.nota ? ' — ' + esc(x.nota) : ''}</li>`).join('')}</ul>` : ''}
    <p style="margin-top:10px"><b>Ubicación:</b></p>
    <p class="doc-ruta">${esc(d.almacen === 'importadas' ? 'Importadas / ' : 'Archivo / ')}${esc(d.rutaRelativa || d.ruta || '—')}</p>
    <p><button class="btn btn-sm btn-accent" data-ver>Ver documento</button></p>
  </div>`));
  document.querySelector('.modal-bg:last-child [data-ver]').onclick = () => verDocumento(d.id);
}

// Corregir cliente / periodo / tipo de un documento del archivo.
function corregirDoc(d, alTerminar) {
  const sentidoActual = d.sentido === 'no-factura' ? 'no-factura' : d.sentido;
  openModal({
    title: 'Corregir · ' + d.nombre,
    saveLabel: 'Guardar y marcar como revisado',
    fields: [
      { name: 'cliente', label: 'Cliente', type: 'select', options: clientesArchivo().map((c) => ({ value: c.id, label: c.alias })) },
      { type: 'group2', fields: [
        { name: 'ejercicio', label: 'Año', type: 'number' },
        { name: 'trimestre', label: 'Trimestre', type: 'select', options: TRIMS.map((t) => ({ value: t, label: t })) },
      ] },
      { name: 'sentido', label: 'Tipo', type: 'select', options: [
        { value: 'emitida', label: 'Emitida (ingreso)' }, { value: 'recibida', label: 'Recibida (gasto)' },
        { value: 'hacienda', label: 'Hacienda (modelos, pagos, notificaciones)' },
        { value: 'no-factura', label: 'No es una factura (no cuenta en el IVA)' }] },
      { name: 'nota', label: 'Nota (opcional)', hint: 'Por qué se cambia. Queda guardado en la ficha del documento.' },
    ],
    values: { cliente: d.sujetoId || (clientesArchivo().find((c) => c.alias === d.cliente) || {}).id, ejercicio: d.ejercicio, trimestre: d.trimestre, sentido: sentidoActual },
    onSave: async (v, close) => {
      if ((v.sentido === 'no-factura' || v.sentido === 'hacienda') && facturasDe(d.id).length && d.sentido !== v.sentido) {
        const nf = facturasDe(d.id).length;
        if (!window.confirm('Al marcarlo como "' + (v.sentido === 'hacienda' ? 'Hacienda' : 'no es factura') + '" ' + (nf > 1 ? 'se quitan sus ' + nf + ' facturas (todo el PDF)' : 'se quita') + ' de la lista de facturas y deja de contar en el IVA. ¿Seguir?')) return;
      }
      await api('POST', 'revision/documento/' + d.id, { ...v, ejercicio: Number(v.ejercicio), revisado: true });
      close(); toast('Guardado y marcado como revisado');
      EXP_ARBOL = null;
      await refreshCache();
      if (alTerminar) alTerminar(); else router();
    },
  });
}

// ---- Importar facturas --------------------------------------------
// IMP.filas: una por fichero. Cada fila guarda la propuesta del servidor y lo
// que la persona va cambiando en pantalla.
const IMP = { filas: [], cargado: false, comun: {}, ocupado: false, resumen: null, repetidas: {} };
const MAX_LOTE_BYTES = 20 * 1024 * 1024;

// ---- Carpetas enteras: se recorren todas las subcarpetas -----------
const EXT_FACTURA = /\.(pdf|jpe?g|png|tiff?|xml|xsig)$/i;
const EXT_COMPRIMIDO = /\.(zip|rar|7z)$/i;
const delSistema = (n) => n.startsWith('.') || n.startsWith('~$') || /^(thumbs\.db|desktop\.ini)$/i.test(n);

function leerEntrada(entry, lista) {
  if (entry.isFile) {
    return new Promise((ok) => entry.file((f) => { lista.push({ file: f, ruta: entry.fullPath.replace(/^\/+/, '') }); ok(); }, () => ok()));
  }
  if (!entry.isDirectory) return Promise.resolve();
  const lector = entry.createReader();
  // readEntries devuelve las entradas a trozos (unas 100): se pide hasta que no quede nada.
  return new Promise((ok) => {
    const trozo = () => lector.readEntries(async (hijos) => {
      try {
        if (!hijos.length) return ok();
        for (const hijo of hijos) await leerEntrada(hijo, lista);
        trozo();
      } catch { ok(); }
    }, () => ok());
    trozo();
  });
}

// Lo soltado puede ser ficheros sueltos o carpetas. Las entradas se piden YA,
// dentro del propio evento: después el navegador las invalida.
function ficherosSoltados(dt) {
  const items = [...(dt.items || [])].filter((i) => i.kind === 'file');
  const entradas = items.map((i) => (i.webkitGetAsEntry ? i.webkitGetAsEntry() : null));
  if (!entradas.some(Boolean)) return Promise.resolve([...dt.files].map((f) => ({ file: f, ruta: f.name })));
  // Lo que no trae «entrada» (p. ej. un adjunto arrastrado desde Outlook) se
  // coge como fichero suelto, para no perderlo.
  const sinEntrada = items.map((i, k) => (entradas[k] ? null : i.getAsFile())).filter(Boolean)
    .map((f) => ({ file: f, ruta: f.name }));
  return (async () => {
    const lista = [...sinEntrada];
    for (const e of entradas) if (e) await leerEntrada(e, lista);
    return lista;
  })();
}

function separarFicheros(entradas) {
  const facturas = [], comprimidos = [], otros = {};
  let sistema = 0;
  for (const x of entradas) {
    const n = x.file.name;
    if (delSistema(n)) sistema++;
    else if (EXT_FACTURA.test(n)) facturas.push(x);
    else if (EXT_COMPRIMIDO.test(n)) comprimidos.push(x.ruta);
    else {
      const ext = (n.match(/\.([^.]+)$/) || [null, 'sin extensión'])[1].toLowerCase();
      otros[ext] = (otros[ext] || 0) + 1;
    }
  }
  return { facturas, comprimidos, otros, sistema };
}

function filaDesdeItem(lote, it) {
  const p = it.propuesta || {};
  const imp = p.importes || {};
  const grave = (it.avisos || []).some((a) => a.grave);
  return {
    lote, token: it.token, nombre: it.nombre, rechazado: it.rechazado || null, carpeta: it.carpeta || '',
    avisos: it.avisos || [], motivos: p.motivos || [], conTexto: it.conTexto, ocr: !!it.ocr,
    fechasPosibles: p.fechasPosibles || [],
    separadaDe: it.separadaDe || null, paginasEscaneo: it.paginasEscaneo || 0, pdfEntero: it.pdfEntero || null,
    // Para agrupar lo pendiente por proveedor (o destinatario).
    nifContraparte: p.nifContraparte || '', clienteAprendido: !!p.clienteAprendido,
    cliente: p.cliente || '', ejercicio: p.ejercicio || '', trimestre: p.trimestre || '',
    sentido: p.sentido || '', numero: p.numero || '', fecha: p.fecha || '',
    contraparte: p.contraparte || '', cpContraparte: p.cpContraparte || '',
    base: imp.base ?? '', iva: imp.iva ?? (imp.total ? '' : 21), irpf: imp.irpf || 0, total: imp.total ?? '',
    importeOrigen: imp.total ? 'pdf' : null, fiabilidad: imp.fiabilidad || null,
    desglose: imp.desglose || null, recargo: imp.recargo || null, tipoDocumento: p.tipoDocumento || 'factura',
    listo: !!p.listo, grave,
    // Propuesta completa pero no segura (p. ej. "¿gasto o ingreso?"): se pide
    // que alguien la mire antes de marcarla.
    porComprobar: !p.listo && !grave,
    marcado: !!p.listo && !grave,
    forzar: false, forzarPeriodo: false, error: null,
  };
}

const pedidoDeFila = (f) => ({
  token: f.token, cliente: f.cliente, ejercicio: Number(f.ejercicio), trimestre: f.trimestre,
  sentido: f.sentido, numero: f.numero, fecha: f.fecha || null, contraparte: f.contraparte,
  nifContraparte: f.nifContraparte, cpContraparte: f.cpContraparte,
  base: f.base, iva: f.iva, irpf: f.irpf, total: f.total, importeOrigen: f.importeOrigen,
  forzar: f.forzar, forzarPeriodo: f.forzarPeriodo,
  tipoDocumento: f.tipoDocumento || 'factura', ...(f.desglose ? { desglose: f.desglose } : {}), ...(num(f.recargo) ? { recargo: num(f.recargo) } : {}),
});

async function cargarPendientes() {
  const lotes = await get('importar/pendientes');
  IMP.filas = [];
  IMP.repetidas = {};
  for (const l of lotes) {
    for (const it of l.items) if (it.propuesta) IMP.filas.push(filaDesdeItem(l.lote, it));
    IMP.repetidas[l.lote] = l.repetidas || [];
  }
  IMP.cargado = true;
}

// Lo que devuelve «analizar» (o «separar»): filas nuevas, avisos rehechos de
// las que ya estaban (una se ha quedado repetida con otra nueva) y la lista
// de repetidas del lote.
function aplicarAnalisis(r) {
  for (const it of r.items || []) IMP.filas.push(filaDesdeItem(r.lote, it));
  for (const a of r.actualizados || []) {
    const f = IMP.filas.find((x) => x.token === a.token);
    if (!f) continue;
    f.avisos = a.avisos || [];
    f.grave = f.avisos.some((x) => x.grave);
    f.listo = !!a.listo;
    if (f.grave && !f.forzar) f.marcado = false;
  }
  if (r.lote) IMP.repetidas[r.lote] = r.repetidas || [];
}

// Grupos de repetidas que siguen en pantalla.
function repetidasVivas() {
  const out = [];
  for (const [lote, grupos] of Object.entries(IMP.repetidas || {})) {
    for (const g of grupos) {
      const vivos = g.miembros.filter((m) => IMP.filas.some((f) => f.token === m.token));
      if (!vivos.length || (g.donde === 'lote' && vivos.length < 2)) continue;
      out.push({ ...g, lote, miembros: vivos, sobran: g.sobran ? g.sobran.filter((t) => vivos.some((m) => m.token === t)) : null });
    }
  }
  return out;
}
const textoRepetida = (g) => (g.donde === 'archivo'
  ? `«${g.miembros[0].nombre}» ya está en el archivo${g.yaArchivada ? ' («' + g.yaArchivada + '»)' : ''}`
  : g.miembros.map((m) => '«' + m.nombre + '»').join(' y ')) + ` — ${g.motivo}${g.numero ? ' (nº ' + g.numero + ')' : ''}`;

function problemasFila(f) {
  const out = [];
  if (!f.cliente) out.push('cliente');
  if (!f.ejercicio) out.push('año');
  if (!f.trimestre) out.push('trimestre');
  if (!f.sentido) out.push('tipo');
  // Hacienda: el 303 del 4T se presenta en enero; su fecha no es su periodo.
  if (f.fecha && f.ejercicio && f.trimestre && f.sentido !== 'hacienda') {
    const t = Math.floor((Number(f.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T';
    if ((Number(f.fecha.slice(0, 4)) !== Number(f.ejercicio) || t !== f.trimestre) && !f.forzarPeriodo) out.push('la fecha no cae en ese trimestre');
  }
  // Lo escrito que no es un número no puede dar la fila por buena.
  const malos = ['base', 'iva', 'irpf', 'total'].filter((k) => f[k] !== '' && f[k] != null && num(f[k]) == null);
  if (malos.length) out.push('importe no válido (' + malos.join(', ') + ')');
  const b = num(f.base), iv = num(f.iva), t = num(f.total);
  if (b != null && iv != null && t != null && !cuadra(b, iv, num(f.irpf) || 0, t, f.desglose, num(f.recargo))) out.push('los importes no cuadran');
  if (f.grave && !f.forzar) out.push('tiene un aviso grave');
  return out;
}

async function renderImportar() {
  const turno = ++NAV;
  if (!IMP.cargado) {
    view.innerHTML = '<div class="empty">Cargando…</div>';
    try { await cargarPendientes(); } catch (e) { if (turno === NAV) view.innerHTML = `<div class="empty">${esc(e.message)}</div>`; return; }
    if (turno !== NAV) return;
  }
  view.innerHTML = '';
  view.appendChild(h('<h1>Importar facturas</h1>'));
  // Escaneos sin leer: si es porque este Windows no tiene el OCR en español (o
  // lo bloquea), se dice aquí, con cómo instalarlo; antes solo salía al ordenar.
  if (IMP.filas.some((f) => !f.conTexto)) {
    const caja = h('<div></div>');
    view.appendChild(caja);
    (IMP.ocr ? Promise.resolve(IMP.ocr) : get('ocr/estado')).then((e) => {
      if (e && e.ok) IMP.ocr = e;
      if (turno === NAV && e) caja.innerHTML = avisoOcr(e.motivo, e.ok);
    }).catch(() => {});
  }
  view.appendChild(h('<p class="sub">Arrastra aquí las facturas nuevas. El programa propone dónde va cada una y lee los importes; tú revisas y confirmas. Nada se archiva hasta que pulses «Importar».</p>'));

  // --- 1. Soltar ficheros ---
  const zona = h(`<div class="dropzone">
    <div class="dz-ico">📄</div>
    <div><b>Suelta aquí las facturas o una carpeta entera</b></div>
    <div><label class="dz-link">Elegir ficheros<input data-in="ficheros" type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff,.xml,.xsig" hidden></label>
      · <label class="dz-link">Elegir una carpeta<input data-in="carpeta" type="file" webkitdirectory multiple hidden></label></div>
    <div class="hint">Da igual lo desordenada que esté: se miran todas sus subcarpetas, y el programa propone el cliente, el año, el trimestre y si es gasto o ingreso de cada factura. PDF, imágenes y facturas electrónicas (XML).</div>
  </div>`);
  const input = zona.querySelector('[data-in="ficheros"]');
  const inputCarpeta = zona.querySelector('[data-in="carpeta"]');
  const cli = clientesArchivo();
  const comun = h(`<details class="comun"${IMP.comun.cliente || IMP.comun.ejercicio ? ' open' : ''}>
    <summary>Datos comunes del lote <span class="hint">(opcional: solo rellenan lo que el programa no averigüe)</span></summary>
    <div class="comun-campos">
      <label>Cliente<select data-c="cliente">${opciones(cli.map((c) => ({ v: c.id, l: c.alias })), IMP.comun.cliente, '—')}</select></label>
      <label>Año<input data-c="ejercicio" type="number" min="2000" max="2100" value="${esc(IMP.comun.ejercicio || '')}" placeholder="—"></label>
      <label>Trimestre<select data-c="trimestre">${opciones(TRIMS.map((t) => ({ v: t, l: t })), IMP.comun.trimestre, '—')}</select></label>
      <label>Tipo<select data-c="sentido">${opciones(TIPOS_DOC, IMP.comun.sentido, '—')}</select></label>
    </div>
    <div class="hint">Útil, por ejemplo, para un trimestre entero de un cliente que llega junto: elige cliente · año · trimestre y suelta todo.</div>
  </details>`);
  comun.querySelectorAll('[data-c]').forEach((el) => { el.onchange = () => { IMP.comun[el.dataset.c] = el.value; }; });
  const progreso = h('<div class="progreso" hidden><div class="barra"><i></i></div><span></span></div>');

  // entradas: [{ file, ruta }], ruta = dónde estaba dentro de la carpeta soltada.
  const subir = async (entradas) => {
    if (IMP.ocupado) { toast('Espera a que termine lo que se está analizando.', true); return; }
    const { facturas: lista, comprimidos, otros, sistema } = separarFicheros(entradas);
    const nOtros = Object.values(otros).reduce((a, b) => a + b, 0);
    IMP.resumen = entradas.some((x) => x.ruta.includes('/')) || comprimidos.length || nOtros
      ? { total: entradas.length, facturas: lista.length, comprimidos, otros, sistema } : null;
    if (!lista.length) {
      toast('No hay ninguna factura (PDF, imagen o XML) en lo que has soltado.', true);
      repintar('importar');
      return;
    }
    IMP.ocupado = true;
    progreso.hidden = false;
    const barra = progreso.querySelector('i');
    const texto = progreso.querySelector('span');
    let hechos = 0, lote = null;
    try {
      // Se envían en tandas de ~20 MB para no pasar el límite del servidor.
      let tanda = [], peso = 0;
      const enviar = async () => {
        if (!tanda.length) return;
        const archivos = [];
        for (const f of tanda) {
          // Un fichero que no se puede leer (ruta de más de 260 caracteres en
          // Windows, o borrado mientras tanto) no para a los demás.
          try {
            archivos.push({ nombre: f.file.name, ruta: f.ruta, contenidoBase64: await fileToB64(f.file) });
          } catch {
            IMP.filas.push({ token: 'x' + Math.random(), nombre: f.file.name, carpeta: f.ruta.includes('/') ? f.ruta.slice(0, f.ruta.lastIndexOf('/')) : '',
              rechazado: 'No se pudo leer el fichero. Suele pasar cuando la carpeta está muy dentro de otras (ruta demasiado larga): mueve la carpeta más arriba, por ejemplo al Escritorio, y vuelve a soltarla.' });
          }
        }
        if (archivos.length) {
          // Si una tanda falla, sus ficheros quedan en la lista como no
          // analizados y se sigue con las demás.
          try {
            const r = await api('POST', 'importar/analizar', { archivos, lote, comun: IMP.comun });
            lote = r.lote;
            aplicarAnalisis(r);
          } catch (e) {
            for (const a of archivos) {
              IMP.filas.push({ token: 'x' + Math.random(), nombre: a.nombre, carpeta: a.ruta.includes('/') ? a.ruta.slice(0, a.ruta.lastIndexOf('/')) : '',
                rechazado: 'No se pudo analizar (' + e.message + '). Vuelve a soltarlo.' });
            }
          }
        }
        hechos += tanda.length;
        barra.style.width = Math.round(100 * hechos / lista.length) + '%';
        texto.textContent = `Analizadas ${hechos} de ${lista.length}…`;
        tanda = []; peso = 0;
      };
      for (const f of lista) {
        // 36 MB: en base64 ocupa un tercio más y el servidor admite 50 MB por envío.
        if (f.file.size > 36 * 1024 * 1024) {
          IMP.filas.push({ token: 'x' + Math.random(), nombre: f.file.name, carpeta: '', rechazado: 'Demasiado grande (más de 36 MB).' });
          continue;
        }
        if (peso + f.file.size > MAX_LOTE_BYTES && tanda.length) await enviar();
        tanda.push(f); peso += f.file.size;
      }
      await enviar();
      // Las repetidas saltan con su nombre nada más terminar.
      const rep = repetidasVivas();
      const separadas = IMP.filas.filter((f) => f.lote === lote && f.separadaDe).length;
      if (rep.length) {
        const nombres = rep.slice(0, 3).map((g) => g.miembros.map((m) => '«' + m.nombre + '»').join(' = ')).join('; ');
        toast(`${hechos} archivo(s) analizados. ${rep.length} repetida${rep.length === 1 ? '' : 's'}: ${nombres}${rep.length > 3 ? '…' : ''}`, true);
      } else {
        toast(`${hechos} archivo(s) analizados${separadas ? ` (${separadas} facturas separadas de PDF con varias)` : ''}`);
      }
    } catch (e) { toast(e.message, true); }
    finally {
      IMP.ocupado = false;
      try { CACHE.st = await get('stats'); pintarCabecera(); } catch { /* la cabecera se refresca en la próxima */ }
      repintar('importar');
    }
  };
  // El selector se vacía DESPUÉS de leer los ficheros (vaciarlo antes los
  // invalida) y así se puede volver a elegir la misma carpeta.
  input.onchange = () => subir([...input.files].map((f) => ({ file: f, ruta: f.name }))).finally(() => { input.value = ''; });
  inputCarpeta.onchange = () => subir([...inputCarpeta.files].map((f) => ({ file: f, ruta: f.webkitRelativePath || f.name })))
    .finally(() => { inputCarpeta.value = ''; });
  zona.addEventListener('dragover', (e) => { e.preventDefault(); zona.classList.add('encima'); });
  zona.addEventListener('dragleave', () => zona.classList.remove('encima'));
  zona.addEventListener('drop', (e) => {
    e.preventDefault(); zona.classList.remove('encima');
    if (IMP.ocupado) return toast('Espera a que termine lo que se está analizando y vuelve a soltarlo.', true);
    progreso.hidden = false;
    progreso.querySelector('span').textContent = 'Leyendo la carpeta…';
    ficherosSoltados(e.dataTransfer).then(subir)
      .catch((err) => { progreso.hidden = true; toast('No se pudo leer lo soltado: ' + err.message, true); });
  });
  view.append(zona, comun, progreso);

  // Qué se ha quedado fuera de lo soltado, para que nada se pierda sin saberlo.
  if (IMP.resumen) {
    const r = IMP.resumen;
    const fuera = Object.entries(r.otros).sort((a, b) => b[1] - a[1]).map(([ext, n]) => `${n} .${ext}`);
    const caja = h(`<div class="aviso-archivo" style="margin-top:12px">
      <div><b>${r.total} fichero${r.total === 1 ? '' : 's'} en lo soltado</b> · ${r.facturas} factura${r.facturas === 1 ? '' : 's'} para analizar</div>
      ${fuera.length ? `<div class="hint">No son facturas y se han dejado fuera: ${esc(fuera.join(', '))}.</div>` : ''}
      ${r.sistema ? `<div class="hint">${r.sistema} fichero${r.sistema === 1 ? '' : 's'} del sistema ignorado${r.sistema === 1 ? '' : 's'} (Thumbs.db, desktop.ini…).</div>` : ''}
      ${r.comprimidos.length ? `<div><b>Hay ${r.comprimidos.length} comprimido${r.comprimidos.length === 1 ? '' : 's'} sin abrir</b>: descomprímelo${r.comprimidos.length === 1 ? '' : 's'} y suelta otra vez su carpeta. ${esc(r.comprimidos.slice(0, 5).join(' · '))}${r.comprimidos.length > 5 ? '…' : ''}</div>` : ''}
    </div>`);
    const x = h('<button class="btn btn-sm" style="margin-top:6px">Entendido</button>');
    x.onclick = () => { IMP.resumen = null; caja.remove(); };
    caja.appendChild(x);
    view.appendChild(caja);
  }

  if (!IMP.filas.length) {
    view.appendChild(h('<div class="vacio-exp" style="margin-top:16px">No hay nada pendiente de importar.</div>'));
    return;
  }

  // --- Repetidas: con el nombre de cada fichero, y un botón para quitar la que sobra.
  const repetidas = repetidasVivas();
  if (repetidas.length) {
    const caja = h(`<div class="aviso-archivo caja-repetidas" style="margin-top:12px">
      <div><b>⚠ ${repetidas.length} factura${repetidas.length === 1 ? '' : 's'} repetida${repetidas.length === 1 ? '' : 's'}</b> <span class="hint">No se importan hasta que quites la que sobra (o marques «Importar igualmente» en su fila).</span></div>
      <ul class="lista-repetidas"></ul></div>`);
    const ul = caja.querySelector('ul');
    const quitar = async (grupos) => {
      const porLote = {};
      for (const g of grupos) for (const t of g.sobran || []) (porLote[g.lote] = porLote[g.lote] || new Set()).add(t);
      for (const [lote, tokens] of Object.entries(porLote)) await api('POST', 'importar/descartar', { lote, tokens: [...tokens] });
      const rechazadas = IMP.filas.filter((f) => f.rechazado);
      await cargarPendientes(); // los avisos de las que quedan se rehacen
      IMP.filas.push(...rechazadas);
      try { CACHE.st = await get('stats'); pintarCabecera(); } catch { /* se refresca luego */ }
      repintar('importar');
    };
    for (const g of repetidas.slice(0, 40)) {
      const li = h(`<li><span>${esc(textoRepetida(g))}.${g.buena ? ` <b>La buena parece «${esc(g.buena)}»</b>.` : ''}</span> </li>`);
      if (g.sobran && g.sobran.length) {
        const sobra = g.miembros.filter((m) => g.sobran.includes(m.token)).map((m) => '«' + m.nombre + '»').join(', ');
        const b = h(`<button class="btn btn-sm" title="Quita de la espera ${esc(sobra)}">Descartar la que sobra</button>`);
        b.onclick = () => confirmar(`¿Descartar ${sobra}? Se quita de la espera y no se importa (tu fichero original no se toca).`, () => quitar([g]).catch((e) => toast(e.message, true)));
        li.appendChild(b);
      } else {
        li.appendChild(h('<span class="hint">Ábrelas y descarta una.</span>'));
      }
      ul.appendChild(li);
    }
    if (repetidas.length > 40) ul.appendChild(h(`<li class="hint">…y ${repetidas.length - 40} más.</li>`));
    const claras = repetidas.filter((g) => g.sobran && g.sobran.length);
    if (claras.length > 1) {
      const b = h(`<button class="btn btn-sm" style="margin-top:6px">Descartar las ${claras.length} que sobran</button>`);
      b.onclick = () => confirmar(`¿Descartar las ${claras.reduce((n, g) => n + g.sobran.length, 0)} copias que sobran? Se quitan de la espera y no se importan (tus ficheros originales no se tocan).`, () => quitar(claras).catch((e) => toast(e.message, true)));
      caja.appendChild(b);
    }
    view.appendChild(caja);
  }

  // --- 2. Revisar y confirmar ---
  const validas = IMP.filas.filter((f) => !f.rechazado);
  const esLista = (f) => !problemasFila(f).length && !f.porComprobar;
  const listas = validas.filter(esLista).length;
  const graves = validas.filter((f) => f.grave && !f.forzar).length;
  const pl = (n, uno, varios) => `<b>${n}</b> ${n === 1 ? uno : varios}`;
  view.appendChild(h(`<h2 class="h2">Revisa y confirma <span class="hint">(${validas.length} archivo${validas.length === 1 ? '' : 's'})</span></h2>`));
  view.appendChild(h(`<div class="exp-resumen">
    <span><span class="pto verde"></span> ${pl(listas, 'lista para importar', 'listas para importar')}</span>
    <span><span class="pto ambar"></span> ${pl(validas.length - listas - graves, 'por comprobar o completar', 'por comprobar o completar')}</span>
    <span><span class="pto rojo"></span> ${pl(graves, 'con aviso grave', 'con aviso grave')} (duplicado, número repetido…)</span>
  </div>`));

  const barra = h('<div class="toolbar"></div>');
  const izq = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const bListas = h('<button class="btn">Marcar las listas</button>');
  const bNinguna = h('<button class="btn">Desmarcar todo</button>');
  izq.append(bListas, bNinguna);
  // Una a una, con el documento al lado y el teclado: lo más rápido para lo que
  // hay que mirar.
  const porMirar = validas.filter((f) => !esLista(f));
  if (porMirar.length) {
    const bRapida = h(`<button class="btn btn-accent" title="Una a una, con el documento al lado y atajos de teclado">⚡ Revisión rápida (${porMirar.length})</button>`);
    bRapida.onclick = () => abrirRevisionRapida(porMirar, cli);
    izq.prepend(bRapida);
  }
  const der = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const bDescartar = h('<button class="btn btn-danger">Descartar las no marcadas</button>');
  const bImportar = h('<button class="btn btn-accent">Importar marcadas</button>');
  der.append(bDescartar, bImportar);
  barra.append(izq, der);
  view.appendChild(barra);

  // Lo pendiente del mismo proveedor se decide de una vez.
  const grupos = gruposPendientes(porMirar);
  if (grupos.length) view.appendChild(panelGrupos(grupos, cli));

  const tabla = h(`<div class="tabla-scroll"><table class="imp-tabla"><thead><tr>
    <th></th><th>Documento y avisos</th><th>Cliente</th><th>Año</th><th>Trim.</th><th>Tipo</th><th>Nº factura</th><th>Fecha</th>
    <th>Base €</th><th>IVA %</th><th>IRPF %</th><th>Total €</th>
  </tr></thead><tbody></tbody></table></div>`);
  const tb = tabla.querySelector('tbody');
  view.appendChild(tabla);

  const contarMarcadas = () => {
    const n = IMP.filas.filter((f) => f.marcado && !f.rechazado).length;
    bImportar.textContent = `Importar marcadas (${n})`;
    bImportar.disabled = !n;
  };

  const pintarFila = (f) => {
    if (f.rechazado) {
      const tr = h(`<tr class="fila-rechazada"><td></td><td><div class="doc-nom">${esc(f.nombre)}</div>${f.carpeta ? `<div class="hint">📁 ${esc(f.carpeta)}</div>` : ''}</td><td colspan="10"><span class="aviso-inc aviso-dup">${esc(f.rechazado)}</span> </td></tr>`);
      const x = h('<button class="btn btn-sm">Quitar de la lista</button>');
      x.onclick = () => { IMP.filas = IMP.filas.filter((y) => y !== f); renderImportar(); };
      tr.lastElementChild.appendChild(x);
      return tr;
    }
    const tr = h('<tr></tr>');
    const celda = (html) => { const td = h('<td></td>'); td.innerHTML = html; tr.appendChild(td); return td; };
    const chk = h('<input type="checkbox" class="chk-grande" title="Importar este archivo">');
    chk.checked = f.marcado;
    chk.onchange = () => { f.marcado = chk.checked; if (chk.checked) f.porComprobar = false; estado(); contarMarcadas(); };
    celda('').appendChild(chk);

    const nom = celda(`<div class="doc-nom">${esc(f.nombre)}</div>`);
    const ver = h('<a href="#" class="ver-pdf">👁 ver PDF</a>');
    // (De un PDF con varias facturas: el PDF entero, abierto en su página.)
    ver.onclick = (e) => { e.preventDefault(); window.open(f.pdfEntero ? `/api/importar/ver/${f.lote}/${f.token}?entero=1#page=${f.pdfEntero.desde}` : `/api/importar/ver/${f.lote}/${f.token}`, '_blank', 'noopener'); };
    nom.appendChild(ver);
    if (f.carpeta) nom.appendChild(h(`<div class="hint" title="Carpeta de la que viene">📁 ${esc(f.carpeta)}</div>`));
    nom.appendChild(h(`<div class="hint motivos">${esc(f.motivos.slice(0, 2).join(' · ') || (f.conTexto ? '' : 'Sin texto legible (escaneo): rellena los datos mirando el PDF.'))}</div>`));
    if (f.separadaDe) {
      const s = f.separadaDe;
      nom.prepend(h(`<span class="tag hoja" title="Está dentro de «${esc(s.nombre)}», un PDF con varias facturas${f.pdfEntero ? ': el PDF se guarda entero y esta factura apunta a sus páginas' : ''}">${s.desde === s.hasta ? 'Hoja ' + s.desde : 'Hojas ' + s.desde + '–' + s.hasta} de ${s.total}</span>`));
      nom.appendChild(h(f.pdfEntero ? `<div class="hint sep-de">📄 dentro de «${esc(s.nombre)}» (se guarda entero)</div>` : `<div class="hint sep-de">✂ separada de «${esc(s.nombre)}»</div>`));
      if (s.dudas && s.dudas.length) nom.appendChild(h(`<div class="aviso-inc">Doble revisión: ${esc(s.dudas.join(' · '))}</div>`));
    }
    if (f.paginasEscaneo > 1) {
      const b = h(`<button class="btn btn-sm" style="margin-top:4px" title="Si este escaneo trae varias facturas, crea una fila por página">✂ Separar por páginas (${f.paginasEscaneo})</button>`);
      b.onclick = async () => {
        b.disabled = true; b.textContent = 'Separando…';
        try {
          const r = await api('POST', 'importar/separar', { lote: f.lote, token: f.token });
          IMP.filas = IMP.filas.filter((x) => x.token !== r.quitado);
          aplicarAnalisis(r);
          toast(`Separado en ${r.items.length} páginas`);
          repintar('importar');
        } catch (e) { b.disabled = false; b.textContent = `✂ Separar por páginas (${f.paginasEscaneo})`; toast(e.message, true); }
      };
      nom.appendChild(b);
    }
    if (f.ocr) nom.appendChild(h('<div class="hint" title="Los datos salen de leer el escaneo: comprueba fecha e importe">🔎 leído del escaneo (OCR)</div>'));
    // La otra parte de la factura (el proveedor, si es recibida): empresa, CIF
    // y código postal leídos del documento. Se pueden corregir aquí mismo.
    const prov = h(`<div class="prov-fila" title="Empresa, CIF y código postal de quien emite la factura (o de a quién va, si es emitida)">
      <input data-p="contraparte" placeholder="Empresa" value="${esc(f.contraparte)}">
      <input data-p="nifContraparte" placeholder="CIF / NIF" value="${esc(f.nifContraparte)}">
      <input data-p="cpContraparte" placeholder="C.P." inputmode="numeric" maxlength="5" value="${esc(f.cpContraparte)}"></div>`);
    prov.querySelectorAll('[data-p]').forEach((el) => { el.oninput = () => { f[el.dataset.p] = el.value.trim(); }; });
    nom.appendChild(prov);
    const tdE = h('<div class="estado-fila"></div>');
    nom.appendChild(tdE);

    const campo = (html, clave, conv) => {
      const td = celda(html);
      const el = td.firstElementChild;
      el.oninput = el.onchange = () => {
        f[clave] = conv ? conv(el.value) : el.value;
        // Si se cambia el tipo o la base ya no es la suma del desglose, la
        // factura pasa a ser de un solo tipo: el desglose leído deja de valer.
        if ((clave === 'iva' || (clave === 'base' && !partesDe(num(f.base), num(f.iva), f.desglose))) && f.desglose) f.desglose = null;
        if (['base', 'iva', 'irpf'].includes(clave) && f.totalAuto !== false) {
          const b = num(f.base), iv = num(f.iva);
          if (b != null && iv != null) {
            f.total = totalDe(b, iv, num(f.irpf) || 0, f.desglose, num(f.recargo));
            tr.querySelector('[data-total]').value = f.total;
          }
        }
        if (clave === 'total') f.totalAuto = false;
        if (['base', 'iva', 'irpf', 'total'].includes(clave)) f.importeOrigen = 'manual';
        // Quien toca un dato ya está mirando la factura.
        f.porComprobar = false;
        f.error = null;
        if (!problemasFila(f).length && !f.marcado && !f.grave) { f.marcado = true; chk.checked = true; contarMarcadas(); }
        estado();
        if (['base', 'iva', 'irpf', 'total', 'sentido'].includes(clave)) refrescarSumas();
      };
      return el;
    };
    const vacio = (k) => (f[k] === '' || f[k] == null ? ' falta' : '');
    campo(`<select class="${vacio('cliente')}">${opciones(cli.map((c) => ({ v: c.id, l: c.alias })), f.cliente, '¿?')}</select>`, 'cliente');
    campo(`<input data-ej type="number" class="w-anio${vacio('ejercicio')}" value="${esc(f.ejercicio)}">`, 'ejercicio', (v) => (v ? Number(v) : ''));
    campo(`<select data-tr class="${vacio('trimestre')}">${opciones(TRIMS.map((t) => ({ v: t, l: t })), f.trimestre, '¿?')}</select>`, 'trimestre');
    campo(`<select class="${vacio('sentido')}">${opciones(TIPOS_DOC, f.sentido, '¿?')}</select>`, 'sentido');
    campo(`<input class="w-num" value="${esc(f.numero)}">`, 'numero');
    // Fecha: al elegirla, el año y el trimestre se ponen solos.
    const tdF = celda('');
    const inF = h(`<input type="date" value="${esc(f.fecha)}">`);
    tdF.appendChild(inF);
    inF.oninput = inF.onchange = () => {
      f.fecha = inF.value;
      if (f.fecha) {
        f.ejercicio = Number(f.fecha.slice(0, 4));
        f.trimestre = Math.floor((Number(f.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T';
        tr.querySelector('[data-ej]').value = f.ejercicio;
        tr.querySelector('[data-tr]').value = f.trimestre;
        f.forzarPeriodo = false;
      }
      if (!problemasFila(f).length && !f.marcado && !f.grave) { f.marcado = true; chk.checked = true; contarMarcadas(); }
      estado();
    };
    if (f.fechasPosibles.length) {
      const alt = h(`<div class="hint">El PDF tiene varias: ${f.fechasPosibles.map((x) => `<a href="#" data-f="${esc(x)}">${esc(fdate(x))}</a>`).join(', ')}</div>`);
      alt.querySelectorAll('[data-f]').forEach((a) => { a.onclick = (e) => { e.preventDefault(); inF.value = a.dataset.f; inF.onchange(); }; });
      tdF.appendChild(alt);
    }
    campo(`<input class="w-imp" inputmode="decimal" value="${esc(f.base)}">`, 'base', aImporte);
    campo(`<input class="w-pct" inputmode="decimal" value="${esc(f.iva)}">`, 'iva', aPct);
    campo(`<input class="w-pct" inputmode="decimal" value="${esc(f.irpf)}">`, 'irpf', aPct);
    campo(`<input data-total class="w-imp" inputmode="decimal" value="${esc(f.total)}">`, 'total', aImporte);

    function estado() {
      const prob = problemasFila(f);
      tr.querySelectorAll('.falta').forEach((el) => { if (el.value) el.classList.remove('falta'); });
      tr.className = f.error ? 'fila-error'
        : prob.length ? (f.grave && !f.forzar ? 'fila-grave' : 'fila-pendiente')
          : f.porComprobar && !f.marcado ? 'fila-pendiente' : 'fila-lista';
      tdE.innerHTML = '';
      if (f.error) tdE.appendChild(h(`<div class="aviso-inc aviso-dup">No se importó: ${esc(f.error)}</div>`));
      for (const a of f.avisos) tdE.appendChild(h(`<div class="${a.grave ? 'aviso-inc aviso-dup' : 'aviso-inc'}">${esc(a.texto)}</div>`));
      if (f.fiabilidad && f.importeOrigen === 'pdf') tdE.appendChild(h(`<div class="hint">Importe leído del PDF (fiabilidad ${esc(f.fiabilidad)}): compruébalo.</div>`));
      if (f.grave) {
        const l = h(`<label class="forzar"><input type="checkbox"${f.forzar ? ' checked' : ''}> Importar igualmente</label>`);
        l.querySelector('input').onchange = (e) => {
          f.forzar = e.target.checked;
          if (f.forzar) { f.marcado = true; chk.checked = true; f.error = null; }
          estado(); contarMarcadas();
        };
        tdE.appendChild(l);
      }
      if (prob.includes('la fecha no cae en ese trimestre')) {
        const l = h('<label class="forzar"><input type="checkbox"> Dejarla en ese trimestre igualmente</label>');
        l.querySelector('input').onchange = (e) => { f.forzarPeriodo = e.target.checked; estado(); };
        tdE.appendChild(l);
      }
      const faltan = prob.filter((p) => p !== 'tiene un aviso grave');
      if (faltan.length) tdE.appendChild(h(`<div class="aviso-inc">Falta: ${esc(faltan.join(', '))}</div>`));
      else if (f.grave && !f.forzar) { /* el aviso grave ya se ve arriba */ }
      else if (f.porComprobar && !f.marcado) tdE.appendChild(h('<div class="aviso-inc">Compruébala y márcala para importarla.</div>'));
      else tdE.appendChild(h('<span class="tag ok">✓ lista</span>'));
    }
    estado();
    return tr;
  };

  // Lectura por hojas: un PDF con varias facturas sale como un bloque (su
  // nombre, una fila por factura con sus columnas y, debajo, el resumen con la
  // suma); al final de la tabla, el total de todo lo analizado.
  const bloques = [];
  const porClave = new Map();
  for (const f of IMP.filas) {
    // El id es del PDF original: dos PDF distintos con el mismo nombre no se mezclan.
    const k = f.separadaDe ? `${f.lote}|${f.carpeta || ''}|${f.separadaDe.nombre}|${f.separadaDe.id || ''}` : `${f.lote}|${f.token}`;
    if (!porClave.has(k)) { const b = { filas: [], sd: f.separadaDe }; porClave.set(k, b); bloques.push(b); }
    porClave.get(k).filas.push(f);
  }
  const sumas = []; // [{ filas, celdas }] para rehacer las cifras al corregir
  const celdasSuma = (tr) => ({ n: tr.querySelector('[data-s=n]'), base: tr.querySelector('[data-s=base]'), cuota: tr.querySelector('[data-s=cuota]'), total: tr.querySelector('[data-s=total]') });
  // En una sola línea a la izquierda: la tabla es más ancha que la pantalla y
  // las columnas de la derecha quedarían fuera de la vista.
  const filaSuma = (clase, titulo) => h(`<tr class="${clase}"><td></td><td colspan="11"><div class="suma-linea">
    <span><b>${titulo}</b> <span class="hint" data-s="n"></span></span>
    <span class="num" data-s="base"></span><span class="num" data-s="cuota"></span><b class="num" data-s="total"></b></div></td></tr>`);
  for (const b of bloques) {
    const varias = b.sd && b.filas.length > 1;
    if (varias) {
      b.filas.sort((x, y) => (x.separadaDe.desde || 0) - (y.separadaDe.desde || 0));
      tb.appendChild(h(`<tr class="bloque-pdf"><td></td><td colspan="11">📄 <b>${esc(b.sd.nombre)}</b> <span class="hint">· ${b.sd.total} hojas leídas una a una → ${b.filas.length} facturas, una por fila</span></td></tr>`));
    }
    // Dentro del bloque no se repite en cada hoja lo que ya dice la cabecera.
    for (const f of b.filas) { const tr = pintarFila(f); if (varias) tr.dataset.bloque = '1'; tb.appendChild(tr); }
    if (varias) {
      const tr = filaSuma('resumen-pdf', `Resumen de «${esc(b.sd.nombre)}»`);
      tb.appendChild(tr);
      sumas.push({ filas: b.filas, celdas: celdasSuma(tr) });
    }
  }
  const tfoot = h('<tfoot></tfoot>');
  const trTotal = filaSuma('resumen-total', 'Total de lo analizado');
  tfoot.appendChild(trTotal);
  tabla.querySelector('table').appendChild(tfoot);
  sumas.push({ filas: IMP.filas, celdas: celdasSuma(trTotal) });
  function refrescarSumas() {
    // Solo suma lo que va al libro de IVA: los albaranes, justificantes, lo de
    // Hacienda y los «otro documento» se cuentan aparte.
    const alLibro = (f) => !['otro', 'hacienda', 'no-factura'].includes(f.sentido) && !['albaran', 'justificante'].includes(f.tipoDocumento);
    for (const s of sumas) {
      const vivas = s.filas.filter((f) => !f.rechazado);
      const libro = vivas.filter(alLibro);
      let base = 0, cuota = 0, total = 0, sinImporte = 0;
      const porTipo = { emitida: 0, recibida: 0 };
      for (const f of libro) {
        const b = num(f.base), t = num(f.total);
        if (b == null && t == null) { sinImporte++; continue; }
        base += b || 0;
        total += t || 0;
        if (f.sentido in porTipo) porTipo[f.sentido] += t || 0;
        // La cuota de cada factura como la calcula el Excel (lib/importe.js).
        cuota += b == null ? 0 : cuotaDe(b, num(f.iva), f.desglose);
      }
      const aparte = vivas.length - libro.length;
      const ambos = porTipo.emitida && porTipo.recibida;
      s.celdas.n.textContent = `· ${libro.length} factura${libro.length === 1 ? '' : 's'}`
        + (sinImporte ? ` (${sinImporte} sin importe todavía)` : '')
        + (aparte ? ` · ${aparte} documento${aparte === 1 ? '' : 's'} que no va${aparte === 1 ? '' : 'n'} al libro de IVA, sin sumar` : '')
        + (ambos ? ` · emitidas ${eur(porTipo.emitida)}, recibidas ${eur(porTipo.recibida)}` : '');
      s.celdas.base.textContent = 'Base ' + eur(r2(base));
      s.celdas.cuota.textContent = 'IVA ' + eur(r2(cuota));
      s.celdas.total.textContent = 'Total ' + eur(r2(total));
    }
  }
  refrescarSumas();
  contarMarcadas();

  bListas.onclick = () => { IMP.filas.forEach((f) => { f.marcado = !f.rechazado && esLista(f); }); renderImportar(); };
  bNinguna.onclick = () => { IMP.filas.forEach((f) => { f.marcado = false; }); renderImportar(); };

  bImportar.onclick = async () => {
    const marcadas = IMP.filas.filter((f) => f.marcado && !f.rechazado);
    const conProblemas = marcadas.filter((f) => problemasFila(f).length);
    if (conProblemas.length) {
      toast(`${conProblemas.length} de las marcadas aún tienen datos por completar (en amarillo).`, true);
      return;
    }
    bImportar.disabled = true; bImportar.textContent = 'Importando…';
    const porLote = {};
    for (const f of marcadas) (porLote[f.lote] = porLote[f.lote] || []).push(f);
    let ok = 0, ko = 0;
    try {
      for (const [lote, filas] of Object.entries(porLote)) {
        const r = await api('POST', 'importar/confirmar', { lote, items: filas.map(pedidoDeFila) });
        const hechos = new Set(r.importados.map((x) => x.token));
        ok += hechos.size;
        IMP.filas = IMP.filas.filter((f) => !hechos.has(f.token));
        for (const e of r.errores) {
          const f = IMP.filas.find((x) => x.token === e.token);
          if (f) {
            f.error = e.error; f.marcado = false; ko++;
            // Un aviso grave que aparece al confirmar (p. ej. un escaneo cuya
            // fecha e importe coinciden con otra factura) también se puede saltar.
            if (e.grave) { f.grave = true; f.forzar = false; }
          }
        }
      }
    } catch (e) { toast(e.message, true); }
    EXP_ARBOL = null;
    await refreshCache();
    toast(ko ? `Importadas ${ok}. ${ko} no se pudieron importar (en rojo).` : `Importadas ${ok}. Ya están en el Archivo.`, !!ko);
    repintar('importar');
  };

  bDescartar.onclick = () => {
    const quitar = IMP.filas.filter((f) => !f.marcado);
    if (!quitar.length) return toast('No hay nada sin marcar.');
    confirmar(`¿Descartar ${quitar.length} archivo(s)? Se borran de la espera y no se importan.`, async () => {
      const porLote = {};
      for (const f of quitar) if (!f.rechazado) (porLote[f.lote] = porLote[f.lote] || []).push(f.token);
      for (const [lote, tokens] of Object.entries(porLote)) await api('POST', 'importar/descartar', { lote, tokens });
      IMP.filas = IMP.filas.filter((f) => f.marcado);
      CACHE.st = await get('stats'); pintarCabecera();
      toast('Descartados');
      repintar('importar');
    });
  };
}

// ---- Importar: decidir por grupos --------------------------------
// Lo pendiente del mismo proveedor (su NIF) casi siempre es del mismo cliente y
// del mismo tipo: se decide una vez para todas.
function gruposPendientes(filas) {
  const m = new Map();
  for (const f of filas) {
    if (!f.nifContraparte) continue;
    const g = m.get(f.nifContraparte) || { nif: f.nifContraparte, filas: [] };
    g.filas.push(f);
    m.set(f.nifContraparte, g);
  }
  return [...m.values()].filter((g) => g.filas.length >= 2).sort((a, b) => b.filas.length - a.filas.length);
}

function panelGrupos(grupos, cli) {
  const MAX = 12;
  const caja = h(`<details class="comun grupos"${IMP.gruposCerrado ? '' : ' open'}>
    <summary>Decidir por grupos <span class="hint">(${grupos.length} proveedor${grupos.length === 1 ? '' : 'es'} con varias facturas pendientes: elige el cliente y el tipo una vez para todas)</span></summary>
    <div class="grupos-lista"></div></details>`);
  caja.ontoggle = () => { IMP.gruposCerrado = !caja.open; };
  const lista = caja.querySelector('.grupos-lista');
  for (const g of grupos.slice(0, MAX)) {
    const faltanCli = g.filas.filter((f) => !f.cliente).length;
    const faltanTipo = g.filas.filter((f) => !f.sentido).length;
    const ejemplos = g.filas.slice(0, 2).map((f) => f.nombre).join(', ') + (g.filas.length > 2 ? '…' : '');
    // Si todas proponen lo mismo, sale ya elegido.
    const comunDe = (k) => { const v = new Set(g.filas.map((f) => f[k]).filter(Boolean)); return v.size === 1 ? [...v][0] : ''; };
    // Un mismo proveedor puede tener facturas de clientes distintos (la luz de
    // dos clientes): entonces solo se rellena lo que falta, nunca se cambia el
    // cliente que ya tiene cada una.
    const yaCon = new Map();
    for (const f of g.filas) if (f.cliente) { const a = (cli.find((c) => c.id === f.cliente) || {}).alias || '?'; yaCon.set(a, (yaCon.get(a) || 0) + 1); }
    const mezclados = yaCon.size > 1;
    const aplicables = mezclados ? g.filas.filter((f) => !f.cliente) : g.filas;
    const fila = h(`<div class="grupo-fila">
      <div class="grupo-info"><b>${esc(g.nif)}</b> · ${g.filas.length} documentos
        <div class="hint">${esc(ejemplos)}</div>
        <div class="hint">${mezclados ? `de clientes distintos (${esc([...yaCon].map(([a, n]) => `${a} ${n}`).join(', '))}): solo se completan las que no tienen cliente`
          : [yaCon.size ? `${esc([...yaCon][0][1] + ' ya propuesta(s) para ' + [...yaCon][0][0])}` : '', faltanCli ? `sin cliente: ${faltanCli}` : '', faltanTipo ? `sin tipo: ${faltanTipo}` : ''].filter(Boolean).join(' · ') || 'por comprobar'}</div></div>
      <select data-g="cliente">${opciones(cli.map((c) => ({ v: c.id, l: c.alias })), mezclados ? '' : comunDe('cliente'), 'Cliente…')}</select>
      <select data-g="sentido">${opciones(TIPOS_DOC, mezclados ? '' : comunDe('sentido'), 'Tipo…')}</select>
      <button class="btn btn-sm btn-accent"${aplicables.length ? '' : ' disabled'}>Aplicar a ${aplicables.length === g.filas.length ? 'las ' : ''}${aplicables.length}</button></div>`);
    fila.querySelector('button').onclick = () => {
      const c = fila.querySelector('[data-g="cliente"]').value, s = fila.querySelector('[data-g="sentido"]').value;
      if (!c && !s) return toast('Elige el cliente, el tipo o los dos.', true);
      let listas = 0;
      for (const f of aplicables) {
        if (c) f.cliente = c;
        if (s && (!mezclados || !f.sentido)) f.sentido = s;
        f.porComprobar = false; f.error = null;
        if (!problemasFila(f).length && !f.grave) { f.marcado = true; listas++; }
      }
      const resto = aplicables.length - listas;
      toast(`Aplicado a ${aplicables.length}: ${listas} listas para importar${resto ? `; a ${resto} aún les falta algo (en amarillo)` : ''}.`);
      renderImportar();
    };
    lista.appendChild(fila);
  }
  if (grupos.length > MAX) lista.appendChild(h(`<div class="hint">Y ${grupos.length - MAX} grupo(s) más: aparecen al resolver estos.</div>`));
  return caja;
}

// ---- Importar: revisión rápida -----------------------------------
// Una a una, con el documento a la izquierda y los datos a la derecha. Todo se
// hace con el teclado: 1–9 cliente, G gasto, I ingreso, O otro, Intro importa
// y pasa a la siguiente, ← → para moverse, Esc cierra.
function abrirRevisionRapida(filas, cli) {
  filas = filas.slice();
  if (!filas.length) return toast('No hay nada pendiente de revisar.');
  let i = 0, hechas = 0;
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg rr-bg"></div>');
  const caja = h(`<div class="rr" role="dialog" aria-label="Revisión rápida">
    <div class="rr-visor"><iframe title="Documento"></iframe><div class="rr-tabla" hidden></div></div>
    <div class="rr-panel">
      <div class="rr-cab"><b data-pos></b><button class="btn-ghost" data-x title="Cerrar (Esc)">✕</button></div>
      <div class="doc-nom" data-nom></div>
      <div class="hint" data-carpeta></div>
      <div class="hint" data-motivos></div>
      <div data-avisos></div>
      <label class="field"><span>Cliente <span class="hint">· teclas 1–9</span></span><select data-k="cliente"></select></label>
      <label class="field"><span>Fecha de la factura</span><input type="date" data-k="fecha"></label>
      <div data-fechas class="hint"></div>
      <div class="rr-dos">
        <label class="field"><span>Año</span><input type="number" min="2000" max="2100" data-k="ejercicio"></label>
        <label class="field"><span>Trimestre</span><select data-k="trimestre"></select></label>
      </div>
      <label class="field"><span>Tipo <span class="hint">· G gasto · I ingreso · O otro</span></span><select data-k="sentido"></select></label>
      <div class="rr-importes">
        <label class="field"><span>Base €</span><input inputmode="decimal" data-k="base"></label>
        <label class="field"><span>IVA %</span><input inputmode="decimal" data-k="iva"></label>
        <label class="field"><span>IRPF %</span><input inputmode="decimal" data-k="irpf"></label>
        <label class="field"><span>Total €</span><input inputmode="decimal" data-k="total"></label>
      </div>
      <label class="forzar" data-periodo hidden><input type="checkbox"> Dejarla en ese trimestre igualmente</label>
      <label class="forzar" data-forzar hidden><input type="checkbox"> Importar igualmente (tiene un aviso grave)</label>
      <div data-estado></div>
      <div class="rr-botones">
        <button class="btn" data-ant title="Anterior (←)">←</button>
        <button class="btn" data-sig title="Saltar esta (→)">Saltar →</button>
        <button class="btn btn-accent" data-ok>Importar (Intro)</button>
      </div>
      <div class="hint">Intro importa y pasa a la siguiente · ← → para moverte sin importar · Esc cierra. Lo que no importes sigue en la lista.</div>
    </div></div>`);
  bg.appendChild(caja);
  root.appendChild(bg);
  const $ = (s) => caja.querySelector(s);
  const campo = (k) => $(`[data-k="${k}"]`);
  campo('cliente').innerHTML = opciones(cli.map((c, n) => ({ v: c.id, l: (n < 9 ? n + 1 + ' · ' : '') + c.alias })), '', '¿?');
  campo('trimestre').innerHTML = opciones(TRIMS.map((t) => ({ v: t, l: t })), '', '¿?');
  campo('sentido').innerHTML = opciones(TIPOS_DOC, '', '¿?');

  const estado = () => {
    const f = filas[i];
    const prob = problemasFila(f);
    const e = $('[data-estado]');
    e.innerHTML = '';
    if (f.error) e.appendChild(h(`<div class="aviso-inc aviso-dup">No se importó: ${esc(f.error)}</div>`));
    const faltan = prob.filter((p) => p !== 'tiene un aviso grave');
    if (faltan.length) e.appendChild(h(`<div class="aviso-inc">Falta: ${esc(faltan.join(', '))}</div>`));
    else if (f.grave && !f.forzar) e.appendChild(h('<div class="aviso-inc aviso-dup">Tiene un aviso grave: márcalo arriba si aun así quieres importarla.</div>'));
    else e.appendChild(h('<span class="tag ok">✓ lista: pulsa Intro</span>'));
    for (const k of ['cliente', 'ejercicio', 'trimestre', 'sentido']) campo(k).classList.toggle('falta', !f[k]);
    const fp = $('[data-periodo]');
    fp.hidden = !prob.includes('la fecha no cae en ese trimestre') && !f.forzarPeriodo;
    fp.querySelector('input').checked = !!f.forzarPeriodo;
  };
  // Tras importar o moverse, el teclado vuelve al panel: una cifra pulsada
  // después nunca cae dentro del Total o la Fecha del documento siguiente.
  caja.tabIndex = -1;
  let mostradoEn = 0;
  let pintarTabla = () => {};
  const mostrar = () => {
    if (document.activeElement && document.activeElement !== caja) document.activeElement.blur();
    caja.focus();
    mostradoEn = Date.now();
    const f = filas[i];
    $('[data-pos]').textContent = `${i + 1} de ${filas.length}` + (hechas ? ` · ${hechas} importada${hechas === 1 ? '' : 's'}` : '');
    $('[data-nom]').textContent = f.nombre;
    $('[data-carpeta]').textContent = f.carpeta ? '📁 ' + f.carpeta : '';
    $('[data-motivos]').textContent = (f.ocr ? '🔎 leído del escaneo (OCR) · ' : '') + (f.motivos.slice(0, 3).join(' · ') || (f.conTexto ? '' : 'Sin texto legible: mira el documento.'));
    const av = $('[data-avisos]');
    av.innerHTML = '';
    for (const a of f.avisos) av.appendChild(h(`<div class="${a.grave ? 'aviso-inc aviso-dup' : 'aviso-inc'}">${esc(a.texto)}</div>`));
    for (const k of ['cliente', 'fecha', 'ejercicio', 'trimestre', 'sentido', 'base', 'iva', 'irpf', 'total']) campo(k).value = f[k] ?? '';
    const fx = $('[data-fechas]');
    fx.innerHTML = f.fechasPosibles.length ? 'El documento tiene varias: ' + f.fechasPosibles.map((x) => `<a href="#" data-f="${esc(x)}">${esc(fdate(x))}</a>`).join(', ') : '';
    fx.querySelectorAll('[data-f]').forEach((a) => { a.onclick = (e) => { e.preventDefault(); campo('fecha').value = a.dataset.f; campo('fecha').onchange(); }; });
    const fz = $('[data-forzar]');
    fz.hidden = !f.grave;
    fz.querySelector('input').checked = !!f.forzar;
    const ifr = $('iframe');
    const tablaRr = $('.rr-tabla');
    // Debajo del documento, la tabla hoja por hoja con lo que hay escrito ahora
    // en cada fila: de un PDF con varias facturas, todas sus hojas (y el PDF
    // entero en la de esta); de un documento suelto o una foto, su fila.
    const base = f.pdfEntero
      ? `/api/importar/ver/${encodeURIComponent(f.lote)}/${encodeURIComponent(f.token)}?entero=1`
      : `/api/importar/ver/${encodeURIComponent(f.lote)}/${encodeURIComponent(f.token)}`;
    const src = f.pdfEntero ? base + '&p=' + f.pdfEntero.desde + '#page=' + f.pdfEntero.desde : base;
    if (ifr.getAttribute('src') !== src) ifr.setAttribute('src', src);
    const hermanas = f.pdfEntero
      ? IMP.filas.filter((x) => x.lote === f.lote && x.pdfEntero && x.pdfEntero.id === f.pdfEntero.id && !x.rechazado)
      : [f];
    pintarTabla = () => {
    const abierto = !!(tablaRr.querySelector('details') || {}).open;
    tablaRr.innerHTML = '';
    tablaRr.appendChild(tablaHojas(hermanas.map((x) => ({
      clave: x.token, desde: x.pdfEntero ? x.pdfEntero.desde : 1, hasta: x.pdfEntero ? x.pdfEntero.hasta : 1,
      numero: x.numero, fecha: x.fecha, contraparte: x.contraparte,
      base: x.base, iva: x.iva, irpf: x.irpf, recargo: x.recargo, desglose: x.desglose, total: x.total,
      dudas: (x.separadaDe && x.separadaDe.dudas) || [],
    })), {
      actual: f.pdfEntero ? f.pdfEntero.desde : 1,
      alPagina: f.pdfEntero ? (n) => irAPagina(ifr, base, n) : null,
      alCambiar: (clave, v) => {
        const x = hermanas.find((y) => y.token === clave);
        if (!x) return;
        const cambiaFecha = (v.fecha || '') !== (x.fecha || '');
        Object.assign(x, { contraparte: v.contraparte, base: v.base ?? '', iva: v.iva, irpf: v.irpf || 0, total: v.total ?? '', desglose: v.desglose, recargo: v.recargo || 0, importeOrigen: 'manual', porComprobar: false, error: null });
        if (cambiaFecha) {
          x.fecha = v.fecha;
          if (v.fecha) { x.ejercicio = Number(v.fecha.slice(0, 4)); x.trimestre = Math.floor((Number(v.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T'; x.forzarPeriodo = false; }
        }
        // Si es la que está en el formulario de arriba, se ve también ahí.
        if (x === filas[i]) { for (const k of ['fecha', 'ejercicio', 'trimestre', 'base', 'iva', 'irpf', 'total']) campo(k).value = x[k] ?? ''; estado(); }
      },
    }));
    if (abierto) tablaRr.querySelector('details').open = true;
    };
    pintarTabla();
    tablaRr.hidden = false;
    estado();
  };
  // Lo que se escribe queda en la fila de la lista (aunque no se importe).
  const tocar = (k, v) => {
    const f = filas[i];
    f[k] = v;
    if (['base', 'iva', 'irpf', 'total'].includes(k)) f.importeOrigen = 'manual';
    if (k === 'total') f.totalAuto = false;
    // Como en la tabla: al cambiar base, IVA o IRPF, el total se recalcula
    // (salvo que se haya escrito a mano).
    if ((k === 'iva' || (k === 'base' && !partesDe(num(f.base), num(f.iva), f.desglose))) && f.desglose) f.desglose = null;
    if (['base', 'iva', 'irpf'].includes(k) && f.totalAuto !== false) {
      const b = num(f.base), iv = num(f.iva);
      if (b != null && iv != null) { f.total = totalDe(b, iv, num(f.irpf) || 0, f.desglose, num(f.recargo)); campo('total').value = f.total; }
    }
    f.porComprobar = false; f.error = null;
    estado();
    // La tabla de debajo (y su resumen) siguen a lo que se escribe aquí.
    if (['base', 'iva', 'irpf', 'total', 'fecha'].includes(k)) pintarTabla();
  };
  campo('cliente').onchange = () => tocar('cliente', campo('cliente').value);
  campo('sentido').onchange = () => tocar('sentido', campo('sentido').value);
  campo('trimestre').onchange = () => tocar('trimestre', campo('trimestre').value);
  campo('ejercicio').oninput = () => tocar('ejercicio', campo('ejercicio').value ? Number(campo('ejercicio').value) : '');
  for (const k of ['base', 'iva', 'irpf', 'total']) campo(k).oninput = () => tocar(k, (k === 'base' || k === 'total' ? aImporte : aPct)(campo(k).value));
  $('[data-periodo] input').onchange = (e) => { filas[i].forzarPeriodo = e.target.checked; estado(); };
  campo('fecha').oninput = campo('fecha').onchange = () => {
    const f = filas[i], v = campo('fecha').value;
    f.fecha = v;
    if (v) {
      f.ejercicio = Number(v.slice(0, 4));
      f.trimestre = Math.floor((Number(v.slice(5, 7)) - 1) / 3) + 1 + 'T';
      f.forzarPeriodo = false;
      campo('ejercicio').value = f.ejercicio; campo('trimestre').value = f.trimestre;
    }
    tocar('fecha', v);
  };
  $('[data-forzar] input').onchange = (e) => { filas[i].forzar = e.target.checked; estado(); };

  const ir = (d) => { i = (i + d + filas.length) % filas.length; mostrar(); };
  let ocupado = false;
  const importar = async () => {
    const f = filas[i];
    if (ocupado) return;
    if (problemasFila(f).length) { estado(); return toast('Aún falta algo (en amarillo).', true); }
    ocupado = true;
    $('[data-ok]').disabled = true;
    try {
      const r = await api('POST', 'importar/confirmar', { lote: f.lote, items: [pedidoDeFila(f)] });
      if (r.importados.length) {
        hechas++;
        IMP.filas = IMP.filas.filter((x) => x !== f);
        filas.splice(i, 1);
        if (!filas.length) { toast(`Hecho: ${hechas} importada${hechas === 1 ? '' : 's'}.`); return cerrar(); }
        if (i >= filas.length) i = 0;
      } else {
        const e = r.errores[0] || {};
        f.error = e.error || 'No se pudo importar.';
        if (e.grave) { f.grave = true; f.forzar = false; }
      }
      mostrar();
    } catch (e) { toast(e.message, true); } finally { ocupado = false; $('[data-ok]').disabled = false; }
  };
  $('[data-ok]').onclick = importar;
  $('[data-sig]').onclick = () => ir(1);
  $('[data-ant]').onclick = () => ir(-1);

  const teclas = (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    // (También en la tabla de debajo: sus desplegables de IVA no son un «1 = cliente».)
    const enTabla = !!(e.target.closest && e.target.closest('.tabla-pdf'));
    const escribiendo = e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || enTabla;
    if (e.key === 'Escape') { e.preventDefault(); return cerrar(); }
    // En la tabla, Intro solo confirma lo escrito en la caja (no importa).
    if (e.key === 'Enter' && enTabla && e.target.tagName !== 'BUTTON') { e.preventDefault(); return e.target.blur(); }
    if (e.key === 'Enter') {
      // En un botón (✕, ←, Saltar), Intro hace lo del botón.
      if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
      e.preventDefault();
      // Intro mantenido o dos pulsaciones seguidas no importan la siguiente
      // sin haberla visto.
      if (e.repeat || Date.now() - mostradoEn < 400) return;
      if (escribiendo) e.target.blur(); // confirma lo escrito y suelta el campo
      return importar();
    }
    if (escribiendo) return;
    const k = e.key.toLowerCase();
    if (e.key === 'ArrowRight') { e.preventDefault(); return ir(1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); return ir(-1); }
    if (/^[1-9]$/.test(e.key) && cli[Number(e.key) - 1]) { e.preventDefault(); campo('cliente').value = cli[Number(e.key) - 1].id; return campo('cliente').onchange(); }
    const tipo = { g: 'recibida', i: 'emitida', o: 'otro' }[k];
    if (tipo) { e.preventDefault(); campo('sentido').value = tipo; return campo('sentido').onchange(); }
  };
  document.addEventListener('keydown', teclas, true);
  let cerrado = false;
  async function cerrar() {
    if (cerrado) return;
    cerrado = true;
    document.removeEventListener('keydown', teclas, true);
    bg.remove();
    if (hechas) { EXP_ARBOL = null; await refreshCache(); }
    repintar('importar');
  }
  $('[data-x]').onclick = cerrar;
  // Al hacer clic en el documento, el visor se queda con el teclado: al volver
  // con el ratón al panel, los atajos vuelven a funcionar.
  $('.rr-panel').addEventListener('mouseenter', () => { if (document.activeElement === $('iframe')) caja.focus(); });
  mostrar();
}

// ---- Revisar: emitida o gasto, rápido ------------------------------
// Como en Importar: lo del mismo proveedor se decide de una vez, y lo demás una
// a una con el documento al lado y el teclado (G gasto, I ingreso, O no es
// factura, Intro la deja como está). Todo queda en Trazabilidad.
const SENTIDO_REV = {
  recibida: { hecho: 'como gasto', nota: 'revisado: es un gasto (recibida)' },
  emitida: { hecho: 'como emitidas', nota: 'revisado: es una factura emitida' },
  'no-factura': { hecho: 'como «no es factura»', nota: 'revisado: no es una factura' },
};
const esDeSentido = (d) => avisosDoc(d).some((a) => a.cod === 'sentido');
// sentido '' = el tipo que tiene está bien. Solo quita el aviso de tipo: si
// tiene otros (trimestre dudoso, duplicado…), siguen en Revisar.
function marcarSentido(d, sentido) {
  return api('POST', 'revision/documento/' + d.id, sentido
    ? { sentido, soloSentido: true, nota: SENTIDO_REV[sentido].nota }
    : { soloSentido: true, nota: 'revisado: el tipo se deja como estaba' });
}
// Pasar a «no es factura» quita sus importes del IVA: se pide confirmación.
const quitaFactura = (d, sentido) => sentido === 'no-factura' && d.sentido !== 'no-factura' && CACHE.facturaDeDoc.has(d.id);
const nombreSentido = (x) => ({ emitida: 'emitida', recibida: 'gasto', hacienda: 'Hacienda', 'no-factura': 'no es factura' }[x] || 'sin tipo');

// Por proveedor: su NIF o, si no se leyó, su nombre.
function gruposSentido(docs) {
  const m = new Map();
  for (const d of docs) {
    const k = d.nifContraparte ? 'nif:' + d.nifContraparte : d.contraparte ? 'nom:' + String(d.contraparte).trim().toLowerCase() : '';
    if (!k) continue;
    const g = m.get(k) || { nif: d.nifContraparte || '', nombre: d.contraparte || '', docs: [] };
    if (!g.nombre && d.contraparte) g.nombre = d.contraparte;
    g.docs.push(d);
    m.set(k, g);
  }
  return [...m.values()].filter((g) => g.docs.length >= 2).sort((a, b) => b.docs.length - a.docs.length);
}

function panelGruposSentido(grupos, alTerminar) {
  const MAX = 12;
  const caja = h(`<details class="comun grupos"${REV.gruposCerrado ? '' : ' open'}>
    <summary>Decidir por grupos <span class="hint">(${grupos.length} proveedor${grupos.length === 1 ? '' : 'es'} con varias pendientes: gasto o ingreso una vez para todas)</span></summary>
    <div class="grupos-lista"></div></details>`);
  caja.ontoggle = () => { REV.gruposCerrado = !caja.open; };
  const lista = caja.querySelector('.grupos-lista');
  for (const g of grupos.slice(0, MAX)) {
    const tipos = new Map();
    for (const d of g.docs) tipos.set(nombreSentido(d.sentido), (tipos.get(nombreSentido(d.sentido)) || 0) + 1);
    const clientes = [...new Set(g.docs.map((d) => d.cliente).filter(Boolean))];
    const ejemplos = g.docs.slice(0, 2).map((d) => d.nombre).join(', ') + (g.docs.length > 2 ? '…' : '');
    const fila = h(`<div class="grupo-fila">
      <div class="grupo-info"><b>${esc(g.nombre || g.nif)}</b>${g.nif && g.nombre ? ` <span class="hint">${esc(g.nif)}</span>` : ''} · ${g.docs.length} documentos
        <div class="hint">${esc(ejemplos)}</div>
        <div class="hint">Ahora: ${esc([...tipos].map(([t, n]) => n + ' como ' + t).join(', '))}${clientes.length ? ' · ' + esc(clientes.join(', ')) : ''}</div></div>
      <button class="btn btn-sm" data-s="recibida">Todas gasto</button>
      <button class="btn btn-sm" data-s="emitida">Todas emitidas</button>
      <button class="btn btn-sm" data-s="" title="Se quedan con el tipo que tienen">Están bien</button></div>`);
    const quien = g.nombre || g.nif;
    fila.querySelectorAll('[data-s]').forEach((b) => {
      b.setAttribute('aria-label', `${b.textContent} — ${quien}`);
      b.onclick = async () => {
        const sentido = b.dataset.s;
        // Lo que es de Hacienda o «no es factura» no se convierte en factura de
        // golpe (se crearía vacía): eso se decide una a una.
        const aplicables = sentido ? g.docs.filter((d) => !['hacienda', 'no-factura'].includes(d.sentido)) : g.docs;
        const fuera = g.docs.length - aplicables.length;
        if (!aplicables.length) return toast('Ninguna se puede cambiar de golpe: son de Hacienda o «no es factura». Hazlo una a una.', true);
        const que = sentido ? 'como ' + nombreSentido(sentido) : 'con el tipo que tienen';
        if (!confirm(`¿Dejar ${aplicables.length} documento${aplicables.length === 1 ? '' : 's'} de ${quien} ${que}?`
          + (fuera ? `\n\n${fuera} de Hacienda o «no es factura» se quedan fuera.` : '')
          + '\n\nSe puede deshacer en 🕘 Trazabilidad.')) return;
        fila.querySelectorAll('button').forEach((x) => { x.disabled = true; });
        b.textContent = 'Aplicando…';
        let ok = 0; const fallos = [];
        try {
          for (const d of aplicables) {
            try { await marcarSentido(d, sentido); ok++; } catch (e) { fallos.push(e.message); }
          }
          toast((fallos.length ? `${ok} hechas; ${fallos.length} no se pudieron: ${fallos[0]}`
            : sentido ? `${ok} marcadas ${SENTIDO_REV[sentido].hecho}.` : `${ok} se quedan como estaban.`)
            + (fuera ? ` ${fuera} se quedan para hacerlas una a una.` : ''), !!fallos.length);
          EXP_ARBOL = null;
          await refreshCache();
        } catch (e) { toast(e.message, true); } finally { alTerminar(); }
      };
    });
    lista.appendChild(fila);
  }
  if (grupos.length > MAX) lista.appendChild(h(`<div class="hint">Y ${grupos.length - MAX} grupo(s) más: aparecen al resolver estos.</div>`));
  return caja;
}

function abrirRevisionRapidaSentido(docs, alTerminar) {
  docs = docs.slice();
  if (!docs.length) return toast('No hay nada pendiente de revisar.');
  let i = 0, hechas = 0;
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg rr-bg"></div>');
  const caja = h(`<div class="rr" role="dialog" aria-modal="true" aria-label="Revisión rápida: emitida o gasto">
    <div class="rr-visor"><iframe title="Documento"></iframe><div class="rr-tabla" hidden></div></div>
    <div class="rr-panel">
      <div class="rr-cab"><b data-pos aria-live="polite"></b><button class="btn-ghost" data-x title="Cerrar (Esc)" aria-label="Cerrar (Esc)">✕</button></div>
      <div class="doc-nom" data-nom></div>
      <div class="hint" data-carpeta></div>
      <div data-ahora></div>
      <div class="hint" data-quien></div>
      <div data-avisos></div>
      <div class="rr-sentido">
        <button class="btn" data-s="recibida"><b>G</b> · Gasto (recibida)</button>
        <button class="btn" data-s="emitida"><b>I</b> · Ingreso (emitida)</button>
        <button class="btn" data-s="no-factura"><b>O</b> · No es factura</button>
        <button class="btn btn-accent" data-s="">Está bien (Intro)</button>
      </div>
      <div class="aviso-inc" data-confirma role="alert" hidden></div>
      <div class="rr-botones">
        <button class="btn" data-ant title="Anterior (←)" aria-label="Anterior (←)">←</button>
        <button class="btn" data-sig title="Saltar esta (→)">Saltar →</button>
      </div>
      <div class="hint">G gasto · I ingreso · O no es factura · Intro deja el tipo como está. Cada tecla la guarda y pasa a la siguiente. Solo decide el tipo: si tiene otro aviso (trimestre, duplicado…), sigue en Revisar. ← → para moverte sin tocarla · Esc cierra. Todo se puede deshacer en 🕘 Trazabilidad.</div>
    </div></div>`);
  bg.appendChild(caja);
  root.appendChild(bg);
  const $ = (q) => caja.querySelector(q);
  caja.tabIndex = -1;
  const ifr = $('iframe');
  const aviso = $('[data-confirma]');
  let mostradoEn = 0;
  let armadoO = null, armadoEn = 0; // documento al que ya se le pulsó O una vez, y cuándo
  const desarmar = () => { armadoO = null; aviso.hidden = true; aviso.textContent = ''; };
  const mostrar = () => {
    if (document.activeElement && document.activeElement !== caja) document.activeElement.blur();
    caja.focus();
    mostradoEn = Date.now();
    desarmar();
    const d = docs[i];
    $('[data-pos]').textContent = `${i + 1} de ${docs.length}` + (hechas ? ` · ${hechas} hecha${hechas === 1 ? '' : 's'}` : '');
    $('[data-nom]').textContent = d.nombre;
    $('[data-carpeta]').textContent = d.rutaRelativa ? '📁 ' + d.rutaRelativa : '';
    $('[data-ahora]').innerHTML = 'Ahora está como: ' + descripcionDoc(d);
    $('[data-quien]').textContent = [d.contraparte, d.nifContraparte, d.cliente ? 'cliente ' + d.cliente : ''].filter(Boolean).join(' · ');
    const av = $('[data-avisos]');
    av.innerHTML = '';
    for (const a of avisosDoc(d)) av.appendChild(h(`<div class="aviso-inc">${esc(a.texto)}</div>`));
    caja.querySelectorAll('[data-s]').forEach((b) => {
      const actual = !!b.dataset.s && b.dataset.s === d.sentido;
      b.classList.toggle('actual', actual);
      b.setAttribute('aria-pressed', actual ? 'true' : 'false');
    });
    const src = '/api/archivo/ver/' + encodeURIComponent(d.id);
    if (ifr.getAttribute('src') !== src) ifr.setAttribute('src', src);
    const tablaRr = $('.rr-tabla');
    const filasPdf = filasPdfDeDoc(d);
    tablaRr.innerHTML = '';
    tablaRr.hidden = !filasPdf.length;
    if (filasPdf.length) tablaRr.appendChild(tablaHojas(filasPdf, { alPagina: (n) => irAPagina(ifr, src, n), alCambiar: guardarFilaArchivada }));
  };
  let ocupado = null; // la petición en curso, si la hay
  let cerrado = false;
  const aplicar = (sentido) => {
    if (ocupado || cerrado) return;
    const d = docs[i];
    if (sentido !== 'no-factura') desarmar();
    // O sobre algo con factura: hay que pulsarla dos veces (quita sus importes del IVA),
    // y no de un doble clic: la segunda, después de haber podido leer el aviso.
    if (quitaFactura(d, sentido) && (armadoO !== d.id || Date.now() - armadoEn < 400)) {
      if (armadoO === d.id) return;
      armadoO = d.id; armadoEn = Date.now();
      aviso.textContent = 'Tiene importes leídos: al marcarla como «no es factura» salen del IVA. Pulsa O otra vez para confirmarlo.';
      aviso.hidden = false;
      return;
    }
    caja.querySelectorAll('[data-s]').forEach((b) => { b.disabled = true; });
    ocupado = (async () => {
      try {
        await marcarSentido(d, sentido);
        hechas++;
        if (cerrado) return;
        // Por identidad, no por posición: aunque se haya movido mientras guardaba.
        const k = docs.indexOf(d);
        if (k >= 0) { docs.splice(k, 1); if (k < i) i--; }
        if (!docs.length) { toast(`Hecho: ${hechas} revisada${hechas === 1 ? '' : 's'}.`); cerrar(); return; }
        if (i >= docs.length) i = 0;
        mostrar();
      } catch (e) {
        toast(e.message, true);
        if (!cerrado) caja.focus(); // que Intro no repita el botón que falló
      } finally {
        ocupado = null;
        caja.querySelectorAll('[data-s]').forEach((b) => { b.disabled = false; });
      }
    })();
  };
  caja.querySelectorAll('[data-s]').forEach((b) => { b.onclick = () => aplicar(b.dataset.s); });
  const ir = (n) => { if (ocupado) return; i = (i + n + docs.length) % docs.length; mostrar(); };
  $('[data-sig]').onclick = () => ir(1);
  $('[data-ant]').onclick = () => ir(-1);

  const teclas = (e) => {
    if (current !== 'revisar') return cerrar();
    if (e.key === 'Tab') {
      // El foco no sale del cuadro (lo de detrás no se toca con él abierto).
      const f = [...caja.querySelectorAll('button:not([disabled])')];
      if (!f.length) return;
      const pos = f.indexOf(document.activeElement);
      if (e.shiftKey ? pos <= 0 : pos === f.length - 1 || pos < 0) {
        e.preventDefault();
        (e.shiftKey ? f[f.length - 1] : f[0]).focus();
      }
      return;
    }
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    if (e.key === 'Escape') { e.preventDefault(); return cerrar(); }
    // Escribiendo en la tabla de debajo, las teclas son de la caja: una «g» o
    // una «o» de un nombre no deciden el tipo, e Intro solo confirma lo escrito.
    if (e.target.closest && e.target.closest('.tabla-pdf')) {
      if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') { e.preventDefault(); e.target.blur(); }
      return;
    }
    // Una tecla mantenida, o dos pulsaciones seguidas, no deciden la siguiente
    // sin haberla visto.
    const recien = e.repeat || Date.now() - mostradoEn < 400;
    if (e.key === 'Enter') {
      if ((e.target.tagName === 'BUTTON' || e.target.tagName === 'A') && caja.contains(e.target)) return; // Intro en un botón hace lo del botón
      e.preventDefault();
      if (!recien) aplicar('');
      return;
    }
    if (e.key === 'ArrowRight') { e.preventDefault(); return ir(1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); return ir(-1); }
    const sentido = { g: 'recibida', i: 'emitida', o: 'no-factura' }[e.key.toLowerCase()];
    if (sentido) { e.preventDefault(); if (!recien) aplicar(sentido); }
  };
  document.addEventListener('keydown', teclas, true);
  // Atrás del navegador (o cambiar la dirección) con esto abierto: se cierra.
  const alCambiarRuta = () => cerrar();
  window.addEventListener('hashchange', alCambiarRuta);
  async function cerrar() {
    if (cerrado) return;
    cerrado = true;
    document.removeEventListener('keydown', teclas, true);
    window.removeEventListener('hashchange', alCambiarRuta);
    bg.remove();
    // Si se cierra mientras guarda, se espera a que termine para no dejar la lista vieja.
    if (ocupado) { try { await ocupado; } catch { /* ya avisado */ } }
    if (hechas) { EXP_ARBOL = null; try { await refreshCache(); } catch (e) { toast(e.message, true); } }
    alTerminar();
  }
  $('[data-x]').onclick = cerrar;
  // Al hacer clic en el documento, el visor se queda con el teclado: al volver
  // con el ratón al panel, o al cargar el siguiente, los atajos vuelven a funcionar.
  $('.rr-panel').addEventListener('mouseenter', () => { if (document.activeElement === ifr) caja.focus(); });
  ifr.addEventListener('load', () => { if (!cerrado && document.activeElement === ifr) caja.focus(); });
  mostrar();
}

// ---- Revisar -----------------------------------------------------
const REV = { vista: 'clasificacion', filtro: '', filtroImp: 'pdf', mostrar: 100 };

async function renderRevisar() {
  view.innerHTML = '';
  view.appendChild(h('<h1>Revisar</h1>'));
  view.appendChild(h('<p class="sub">Lo que el programa no puede dar por bueno sin que alguien lo mire. Corrige la clasificación o descarta lo que no sea una factura (impuestos, justificantes…).</p>'));

  const pendDocs = CACHE.documentos.filter((d) => avisosDoc(d).length);
  const porConfirmar = CACHE.facturas.filter((f) => f.total > 0 && f.importeOrigen === 'pdf' && !f.importeConfirmado);
  const sinImporte = CACHE.facturas.filter((f) => !(f.total > 0));

  const pest = h(`<div class="segmento">
    <button data-v="clasificacion">Clasificación <span class="badge">${pendDocs.length}</span></button>
    <button data-v="importes">Importes <span class="badge">${porConfirmar.length + sinImporte.length}</span></button>
  </div>`);
  pest.querySelectorAll('button').forEach((b) => {
    b.classList.toggle('activo', b.dataset.v === REV.vista);
    b.onclick = () => { REV.vista = b.dataset.v; REV.mostrar = 100; renderRevisar(); };
  });
  view.appendChild(pest);

  // --- Acciones automáticas ---
  const acciones = h('<div class="card acciones-auto"></div>');
  const bAud = h('<button class="btn">🔎 Buscar problemas en los PDF</button>');
  const bImp = h('<button class="btn">💶 Leer importes y empresas de los PDF</button>');
  acciones.append(
    h('<div><b>Comprobaciones automáticas</b><div class="hint">Leen el contenido de los PDF: fechas que caen en otro trimestre, facturas propias archivadas como gasto, importes. Tardan unos segundos. No cambian nada sin avisar.</div></div>'),
    h('<div class="acciones-bot"></div>'),
  );
  acciones.lastElementChild.append(bAud, bImp);
  view.appendChild(acciones);
  const espera = async (btn, txt, fn) => {
    const antes = btn.textContent;
    btn.disabled = true; btn.textContent = txt;
    try { await fn(); } catch (e) { toast(e.message, true); }
    finally { btn.disabled = false; btn.textContent = antes; }
  };
  bAud.onclick = () => espera(bAud, 'Leyendo PDF…', async () => {
    const r = await api('POST', 'revision/auditar');
    const n = r.periodo + r.sentido + r.noFactura;
    toast(n ? `Encontrados ${n} nuevos: ${r.periodo} de trimestre, ${r.sentido} posibles emitidas, ${r.noFactura} que no son factura.` : `Revisados ${r.revisados} documentos: nada nuevo.`);
    await refreshCache(); repintar('revisar');
  });
  bImp.onclick = () => espera(bImp, 'Leyendo PDF…', async () => {
    const r = await api('POST', 'revision/leer-importes');
    const pv = r.proveedores || {};
    toast(`Propuestos ${r.propuestas} importes (${r.alta} fiables, ${r.media} a comprobar). ${r.sinTexto} son escaneos sin texto.${pv.leidas ? ` Empresa leída en ${pv.conNombre} facturas, CIF en ${pv.conNif} y código postal en ${pv.conCp}.` : ''}`);
    REV.vista = 'importes'; REV.filtroImp = 'pdf';
    await refreshCache(); repintar('revisar');
  });

  const host = h('<div></div>');
  view.appendChild(host);
  if (REV.vista === 'clasificacion') {
    const bloques = h('<div></div>');
    host.appendChild(bloques);
    pintarBloques(bloques);
    pintarRevClasificacion(host, pendDocs);
  } else pintarRevImportes(host, porConfirmar, sinImporte);
}

// --- Clasificación automática por bloques -----------------------------------
const SEGURIDAD = {
  seguro: { etiqueta: 'seguro', cls: 'ok', nota: 'Sin riesgo: no cambia ninguna cifra.' },
  revisar: { etiqueta: 'cambia cifras', cls: 'aviso', nota: 'Mueve importes de trimestre o de signo. Míralo antes de aprobar.' },
  opcional: { etiqueta: 'decisión del despacho', cls: '', nota: 'Puede estar bien como está: solo aprueba si el despacho lo quiere así.' },
};

async function pintarBloques(host) {
  host.innerHTML = '';
  let bloques;
  try { bloques = await get('revision/propuestas'); }
  catch { return; }
  if (!host.isConnected || !bloques.length) return; // ya se pintó otra pantalla

  const total = bloques.reduce((a, b) => a + b.total, 0);
  const seguros = bloques.filter((b) => b.seguridad === 'seguro');
  const cab = h(`<div class="bloques-cab">
    <div><b>El programa puede clasificar ${total} documento(s)</b>
      <div class="hint">Cada bloque dice qué cambia y por qué. Nada se aplica hasta que lo apruebas, y todo queda en 🕘 Trazabilidad, donde se puede deshacer.</div></div>
  </div>`);
  if (seguros.length) {
    const nSeg = seguros.reduce((a, b) => a + b.total, 0);
    const bTodo = h(`<button class="btn btn-accent">✓ Aprobar los ${nSeg} seguros</button>`);
    bTodo.onclick = async () => {
      if (!confirm(`Se van a clasificar ${nSeg} documentos de los bloques sin riesgo. Se puede deshacer desde Trazabilidad. ¿Sigo?`)) return;
      bTodo.disabled = true; bTodo.textContent = 'Aplicando…';
      let ok = 0;
      for (const b of seguros) {
        try { ok += (await api('POST', 'revision/aplicar', { bloque: b.id })).aplicados; }
        catch (e) { toast(e.message, true); }
      }
      toast(`Clasificados ${ok} documentos.`);
      EXP_ARBOL = null; await refreshCache(); repintar('revisar');
    };
    cab.appendChild(bTodo);
  }
  host.appendChild(cab);

  for (const b of bloques) {
    const s = SEGURIDAD[b.seguridad] || SEGURIDAD.revisar;
    const card = h(`<div class="card bloque">
      <div class="bloque-cab">
        <div class="bloque-txt">
          <div class="bloque-tit"><b>${esc(b.titulo)}</b> <span class="tag ${s.cls}">${esc(s.etiqueta)}</span> <span class="badge">${b.total}</span></div>
          <div class="hint">${esc(b.explicacion)} ${esc(s.nota)}</div>
        </div>
        <div class="bloque-bot"></div>
      </div>
      <div class="bloque-detalle" hidden></div>
    </div>`);
    const bot = card.querySelector('.bloque-bot');
    const det = card.querySelector('.bloque-detalle');

    const bVer = h(`<button class="btn btn-sm">Ver los ${b.total}</button>`);
    bVer.onclick = () => {
      det.hidden = !det.hidden;
      bVer.textContent = det.hidden ? `Ver los ${b.total}` : 'Ocultar';
      if (det.hidden || det.childElementCount) return;
      const t = h('<table class="doc-tabla"><thead><tr><th>Documento</th><th>Ahora</th><th>Quedará</th><th>Por qué</th><th></th></tr></thead><tbody></tbody></table>');
      const tb = t.querySelector('tbody');
      for (const it of b.items) {
        const tr = h(`<tr>
          <td><div class="doc-nom">${esc(it.nombre)}</div><div class="hint">${esc(it.rutaRelativa)}</div></td>
          <td class="n">${esc(it.antesTexto)}</td>
          <td class="n"><b>${esc(it.despuesTexto)}</b></td>
          <td>${esc(it.motivo)}</td>
          <td></td>
        </tr>`);
        const bv = h('<button class="btn btn-sm btn-accent">Ver</button>');
        bv.onclick = () => verDocumento(it.documentoId);
        tr.lastElementChild.appendChild(bv);
        tb.appendChild(tr);
      }
      det.appendChild(t);
      if (b.total > b.items.length) det.appendChild(h(`<p class="hint">Se listan ${b.items.length} de ${b.total}; se aplican todos.</p>`));
    };

    const bAp = h(`<button class="btn ${b.seguridad === 'seguro' ? 'btn-accent' : ''}">Aprobar las ${b.total}</button>`);
    bAp.onclick = async () => {
      if (b.seguridad !== 'seguro' && !confirm(`${b.titulo}: ${b.total} documentos.\n\n${b.explicacion}\n\nSe puede deshacer desde Trazabilidad. ¿Sigo?`)) return;
      bAp.disabled = true; bAp.textContent = 'Aplicando…';
      try {
        const r = await api('POST', 'revision/aplicar', { bloque: b.id });
        toast(`Clasificados ${r.aplicados}` + (r.errores.length ? `, ${r.errores.length} con problemas` : '') + '.');
        EXP_ARBOL = null; await refreshCache(); repintar('revisar');
      } catch (e) { toast(e.message, true); bAp.disabled = false; bAp.textContent = `Aprobar las ${b.total}`; }
    };
    bot.append(bVer, bAp);
    host.appendChild(card);
  }
}

// ---- Descartar desde Revisar -------------------------------------------
// Lo que hay en Revisar no siempre es una factura: puede ser un impuesto, un
// justificante o un papel que no pinta nada. Como en Importar, se puede
// descartar; aquí hay que decir qué es, porque el documento ya está archivado.
//   items: [{ doc, factura }] (doc puede faltar en una factura metida a mano)
function descartarDocs(items, alTerminar) {
  items = items.filter((x) => x && (x.doc || x.factura));
  if (!items.length) return toast('Marca primero lo que quieres descartar.', true);
  const n = items.length;
  const que = n === 1 ? `«${(items[0].doc || {}).nombre || items[0].factura.numero || 'factura'}»` : `${n} documentos`;
  // Un PDF con varias facturas: descartarlo afecta a todas.
  const enPdf = items.reduce((a, x) => a + (x.doc && facturasDe(x.doc.id).length > 1 ? facturasDe(x.doc.id).length : 0), 0);
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg"></div>');
  const m = h(`<div class="modal"><header><strong>Descartar ${esc(que)}</strong><button class="btn-ghost" data-x>✕</button></header>
    <div class="body">
      <p style="margin:0">No ${n === 1 ? 'es una factura' : 'son facturas'} que haya que revisar. ¿Qué ${n === 1 ? 'es' : 'son'}?</p>
      <button class="btn opcion-descartar" data-o="hacienda"><b>🏛️ ${n === 1 ? 'Es' : 'Son'} de Hacienda</b><small>Un impuesto, un modelo, un pago o una notificación. Pasa a la carpeta Hacienda de su trimestre y deja de contar como factura.</small></button>
      <button class="btn opcion-descartar" data-o="no-factura"><b>📎 No ${n === 1 ? 'es' : 'son'} factura</b><small>Un justificante, un extracto, un contrato… Se queda en el archivo, en «Otros», y deja de contar en el IVA.</small></button>
      <button class="btn opcion-descartar" data-o="quitar"><b>🗑 ${n === 1 ? 'Quitarlo' : 'Quitarlos'} del programa</b><small>No pinta nada aquí. Sale del programa; la copia del programa va a su papelera y la carpeta original no se toca.</small></button>
      ${enPdf ? `<p class="aviso-inc" style="margin:0">Ojo: es un PDF con varias facturas (${enPdf}). Lo que elijas se aplica a todas.</p>` : ''}
      <p class="hint" style="margin:0">Las dos primeras se pueden deshacer en Trazabilidad.</p>
    </div>
    <footer><button class="btn" data-x>Cancelar</button></footer></div>`);
  const cerrar = () => bg.remove();
  m.querySelectorAll('[data-x]').forEach((b) => { b.onclick = cerrar; });
  bg.onclick = (e) => { if (e.target === bg) cerrar(); };
  m.querySelectorAll('[data-o]').forEach((b) => {
    b.onclick = async () => {
      const o = b.dataset.o;
      if (o === 'quitar' && !window.confirm(`Se ${n === 1 ? 'quita' : 'quitan'} ${que} del programa. Esto no se deshace desde Trazabilidad. ¿Seguir?`)) return;
      m.querySelectorAll('button').forEach((x) => { x.disabled = true; });
      let ok = 0; const fallos = [];
      for (const x of items) {
        try {
          if (o === 'quitar' || !x.doc) {
            // Sin documento (factura metida a mano) solo se puede quitar.
            if (x.doc) await api('DELETE', 'documentos/' + x.doc.id);
            else await api('DELETE', 'facturas/' + x.factura.id);
          } else {
            await api('POST', 'revision/documento/' + x.doc.id, {
              sentido: o, revisado: true,
              nota: o === 'hacienda' ? 'descartado en Revisar: es de Hacienda' : 'descartado en Revisar: no es una factura',
            });
          }
          ok++;
        } catch (e) { fallos.push(e.message); }
      }
      cerrar();
      toast(fallos.length ? `${ok} descartados; ${fallos.length} no se pudieron: ${fallos[0]}` : (n === 1 ? 'Descartado' : `${ok} descartados`), !!fallos.length);
      EXP_ARBOL = null;
      await refreshCache();
      if (alTerminar) alTerminar(); else repintar('revisar');
    };
  });
  bg.appendChild(m);
  root.appendChild(bg);
}

// Casillas para descartar varios de una vez. Devuelve cómo añadir la casilla de
// cada fila; la barra con el botón se pone encima de la tabla.
function seleccionParaDescartar(host, alTerminar) {
  const marcados = new Map(); // clave -> { doc, factura }
  const barra = h(`<div class="barra-descartar"><label><input type="checkbox" data-todos> Marcar todo lo que se ve</label>
    <button class="btn btn-sm" data-desc disabled>Descartar marcados…</button></div>`);
  const boton = barra.querySelector('[data-desc]');
  const casillas = [];
  const pintar = () => { boton.disabled = !marcados.size; boton.textContent = marcados.size ? `Descartar marcados (${marcados.size})…` : 'Descartar marcados…'; };
  boton.onclick = () => descartarDocs([...marcados.values()], alTerminar);
  barra.querySelector('[data-todos]').onchange = (e) => {
    for (const c of casillas) { c.el.checked = e.target.checked; if (e.target.checked) marcados.set(c.clave, c.item); else marcados.delete(c.clave); }
    pintar();
  };
  host.appendChild(barra);
  return (clave, item) => {
    const el = h('<input type="checkbox" class="chk-grande" title="Marcar para descartar">');
    el.onchange = () => { if (el.checked) marcados.set(clave, item); else marcados.delete(clave); pintar(); };
    casillas.push({ el, clave, item });
    return el;
  };
}

function pintarRevClasificacion(host, pendDocs) {
  const grupos = [
    { v: '', l: 'Todo' },
    { v: 'sentido', l: '¿Emitida o gasto?' },
    { v: 'periodo', l: 'Trimestre dudoso' },
    { v: 'duplicado', l: 'Duplicados' },
    { v: 'no-factura', l: 'No son factura' },
    { v: 'abono', l: '¿Abono?' },
    { v: 'paginas', l: 'PDF con varias facturas' },
    { v: 'revisar', l: 'Sin clasificar' },
  ];
  const cuenta = (v) => (v ? pendDocs.filter((d) => avisosDoc(d).some((a) => a.cod === v)).length : pendDocs.length);
  const chips = h('<div class="chips"></div>');
  for (const g of grupos) {
    const n = cuenta(g.v);
    if (g.v && !n) continue;
    const b = h(`<button class="chip${REV.filtro === g.v ? ' activo' : ''}">${esc(g.l)} <b>${n}</b></button>`);
    b.onclick = () => { REV.filtro = g.v; REV.mostrar = 100; renderRevisar(); };
    chips.appendChild(b);
  }
  host.appendChild(chips);

  const expl = {
    sentido: 'Hay que confirmar si son gasto o ingreso: o tienen la numeración del propio cliente pero están archivadas como gasto, o se colocaron al ordenar sin saberlo seguro. Lo más rápido: «⚡ Revisión rápida» (G gasto · I ingreso · Intro la deja como está) o decidirlas por proveedor.',
    periodo: 'La fecha de la factura cae en otro trimestre que la carpeta donde está. Para el IVA cuenta el trimestre de la fecha.',
    duplicado: 'Son copias idénticas de otro documento. Si se deja todo como está, se contarían dos veces: marca como «No es una factura» la copia sobrante.',
    'no-factura': 'Son justificantes de pago (tickets de Redsys), no facturas: no sirven para deducir el IVA.',
    revisar: 'No se pudo saber su tipo o su trimestre.',
    paginas: 'PDF que traen varias facturas (se guardan enteros, cada factura con sus páginas) en los que la doble revisión tuvo dudas —una hoja con otro número de factura, dos totales, sin total— o alguna factura es de otro trimestre o tipo. Ábrelos con «Ver»: debajo del PDF sale la tabla de sus facturas; si todo está bien, «Está bien».',
    abono: 'Parecen abonos (facturas rectificativas) y se han puesto en negativo, pero el documento no lo deja del todo claro. Ábrelos con «Ver»: si es un abono, «Es abono»; si no, «No es abono» y vuelven a positivo.',
  };
  if (expl[REV.filtro]) host.appendChild(h(`<p class="hint">${esc(expl[REV.filtro])}</p>`));

  // Emitida o gasto: una a una con el teclado, o por proveedor (como en Importar).
  const deSentido = pendDocs.filter(esDeSentido);
  if (deSentido.length && (!REV.filtro || REV.filtro === 'sentido')) {
    const barra = h('<div class="barra-rapida"></div>');
    const bR = h(`<button class="btn btn-accent" title="Una a una, con el documento al lado y atajos de teclado">⚡ Revisión rápida: emitida o gasto (${deSentido.length})</button>`);
    bR.onclick = () => abrirRevisionRapidaSentido(deSentido, () => repintar('revisar'));
    barra.appendChild(bR);
    host.appendChild(barra);
    const gs = gruposSentido(deSentido);
    if (gs.length) host.appendChild(panelGruposSentido(gs, () => repintar('revisar')));
  }

  const lista = pendDocs.filter((d) => !REV.filtro || avisosDoc(d).some((a) => a.cod === REV.filtro));
  if (!lista.length) { host.appendChild(h('<div class="vacio-exp">✓ Nada pendiente aquí.</div>')); return; }

  const casilla = seleccionParaDescartar(host, () => repintar('revisar'));
  const t = h('<table class="doc-tabla"><thead><tr><th></th><th>Documento</th><th>Ahora está como</th><th>Qué pasa</th><th></th></tr></thead><tbody></tbody></table>');
  const tb = t.querySelector('tbody');
  for (const d of lista.slice(0, REV.mostrar)) {
    const tr = h(`<tr>
      <td class="td-chk"></td>
      <td><div class="doc-nom">${esc(d.nombre)}</div><div class="hint">${esc(d.rutaRelativa || '')}</div></td>
      <td style="white-space:nowrap">${descripcionDoc(d)}</td>
      <td>${avisosDoc(d).map((a) => `<div>${esc(a.texto)}</div>`).join('')}</td>
      <td><div class="acciones"></div></td>
    </tr>`);
    const acc = tr.querySelector('.acciones');
    const bVer = h('<button class="btn btn-sm btn-accent">Ver</button>');
    bVer.onclick = () => verDocumento(d.id);
    const bCor = h('<button class="btn btn-sm">Corregir</button>');
    bCor.onclick = () => corregirDoc(d, () => repintar('revisar'));
    const bOk = h('<button class="btn btn-sm" title="La clasificación actual es correcta">Está bien</button>');
    bOk.onclick = async () => {
      await api('POST', 'revision/documento/' + d.id, { revisado: true, nota: 'revisado: se deja como estaba' });
      EXP_ARBOL = null;
      await refreshCache(); repintar('revisar');
    };
    // Emitida o gasto: un clic.
    if (esDeSentido(d)) {
      for (const [txt, sentido, msg] of [['Es emitida', 'emitida', 'Marcada como emitida'], ['Es gasto', 'recibida', 'Marcada como gasto']]) {
        const b = h('<button class="btn btn-sm"></button>');
        b.textContent = txt;
        b.onclick = async () => {
          const fila = [...acc.querySelectorAll('button')];
          fila.forEach((x) => { x.disabled = true; });
          try { await marcarSentido(d, sentido); } catch (e) { fila.forEach((x) => { x.disabled = false; }); return toast(e.message, true); }
          EXP_ARBOL = null;
          toast(msg); await refreshCache(); repintar('revisar');
        };
        acc.appendChild(b);
      }
    }
    // Abono dudoso: confirmar el negativo o devolverlo a positivo.
    if (avisosDoc(d).some((a) => a.cod === 'abono')) {
      for (const [txt, abono, msg] of [['Es abono', true, 'Confirmado como abono (en negativo)'], ['No es abono', false, 'Vuelve a positivo']]) {
        const b = h('<button class="btn btn-sm"></button>');
        b.textContent = txt;
        b.onclick = async () => {
          await api('POST', 'revision/documento/' + d.id, { abono, revisado: true, nota: abono ? 'confirmado: es un abono' : 'no es un abono: importes en positivo' });
          toast(msg); await refreshCache(); repintar('revisar');
        };
        acc.appendChild(b);
      }
    }
    const bDes = h('<button class="btn btn-sm btn-danger" title="No es una factura que revisar: es de Hacienda, otro documento o sobra">Descartar</button>');
    bDes.onclick = () => descartarDocs([{ doc: d, factura: CACHE.facturaDeDoc.get(d.id) }], renderRevisar);
    acc.append(bVer, bCor, bOk, bDes);
    tr.querySelector('.td-chk').appendChild(casilla(d.id, { doc: d, factura: CACHE.facturaDeDoc.get(d.id) }));
    tb.appendChild(tr);
  }
  host.appendChild(t);
  if (lista.length > REV.mostrar) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${lista.length - REV.mostrar})</button>`);
    mas.onclick = () => { REV.mostrar += 100; renderRevisar(); };
    host.appendChild(mas);
  }
}

function pintarRevImportes(host, porConfirmar, sinImporte) {
  const chips = h('<div class="chips"></div>');
  for (const g of [{ v: 'pdf', l: 'Leídos del PDF, por confirmar', n: porConfirmar.length }, { v: 'sin', l: 'Sin importe', n: sinImporte.length }]) {
    const b = h(`<button class="chip${REV.filtroImp === g.v ? ' activo' : ''}">${esc(g.l)} <b>${g.n}</b></button>`);
    b.onclick = () => { REV.filtroImp = g.v; REV.mostrar = 100; renderRevisar(); };
    chips.appendChild(b);
  }
  host.appendChild(chips);
  host.appendChild(h(`<p class="hint">${REV.filtroImp === 'pdf'
    ? 'Importes leídos automáticamente. Ábrelos con «Ver», comprueba y pulsa «Confirmar». Los de fiabilidad alta cuadran con la etiqueta «Total» del documento.'
    : 'Facturas sin importe: suelen ser escaneos. Ábrelas con «Ver» y escribe base, IVA y total.'}</p>`));

  let lista = REV.filtroImp === 'pdf' ? porConfirmar : sinImporte;
  lista = lista.slice().sort((a, b) => (a.importeFiabilidad === 'alta' ? 0 : 1) - (b.importeFiabilidad === 'alta' ? 0 : 1) || String(a.fecha).localeCompare(String(b.fecha)));
  if (!lista.length) { host.appendChild(h('<div class="vacio-exp">✓ Nada pendiente aquí.</div>')); return; }

  if (REV.filtroImp === 'pdf') {
    // «Alta» dice que el total coincide con la etiqueta del PDF, pero no que
    // base e IVA cuadren: una factura con dos tipos de IVA puede leerse con uno
    // solo y quedar a 4 céntimos. Esas se confirman a mano, nunca en bloque.
    const cuadra = (f) => Math.abs(totalDe(f.base || 0, f.iva || 0, f.irpf || 0, f.desglose, f.recargo) - (f.total || 0)) <= 0.01;
    const altas = lista.filter((f) => f.importeFiabilidad === 'alta' && cuadra(f));
    if (altas.length) {
      const b = h(`<button class="btn" style="margin-bottom:10px">Confirmar las ${altas.length} de fiabilidad alta</button>`);
      b.onclick = () => confirmar(`Se darán por buenos ${altas.length} importes que cuadran con la etiqueta «Total» de su PDF. Recomendado: revisa antes unos cuantos con «Ver». ¿Confirmar?`, async () => {
        let ok = 0;
        for (const f of altas) {
          try { await api('POST', 'revision/factura/' + f.id, { base: f.base, iva: f.iva, irpf: f.irpf || 0, total: f.total }); ok++; } catch { /* sigue */ }
        }
        toast(`Confirmados ${ok}`); await refreshCache(); repintar('revisar');
      });
      host.appendChild(b);
    }
  }

  const casilla = seleccionParaDescartar(host, renderRevisar);
  const t = h(`<div class="tabla-scroll"><table class="imp-tabla"><thead><tr>
    <th></th><th>Factura</th><th>Cliente · periodo</th><th>Base</th><th>IVA %</th><th>IRPF %</th><th>Total</th><th></th>
  </tr></thead><tbody></tbody></table></div>`);
  const tb = t.querySelector('tbody');
  for (const f of lista.slice(0, REV.mostrar)) {
    const d = CACHE.documentos.find((x) => x.id === f.documentoId);
    const tr = h(`<tr>
      <td class="td-chk"></td>
      <td><div class="doc-nom">${esc(d ? d.nombre : f.numero)}</div>
        <div class="hint">${f.sentido === 'emitida' ? 'Emitida' : 'Recibida'} · nº ${esc(f.numero || '—')}${f.importeFiabilidad ? ' · fiabilidad ' + esc(f.importeFiabilidad) : ''}</div></td>
      <td style="white-space:nowrap">${esc(aliasDeId(f.sujetoId))} · ${esc(f.trimestre || '')} ${esc(f.ejercicio || '')}</td>
      <td><input class="w-imp" data-k="base" inputmode="decimal" value="${f.base || ''}"></td>
      <td><input class="w-pct" data-k="iva" inputmode="decimal" value="${f.iva ?? 21}"></td>
      <td><input class="w-pct" data-k="irpf" inputmode="decimal" value="${f.irpf || 0}"></td>
      <td><input class="w-imp" data-k="total" inputmode="decimal" value="${f.total || ''}"></td>
      <td><div class="acciones"></div></td>
    </tr>`);
    const val = (k) => tr.querySelector(`[data-k="${k}"]`);
    const recalcular = () => {
      const b = num(aImporte(val('base').value)), iv = num(aPct(val('iva').value)), ir = num(aPct(val('irpf').value)) || 0;
      // Con varios tipos de IVA, la cuota tipo a tipo (si la base sigue siendo la suma).
      if (b != null && iv != null) val('total').value = totalDe(b, iv, ir, f.desglose, f.recargo).toFixed(2);
    };
    ['base', 'iva', 'irpf'].forEach((k) => { val(k).oninput = recalcular; });
    const acc = tr.querySelector('.acciones');
    if (d) { const bV = h('<button class="btn btn-sm btn-accent">Ver</button>'); bV.onclick = () => verDocumento(d.id, d.nombre); acc.appendChild(bV); }
    const bC = h('<button class="btn btn-sm">Confirmar</button>');
    bC.onclick = async () => {
      const cuerpo = {};
      for (const k of ['base', 'iva', 'irpf', 'total']) cuerpo[k] = num((k === 'base' || k === 'total' ? aImporte : aPct)(val(k).value));
      // Un abono va en negativo: lo que falta es un total distinto de 0.
      if (!cuerpo.total || cuerpo.base == null) return toast('Escribe al menos la base y el total.', true);
      try {
        await api('POST', 'revision/factura/' + f.id, cuerpo);
        tr.remove();
        toast('Importe confirmado');
        CACHE.st = await get('stats'); pintarCabecera();
        Object.assign(f, cuerpo, { importeConfirmado: true });
      } catch (e) { toast(e.message, true); }
    };
    acc.appendChild(bC);
    const bDes = h('<button class="btn btn-sm btn-danger" title="No es una factura: es de Hacienda, otro documento o sobra">Descartar</button>');
    bDes.onclick = () => descartarDocs([{ doc: d, factura: f }], renderRevisar);
    acc.appendChild(bDes);
    tr.querySelector('.td-chk').appendChild(casilla(f.id, { doc: d, factura: f }));
    tb.appendChild(tr);
  }
  host.appendChild(t);
  if (lista.length > REV.mostrar) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${lista.length - REV.mostrar})</button>`);
    mas.onclick = () => { REV.mostrar += 100; renderRevisar(); };
    host.appendChild(mas);
  }
}

// ---- Mapa de relaciones (idea "graphify") -------------------------
async function renderMapa() {
  const turno = ++NAV;
  view.innerHTML = '';
  view.appendChild(h('<h1>Mapa de relaciones</h1>'));
  view.appendChild(h('<p class="sub">Grafo de conocimiento del despacho: grupos → sujetos → facturas / documentos / informes.</p>'));
  const colors = { grupo: '#0d0d0f', sujeto: '#f2635f', factura: '#f0904a', documento: '#3a7bd5', informe: '#1f9d63' };
  view.appendChild(h('<div class="legend">' + Object.entries(colors).map(([k, c]) => `<span><i class="dot" style="background:${c}"></i>${k}</span>`).join('') + '</div>'));
  const g = await get('grafo');
  if (turno !== NAV) return;
  if (!g.nodes.length) { view.appendChild(h('<div class="empty">Aún no hay datos que relacionar.</div>')); return; }

  // layout radial por tipo
  const W = 1100, H = 640, cx = W / 2, cy = H / 2;
  const byType = {};
  g.nodes.forEach((n) => (byType[n.tipo] = byType[n.tipo] || []).push(n));
  const radius = { grupo: 90, sujeto: 210, factura: 340, documento: 340, informe: 460 };
  const pos = {};
  Object.entries(byType).forEach(([tipo, arr]) => {
    arr.forEach((n, k) => {
      const ang = (k / arr.length) * Math.PI * 2 + (tipo === 'documento' ? 0.5 : 0);
      pos[n.id] = { x: cx + Math.cos(ang) * (radius[tipo] || 260), y: cy + Math.sin(ang) * (radius[tipo] || 260) };
    });
  });
  const edges = g.edges.map((e) => {
    const a = pos[e.from], b = pos[e.to];
    if (!a || !b) return '';
    return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#c9ccd3" stroke-width="1"/>`;
  }).join('');
  const nodes = g.nodes.map((n) => {
    const p = pos[n.id];
    return `<g><circle cx="${p.x}" cy="${p.y}" r="${n.tipo === 'grupo' ? 9 : 6}" fill="${colors[n.tipo]}"/><text x="${p.x + 9}" y="${p.y + 4}" font-size="11" fill="#1c1d21">${esc(n.label).slice(0, 26)}</text></g>`;
  }).join('');
  view.appendChild(h(`<div class="graph-wrap"><svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${edges}${nodes}</svg></div>`));
}

// ---- Configuración -----------------------------------------------
// Elegir la carpeta del archivo y comprobarla de verdad: se cuenta cuántos de
// los documentos aparecen dentro, que una carpeta con el nombre correcto pero
// medio vacía es el fallo que nadie ve hasta que falla «Ver».
function tarjetaCarpetaArchivo(c) {
  const card = h(`<div class="card" style="max-width:820px;margin-bottom:16px">
    <b>Carpeta de las facturas</b>
    <p class="hint" style="margin:6px 0 12px">La carpeta que contiene las carpetas de cada cliente y año. De aquí saca el programa los PDF que abre «Ver». Nada de fuera de esta carpeta se abre nunca.</p>
    <div class="field"><label>Ruta en este ordenador</label>
      <input data-carpeta placeholder="Ej.: D:\\Asesoria\\Archivo" value="${esc(c.rutaArchivo || '')}">
      <div class="hint">Ábrela en el explorador de Windows, pulsa en la barra de direcciones de arriba, copia y pega aquí.</div>
    </div>
    <div class="carpeta-acc"></div>
    <div class="carpeta-res"></div>
  </div>`);
  const input = card.querySelector('[data-carpeta]');
  const acc = card.querySelector('.carpeta-acc');
  const res = card.querySelector('.carpeta-res');
  const bloqueada = (c._bloqueadosPorEnv || []).includes('rutaArchivo');

  const pintar = (e, guardada) => {
    res.innerHTML = '';
    if (!e) return;
    if (!e.existe) {
      res.appendChild(h(`<div class="res-mal">✕ Esa carpeta no existe en este ordenador.</div>`));
      return;
    }
    const clase = e.encontrados === 0 ? 'res-mal' : (e.faltan ? 'res-medio' : 'res-bien');
    const icono = e.encontrados === 0 ? '✕' : (e.faltan ? '!' : '✓');
    res.appendChild(h(`<div class="${clase}">${icono} Se encuentran <b>${e.encontrados.toLocaleString('es-ES')}</b> de ${e.total.toLocaleString('es-ES')} documentos${guardada ? ' · carpeta guardada' : ''}.</div>`));
    if (e.encontrados === 0 && e.carpetasEsperadas && e.carpetasEsperadas.length) {
      res.appendChild(h(`<div class="hint">Dentro deberían verse carpetas como: ${esc(e.carpetasEsperadas.slice(0, 4).join(', '))}. Puede que hayas elegido una carpeta de más o de menos.</div>`));
    } else if (e.faltan && e.ejemplos.length) {
      res.appendChild(h(`<div class="hint">No aparecen, por ejemplo: ${esc(e.ejemplos.slice(0, 3).join(' · '))}</div>`));
    }
  };

  const comprobar = async (guardar) => {
    const ruta = input.value.trim();
    if (!ruta) return toast('Escribe o busca la carpeta primero.', true);
    res.innerHTML = '<div class="hint">Comprobando…</div>';
    try {
      const e = await api('POST', 'archivo/comprobar', { ruta });
      if (guardar && e.existe) {
        await api('PUT', 'config', { ...CACHE.config, rutaArchivo: ruta });
        CACHE.config = await get('config');
        ARCHIVO_ESTADO = null;
        await pintarAvisoArchivo();
        toast('Carpeta guardada');
      }
      pintar(e, guardar && e.existe);
      if (guardar && !e.existe) toast('No se ha guardado: esa carpeta no existe.', true);
    } catch (err) { toast(err.message, true); res.innerHTML = ''; }
  };

  const bComp = h('<button class="btn">Comprobar</button>');
  bComp.onclick = () => comprobar(false);
  const bGuardar = h('<button class="btn btn-accent">Usar esta carpeta</button>');
  bGuardar.onclick = () => comprobar(true);
  const bBuscar = h('<button class="btn">Buscarla por mí</button>');
  bBuscar.onclick = async () => {
    res.innerHTML = '<div class="hint">Buscando en las carpetas habituales…</div>';
    try {
      const r = await api('POST', 'archivo/buscar-carpeta', {});
      res.innerHTML = '';
      if (!r.candidatos.length) {
        res.appendChild(h('<div class="res-medio">! No la he encontrado sola. Cópiala del explorador de Windows y pégala arriba.</div>'));
        return;
      }
      res.appendChild(h('<div class="hint">Carpetas que parecen el archivo:</div>'));
      for (const cand of r.candidatos) {
        const fila = h(`<div class="cand"><code>${esc(cand.ruta)}</code> <span class="hint">${cand.deDocumentos ? `${cand.documentos} de ${cand.deDocumentos} documentos · ` : ''}${cand.aciertos} de ${cand.de} carpetas</span></div>`);
        const b = h('<button class="btn btn-sm">Usar esta</button>');
        b.onclick = () => { input.value = cand.ruta; comprobar(true); };
        fila.appendChild(b);
        res.appendChild(fila);
      }
    } catch (err) { toast(err.message, true); res.innerHTML = ''; }
  };
  acc.append(bBuscar, bComp, bGuardar);

  if (bloqueada) {
    input.readOnly = true;
    input.style.background = '#f4f5f7';
    [bGuardar, bBuscar].forEach((b) => { b.disabled = true; });
    card.appendChild(h('<div class="hint">Esta carpeta viene del archivo .env (GF_RUTA_ARCHIVO). Para cambiarla, edita .env y reinicia el programa.</div>'));
  }
  if (c.rutaArchivo) comprobar(false);
  return card;
}

// ---- Versión del programa ---------------------------------------------------
// Las versiones nuevas se instalan solas al abrir el programa. Mientras tanto,
// si ya se sabe que hay una, se avisa arriba con la opción de hacerlo ya.
let ACT_ESTADO = null;

async function pintarAvisoVersion() {
  const caja = document.getElementById('aviso-version');
  if (!caja) return;
  try { ACT_ESTADO = await get('actualizacion'); } catch { return; }
  const d = ACT_ESTADO.disponible;
  if (!d) { caja.hidden = true; caja.innerHTML = ''; return; }
  caja.hidden = false;
  caja.innerHTML = '';
  const b = h(`<div class="aviso-version"><span>⬆ <b>Hay una versión nueva del programa (${esc(d.version)}).</b> ${esc(d.notas || '')} Se instalará sola la próxima vez que lo abras.</span></div>`);
  const bAhora = h('<button class="btn btn-sm btn-accent">Instalar ahora</button>');
  bAhora.onclick = () => instalarVersion(d.version);
  b.appendChild(bAhora);
  caja.appendChild(b);
}

// Instala y espera a que el programa vuelva con la versión nueva.
async function instalarVersion(version) {
  confirmar(`Se instalará la versión ${version}. El programa se reinicia en unos segundos; tus datos no se tocan. ¿Seguir?`, async () => {
    let r;
    try { r = await api('POST', 'actualizacion/instalar', {}); }
    catch (e) { return toast(e.message, true); }
    if (!r.instalada) return toast(r.mensaje || 'No había nada que instalar.');
    if (!r.reinicia) {
      toast(`Instalada la ${r.version}. Cierra el programa y vuelve a abrirlo con INICIAR.bat para usarla.`);
      return pintarAvisoVersion();
    }
    toast(`Instalada la ${r.version}. Reiniciando…`);
    await esperarVersion(r.version);
  });
}

async function esperarVersion(version) {
  for (let i = 0; i < 60; i++) {
    await new Promise((res) => setTimeout(res, 1000));
    try {
      const st = await get('stats');
      if (st.version === version) { location.reload(); return; }
    } catch { /* aún reiniciando */ }
  }
  toast('El programa tarda en volver. Recarga la página en un momento.', true);
}

// ---- Ordenar una carpeta nueva ---------------------------------------
// Sustituye TODO lo del programa por lo que hay en una carpeta desordenada,
// ya colocado. Antes se guarda una copia de lo anterior (se puede recuperar).
const fechaCorta = (iso) => (iso ? new Date(iso).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }) : '');
const postJSON = (ruta, cuerpo) => api('POST', ruta, cuerpo || {});

async function trasCambiarDatos() {
  EXP_ARBOL = null; EXP_RUTA = []; EXP_BUSQUEDA = '';
  IMP.cargado = false; IMP.filas = []; IMP.resumen = null;
  await refreshCache();
  pintarAvisoArchivo();
}

// Por qué los escaneos no se han podido leer (o se leen peor), dicho claro.
function avisoOcr(motivo, ok) {
  const instalar = 'Se instala en Configuración de Windows → Hora e idioma → Idioma → Español → Opciones → Reconocimiento óptico de caracteres.';
  const txt = {
    'sin-motor': 'Hay escaneos, pero este Windows no tiene el lector de texto (OCR): se quedarán para revisar a mano. ' + instalar,
    'otro-idioma': 'El lector de texto (OCR) de este Windows no tiene el español: los escaneos se leen, pero peor (tildes, ñ). ' + instalar,
    'no-responde': 'El lector de texto (OCR) de Windows no ha respondido: los escaneos se quedan para revisar a mano. Prueba a analizar otra vez en un momento.',
    'bloqueado': 'Este Windows no deja al programa usar su lector de texto (OCR), seguramente por una política de seguridad del equipo: los escaneos se quedan para revisar a mano.',
    'desactivado': 'La lectura de escaneos está desactivada (GF_OCR=0 en el archivo .env): se quedan para revisar a mano.',
  }[motivo];
  return txt && (!ok || motivo === 'otro-idioma') ? `<div class="aviso-inc">${esc(txt)}</div>` : '';
}

function abrirOrdenarCarpeta() {
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg"></div>');
  const modal = h(`<div class="modal"><header><strong>Ordenar una carpeta nueva</strong><button class="btn-ghost" data-x>✕</button></header><div class="body"></div></div>`);
  const body = modal.querySelector('.body');
  bg.appendChild(modal); root.appendChild(bg);
  let vivo = true;
  const cerrar = () => { vivo = false; bg.remove(); };
  modal.querySelector('[data-x]').onclick = cerrar;

  const paso = (html) => { body.innerHTML = ''; const n = h(`<div style="display:grid;gap:12px">${html}</div>`); body.appendChild(n); return n; };

  // Espera a que el servidor termine la fase en curso, enseñando el avance.
  const seguir = async (titulo) => {
    const n = paso(`<p><b>${esc(titulo)}</b></p><div class="progreso"><div class="barra"><i></i></div><span></span></div><p class="hint">Puedes cerrar esta ventana: sigue trabajando y al volver a abrirla verás cómo va.</p>`);
    const barra = n.querySelector('.barra i'), txt = n.querySelector('.progreso span');
    while (vivo) {
      let e;
      try { e = await get('ordenar/estado'); } catch { await new Promise((r) => setTimeout(r, 1000)); continue; }
      const t = e.trabajo || {};
      if (t.total) barra.style.width = Math.round(100 * t.hechos / t.total) + '%';
      txt.textContent = `${t.mensaje || ''} ${t.total ? t.hechos + ' de ' + t.total : ''}`;
      if (!['leyendo', 'ordenando', 'recuperando'].includes(t.fase)) return t;
      await new Promise((r) => setTimeout(r, 600));
    }
    return null;
  };

  const elegir = () => {
    const n = paso(`<p>Elige la carpeta con las facturas, esté como esté: el programa mira dentro de todas sus subcarpetas. <b>La carpeta no se toca</b>: solo se lee.</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn btn-accent" data-dialogo>Elegir carpeta…</button></div>
      <div class="field"><label>O escribe (o pega) la ruta</label><input data-ruta placeholder="C:\\Users\\...\\Facturas sin ordenar"></div>
      <div class="error-inline" style="color:#8d2b28" hidden></div>
      <div style="display:flex;justify-content:flex-end;gap:8px"><button class="btn" data-cancelar>Cancelar</button><button class="btn btn-accent" data-analizar>Analizar la carpeta</button></div>`);
    const input = n.querySelector('[data-ruta]'), err = n.querySelector('.error-inline');
    const fallo = (m) => { err.hidden = false; err.textContent = m; };
    n.querySelector('[data-cancelar]').onclick = cerrar;
    n.querySelector('[data-dialogo]').onclick = async (ev) => {
      ev.target.disabled = true; ev.target.textContent = 'Mira la ventana de Windows…';
      try {
        const r = await postJSON('ordenar/elegir');
        if (r.ruta) input.value = r.ruta; else if (r.error) fallo(r.error);
      } catch (e) { fallo(e.message); }
      ev.target.disabled = false; ev.target.textContent = 'Elegir carpeta…';
    };
    n.querySelector('[data-analizar]').onclick = async () => {
      try { await postJSON('ordenar/analizar', { ruta: input.value }); } catch (e) { return fallo(e.message); }
      const t = await seguir('Leyendo la carpeta…');
      if (t) mostrar(t);
    };
  };

  const revisar = (t) => {
    const p = t.previa;
    const fuera = Object.entries(p.otros || {}).sort((a, b) => b[1] - a[1]).map(([x, k]) => `${k} .${x}`);
    const n = paso(`<p><b>${esc(p.ruta)}</b><br>${p.ficheros} ficheros · <b>${p.facturas} facturas</b>${p.leidosOcr ? ` · ${p.leidosOcr} escaneos leídos con OCR` : ''}${p.sinTexto ? ` · ${p.sinTexto} sin texto legible` : ''}</p>
      ${p.escaneos ? avisoOcr(p.ocrMotivo, p.ocrDisponible) : ''}
      ${fuera.length ? `<div class="hint">No son facturas y se dejan fuera: ${esc(fuera.join(', '))}.</div>` : ''}
      ${p.nComprimidos ? `<div class="aviso-inc">Hay ${p.nComprimidos} comprimido(s) sin abrir: lo que tengan dentro no se ordenará. Descomprímelos y vuelve a analizar si hace falta.</div>` : ''}
      ${p.grandes ? `<div class="aviso-inc">${p.grandes} fichero(s) de más de 36 MB no se pueden importar.</div>` : ''}
      <div><b>Clientes detectados</b> <span class="hint">(por el NIF que se repite en sus facturas; corrige el nombre si hace falta)</span></div>
      <div data-clientes></div>
      <div data-uno hidden><label class="field" style="margin:0"><span>¿De quién es la carpeta?</span>
        <select data-uncliente></select></label>
        <div class="hint">Si es la carpeta de un solo cliente, lo que no diga de quién es (tickets, escaneos sin su NIF…) se le asigna a él.</div></div>
      <div class="aviso-archivo" style="display:block"><b>Esto sustituye TODO lo que hay ahora en el programa</b> (${p.ahora.documentos} documentos, ${p.ahora.facturas} facturas, ${p.ahora.clientes} clientes, con sus correcciones).
        Antes se guarda una copia completa y se puede recuperar desde <i>Configuración → Carpeta de trabajo</i>.
        <label style="display:flex;gap:8px;margin-top:8px"><input type="checkbox" data-entiendo> Entendido: quiero sustituirlo por esta carpeta.</label></div>
      <div style="display:flex;justify-content:flex-end;gap:8px"><button class="btn" data-otra>Elegir otra carpeta</button><button class="btn btn-danger" data-ordenar disabled>Ordenar y sustituir</button></div>`);
    const caja = n.querySelector('[data-clientes]');
    const filas = p.clientes.map((c) => ({ ...c, incluir: c.marcado }));
    if (!filas.length) {
      caja.appendChild(h('<div class="hint">No se ha detectado ningún cliente (¿escaneos sin texto?). Puedes ordenar igualmente: todo quedará en «Importar» para asignarlo a mano, o crear los clientes antes en «Sujetos».</div>'));
    } else {
      const tabla = h(`<div class="tabla-scroll"><table class="imp-tabla"><thead><tr><th></th><th>Nombre</th><th>Carpeta</th><th>NIF</th><th>Facturas</th></tr></thead><tbody></tbody></table></div>`);
      const tb = tabla.querySelector('tbody');
      for (const c of filas) {
        const tr = h(`<tr><td><input type="checkbox" class="chk-grande"${c.incluir ? ' checked' : ''}></td>
          <td><input data-n value="${esc(c.nombre)}" style="min-width:220px"></td><td><input data-a value="${esc(c.alias)}" style="width:140px"></td>
          <td>${esc(c.nif)}${c.conocido ? ' <span class="tag ok">ya lo conocía</span>' : ''}</td>
          <td>${c.facturas} <span class="hint">(${c.pct}%)</span>${c.marcado ? '' : '<div class="hint">¿también es cliente?</div>'}</td></tr>`);
        c.chk = tr.querySelector('input[type=checkbox]');
        c.chk.onchange = (e) => {
          c.incluir = e.target.checked;
          // Se desmarca el cliente de «toda la carpeta»: vuelve a «varios», con
          // las marcas de los demás como estaban (y este, desmarcado).
          if (!c.incluir && uno.value === c.nif) { uno.value = ''; uno.onchange(); c.incluir = false; c.chk.checked = false; }
        };
        tr.querySelector('[data-n]').oninput = (e) => { c.nombre = e.target.value; };
        tr.querySelector('[data-a]').oninput = (e) => { c.alias = e.target.value; };
        tb.appendChild(tr);
      }
      caja.appendChild(tabla);
    }
    // Carpeta de un solo cliente: lo que no apunte a nadie es suyo.
    const uno = n.querySelector('[data-uncliente]');
    if (filas.length) {
      n.querySelector('[data-uno]').hidden = false;
      uno.innerHTML = '<option value="">De varios clientes: lo dice cada factura</option>'
        + filas.map((c) => `<option value="${esc(c.nif)}">Toda es de ${esc(c.nombre)}</option>`).join('');
      // Si toda es de uno, los demás «clientes» que salen son sus proveedores:
      // se desmarcan (se pueden volver a marcar). Al volver a «varios», cada uno
      // queda como estaba.
      let antes = null;
      uno.onchange = () => {
        if (!uno.value) {
          if (antes) for (const c of filas) { c.incluir = antes.get(c) ?? c.incluir; c.chk.checked = c.incluir; }
          antes = null;
          return;
        }
        if (!antes) antes = new Map(filas.map((c) => [c, c.incluir]));
        for (const c of filas) { c.incluir = c.nif === uno.value; c.chk.checked = c.incluir; }
      };
    }
    const bOrd = n.querySelector('[data-ordenar]');
    n.querySelector('[data-entiendo]').onchange = (e) => { bOrd.disabled = !e.target.checked; };
    n.querySelector('[data-otra]').onclick = elegir;
    bOrd.onclick = async () => {
      bOrd.disabled = true;
      try { await postJSON('ordenar/ordenar', { id: t.id, clientes: filas.map(({ chk, ...c }) => c), unCliente: uno.value || null }); } catch (e) { toast(e.message, true); bOrd.disabled = false; return; }
      const fin = await seguir('Ordenando: copia de seguridad y cada factura a su sitio…');
      if (fin) { await trasCambiarDatos(); mostrar(fin); }
    };
  };

  const terminado = (t) => {
    const r = t.resultado || {};
    const n = paso(`<p><b>Carpeta ordenada.</b> ${esc(r.origen || '')}</p>
      <div class="exp-resumen"><span><span class="pto verde"></span> <b>${r.colocadas}</b> facturas colocadas en su cliente, año, trimestre y tipo${r.leidosOcr ? ` (${r.leidosOcr} escaneos leídos con OCR)` : ''}</span>
      ${r.tipoPorConfirmar ? `<span><span class="pto ambar"></span> de ellas, <b>${r.tipoPorConfirmar}</b> con el tipo por confirmar (¿gasto o ingreso?) en «Revisar»</span>` : ''}
      ${r.separadas ? `<span><span class="pto verde"></span> <b>${r.separadas}</b> facturas sacadas de PDF que traían varias juntas</span>` : ''}
      <span><span class="pto ambar"></span> <b>${r.pendientes}</b> sin colocar, para revisar en «Importar» (sin cliente o sin fecha, o repetidas)</span>
      ${(r.repetidas || []).length ? `<div class="hint" style="flex-basis:100%"><b>Repetidas (${r.repetidas.length}):</b> ${esc(r.repetidas.slice(0, 8).join(' · '))}${r.repetidas.length > 8 ? '…' : ''}</div>` : ''}
      ${r.noLeidas ? `<span><span class="pto rojo"></span> <b>${r.noLeidas}</b> no se pudieron leer</span>` : ''}</div>
      <p class="hint">La copia ordenada está en ${esc(r.carpetaOrdenada || '')}. Lo que había antes quedó guardado (${esc(r.copia || '')}).</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end">
        <button class="btn" data-carpeta>Abrir la carpeta ordenada</button>
        ${r.pendientes ? '<button class="btn" data-importar>Revisar las dudosas</button>' : ''}
        <button class="btn btn-accent" data-archivo>Ver el archivo</button></div>`);
    n.querySelector('[data-carpeta]').onclick = () => postJSON('ordenar/abrir').catch((e) => toast(e.message, true));
    const bi = n.querySelector('[data-importar]');
    if (bi) bi.onclick = () => { cerrar(); irA('importar'); };
    n.querySelector('[data-archivo]').onclick = () => { cerrar(); irA('archivo'); };
  };

  const mostrar = (t) => {
    if (!t) return elegir();
    if (t.fase === 'analizada') return revisar(t);
    if (t.fase === 'hecho') return terminado(t);
    if (t.fase === 'recuperada') { paso('<p><b>Recuperado lo anterior.</b></p>'); return; }
    if (t.fase === 'error') {
      const n = paso(`<div class="aviso-inc aviso-dup">${esc(t.error || 'Algo falló.')}</div><div style="display:flex;justify-content:flex-end;gap:8px"><button class="btn" data-otra>Volver a empezar</button></div>`);
      n.querySelector('[data-otra]').onclick = elegir;
      return;
    }
    return elegir();
  };

  // Si ya había algo en marcha (o a medias de revisar), se sigue desde ahí.
  get('ordenar/estado').then(async (e) => {
    const t = e.trabajo;
    if (t && ['leyendo', 'ordenando', 'recuperando'].includes(t.fase)) {
      const fin = await seguir(t.fase === 'leyendo' ? 'Leyendo la carpeta…' : 'Ordenando…');
      if (fin && fin.fase === 'hecho') await trasCambiarDatos();
      return mostrar(fin);
    }
    return mostrar(t && t.fase === 'analizada' ? t : null);
  }).catch(() => elegir());
}

function tarjetaCarpetaTrabajo() {
  const card = h(`<div class="card" style="max-width:820px;margin-bottom:16px">
    <b>Carpeta de trabajo</b>
    <div class="ct-cuerpo" style="margin-top:8px"><div class="hint">Cargando…</div></div>
  </div>`);
  const cuerpo = card.querySelector('.ct-cuerpo');
  const pintar = (e) => {
    cuerpo.innerHTML = '';
    const a = e.actual;
    cuerpo.appendChild(h(a && a.origen
      ? `<div>Ahora el programa muestra la carpeta <b>${esc(a.origen)}</b>, ordenada el ${esc(fechaCorta(a.fecha))}: ${a.colocadas ?? '?'} facturas colocadas${a.pendientes ? `, ${a.pendientes} para revisar` : ''}.</div>`
      : '<div>Ahora el programa muestra el archivo con el que se instaló.</div>'));
    cuerpo.appendChild(h('<div class="hint" style="margin-top:4px">«Ordenar una carpeta nueva» sustituye todo lo del programa por lo que haya en otra carpeta, ya ordenado. Antes guarda una copia de lo de ahora.</div>'));
    const acc = h('<div class="carpeta-acc" style="margin-top:10px"></div>');
    const bOrd = h('<button class="btn btn-accent">Ordenar una carpeta nueva</button>');
    bOrd.onclick = abrirOrdenarCarpeta;
    acc.appendChild(bOrd);
    if (a && a.origen) {
      const bAb = h('<button class="btn">Abrir la carpeta ordenada</button>');
      bAb.onclick = () => postJSON('ordenar/abrir').catch((err) => toast(err.message, true));
      acc.appendChild(bAb);
    }
    const original = (e.copias || []).find((x) => x.original);
    if (original && a && a.origen) {
      const bOri = h('<button class="btn">Volver al archivo original</button>');
      bOri.onclick = () => confirmar(`Se vuelve al archivo con el que se instaló el programa (${original.documentos} documentos, guardado el ${fechaCorta(original.fecha)}). Lo de ahora también se guarda. ¿Seguir?`, async () => {
        try {
          const r = await postJSON('ordenar/recuperar', { cual: 'original' });
          if (r.fase === 'error') throw new Error(r.error);
          await trasCambiarDatos();
          toast(`Vuelto al archivo original: ${r.resultado.documentos} documentos.`);
          get('ordenar/estado').then(pintar);
        } catch (err) { toast(err.message, true); }
      });
      acc.appendChild(bOri);
    }
    const copia = (e.copias || [])[0];
    if (copia) {
      const bRec = h('<button class="btn">Recuperar lo anterior</button>');
      bRec.onclick = () => confirmar(`Se vuelve a lo que había antes del último cambio (guardado el ${fechaCorta(copia.fecha)}: ${copia.documentos} documentos${copia.carpeta ? ', carpeta ' + copia.carpeta : ''}). Lo de ahora también se guarda, así que se puede volver. ¿Seguir?`, async () => {
        try {
          const r = await postJSON('ordenar/recuperar');
          if (r.fase === 'error') throw new Error(r.error);
          await trasCambiarDatos();
          toast(`Recuperado: ${r.resultado.documentos} documentos.`);
          get('ordenar/estado').then(pintar);
        } catch (err) { toast(err.message, true); }
      });
      acc.appendChild(bRec);
    }
    cuerpo.appendChild(acc);
  };
  get('ordenar/estado').then(pintar).catch((err) => { cuerpo.innerHTML = '<div class="hint">' + esc(err.message) + '</div>'; });
  return card;
}

function tarjetaVersion() {
  const card = h(`<div class="card" style="max-width:820px;margin-bottom:16px">
    <b>Versión del programa</b>
    <div class="version-cuerpo" style="margin-top:8px"><div class="hint">Cargando…</div></div>
  </div>`);
  const cuerpo = card.querySelector('.version-cuerpo');
  const cuando = (iso) => iso ? new Date(iso).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }) : 'nunca';

  const pintar = (e) => {
    cuerpo.innerHTML = '';
    const lineas = [`Instalada: <b>${esc(e.actual)}</b>`];
    if (!e.configurado) {
      lineas.push('Actualizaciones automáticas: <b>sin configurar</b> (falta GF_ACTUALIZACIONES_URL en el archivo .env).');
    } else {
      lineas.push(`Actualizaciones automáticas: <b>activadas</b> · última comprobación: ${esc(cuando(e.ultimaComprobacion))}`);
      if (e.errorComprobacion) lineas.push(`<span style="color:#8d2b28">${esc(e.errorComprobacion)}</span>`);
      lineas.push(e.disponible
        ? `<b>Hay versión nueva: ${esc(e.disponible.version)}</b>${e.disponible.notas ? ' — ' + esc(e.disponible.notas) : ''}`
        : 'Estás en la última versión publicada.');
    }
    if (e.vueltaAtrasAMedias) lineas.push('La vuelta a la versión anterior se quedó a medias. Pulsa otra vez «Volver a la ' + esc(e.anteriores[0]) + '» o cierra y abre el programa: se termina sola.');
    if (e.pendienteDeConfirmar) lineas.push('Recién instalada: se da por buena tras 30 segundos en marcha. Si fallara al arrancar, el programa vuelve solo a la anterior.');
    cuerpo.appendChild(h('<div style="display:grid;gap:4px">' + lineas.map((l) => '<div>' + l + '</div>').join('') + '</div>'));

    const acc = h('<div class="carpeta-acc" style="margin-top:10px"></div>');
    if (e.configurado) {
      const bBuscar = h('<button class="btn">Buscar ahora</button>');
      bBuscar.onclick = async () => {
        bBuscar.disabled = true;
        try { pintar(await api('POST', 'actualizacion/buscar', {})); pintarAvisoVersion(); }
        catch (err) { toast(err.message, true); bBuscar.disabled = false; }
      };
      acc.appendChild(bBuscar);
    }
    if (e.disponible) {
      const bInst = h(`<button class="btn btn-accent">Instalar la ${esc(e.disponible.version)}</button>`);
      bInst.onclick = () => instalarVersion(e.disponible.version);
      acc.appendChild(bInst);
    }
    // Sin internet o sin canal: el fichero «.actualizacion» que deja quien
    // publica. Pasa las mismas comprobaciones de firma que lo que llega solo.
    {
      const entrada = h('<input type="file" accept=".actualizacion" hidden>');
      const bFich = h('<button class="btn" title="Para un equipo sin internet: el fichero .actualizacion que te pasen">Actualizar desde un fichero…</button>');
      bFich.onclick = () => entrada.click();
      entrada.onchange = () => {
        const f = entrada.files[0];
        entrada.value = '';
        if (!f) return;
        const lector = new FileReader();
        lector.onerror = () => toast('No se pudo leer el fichero.', true);
        lector.onload = async () => {
          const contenidoBase64 = String(lector.result).split(',')[1] || '';
          let info;
          try { info = await api('POST', 'actualizacion/fichero', { contenidoBase64, comprobar: true }); }
          catch (err) { return toast(err.message, true); }
          if (info.descartada) return toast(`La versión ${info.version} se retiró en este equipo (no arrancó o se volvió atrás): no se instala.`, true);
          if (!info.nueva) return toast(`Ese fichero es la versión ${info.version} y ya tienes la ${info.actual}: no hace falta instalarlo.`);
          confirmar(`El fichero es la versión ${info.version} (firmada)${info.notas ? ': ' + info.notas : ''}. Se instalará en lugar de la ${info.actual}; el programa se reinicia en unos segundos y tus datos no se tocan. ¿Seguir?`, async () => {
            let r;
            try { r = await api('POST', 'actualizacion/fichero', { contenidoBase64 }); }
            catch (err) { return toast(err.message, true); }
            if (!r.instalada) return toast(r.mensaje || 'No había nada que instalar.');
            if (!r.reinicia) { toast(`Instalada la ${r.version}. Cierra el programa y vuelve a abrirlo con INICIAR.bat para usarla.`); return; }
            toast(`Instalada la ${r.version}. Reiniciando…`);
            await esperarVersion(r.version);
          });
        };
        lector.readAsDataURL(f);
      };
      acc.appendChild(entrada);
      acc.appendChild(bFich);
    }
    if (e.anteriores && e.anteriores.length) {
      const bVolver = h(`<button class="btn">Volver a la ${esc(e.anteriores[0])}</button>`);
      bVolver.onclick = () => confirmar(`Se volverá a la versión ${e.anteriores[0]} y la ${e.actual} no se volverá a instalar sola. Tus datos no se tocan. ¿Seguir?`, async () => {
        try {
          const r = await api('POST', 'actualizacion/volver', {});
          if (r.reinicia) { toast('Volviendo a la ' + r.a + '…'); await esperarVersion(r.a); }
          else toast('Hecho. Cierra el programa y vuelve a abrirlo con INICIAR.bat.');
        } catch (err) { toast(err.message, true); }
      });
      acc.appendChild(bVolver);
    }
    if (acc.children.length) cuerpo.appendChild(acc);

    if (e.historial && e.historial.length) {
      const lista = h('<div class="hint" style="margin-top:10px;display:grid;gap:2px"></div>');
      for (const x of e.historial.slice(0, 5)) lista.appendChild(h(`<div>${esc(cuando(x.fecha))} · ${esc(x.texto)}</div>`));
      cuerpo.appendChild(lista);
    }
  };
  get('actualizacion').then(pintar).catch((err) => { cuerpo.innerHTML = '<div class="hint">' + esc(err.message) + '</div>'; });
  return card;
}

function renderConfig() {
  const c = CACHE.config;
  view.innerHTML = '';
  view.appendChild(h('<h1>Configuración</h1>'));
  view.appendChild(h('<p class="sub">Dónde están las facturas en este ordenador y, si algún día existe, la conexión con el servidor de la oficina.</p>'));

  // La carpeta del archivo va primero y con comprobación: es lo único que hay
  // que acertar para que el programa abra los PDF en este ordenador.
  view.appendChild(tarjetaCarpetaArchivo(c));
  view.appendChild(tarjetaCarpetaTrabajo());
  view.appendChild(tarjetaVersion());

  const form = h('<div class="card" style="display:grid;gap:12px;max-width:640px"></div>');
  const f = (label, name, val, hint, type = 'text') => {
    const w = h(`<div class="field"><label>${esc(label)}</label><input type="${type}" data-name="${name}" value="${esc(val || '')}">${hint ? `<div class="hint">${esc(hint)}</div>` : ''}</div>`);
    return w;
  };
  form.appendChild(f('URL base de la API', 'apiBaseUrl', c.apiBaseUrl, 'Dirección del servidor de archivos de la oficina, que debe exponer GET /ficheros. NO es la dirección de este programa. Vacío = sincronización desactivada.'));
  // La clave solo vive en el .env. El campo se muestra para saber si esta
  // puesta, pero bloqueado: escribirla aqui la guardaria en data/db.json, que
  // es justo el fichero que se entrega al cliente dentro del paquete.
  const campoClave = f('API Key / Token', 'apiKey', c.apiKey,
    'Se escribe en el archivo .env (GF_API_KEY), nunca aquí. Se envía como cabecera Authorization: Bearer …', 'password');
  const inputClave = campoClave.querySelector('input');
  inputClave.readOnly = true;
  inputClave.style.background = '#f4f5f7';
  inputClave.placeholder = 'Sin definir — ponla en el archivo .env';
  form.appendChild(campoClave);
  form.appendChild(f('Ruta del servidor local', 'servidorLocal', c.servidorLocal, 'Ruta UNC de referencia, ej. \\\\SERVIDOR-OFICINA\\Asesoria'));
  form.appendChild(f('Carpeta de fichas', 'carpetaFichas', c.carpetaFichas, 'Subcarpeta donde están las fichas dentro del servidor. Déjalo vacío si no la usas.'));
  form.appendChild(f('Brand de inversión', 'brandInversion', c.brandInversion, 'Ej.: 4T-26'));
  form.appendChild(h(`<div class="field"><label>Gestión adicional (correo / anotación manuscrita)</label><textarea data-name="notas">${esc(c.notas || '')}</textarea></div>`));

  const bar = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const save = h('<button class="btn btn-accent">Guardar configuración</button>');
  const test = h('<button class="btn">Probar conexión</button>');
  const sync = h('<button class="btn">Sincronizar ahora</button>');
  bar.append(save, test, sync);
  form.appendChild(bar);
  view.appendChild(form);

  view.appendChild(h(`<div class="card" style="margin-top:16px;max-width:640px">
    <b>Contrato esperado de la API</b>
    <pre style="white-space:pre-wrap;font-size:12px;color:#444">GET {URL base}/ficheros
Authorization: Bearer {API Key}

respuesta: [
  { "nombre": "factura_2026_001.pdf", "tipo": "pdf",
    "sujetoNif": "B12345678", "contenidoBase64": "JVBERi0…", "tamano": 12345 }
]</pre>
    <div class="hint">Los ficheros con <code>sujetoNif</code> coincidente se asocian automáticamente al sujeto. Los repetidos no se duplican.</div>
  </div>`));

  // Campos que manda el .env: se muestran, no se editan y no se reenvian al guardar.
  const bloqueados = c._bloqueadosPorEnv || [];
  if (bloqueados.length) {
    form.querySelectorAll('[data-name]').forEach((i) => {
      if (!bloqueados.includes(i.dataset.name)) return;
      i.readOnly = true;
      i.style.background = '#f4f5f7';
      i.style.color = '#6b7280';
      const texto = 'Definido en el archivo .env. Para cambiarlo, edita .env y reinicia el programa.';
      const hint = i.parentElement.querySelector('.hint');
      if (hint) hint.textContent = texto;
      else i.parentElement.appendChild(h('<div class="hint"></div>')).textContent = texto;
    });
    view.insertBefore(h('<div class="card" style="max-width:640px;border-left:4px solid #f0904a"><b>Claves cargadas desde .env</b><div class="hint">Los campos marcados vienen del archivo <code>.env</code> que hay junto a <code>server.js</code>. Se editan ahi; aqui solo se muestran. La clave nunca se guarda en <code>data/db.json</code>.</div></div>'), form);
  }

  const read = () => {
    const o = {};
    form.querySelectorAll('[data-name]').forEach((i) => { if (!i.readOnly) o[i.dataset.name] = i.value; });
    return o;
  };
  const refrescarBotones = () => {
    const url = (form.querySelector('[data-name="apiBaseUrl"]') || {}).value || '';
    const sinApi = !url.trim();
    for (const b of [test, sync]) {
      b.disabled = sinApi;
      b.title = sinApi ? 'Primero pon la dirección del servidor de archivos de la oficina.' : '';
      b.style.opacity = sinApi ? 0.45 : 1;
      b.style.cursor = sinApi ? 'not-allowed' : 'pointer';
    }
    aviso.hidden = !sinApi;
  };
  const aviso = h('<div class="hint" style="margin-top:4px">Sin dirección de API, la sincronización está desactivada. El resto del programa funciona igual: el archivo de facturas se lee de la carpeta local.</div>');
  form.appendChild(aviso);
  const inputUrl = form.querySelector('[data-name="apiBaseUrl"]');
  if (inputUrl) inputUrl.addEventListener('input', refrescarBotones);
  refrescarBotones();

  save.onclick = async () => { CACHE.config = await api('PUT', 'config', read()); toast('Configuración guardada'); refrescarBotones(); };
  test.onclick = async () => {
    await api('PUT', 'config', read());
    try { const r = await api('POST', 'probar-conexion'); toast(r.ok ? 'Conexión OK (HTTP ' + r.status + ')' : 'Respuesta HTTP ' + r.status, !r.ok); }
    catch (e) { toast(e.message, true); }
  };
  sync.onclick = async () => { await api('PUT', 'config', read()); doSync(); };
}

// ---------------------------------------------------------------------------
// Sincronización
// ---------------------------------------------------------------------------
async function doSync() {
  const btn = document.getElementById('btn-sync');
  btn.disabled = true; btn.textContent = 'Sincronizando…';
  try {
    const r = await api('POST', 'sincronizar');
    toast(`Sincronizado: ${r.creados} documentos nuevos de ${r.recibidos} recibidos.`);
    await refreshCache();
    router();
  } catch (e) { toast(e.message, true); }
  finally { btn.disabled = false; btn.textContent = 'Sincronizar servidor local'; }
}

// ---------------------------------------------------------------------------
// Trazabilidad: el historial de todo lo que se ha movido
// ---------------------------------------------------------------------------
const TRAZA = { tipo: '', busca: '', desde: '', hasta: '', limite: 200 };

const TIPOS_MOV = {
  duplicado: 'Copia repetida', 'no-factura': 'No es factura', sentido: 'Emitida o gasto',
  periodo: 'Cambio de trimestre', clasificacion: 'Clasificación', correccion: 'Corrección a mano',
  importacion: 'Importación', borrado: 'Borrado', deshacer: 'Deshecho',
};

async function renderTrazabilidad() {
  const turno = ++NAV;
  view.innerHTML = '';
  view.appendChild(h('<h1>Trazabilidad</h1>'));
  view.appendChild(h('<p class="sub">Todo lo que ha cambiado en el archivo: qué documento, qué tenía antes, qué tiene ahora, quién lo hizo y por qué. Lo que se hizo en bloque se puede deshacer aquí.</p>'));

  const barra = h(`<div class="card traza-filtros">
    <label>Tipo <select></select></label>
    <label>Desde <input type="date"></label>
    <label>Hasta <input type="date"></label>
    <label class="crece">Buscar <input type="search" placeholder="documento, motivo…"></label>
  </div>`);
  const [sel, desde, hasta, busca] = barra.querySelectorAll('select, input');
  sel.appendChild(h('<option value="">Todos</option>'));
  for (const [v, l] of Object.entries(TIPOS_MOV)) sel.appendChild(h(`<option value="${v}">${esc(l)}</option>`));
  sel.value = TRAZA.tipo; desde.value = TRAZA.desde; hasta.value = TRAZA.hasta; busca.value = TRAZA.busca;
  const recargar = () => {
    TRAZA.tipo = sel.value; TRAZA.desde = desde.value; TRAZA.hasta = hasta.value; TRAZA.busca = busca.value.trim();
    renderTrazabilidad();
  };
  sel.onchange = desde.onchange = hasta.onchange = recargar;
  let t0; busca.oninput = () => { clearTimeout(t0); t0 = setTimeout(recargar, 350); };
  view.appendChild(barra);

  const q = new URLSearchParams();
  for (const k of ['tipo', 'desde', 'hasta', 'busca', 'limite']) if (TRAZA[k]) q.set(k, TRAZA[k]);
  let datos;
  try { datos = await get('movimientos?' + q); }
  catch (e) { if (turno === NAV) view.appendChild(h(`<div class="empty">No se pudo leer el historial: ${esc(e.message)}</div>`)); return; }
  if (turno !== NAV) return;

  if (!datos.total) {
    view.appendChild(h('<div class="vacio-exp">Todavía no hay movimientos registrados.</div>'));
    return;
  }

  const resumen = h(`<div class="exp-resumen"><span><b>${datos.total}</b> movimientos</span>
    <span>Mostrando ${datos.movimientos.length}</span></div>`);
  const bCSV = h('<button class="btn btn-sm">⬇ Descargar CSV</button>');
  bCSV.onclick = () => descargarCSV('trazabilidad.csv', [
    { label: 'Fecha', get: (m) => m.fecha.slice(0, 19).replace('T', ' ') },
    { label: 'Tipo', get: (m) => TIPOS_MOV[m.tipo] || m.tipo },
    { label: 'Origen', get: (m) => (m.automatico ? 'Automático (aprobado en bloque)' : 'Persona') },
    { label: 'Documento', get: (m) => m.nombre },
    { label: 'Carpeta', get: (m) => m.rutaRelativa },
    { label: 'Cambio', get: (m) => m.texto },
    { label: 'Motivo', get: (m) => m.motivo },
    { label: 'Deshecho', get: (m) => (m.deshecho ? 'sí' : '') },
  ], datos.movimientos);
  resumen.appendChild(bCSV);
  view.appendChild(resumen);

  const t = h(`<table class="doc-tabla traza"><thead><tr>
    <th>Cuándo</th><th>Qué</th><th>Documento</th><th>Cambio</th><th>Quién</th><th></th>
  </tr></thead><tbody></tbody></table>`);
  const tb = t.querySelector('tbody');
  for (const m of datos.movimientos) {
    const tr = h(`<tr${m.deshecho ? ' class="mov-deshecho"' : ''}>
      <td class="n">${esc(m.fecha.slice(0, 10).split('-').reverse().join('/'))}<div class="hint">${esc(m.fecha.slice(11, 16))}</div></td>
      <td class="n">${esc(TIPOS_MOV[m.tipo] || m.tipo)}</td>
      <td><div class="doc-nom">${esc(m.nombre)}</div><div class="hint">${esc(m.rutaRelativa || '')}</div></td>
      <td>${esc(m.texto)}${m.motivo ? `<div class="hint">${esc(m.motivo)}</div>` : ''}${m.deshecho ? '<div class="hint">deshecho</div>' : ''}</td>
      <td class="n">${m.automatico ? 'Automático' : 'Persona'}</td>
      <td><div class="acciones"></div></td>
    </tr>`);
    const acc = tr.querySelector('.acciones');
    if (m.documentoId) {
      const bv = h('<button class="btn btn-sm btn-accent">Ver</button>');
      bv.onclick = () => verDocumento(m.documentoId);
      acc.appendChild(bv);
    }
    if (m.reversible && !m.deshecho) {
      const bd = h('<button class="btn btn-sm">Deshacer</button>');
      bd.onclick = async () => {
        if (!confirm(`Se devolverá «${m.nombre}» a como estaba:\n${m.texto}\n\n¿Sigo?`)) return;
        bd.disabled = true;
        try {
          await api('POST', `movimientos/${m.id}/deshacer`);
          toast('Deshecho.');
          EXP_ARBOL = null; await refreshCache(); repintar('trazabilidad');
        } catch (e) { toast(e.message, true); bd.disabled = false; }
      };
      acc.appendChild(bd);
    }
    tb.appendChild(tr);
  }
  view.appendChild(t);
  if (datos.total > datos.movimientos.length) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${datos.total - datos.movimientos.length})</button>`);
    mas.onclick = () => { TRAZA.limite += 200; renderTrazabilidad(); };
    view.appendChild(mas);
  }
}

// ---------------------------------------------------------------------------
// Historial: todo lo que se ha hecho en el programa, desde el primer día
// ---------------------------------------------------------------------------
const HIST = { accion: '', busca: '', desde: '', hasta: '', limite: 200 };

const TIPOS_HIST = {
  programa: 'Programa', importar: 'Importar', ordenar: 'Ordenar carpeta', revisar: 'Revisar',
  exportar: 'Exportar', clientes: 'Clientes', facturas: 'Facturas', documentos: 'Documentos',
  informes: 'Informes', grupos: 'Grupos', configuracion: 'Configuración', actualizacion: 'Actualización', copia: 'Copia de seguridad',
};

async function renderHistorial() {
  const turno = ++NAV;
  view.innerHTML = '';
  view.appendChild(h('<h1>Historial</h1>'));
  view.appendChild(h('<p class="sub">Todo lo que se ha hecho en el programa desde el primer día: cuándo, en qué equipo y qué. Se guarda aparte de los datos, así que ni ordenar una carpeta nueva ni recuperar una copia lo borran.</p>'));

  const barra = h(`<div class="card traza-filtros">
    <label>Qué <select></select></label>
    <label>Desde <input type="date"></label>
    <label>Hasta <input type="date"></label>
    <label class="crece">Buscar <input type="search" placeholder="cliente, factura, carpeta…"></label>
  </div>`);
  const [sel, desde, hasta, busca] = barra.querySelectorAll('select, input');
  sel.appendChild(h('<option value="">Todo</option>'));
  for (const [v, l] of Object.entries(TIPOS_HIST)) sel.appendChild(h(`<option value="${v}">${esc(l)}</option>`));
  sel.value = HIST.accion; desde.value = HIST.desde; hasta.value = HIST.hasta; busca.value = HIST.busca;
  const recargar = () => {
    HIST.accion = sel.value; HIST.desde = desde.value; HIST.hasta = hasta.value; HIST.busca = busca.value.trim();
    renderHistorial();
  };
  sel.onchange = desde.onchange = hasta.onchange = recargar;
  let t0; busca.oninput = () => { clearTimeout(t0); t0 = setTimeout(recargar, 350); };
  view.appendChild(barra);

  const q = new URLSearchParams();
  for (const k of ['accion', 'busca', 'limite']) if (HIST[k]) q.set(k, HIST[k]);
  if (HIST.desde) q.set('desde', new Date(HIST.desde + 'T00:00:00').toISOString());
  if (HIST.hasta) q.set('hasta', new Date(HIST.hasta + 'T23:59:59.999').toISOString());
  let datos;
  try { datos = await get('historial?' + q); }
  catch (e) { if (turno === NAV) view.appendChild(h(`<div class="empty">No se pudo leer el historial: ${esc(e.message)}</div>`)); return; }
  if (turno !== NAV) return;

  if (!datos.total) {
    view.appendChild(h(`<div class="vacio-exp">${HIST.accion || HIST.busca || HIST.desde || HIST.hasta ? 'Nada con estos filtros.' : 'Todavía no se ha hecho nada en el programa.'}</div>`));
    return;
  }

  const resumen = h(`<div class="exp-resumen"><span><b>${datos.total}</b> ${datos.total === 1 ? 'acción' : 'acciones'}</span>
    <span>Mostrando ${datos.entradas.length}</span></div>`);
  const bCSV = h('<button class="btn btn-sm">⬇ Descargar CSV</button>');
  bCSV.onclick = () => descargarCSV('historial.csv', [
    { label: 'Fecha', get: (e) => e.fecha.slice(0, 19).replace('T', ' ') },
    { label: 'Qué', get: (e) => TIPOS_HIST[e.accion] || e.accion },
    { label: 'Equipo', get: (e) => e.equipo || '' },
    { label: 'Detalle', get: (e) => e.texto },
  ], datos.entradas);
  resumen.appendChild(bCSV);
  view.appendChild(resumen);

  const t = h(`<table class="doc-tabla traza"><thead><tr>
    <th>Cuándo</th><th>Qué</th><th>Detalle</th><th>Equipo</th>
  </tr></thead><tbody></tbody></table>`);
  const tb = t.querySelector('tbody');
  for (const e of datos.entradas) {
    const local = new Date(e.fecha);
    const dia = isNaN(local) ? e.fecha.slice(0, 10) : local.toLocaleDateString('es-ES');
    const hora = isNaN(local) ? e.fecha.slice(11, 16) : local.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    tb.appendChild(h(`<tr>
      <td class="n">${esc(dia)}<div class="hint">${esc(hora)}</div></td>
      <td class="n">${esc(TIPOS_HIST[e.accion] || e.accion)}</td>
      <td>${esc(e.texto)}</td>
      <td class="n">${esc(e.equipo || '')}</td>
    </tr>`));
  }
  view.appendChild(t);
  if (datos.total > datos.entradas.length && HIST.limite >= 5000) {
    view.appendChild(h(`<div class="hint" style="margin-top:10px">Se enseñan las 5.000 más recientes de ${datos.total}: usa las fechas o «Buscar» para ver las demás.</div>`));
  } else if (datos.total > datos.entradas.length) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${datos.total - datos.entradas.length})</button>`);
    mas.onclick = () => { HIST.limite = Math.min(5000, HIST.limite + 200); renderHistorial(); };
    view.appendChild(mas);
  }
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
const ROUTES = {
  panel: renderPanel, archivo: renderArchivo, importar: renderImportar, revisar: renderRevisar,
  trazabilidad: renderTrazabilidad, historial: renderHistorial,
  grupos: renderGrupos, sujetos: renderSujetos, facturas: renderFacturas, documentos: renderDocumentos,
  informes: renderInformes, mapa: renderMapa, config: renderConfig,
};
let current = 'panel';

async function reload(col) {
  if (col) CACHE[col] = await get(col);
  if (col === 'facturas') { CACHE.facturaDeDoc = new Map(CACHE.facturas.filter((f) => f.documentoId).map((f) => [f.documentoId, f])); CACHE.facturasDeDoc = agruparPorDoc(CACHE.facturas); }
  if (col === 'documentos') EXP_ARBOL = null;
  CACHE.st = await get('stats');
  pintarCabecera();
  router();
}
// Cada vez que se pinta una pantalla sube NAV. Las pantallas que esperan datos
// a mitad de pintarse guardan su turno y, al volver, si ya se ha pintado otra
// cosa, no tocan nada: antes, aprobar un bloque y cambiar de pestaña enseguida
// hacía que «Revisar» se pintara encima de la pestaña nueva.
let NAV = 0;
function router() { NAV++; (ROUTES[current] || renderPanel)(); }
// Tras guardar algo se vuelve a pintar, pero solo si se sigue en esa pantalla.
function repintar(tab) { if (current === tab) router(); }

document.getElementById('tabs').addEventListener('click', async (e) => {
  const b = e.target.closest('button[data-tab]');
  if (!b) return;
  document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('active', x === b));
  current = b.dataset.tab;
  if (location.hash.slice(1) !== current) history.pushState(null, '', '#' + current);
  // Al volver a Inicio o a Revisar se refrescan los datos: otra ventana puede
  // haber importado o corregido algo mientras tanto.
  if (current === 'panel' || current === 'revisar') {
    try { await refreshCache(); EXP_ARBOL = null; } catch { /* se pinta con lo que hay */ }
  }
  if (current === 'importar') IMP.cargado = IMP.filas.length > 0;
  router();
});

// Cambiar la dirección a mano (o el botón "atrás") también cambia de pestaña.
window.addEventListener('hashchange', () => {
  const pedida = location.hash.slice(1);
  if (ROUTES[pedida] && pedida !== current) {
    const b = document.querySelector(`#tabs button[data-tab="${pedida}"]`);
    if (b) b.click();
  }
});

// Avisar antes de cerrar si hay una importación a medias.
window.addEventListener('beforeunload', (e) => {
  if (IMP.ocupado) { e.preventDefault(); e.returnValue = ''; }
});
document.getElementById('btn-sync').onclick = doSync;

(async function init() {
  try {
    await refreshCache();
    // La pestaña puede venir en la dirección: http://localhost:4360/#importar
    const pedida = location.hash.slice(1);
    if (ROUTES[pedida]) {
      current = pedida;
      document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('active', x.dataset.tab === pedida));
    }
    router();
    pintarAvisoArchivo(); // si falta la carpeta de las facturas, que se vea ya
    pintarAvisoVersion();
    setInterval(pintarAvisoVersion, 30 * 60 * 1000);
  } catch (e) { view.innerHTML = '<div class="empty">No se pudo cargar: ' + esc(e.message) + '</div>'; }
})();
