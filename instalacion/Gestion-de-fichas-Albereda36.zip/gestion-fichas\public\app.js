'use strict';

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
async function api(method, path, body) {
  const opt = { method, headers: {} };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch('/api/' + path, opt);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || ('Error ' + r.status));
  return data;
}
const get = (p) => api('GET', p);

function toast(msg, isErr) {
  const box = document.getElementById('toast');
  const t = document.createElement('div');
  t.className = 'toast-item' + (isErr ? ' err' : '');
  t.textContent = msg;
  box.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

// Crea un elemento a partir de HTML. Se usa <template> y no <div>: dentro de
// un <div> el navegador descarta las etiquetas <tr>, <td> y <thead> sueltas, y
// las tablas se quedaban vacías.
function h(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const eur = (n) => (Number(n) || 0).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
const fdate = (s) => s ? new Date(s).toLocaleDateString('es-ES') : '—';

// ---------------------------------------------------------------------------
// Modal genérico basado en especificación de campos
// ---------------------------------------------------------------------------
function openModal({ title, fields, values = {}, onSave, saveLabel = 'Guardar' }) {
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg"></div>');
  const modal = h(`<div class="modal"><header><strong>${esc(title)}</strong><button class="btn-ghost" data-x>✕</button></header><div class="body"></div><footer><button class="btn" data-cancel>Cancelar</button><button class="btn btn-accent" data-save>${esc(saveLabel)}</button></footer></div>`);
  const body = modal.querySelector('.body');

  for (const f of fields) {
    if (f.type === 'group2') { // dos campos en fila
      const wrap = h('<div class="grid-2"></div>');
      f.fields.forEach((sf) => wrap.appendChild(fieldNode(sf, values[sf.name])));
      body.appendChild(wrap);
    } else {
      body.appendChild(fieldNode(f, values[f.name]));
    }
  }

  function fieldNode(f, val) {
    const wrap = h('<div class="field"></div>');
    wrap.appendChild(h(`<label>${esc(f.label)}${f.required ? ' *' : ''}</label>`));
    let input;
    if (f.type === 'textarea') {
      input = h('<textarea></textarea>'); input.value = val || '';
    } else if (f.type === 'select') {
      input = h('<select></select>');
      (f.options || []).forEach((o) => {
        const op = h(`<option value="${esc(o.value)}">${esc(o.label)}</option>`);
        if (String(o.value) === String(val ?? f.default ?? '')) op.selected = true;
        input.appendChild(op);
      });
    } else if (f.type === 'checks') {
      input = h('<div class="checks"></div>');
      const sel = new Set(Array.isArray(val) ? val.map(String) : []);
      (f.options || []).forEach((o) => {
        const lb = h(`<label><input type="checkbox" value="${esc(o.value)}"> ${esc(o.label)}</label>`);
        if (sel.has(String(o.value))) lb.querySelector('input').checked = true;
        input.appendChild(lb);
      });
    } else if (f.type === 'subfields') {
      input = buildSubfields(val || []);
    } else if (f.type === 'file') {
      input = h('<input type="file">');
    } else {
      input = h(`<input type="${f.type || 'text'}">`);
      if (val != null) input.value = val;
      if (f.step) input.step = f.step;
    }
    input.dataset.name = f.name;
    input._spec = f;
    wrap.appendChild(input);
    if (f.hint) wrap.appendChild(h(`<div class="hint">${esc(f.hint)}</div>`));
    return wrap;
  }

  function buildSubfields(rows) {
    const box = h('<div class="subfields"></div>');
    const list = h('<div class="sf-list"></div>');
    const add = (r = {}) => list.appendChild(h(
      `<div class="subfield-row"><input placeholder="clave" value="${esc(r.key || '')}" data-k><input placeholder="etiqueta visible" value="${esc(r.label || '')}" data-l><button type="button" class="btn btn-sm btn-danger" data-del>✕</button></div>`));
    (rows || []).forEach(add);
    box.appendChild(list);
    const btn = h('<button type="button" class="btn btn-sm">+ Campo personalizado</button>');
    btn.onclick = () => add();
    list.addEventListener('click', (e) => { if (e.target.dataset.del !== undefined) e.target.closest('.subfield-row').remove(); });
    box.appendChild(btn);
    box._read = () => [...list.querySelectorAll('.subfield-row')].map((row) => ({
      key: row.querySelector('[data-k]').value.trim(),
      label: row.querySelector('[data-l]').value.trim() || row.querySelector('[data-k]').value.trim(),
      type: 'text',
    })).filter((x) => x.key);
    return box;
  }

  function collect() {
    const out = {};
    body.querySelectorAll('[data-name]').forEach((input) => {
      const f = input._spec;
      if (f.type === 'checks') out[f.name] = [...input.querySelectorAll('input:checked')].map((i) => i.value);
      else if (f.type === 'subfields') out[f.name] = input._read();
      else if (f.type === 'number') out[f.name] = input.value === '' ? null : Number(input.value);
      else if (f.type === 'file') out[f.name] = input.files[0] || null;
      else out[f.name] = input.value;
    });
    return out;
  }

  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  modal.querySelector('[data-x]').onclick = close;
  modal.querySelector('[data-cancel]').onclick = close;
  bg.onclick = (e) => { if (e.target === bg) close(); };
  modal.querySelector('[data-save]').onclick = async () => {
    try { await onSave(collect(), close); } catch (err) { toast(err.message, true); }
  };

  bg.appendChild(modal);
  root.appendChild(bg);
  const first = body.querySelector('input, select, textarea');
  if (first) first.focus();
}

function confirmar(msg, fn) {
  openModal({
    title: 'Confirmar', saveLabel: 'Sí, continuar',
    fields: [{ name: '_', type: 'textarea', label: msg }],
    values: {}, onSave: async (_v, close) => { close(); await fn(); },
  });
  // reemplaza el textarea por texto plano
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (ta) { const p = h(`<p>${esc(msg)}</p>`); ta.replaceWith(p); }
}

// ---------------------------------------------------------------------------
// Vistas
// ---------------------------------------------------------------------------
const view = document.getElementById('view');
let CACHE = {};

async function refreshCache() {
  const [grupos, sujetos, facturas, documentos, informes, config, st] = await Promise.all([
    get('grupos'), get('sujetos'), get('facturas'), get('documentos'), get('informes'), get('config'), get('stats'),
  ]);
  CACHE = { grupos, sujetos, facturas, documentos, informes, config, st };
  CACHE.facturaDeDoc = new Map(facturas.filter((f) => f.documentoId).map((f) => [f.documentoId, f]));
  pintarCabecera();
}

// Contadores de las pestañas y el botón de sincronizar (solo si hay API).
function pintarCabecera() {
  const st = CACHE.st || {};
  const badge = (id, n) => { const b = document.getElementById(id); if (!b) return; b.hidden = !n; b.textContent = n > 999 ? '999+' : n; };
  badge('badge-importar', st.importacionesEnEspera || 0);
  badge('badge-revisar', (st.avisosPendientes || 0) + (st.importePorConfirmar || 0));
  const marca = document.querySelector('.brand small');
  if (marca && st.version) marca.textContent = 'Asesoría Albereda 36, S.L. · versión ' + st.version;
  const sync = document.getElementById('sync-state');
  const btn = document.getElementById('btn-sync');
  sync.hidden = btn.hidden = !st.apiConfigurada;
  sync.textContent = st.sincronizado ? 'Sincronizado ' + new Date(st.sincronizado).toLocaleString('es-ES') : 'Sin sincronizar';
}

const nombreGrupo = (id) => (CACHE.grupos.find((g) => g.id === id) || {}).nombre || '—';
const nombreSujeto = (id) => (CACHE.sujetos.find((s) => s.id === id) || {}).nombre || '(sin cliente)';

// ---- Datos comunes de archivo -------------------------------------------
const TRIMS = ['1T', '2T', '3T', '4T'];
const TIPOS_DOC = [
  { v: 'emitida', l: 'Emitida (ingreso)' },
  { v: 'recibida', l: 'Recibida (gasto)' },
  { v: 'otro', l: 'Otro documento' },
];
const clientesArchivo = () => CACHE.sujetos.map((s) => ({ id: s.id, alias: s.aliasArchivo || s.nombre, nombre: s.nombre }));
const aliasDeId = (id) => (clientesArchivo().find((c) => c.id === id) || {}).alias || '';
const opciones = (lista, sel, vacio) =>
  (vacio !== undefined ? `<option value="">${esc(vacio)}</option>` : '') +
  lista.map((o) => `<option value="${esc(o.v)}"${String(o.v) === String(sel ?? '') ? ' selected' : ''}>${esc(o.l)}</option>`).join('');
const num = (v) => (v === '' || v == null || Number.isNaN(Number(v)) ? null : Number(v));
const cuadra = (b, iva, irpf, t) => Math.abs(b * (1 + (iva - (irpf || 0)) / 100) - t) <= Math.max(0.05, t * 0.001);

// Avisos de un documento, en lenguaje de despacho.
function avisosDoc(d) {
  if (d.revisado) return [];
  const out = [];
  if (d.duplicadoDe) out.push({ cod: 'duplicado', corto: 'duplicado', texto: 'Es una copia idéntica de ' + d.duplicadoDe, cls: 'aviso-dup' });
  if (d.revisionManual) out.push({ cod: 'revisar', corto: 'revisar', texto: 'No se pudo saber el tipo o el trimestre.' });
  for (const parte of String(d.incidencias || '').split(/;\s*|\s\|\s/)) {
    const [codigo, ...resto] = parte.split(':');
    const det = resto.join(':').trim();
    if (codigo === 'trimestre_discrepante') {
      const m = det.match(/carpeta=(\S+)\s+fecha=(\S+)/);
      out.push({ cod: 'periodo', corto: 'trimestre dudoso', texto: m ? `La fecha del nombre es del ${m[2]} y está en la carpeta del ${m[1]}.` : 'La fecha no cuadra con la carpeta.' });
    } else if (codigo === 'ejercicio_discrepante') {
      const m = det.match(/carpeta=(\S+)\s+fecha=(\S+)/);
      out.push({ cod: 'periodo', corto: 'año dudoso', texto: m ? `La fecha es de ${m[2]} y está en la carpeta de ${m[1]}.` : 'El año no cuadra con la carpeta.' });
    } else if (codigo === 'trimestre_discrepante_pdf') {
      out.push({ cod: 'periodo', corto: 'trimestre dudoso', texto: det.charAt(0).toUpperCase() + det.slice(1) + '.' });
    } else if (codigo === 'sentido_dudoso') {
      out.push({ cod: 'sentido', corto: '¿emitida?', texto: 'Tiene la numeración propia del cliente pero está archivada como gasto.' });
    } else if (codigo === 'no_es_factura') {
      out.push({ cod: 'no-factura', corto: 'no es factura', texto: 'Es un justificante de pago, no una factura: no sirve para deducir IVA.' });
    }
  }
  return out;
}

function descripcionDoc(d) {
  const tipo = { emitida: 'emitida', recibida: 'recibida', 'no-factura': 'otro' }[d.sentido] || '—';
  return `${esc(d.cliente || '—')} · ${esc(d.ejercicio || '—')} ${esc(d.trimestre || '')} · ${tipo}`;
}

// ---- Panel ----------------------------------------------------------------
function irA(tab, pre) {
  if (pre) pre();
  const b = document.querySelector(`#tabs button[data-tab="${tab}"]`);
  if (b) b.click();
}

function renderPanel() {
  const s = CACHE.st;
  view.innerHTML = '';
  view.appendChild(h('<h1>Inicio</h1>'));
  view.appendChild(h('<p class="sub">El despacho de un vistazo. Los datos no salen de este ordenador.</p>'));

  // --- Qué hay pendiente hoy ---
  const tareas = [];
  if (s.importacionesEnEspera) tareas.push({ n: s.importacionesEnEspera, t: 'facturas analizadas esperando a que las confirmes', tab: 'importar', b: 'Terminar importación' });
  if (s.avisosPendientes) tareas.push({ n: s.avisosPendientes, t: 'documentos con algo que revisar (duplicados, trimestre dudoso…)', tab: 'revisar', b: 'Revisar', pre: () => { REV.vista = 'clasificacion'; } });
  if (s.importePorConfirmar) tareas.push({ n: s.importePorConfirmar, t: 'importes leídos de los PDF pendientes de confirmar', tab: 'revisar', b: 'Confirmar importes', pre: () => { REV.vista = 'importes'; REV.filtroImp = 'pdf'; } });
  if (s.sinImporte) tareas.push({ n: s.sinImporte, t: 'facturas sin importe (escaneos o PDF sin datos legibles)', tab: 'revisar', b: 'Completar', pre: () => { REV.vista = 'importes'; REV.filtroImp = 'sin'; } });
  const caja = h('<div class="tareas"></div>');
  if (!tareas.length) caja.appendChild(h('<div class="tarea ok"><b>✓ Todo al día.</b><span>No hay nada pendiente de revisar.</span></div>'));
  for (const t of tareas) {
    const fila = h(`<div class="tarea"><b>${t.n.toLocaleString('es-ES')}</b><span>${esc(t.t)}</span></div>`);
    const b = h(`<button class="btn btn-sm btn-accent">${esc(t.b)} →</button>`);
    b.onclick = () => irA(t.tab, t.pre);
    fila.appendChild(b);
    caja.appendChild(fila);
  }
  view.appendChild(h('<h2 class="h2">Pendiente</h2>'));
  view.appendChild(caja);

  view.appendChild(h('<h2 class="h2">Cifras</h2>'));
  view.appendChild(h(`<div class="cards">
    <div class="card"><div class="n">${s.documentos.toLocaleString('es-ES')}</div><div class="l">Documentos en el archivo</div></div>
    <div class="card"><div class="n">${s.facturas.toLocaleString('es-ES')}</div><div class="l">Facturas</div></div>
    <div class="card"><div class="n">${s.sujetos}</div><div class="l">Clientes</div></div>
    <div class="card"><div class="n">${eur(s.totalFacturado)}</div><div class="l">Facturado (emitidas con importe)</div></div>
    <div class="card"><div class="n">${eur(s.totalGastos)}</div><div class="l">Gastos (recibidas con importe)</div></div>
    <div class="card"><div class="n">${eur(s.pendienteCobro)}</div><div class="l">Pendiente de cobro</div></div>
  </div>`));
  if (s.sinImporte || s.importePorConfirmar) {
    view.appendChild(h(`<p class="hint">Las cifras solo suman las facturas que tienen importe. ${s.sinImporte ? `Faltan ${s.sinImporte.toLocaleString('es-ES')} por completar. ` : ''}${s.importePorConfirmar ? `${s.importePorConfirmar.toLocaleString('es-ES')} son lecturas automáticas aún sin confirmar.` : ''}</p>`));
  }

  view.appendChild(h('<h2 class="h2">Cómo se trabaja</h2>'));
  view.appendChild(h(`<div class="steps">
    <div class="step"><b>1 · Entran facturas nuevas</b><small>En <b>📥 Importar</b>, arrastra los PDF. El programa propone cliente, trimestre, tipo e importes, y avisa si alguna ya estaba o repite número.</small></div>
    <div class="step"><b>2 · Se revisa lo dudoso</b><small>En <b>⚠ Revisar</b> están los duplicados, las facturas en un trimestre que no les toca y los importes por confirmar.</small></div>
    <div class="step"><b>3 · Se consulta y se presenta</b><small>En <b>📁 Archivo</b> se busca cualquier documento; en <b>Facturas</b> y <b>Informes</b> se sacan los listados para Excel.</small></div>
  </div>`));
}

// ---- Tabla genérica ------------------------------------------------------
// CSV para Excel en español: BOM + punto y coma + decimales con coma.
function descargarCSV(nombre, columnas, filas) {
  const celda = (v) => {
    if (typeof v === 'number') v = String(v).replace('.', ',');
    return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  };
  const txt = '﻿' + [columnas.map((c) => celda(c.label)).join(';'),
    ...filas.map((r) => columnas.map((c) => celda(c.csv ? c.csv(r) : c.get(r))).join(';'))].join('\r\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([txt], { type: 'text/csv;charset=utf-8' }));
  a.download = nombre;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
}

function tableView({ title, sub, columns, rows, onNew, newLabel, filters, exportName, limite }) {
  view.innerHTML = '';
  view.appendChild(h(`<h1>${esc(title)}</h1>`));
  if (sub) view.appendChild(h(`<p class="sub">${esc(sub)}</p>`));

  const bar = h('<div class="toolbar"></div>');
  const left = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const search = h('<input type="search" placeholder="Buscar…">');
  left.appendChild(search);
  (filters || []).forEach((f) => left.appendChild(f.el));
  bar.appendChild(left);
  const derecha = h('<div style="display:flex;gap:8px"></div>');
  let actual = [];
  if (exportName) {
    const x = h('<button class="btn">⬇ Excel (lo filtrado)</button>');
    x.onclick = () => descargarCSV(exportName, columns, actual);
    derecha.appendChild(x);
  }
  if (onNew) { const b = h(`<button class="btn btn-accent">+ ${esc(newLabel)}</button>`); b.onclick = onNew; derecha.appendChild(b); }
  bar.appendChild(derecha);
  view.appendChild(bar);

  const resumen = h('<div class="exp-resumen"></div>');
  view.appendChild(resumen);
  const host = h('<div></div>');
  view.appendChild(host);
  let mostrar = limite || Infinity;

  function draw() {
    const q = search.value.toLowerCase().trim();
    let list = rows();
    (filters || []).forEach((f) => { list = f.apply(list); });
    if (q) list = list.filter((r) => columns.some((c) => String(c.get(r) ?? '').toLowerCase().includes(q)));
    actual = list;
    resumen.innerHTML = `<span><b>${list.length.toLocaleString('es-ES')}</b> registros</span>` +
      columns.filter((c) => c.sumar).map((c) => `<span>${esc(c.label)}: <b>${eur(list.reduce((a, r) => a + (Number(c.get(r)) || 0), 0))}</b></span>`).join('');
    if (!list.length) { host.innerHTML = ''; host.appendChild(h('<div class="empty">Sin registros.</div>')); return; }
    const t = h('<table></table>');
    t.appendChild(h('<thead><tr>' + columns.map((c) => `<th>${esc(c.label)}</th>`).join('') + '<th></th></tr></thead>'));
    const tb = h('<tbody></tbody>');
    list.slice(0, mostrar).forEach((r) => {
      const tr = h('<tr></tr>');
      columns.forEach((c) => { const td = h('<td></td>'); td.innerHTML = c.render ? c.render(r) : esc(c.get(r)); tr.appendChild(td); });
      const act = h('<td><div class="row-actions"></div></td>');
      const ra = act.querySelector('.row-actions');
      (r._actions || []).forEach((a) => { const b = h(`<button class="btn btn-sm ${a.cls || ''}">${esc(a.label)}</button>`); b.onclick = a.fn; ra.appendChild(b); });
      tr.appendChild(act);
      tb.appendChild(tr);
    });
    t.appendChild(tb);
    host.innerHTML = ''; host.appendChild(t);
    if (list.length > mostrar) {
      const mas = h(`<button class="btn" style="margin-top:10px">Mostrar ${Math.min(200, list.length - mostrar)} más (quedan ${list.length - mostrar})</button>`);
      mas.onclick = () => { mostrar += 200; draw(); };
      host.appendChild(mas);
    }
  }
  search.oninput = () => { mostrar = limite || Infinity; draw(); };
  (filters || []).forEach((f) => f.el.onchange = () => { mostrar = limite || Infinity; draw(); });
  draw();
}

// ---- Grupos -------------------------------------------------------------
function renderGrupos() {
  const rows = () => CACHE.grupos.map((g) => ({
    ...g,
    _actions: [
      { label: 'Editar', fn: () => formGrupo(g) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar el grupo "${g.nombre}"? Los sujetos quedarán sin grupo.`, async () => { await api('DELETE', 'grupos/' + g.id); await reload('grupos'); }) },
    ],
  }));
  tableView({
    title: 'Grupos', sub: 'Archivo de sujetos. Cada grupo puede tener campos personalizados que se usan al crear sujetos.',
    newLabel: 'Nuevo grupo', onNew: () => formGrupo(),
    columns: [
      { label: 'Nombre', get: (r) => r.nombre },
      { label: 'Descripción', get: (r) => r.descripcion },
      { label: 'Campos personalizados', get: (r) => (r.campos || []).map((c) => c.label).join(', ') || '—' },
      { label: 'Sujetos', get: (r) => CACHE.sujetos.filter((s) => s.grupoId === r.id).length },
    ],
    rows,
  });
}
function formGrupo(g) {
  openModal({
    title: g ? 'Editar grupo' : 'Nuevo grupo',
    fields: [
      { name: 'nombre', label: 'Nombre del grupo', required: true },
      { name: 'descripcion', label: 'Descripción', type: 'textarea' },
      { name: 'campos', label: 'Campos personalizados del grupo', type: 'subfields', hint: 'Se mostrarán como campos extra al dar de alta un sujeto de este grupo.' },
    ],
    values: g || {},
    onSave: async (v, close) => {
      if (!v.nombre) throw new Error('El nombre es obligatorio.');
      if (g) await api('PUT', 'grupos/' + g.id, v); else await api('POST', 'grupos', v);
      close(); toast('Grupo guardado'); await reload('grupos');
    },
  });
}

// ---- Sujetos ----------------------------------------------------------
function renderSujetos() {
  const sel = h('<select><option value="">Todos los grupos</option>' + CACHE.grupos.map((g) => `<option value="${g.id}">${esc(g.nombre)}</option>`).join('') + '</select>');
  const filtroGrupo = { el: sel, apply: (list) => sel.value ? list.filter((r) => r.grupoId === sel.value) : list };

  const rows = () => CACHE.sujetos.map((s) => ({
    ...s,
    _actions: [
      { label: 'Editar', fn: () => formSujeto(s) },
      { label: 'Ficha', fn: () => fichaSujeto(s) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar a "${s.nombre}" y sus facturas asociadas?`, async () => { await api('DELETE', 'sujetos/' + s.id); await reload('sujetos'); }) },
    ],
  }));
  tableView({
    title: 'Clientes', sub: 'Las fichas de los clientes del despacho. El NIF sirve para reconocer sus facturas al importarlas.',
    newLabel: 'Nuevo cliente', onNew: () => formSujeto(),
    filters: [filtroGrupo],
    columns: [
      { label: 'Nombre', get: (r) => r.nombre },
      { label: 'NIF', get: (r) => r.nif },
      { label: 'Grupo', get: (r) => nombreGrupo(r.grupoId), render: (r) => `<span class="tag">${esc(nombreGrupo(r.grupoId))}</span>` },
      { label: 'Email', get: (r) => r.email },
      { label: 'Teléfono', get: (r) => r.telefono },
      { label: 'Facturado', get: (r) => CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'emitida').reduce((a, f) => a + (f.total || 0), 0), render: (r) => eur(CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'emitida').reduce((a, f) => a + (f.total || 0), 0)) },
      { label: 'Gastos', get: (r) => CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'recibida').reduce((a, f) => a + (f.total || 0), 0), render: (r) => eur(CACHE.facturas.filter((f) => f.sujetoId === r.id && f.sentido === 'recibida').reduce((a, f) => a + (f.total || 0), 0)) },
    ],
    rows,
  });
}
function formSujeto(s) {
  const grupoOpts = CACHE.grupos.map((g) => ({ value: g.id, label: g.nombre }));
  const build = (grupoId) => {
    const grupo = CACHE.grupos.find((g) => g.id === grupoId) || CACHE.grupos[0];
    const extra = (grupo && grupo.campos || []).map((c) => ({ name: 'datos.' + c.key, label: c.label + ' (grupo ' + grupo.nombre + ')' }));
    const flat = {};
    Object.assign(flat, s || {});
    if (s && s.datos) for (const k in s.datos) flat['datos.' + k] = s.datos[k];
    if (!flat.grupoId && grupo) flat.grupoId = grupo.id;
    openModal({
      title: s ? 'Editar sujeto' : 'Nuevo sujeto',
      fields: [
        { name: 'grupoId', label: 'Grupo', type: 'select', options: grupoOpts, hint: 'Cambia el grupo y vuelve a abrir para ver sus campos personalizados.' },
        { name: 'nombre', label: 'Nombre / Razón social', required: true },
        { type: 'group2', fields: [{ name: 'nif', label: 'NIF / DNI' }, { name: 'telefono', label: 'Teléfono' }] },
        { name: 'email', label: 'Email', type: 'email' },
        { name: 'direccion', label: 'Dirección' },
        ...extra,
        { name: 'notas', label: 'Notas / anotación manuscrita', type: 'textarea' },
      ],
      values: flat,
      onSave: async (v, close) => {
        const datos = {};
        for (const k in v) if (k.startsWith('datos.')) { datos[k.slice(6)] = v[k]; delete v[k]; }
        v.datos = datos;
        if (!v.nombre) throw new Error('El nombre es obligatorio.');
        if (s) await api('PUT', 'sujetos/' + s.id, v); else await api('POST', 'sujetos', v);
        close(); toast('Sujeto guardado'); await reload('sujetos');
      },
    });
  };
  build(s ? s.grupoId : (CACHE.grupos[0] || {}).id);
}
function fichaSujeto(s) {
  const facturas = CACHE.facturas.filter((f) => f.sujetoId === s.id);
  const docs = CACHE.documentos.filter((d) => d.sujetoId === s.id);
  const datosExtra = Object.entries(s.datos || {}).map(([k, v]) => `<div><b>${esc(k)}:</b> ${esc(v)}</div>`).join('') || '<span class="hint">Sin campos personalizados.</span>';
  openModal({
    title: 'Ficha · ' + s.nombre, saveLabel: 'Cerrar',
    fields: [{ name: '_', type: 'textarea', label: '' }],
    values: {}, onSave: (_v, close) => close(),
  });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (ta) ta.replaceWith(h(`<div>
    <p><b>NIF:</b> ${esc(s.nif) || '—'} &nbsp; <b>Grupo:</b> ${esc(nombreGrupo(s.grupoId))}</p>
    <p><b>Email:</b> ${esc(s.email) || '—'} &nbsp; <b>Tel:</b> ${esc(s.telefono) || '—'}</p>
    <p><b>Dirección:</b> ${esc(s.direccion) || '—'}</p>
    <h4>Campos del grupo</h4>${datosExtra}
    <h4>Facturas (${facturas.length})</h4>${facturas.map((f) => `<div>${esc(f.numero)} · ${fdate(f.fecha)} · ${eur(f.total)} · ${esc(f.estado)}</div>`).join('') || '<span class="hint">Sin facturas.</span>'}
    <h4>Documentos (${docs.length})</h4>${docs.map((d) => `<div>${esc(d.nombre)} <span class="hint">(${esc(d.origen)})</span></div>`).join('') || '<span class="hint">Sin documentos.</span>'}
    <h4>Notas</h4><div>${esc(s.notas) || '<span class="hint">—</span>'}</div>
  </div>`));
}

// ---- Facturas -------------------------------------------------------
function estadoImporte(f) {
  if (!(f.total > 0)) return { cls: 'vencida', t: 'sin importe' };
  if (f.importeOrigen === 'pdf' && !f.importeConfirmado) return { cls: 'pendiente', t: 'leído, sin confirmar' };
  return { cls: 'pagada', t: 'confirmado' };
}

function renderFacturas() {
  const selTipo = h('<select><option value="">Emitidas y recibidas</option><option value="emitida">Emitidas (ingresos)</option><option value="recibida">Recibidas (gastos)</option></select>');
  const selCli = h('<select><option value="">Todos los clientes</option>' + CACHE.sujetos.map((s) => `<option value="${s.id}">${esc(s.aliasArchivo || s.nombre)}</option>`).join('') + '</select>');
  const anios = [...new Set(CACHE.facturas.map((f) => f.ejercicio || (f.fecha || '').slice(0, 4)).filter(Boolean))].sort().reverse();
  const selAnio = h('<select><option value="">Todos los años</option>' + anios.map((a) => `<option>${a}</option>`).join('') + '</select>');
  const selTri = h('<select><option value="">Todos los trimestres</option>' + TRIMS.map((t) => `<option>${t}</option>`).join('') + '</select>');
  const selImp = h('<select><option value="">Cualquier importe</option><option value="confirmado">Importe confirmado</option><option value="pdf">Leído, sin confirmar</option><option value="sin">Sin importe</option></select>');
  const periodo = (f) => ({ anio: String(f.ejercicio || (f.fecha || '').slice(0, 4)), tri: f.trimestre || (f.fecha ? Math.floor((Number(f.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T' : '') });
  const filtros = [
    { el: selTipo, apply: (l) => selTipo.value ? l.filter((r) => r.sentido === selTipo.value) : l },
    { el: selCli, apply: (l) => selCli.value ? l.filter((r) => r.sujetoId === selCli.value) : l },
    { el: selAnio, apply: (l) => selAnio.value ? l.filter((r) => periodo(r).anio === selAnio.value) : l },
    { el: selTri, apply: (l) => selTri.value ? l.filter((r) => periodo(r).tri === selTri.value) : l },
    { el: selImp, apply: (l) => {
      if (!selImp.value) return l;
      const k = { confirmado: 'confirmado', pdf: 'leído, sin confirmar', sin: 'sin importe' }[selImp.value];
      return l.filter((r) => estadoImporte(r).t === k);
    } },
  ];
  const rows = () => CACHE.facturas.slice().sort((a, b) => String(b.fecha).localeCompare(String(a.fecha))).map((f) => ({
    ...f,
    _actions: [
      ...(f.documentoId ? [{ label: 'Ver', fn: () => verDocumento(f.documentoId) }] : []),
      { label: 'Editar', fn: () => formFactura(f) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar la factura ${f.numero || ''}? El documento del archivo no se borra.`, async () => { await api('DELETE', 'facturas/' + f.id); await reload('facturas'); }) },
    ],
  }));
  tableView({
    title: 'Facturas', sub: 'Todas las facturas del despacho. Filtra por cliente y trimestre y descarga el listado para el modelo 303 o el libro de IVA.',
    newLabel: 'Nueva factura', onNew: () => formFactura(), filters: filtros,
    exportName: 'facturas.csv', limite: 200,
    columns: [
      { label: 'Nº', get: (r) => r.numero },
      { label: 'Cliente', get: (r) => aliasDeId(r.sujetoId) || nombreSujeto(r.sujetoId) },
      { label: 'Tipo', get: (r) => r.sentido, render: (r) => r.sentido === 'emitida' ? '<span class="tag ok">emitida</span>' : '<span class="tag">recibida</span>' },
      { label: 'Fecha', get: (r) => r.fecha, render: (r) => fdate(r.fecha) + (r.fechaEstimada ? ' <span class="hint" title="Fecha aproximada: primer día del trimestre">≈</span>' : '') },
      { label: 'Periodo', get: (r) => periodo(r).tri + ' ' + periodo(r).anio },
      { label: 'Contraparte', get: (r) => r.contraparte || '' },
      { label: 'Base', get: (r) => r.base, render: (r) => eur(r.base), sumar: true, csv: (r) => r.base },
      { label: 'IVA %', get: (r) => r.iva },
      { label: 'Cuota IVA', get: (r) => +(r.base * r.iva / 100).toFixed(2), render: (r) => eur(r.base * r.iva / 100), sumar: true },
      { label: 'IRPF %', get: (r) => r.irpf || 0 },
      { label: 'Total', get: (r) => r.total, render: (r) => eur(r.total), sumar: true, csv: (r) => r.total },
      { label: 'Importe', get: (r) => estadoImporte(r).t, render: (r) => `<span class="tag ${estadoImporte(r).cls}">${estadoImporte(r).t}</span>` },
      { label: 'Cobro/pago', get: (r) => r.estado, render: (r) => `<span class="tag ${r.estado}">${esc(r.estado)}</span>` },
    ],
    rows,
  });
}
function formFactura(f) {
  openModal({
    title: f ? 'Editar factura' : 'Nueva factura',
    fields: [
      { name: 'sujetoId', label: 'Cliente', type: 'select', options: CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre + (s.nif ? ' · ' + s.nif : '') })) },
      { type: 'group2', fields: [
        { name: 'sentido', label: 'Tipo', type: 'select', options: [{ value: 'emitida', label: 'Emitida (ingreso)' }, { value: 'recibida', label: 'Recibida (gasto)' }] },
        { name: 'estado', label: 'Cobro / pago', type: 'select', options: [{ value: 'pendiente', label: 'Pendiente' }, { value: 'pagada', label: 'Pagada' }, { value: 'vencida', label: 'Vencida' }] },
      ] },
      { type: 'group2', fields: [{ name: 'numero', label: 'Número', required: true }, { name: 'fecha', label: 'Fecha', type: 'date' }] },
      { name: 'concepto', label: 'Concepto' },
      { type: 'group2', fields: [{ name: 'base', label: 'Base imponible (€)', type: 'number', step: '0.01' }, { name: 'iva', label: 'IVA %', type: 'number', step: '0.01' }] },
      { name: 'irpf', label: 'Retención IRPF %', type: 'number', step: '0.01', hint: 'El total se calcula solo: base + IVA − IRPF.' },
    ],
    values: f || { iva: 21, irpf: 0, sentido: 'emitida', fecha: new Date().toISOString().slice(0, 10) },
    onSave: async (v, close) => {
      if (!v.numero) throw new Error('El número es obligatorio.');
      // Si se toca el importe a mano, queda confirmado por quien lo toca.
      v.importeConfirmado = true;
      if (v.fecha) {
        v.ejercicio = Number(v.fecha.slice(0, 4));
        v.trimestre = Math.floor((Number(v.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T';
        v.fechaEstimada = false;
      }
      if (f) await api('PUT', 'facturas/' + f.id, v); else await api('POST', 'facturas', v);
      close(); toast('Factura guardada'); await reload('facturas');
    },
  });
}

// ---- Documentos ----------------------------------------------------
function renderDocumentos() {
  const rows = () => CACHE.documentos.map((d) => ({
    ...d,
    _actions: [
      ...(d.ruta ? [{ label: 'Descargar', fn: () => window.open('/api/download/' + d.id) }] : []),
      { label: 'Reasignar', fn: () => formDoc(d) },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar el documento "${d.nombre}"?`, async () => { await api('DELETE', 'documentos/' + d.id); await reload('documentos'); }) },
    ],
  }));
  tableView({
    title: 'Documentos', sub: 'Archivos subidos manualmente o importados del servidor local de la oficina.',
    newLabel: 'Subir documento', onNew: () => subirDoc(),
    columns: [
      { label: 'Nombre', get: (r) => r.nombre },
      { label: 'Tipo', get: (r) => r.tipo },
      { label: 'Sujeto', get: (r) => r.sujetoId ? nombreSujeto(r.sujetoId) : '—' },
      { label: 'Origen', get: (r) => r.origen, render: (r) => `<span class="tag">${esc(r.origen)}</span>` },
      { label: 'Tamaño', get: (r) => r.tamano, render: (r) => r.tamano ? (r.tamano / 1024).toFixed(1) + ' KB' : '—' },
      { label: 'Fecha', get: (r) => r.creado, render: (r) => fdate(r.creado) },
    ],
    rows,
  });
}
function subirDoc() {
  openModal({
    title: 'Subir documento',
    fields: [
      { name: 'file', label: 'Archivo', type: 'file', required: true },
      { name: 'sujetoId', label: 'Asociar a sujeto', type: 'select', options: [{ value: '', label: '— Ninguno —' }, ...CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre }))] },
    ],
    values: {},
    onSave: async (v, close) => {
      if (!v.file) throw new Error('Selecciona un archivo.');
      const b64 = await fileToB64(v.file);
      await api('POST', 'upload', { nombre: v.file.name, tipo: v.file.name.split('.').pop(), sujetoId: v.sujetoId || null, contenidoBase64: b64 });
      close(); toast('Documento subido'); await reload('documentos');
    },
  });
}
function formDoc(d) {
  openModal({
    title: 'Reasignar documento',
    fields: [
      { name: 'nombre', label: 'Nombre' },
      { name: 'sujetoId', label: 'Sujeto', type: 'select', options: [{ value: '', label: '— Ninguno —' }, ...CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre }))] },
    ],
    values: d,
    onSave: async (v, close) => { await api('PUT', 'documentos/' + d.id, { ...d, ...v, sujetoId: v.sujetoId || null }); close(); await reload('documentos'); },
  });
}
function fileToB64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1]);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

// ---- Informes -----------------------------------------------------
const CAMPOS_INFORME = [
  { value: 'nombre', label: 'Nombre' }, { value: 'nif', label: 'NIF' },
  { value: 'numEmitidas', label: 'Nº de facturas emitidas' }, { value: 'baseEmitidas', label: 'Base imponible emitidas' },
  { value: 'ivaRepercutido', label: 'IVA repercutido' }, { value: 'irpfRetenido', label: 'IRPF retenido' },
  { value: 'totalFacturado', label: 'Total facturado' },
  { value: 'numRecibidas', label: 'Nº de facturas recibidas' }, { value: 'baseRecibidas', label: 'Base imponible recibidas' },
  { value: 'ivaSoportado', label: 'IVA soportado' }, { value: 'resultadoIva', label: 'Resultado IVA (repercutido − soportado)' },
  { value: 'sinImporte', label: 'Facturas sin importe' }, { value: 'porConfirmar', label: 'Importes por confirmar' },
  { value: 'email', label: 'Email' }, { value: 'telefono', label: 'Teléfono' }, { value: 'direccion', label: 'Dirección' },
];
const CAMPOS_303 = ['nombre', 'nif', 'numEmitidas', 'baseEmitidas', 'ivaRepercutido', 'numRecibidas', 'baseRecibidas', 'ivaSoportado', 'resultadoIva', 'sinImporte', 'porConfirmar'];
function renderInformes() {
  const rows = () => CACHE.informes.map((i) => ({
    ...i,
    _actions: [
      { label: 'Editar', fn: () => formInforme(i) },
      { label: 'Ver / gráfico', fn: () => verInforme(i) },
      { label: 'Excel (CSV)', fn: () => window.open('/api/informes/' + i.id + '/export') },
      { label: 'Eliminar', cls: 'btn-danger', fn: () => confirmar(`¿Eliminar el informe "${i.titulo}"?`, async () => { await api('DELETE', 'informes/' + i.id); await reload('informes'); }) },
    ],
  }));
  tableView({
    title: 'Informes', sub: 'Flujo de informes: lectura de información, preparación de datos y resultado.',
    newLabel: 'Nuevo informe', onNew: () => formInforme(),
    columns: [
      { label: 'Título', get: (r) => r.titulo },
      { label: 'Tipo', get: (r) => r.tipo },
      { label: 'Periodo / brand', get: (r) => r.periodo },
      { label: 'Sujetos', get: (r) => r.sujetoIds.length },
      { label: 'Campos', get: (r) => r.campos.join(', ') },
      { label: 'Estado', get: (r) => r.estado, render: (r) => `<span class="tag ${r.estado}">${esc(r.estado)}</span>` },
    ],
    rows,
  });
}
function formInforme(i) {
  openModal({
    title: i ? 'Editar informe' : 'Nuevo informe',
    fields: [
      { name: 'titulo', label: 'Título', required: true },
      { type: 'group2', fields: [
        { name: 'tipo', label: 'Tipo', type: 'select', options: ['general', 'trimestral', 'anual', 'IVA', 'IRPF'].map((x) => ({ value: x, label: x })) },
        { name: 'periodo', label: 'Periodo / brand inversión' },
      ] },
      { name: 'estado', label: 'Estado', type: 'select', options: [{ value: 'borrador', label: 'Borrador' }, { value: 'revision', label: 'En revisión' }, { value: 'completado', label: 'Completado' }] },
      { name: 'campos', label: 'Columnas del Excel', type: 'checks', options: CAMPOS_INFORME, hint: 'Las cifras se calculan solo con las facturas del periodo indicado arriba (por ejemplo 3T-2025, o 2025 para el año entero).' },
      { name: 'sujetoIds', label: 'Clientes incluidos', type: 'checks', options: CACHE.sujetos.map((s) => ({ value: s.id, label: s.nombre + (s.nif ? ' · ' + s.nif : '') })) },
      { name: 'observaciones', label: 'Observaciones / información consultada', type: 'textarea' },
    ],
    values: i || { tipo: 'trimestral', periodo: CACHE.config.brandInversion || '4T-26', campos: CAMPOS_303, sujetoIds: CACHE.sujetos.map((s) => s.id) },
    onSave: async (v, close) => {
      if (!v.titulo) throw new Error('El título es obligatorio.');
      if (i) await api('PUT', 'informes/' + i.id, v); else await api('POST', 'informes', v);
      close(); toast('Informe guardado'); await reload('informes');
    },
  });
}
async function verInforme(i) {
  let d;
  try { d = await get('informes/' + i.id + '/datos'); } catch (e) { return toast(e.message, true); }
  const DINERO = new Set(['baseEmitidas', 'ivaRepercutido', 'irpfRetenido', 'totalFacturado', 'baseRecibidas', 'ivaSoportado', 'resultadoIva']);
  const fmt = (k, v) => (DINERO.has(k) ? eur(v) : esc(v ?? ''));
  const barras = (clave, titulo) => {
    const max = Math.max(1, ...d.filas.map((f) => Math.abs(f[clave] || 0)));
    return `<h4>${esc(titulo)}</h4>` + (d.filas.map((f) => `<div class="barra-fila"><span>${esc(f.nombre)}</span>
      <i style="width:${Math.round(Math.abs(f[clave] || 0) / max * 220)}px;${clave === 'baseRecibidas' ? 'background:#3a7bd5' : ''}"></i><small>${eur(f[clave] || 0)}</small></div>`).join('') || '<span class="hint">Sin clientes.</span>');
  };
  openModal({ title: 'Informe · ' + i.titulo, saveLabel: 'Cerrar', fields: [{ name: '_', type: 'textarea', label: '' }], values: {}, onSave: (_v, c) => c() });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (ta) ta.replaceWith(h(`<div>
    <p><b>Periodo:</b> ${esc(d.periodo)} &nbsp; <b>Estado:</b> ${esc(i.estado)}</p>
    ${d.nota ? `<div class="aviso-caja">${esc(d.nota)}</div>` : ''}
    ${barras('baseEmitidas', 'Base imponible emitida (ingresos)')}
    ${barras('baseRecibidas', 'Base imponible recibida (gastos)')}
    <h4>Datos</h4><div class="tabla-scroll"><table><thead><tr>${d.columnas.map((c) => `<th>${esc(c.label)}</th>`).join('')}</tr></thead>
    <tbody>${d.filas.map((f) => '<tr>' + d.columnas.map((c) => `<td class="${DINERO.has(c.key) ? 'num' : ''}">${fmt(c.key, f[c.key])}</td>`).join('') + '</tr>').join('')}</tbody></table></div>
    <p style="margin-top:10px"><b>Observaciones:</b> ${esc(i.observaciones) || '—'}</p>
    <p><a class="btn btn-sm btn-accent" href="/api/informes/${i.id}/export">⬇ Descargar Excel</a></p>
  </div>`));
}

// ---- Explorador de archivo (vista ERP) ----------------------------
let EXP_RUTA = [];        // ej. ['Maxi','2025','4T','Emitidas']
let EXP_ARBOL = null;
let EXP_BUSQUEDA = '';

const NIVELES = ['Cliente', 'Año', 'Trimestre', 'Tipo', 'Mes', 'Semana', 'Día'];
const ICONOS = { Emitidas: '📤', Recibidas: '📥', Otros: '📎' };

const bytes = (b) => !b ? '—'
  : b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB';

function nodoEnRuta(arbol, ruta) {
  let n = arbol;
  for (const paso of ruta) {
    const sig = (n.hijos || []).find((h) => h.nombre === paso);
    if (!sig) return n;
    n = sig;
  }
  return n;
}

// ¿Este documento pertenece a esa carpeta? El criterio viene del propio árbol
// (`filtro`), así que el servidor y esta pantalla nunca pueden discrepar.
function cumpleFiltro(d, f) {
  if (!f) return true;
  switch (f.campo) {
    case 'cliente': return (d.cliente || null) === f.valor;
    case 'ejercicio': return (d.ejercicio || null) === f.valor;
    case 'trimestre': return (d.trimestre || null) === f.valor;
    case 'sentido': return f.valor === 'otros'
      ? !['emitida', 'recibida'].includes(d.sentido)
      : d.sentido === f.valor;
    case 'mes': return (d.fechaEfectiva || '').slice(0, 7) === f.valor;
    case 'sinFecha': return !d.fechaEfectiva;
    case 'fecha': return !!d.fechaEfectiva && d.fechaEfectiva >= f.desde && d.fechaEfectiva <= f.hasta;
    default: return true;
  }
}

// Documentos que cuelgan de la ruta actual.
function docsDeRuta(arbol, ruta) {
  const filtros = [];
  let n = arbol;
  for (const paso of ruta) {
    const sig = (n.hijos || []).find((h) => h.nombre === paso);
    if (!sig) break;
    filtros.push(sig.filtro);
    n = sig;
  }
  return CACHE.documentos.filter((d) => filtros.every((f) => cumpleFiltro(d, f)));
}

async function renderArchivo() {
  const turno = ++NAV;
  if (!EXP_ARBOL) {
    try { EXP_ARBOL = await get('archivo/arbol'); }
    catch (e) { if (turno === NAV) view.innerHTML = `<div class="empty">No se pudo leer el archivo: ${esc(e.message)}</div>`; return; }
    if (turno !== NAV) return;
  }
  view.innerHTML = '';
  view.appendChild(h('<h1>Archivo</h1>'));
  view.appendChild(h('<p class="sub">Todos los documentos del despacho, en carpetas: cliente › año › trimestre › emitidas o gastos › mes › semana › día. «Ver» abre el documento aquí mismo; «Carpeta», su carpeta en Windows.</p>'));

  // --- barra de búsqueda global ---
  const barra = h('<div class="exp-barra"></div>');
  const buscar = h(`<input type="search" placeholder="Buscar en los ${CACHE.documentos.length.toLocaleString('es-ES')} documentos por nombre, número, proveedor o importe…">`);
  buscar.value = EXP_BUSQUEDA;
  const limpiar = h('<button class="btn">Limpiar</button>');
  barra.append(buscar, limpiar);
  view.appendChild(barra);

  buscar.oninput = () => { EXP_BUSQUEDA = buscar.value.trim(); pintar(); };
  limpiar.onclick = () => { EXP_BUSQUEDA = ''; EXP_RUTA = []; renderArchivo(); };

  const cuerpo = h('<div></div>');
  view.appendChild(cuerpo);

  function pintar() {
    cuerpo.innerHTML = '';

    // --- migas de pan ---
    const migas = h('<div class="migas"></div>');
    const inicio = h('<button>📁 Archivo</button>');
    inicio.onclick = () => { EXP_RUTA = []; pintar(); };
    migas.appendChild(inicio);
    EXP_RUTA.forEach((paso, i) => {
      migas.appendChild(h('<span class="sep">›</span>'));
      const b = h(`<button>${esc(paso)}</button>`);
      b.onclick = () => { EXP_RUTA = EXP_RUTA.slice(0, i + 1); pintar(); };
      migas.appendChild(b);
    });
    cuerpo.appendChild(migas);

    // --- modo búsqueda: tabla plana sobre todo el archivo ---
    if (EXP_BUSQUEDA) {
      const q = EXP_BUSQUEDA.toLowerCase();
      const qNum = num(EXP_BUSQUEDA.replace(/\./g, '').replace(',', '.'));
      const hits = CACHE.documentos.filter((d) => {
        const f = CACHE.facturaDeDoc.get(d.id);
        return (d.nombre || '').toLowerCase().includes(q) ||
          String(d.numeroDetectado || '').toLowerCase().includes(q) ||
          (d.proveedor || '').toLowerCase().includes(q) ||
          (d.contraparte || '').toLowerCase().includes(q) ||
          (qNum != null && f && (Math.abs(f.total - qNum) < 0.005 || Math.abs(f.base - qNum) < 0.005));
      });
      cuerpo.appendChild(h(`<div class="exp-resumen"><span><b>${hits.length}</b> resultados para “${esc(EXP_BUSQUEDA)}”</span></div>`));
      cuerpo.appendChild(tablaDocs(hits.slice(0, 300)));
      if (hits.length > 300) cuerpo.appendChild(h(`<p class="sub">Mostrando los primeros 300 de ${hits.length}. Afina la búsqueda.</p>`));
      return;
    }

    const nodo = nodoEnRuta(EXP_ARBOL, EXP_RUTA);
    const docs = docsDeRuta(EXP_ARBOL, EXP_RUTA);

    cuerpo.appendChild(h(`<div class="exp-resumen">
      <span><b>${nodo.docs}</b> documentos</span>
      <span><b>${bytes(nodo.bytes)}</b></span>
      ${EXP_RUTA.length < NIVELES.length ? `<span>Siguiente nivel: <b>${NIVELES[EXP_RUTA.length]}</b></span>` : ''}
    </div>`));

    // --- carpetas del nivel actual ---
    if (nodo.hijos && nodo.hijos.length) {
      const rejilla = h('<div class="carpetas"></div>');
      for (const hijo of nodo.hijos) {
        const ico = ICONOS[hijo.nombre] || '📁';
        const c = h(`<div class="carpeta"><div class="ico">${ico}</div>
          <div class="txt"><div class="nom">${esc(hijo.nombre)}</div>
          <div class="sub">${hijo.docs} doc · ${bytes(hijo.bytes)}</div></div></div>`);
        c.onclick = () => { EXP_RUTA = [...EXP_RUTA, hijo.nombre]; pintar(); };
        rejilla.appendChild(c);
      }
      cuerpo.appendChild(rejilla);
    }

    // --- documentos: a partir del tipo ya se ven aquí mismo, además de en
    //     las subcarpetas de mes, semana y día ---
    if (!nodo.hijos.length || EXP_RUTA.length >= 4) {
      cuerpo.appendChild(docs.length ? tablaDocs(docs)
        : h('<div class="vacio-exp">Esta carpeta no tiene documentos.</div>'));
    }
  }

  pintar();
}

function tablaDocs(docs) {
  const t = h(`<table class="doc-tabla"><thead><tr>
    <th>Documento</th><th>Nº</th><th>Fecha</th><th>Contraparte</th>
    <th>Importe</th><th>Estado</th><th></th></tr></thead></table>`);
  const tb = h('<tbody></tbody>');
  for (const d of docs) {
    const avisos = avisosDoc(d).map((a) => `<span class="aviso-inc ${a.cls || ''}" title="${esc(a.texto)}">${esc(a.corto)}</span>`);
    if (d.revisado) avisos.push('<span class="tag ok" title="Revisado a mano">revisado</span>');
    if (d.origen === 'importacion') avisos.push('<span class="tag">importado</span>');
    const f = CACHE.facturaDeDoc.get(d.id);
    const importe = !f ? '<span class="hint">—</span>'
      : f.total > 0 ? eur(f.total) + (f.importeOrigen === 'pdf' && !f.importeConfirmado ? ' <span class="hint" title="Leído del PDF, sin confirmar">*</span>' : '')
        : '<span class="hint">sin importe</span>';

    const tr = h(`<tr>
      <td class="doc-nom">${esc(d.nombre)}</td>
      <td>${esc(d.numeroDetectado || '—')}</td>
      <td>${d.fechaDocumento ? fdate(d.fechaDocumento) : f && !f.fechaEstimada ? fdate(f.fecha) : '—'}</td>
      <td>${esc(d.contraparte || d.proveedor || (f && f.contraparte) || '—')}</td>
      <td style="white-space:nowrap">${importe}</td>
      <td>${avisos.join(' ') || '<span class="tag ok">correcto</span>'}</td>
    </tr>`);
    const acc = h('<td><div class="acciones"></div></td>');
    const cont = acc.querySelector('.acciones');

    const bVer = h('<button class="btn btn-sm btn-accent" title="Verlo aquí, en el navegador">Ver</button>');
    bVer.onclick = () => verDocumento(d.id);
    const bCarpeta = h('<button class="btn btn-sm" title="Abrir la carpeta en el Explorador de Windows">Carpeta</button>');
    bCarpeta.onclick = () => abrirDoc(d, true);
    const bInfo = h('<button class="btn btn-sm">Ficha</button>');
    bInfo.onclick = () => fichaDocumento(d);
    cont.append(bVer, bCarpeta, bInfo);
    tr.appendChild(acc);
    tb.appendChild(tr);
  }
  t.appendChild(tb);
  return t;
}

// ---- Ver el documento ------------------------------------------------------
// El programa se instala en otro ordenador, donde la carpeta de las facturas
// está en otro sitio. Antes de abrir una pestaña en blanco se pregunta al
// servidor si el fichero aparece; si no, se dice qué hay que hacer.
let ARCHIVO_ESTADO = null;

async function estadoDelArchivo(recargar) {
  if (!ARCHIVO_ESTADO || recargar) {
    try { ARCHIVO_ESTADO = await get('archivo/estado'); } catch { ARCHIVO_ESTADO = null; }
  }
  return ARCHIVO_ESTADO;
}

async function verDocumento(id, nombre) {
  let r;
  try { r = await get('archivo/localizar/' + encodeURIComponent(id)); }
  catch (e) { return toast(e.message, true); }
  if (!r.ok) {
    ARCHIVO_ESTADO = null;
    pintarAvisoArchivo();
    return avisoNoSeAbre(r.error);
  }
  abrirVisor(id, nombre || r.nombre);
}

function avisoNoSeAbre(mensaje) {
  const root = document.getElementById('modal-root');
  const bg = h('<div class="modal-bg"></div>');
  const m = h(`<div class="modal"><header><strong>No se puede abrir el documento</strong><button class="btn-ghost" data-x>✕</button></header>
    <div class="body"><p style="line-height:1.55;margin:0">${esc(mensaje)}</p></div>
    <footer><button class="btn" data-cerrar>Cerrar</button><button class="btn btn-accent" data-cfg>Ir a Configuración</button></footer></div>`);
  const cerrar = () => bg.remove();
  m.querySelector('[data-x]').onclick = cerrar;
  m.querySelector('[data-cerrar]').onclick = cerrar;
  m.querySelector('[data-cfg]').onclick = () => { cerrar(); irA('config'); };
  bg.onclick = (e) => { if (e.target === bg) cerrar(); };
  bg.appendChild(m);
  root.appendChild(bg);
}

// Visor al lado: se lee el PDF y se escriben los importes sin cambiar de
// pantalla, que es lo que hace falta para corregir muchas facturas seguidas.
let VISOR = null;
function abrirVisor(id, nombre) {
  const src = '/api/archivo/ver/' + encodeURIComponent(id);
  if (!VISOR) {
    VISOR = h(`<aside class="visor">
      <header>
        <b class="visor-nom"></b>
        <span class="visor-acc">
          <a class="btn btn-sm" target="_blank" rel="noopener">Pestaña aparte</a>
          <button class="btn btn-sm" data-ancho title="Más ancho / más estrecho">⇔</button>
          <button class="btn btn-sm" data-x title="Cerrar el visor">✕</button>
        </span>
      </header>
      <iframe title="Documento"></iframe>
    </aside>`);
    VISOR.querySelector('[data-x]').onclick = cerrarVisor;
    VISOR.querySelector('[data-ancho]').onclick = () => VISOR.classList.toggle('ancho');
    document.body.appendChild(VISOR);
    document.body.classList.add('con-visor');
  }
  VISOR.querySelector('.visor-nom').textContent = nombre || 'Documento';
  VISOR.querySelector('a').href = src;
  VISOR.querySelector('iframe').src = src;
}
function cerrarVisor() {
  if (VISOR) VISOR.remove();
  VISOR = null;
  document.body.classList.remove('con-visor');
}
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && VISOR && !document.querySelector('.modal-bg')) cerrarVisor(); });

// Aviso permanente mientras el programa no sepa dónde están las facturas:
// sin él, «Ver» falla una y otra vez sin que nadie sepa por qué.
async function pintarAvisoArchivo() {
  const caja = document.getElementById('aviso-archivo');
  if (!caja) return;
  const e = await estadoDelArchivo(true);
  if (!e || !e.total || (e.existe && e.encontrados > 0)) { caja.hidden = true; caja.innerHTML = ''; return; }
  const texto = !e.configurada
    ? 'El programa todavía no sabe dónde están las facturas en este ordenador, así que los botones «Ver» y «Carpeta» no pueden abrir nada.'
    : !e.existe
      ? 'La carpeta del archivo configurada no existe en este ordenador: ' + e.ruta
      : 'Ninguno de los ' + e.total.toLocaleString('es-ES') + ' documentos aparece dentro de ' + e.ruta + '.';
  caja.hidden = false;
  caja.innerHTML = '';
  const b = h(`<div class="aviso-archivo"><span>📂 <b>Falta la carpeta de las facturas.</b> ${esc(texto)}</span></div>`);
  const acc = h('<span class="aviso-acc"></span>');
  const bCfg = h('<button class="btn btn-sm btn-accent">Elegir la carpeta</button>');
  bCfg.onclick = () => irA('config');
  acc.appendChild(bCfg);
  b.appendChild(acc);
  caja.appendChild(b);
}

async function abrirDoc(d, soloCarpeta) {
  if (!d.rutaRelativa && !d.ruta) return toast('Este documento no tiene archivo asociado.', true);
  try {
    const r = await api('POST', 'archivo/abrir', { documentoId: d.id, soloCarpeta: !!soloCarpeta });
    toast(soloCarpeta ? 'Abriendo la carpeta…' : 'Abriendo el documento…');
    return r;
  } catch (e) { toast(e.message, true); }
}

function fichaDocumento(d) {
  const f = CACHE.facturaDeDoc.get(d.id);
  openModal({ title: d.nombre, saveLabel: 'Corregir clasificación',
    fields: [{ name: '_', type: 'textarea', label: '' }], values: {},
    onSave: (_v, c) => { c(); corregirDoc(d); } });
  const ta = document.querySelector('.modal-bg:last-child textarea');
  if (!ta) return;
  const fila = (k, v) => v || v === 0 ? `<tr><td style="color:#6b7280">${esc(k)}</td><td><b>${esc(v)}</b></td></tr>` : '';
  const avisos = avisosDoc(d);
  ta.replaceWith(h(`<div>
    <table style="box-shadow:none;border:1px solid var(--line)"><tbody>
      ${fila('Cliente', d.cliente)}
      ${fila('Ejercicio', d.ejercicio)}
      ${fila('Trimestre', d.trimestre)}
      ${fila('Tipo', { emitida: 'Emitida (ingreso)', recibida: 'Recibida (gasto)', 'no-factura': 'Otro documento' }[d.sentido] || d.sentido)}
      ${fila('Número', d.numeroDetectado)}
      ${fila('Fecha del documento', d.fechaDocumento ? fdate(d.fechaDocumento) : '')}
      ${fila('Contraparte', d.contraparte || d.proveedor)}
      ${f ? fila('Base', eur(f.base)) + fila('IVA', f.iva + ' %') + (f.irpf ? fila('IRPF', f.irpf + ' %') : '') + fila('Total', eur(f.total)) + fila('Importe', estadoImporte(f).t) : ''}
      ${fila('Tamaño', bytes(d.tamano))}
      ${fila('Origen', { importacion: 'Importado ' + (d.importado ? fdate(d.importado) : ''), 'archivo-albereda36': 'Archivo inicial' }[d.origen] || d.origen)}
      ${fila('Duplicado de', d.duplicadoDe)}
    </tbody></table>
    ${avisos.length ? `<div class="aviso-caja"><b>A revisar:</b><ul>${avisos.map((a) => `<li>${esc(a.texto)}</li>`).join('')}</ul></div>` : ''}
    ${(d.historial || []).length ? `<p style="margin-top:10px"><b>Cambios hechos a mano:</b></p><ul class="hint">${d.historial.map((x) => `<li>${fdate(x.fecha)}: ${esc(x.antes)} → ${esc(x.despues)}${x.nota ? ' — ' + esc(x.nota) : ''}</li>`).join('')}</ul>` : ''}
    <p style="margin-top:10px"><b>Ubicación:</b></p>
    <p class="doc-ruta">${esc(d.almacen === 'importadas' ? 'Importadas / ' : 'Archivo / ')}${esc(d.rutaRelativa || d.ruta || '—')}</p>
    <p><button class="btn btn-sm btn-accent" data-ver>Ver documento</button></p>
  </div>`));
  document.querySelector('.modal-bg:last-child [data-ver]').onclick = () => verDocumento(d.id);
}

// Corregir cliente / periodo / tipo de un documento del archivo.
function corregirDoc(d, alTerminar) {
  const sentidoActual = d.sentido === 'no-factura' ? 'no-factura' : d.sentido;
  openModal({
    title: 'Corregir · ' + d.nombre,
    saveLabel: 'Guardar y marcar como revisado',
    fields: [
      { name: 'cliente', label: 'Cliente', type: 'select', options: clientesArchivo().map((c) => ({ value: c.id, label: c.alias })) },
      { type: 'group2', fields: [
        { name: 'ejercicio', label: 'Año', type: 'number' },
        { name: 'trimestre', label: 'Trimestre', type: 'select', options: TRIMS.map((t) => ({ value: t, label: t })) },
      ] },
      { name: 'sentido', label: 'Tipo', type: 'select', options: [
        { value: 'emitida', label: 'Emitida (ingreso)' }, { value: 'recibida', label: 'Recibida (gasto)' },
        { value: 'no-factura', label: 'No es una factura (no cuenta en el IVA)' }] },
      { name: 'nota', label: 'Nota (opcional)', hint: 'Por qué se cambia. Queda guardado en la ficha del documento.' },
    ],
    values: { cliente: d.sujetoId || (clientesArchivo().find((c) => c.alias === d.cliente) || {}).id, ejercicio: d.ejercicio, trimestre: d.trimestre, sentido: sentidoActual },
    onSave: async (v, close) => {
      if (v.sentido === 'no-factura' && CACHE.facturaDeDoc.get(d.id) && d.sentido !== 'no-factura') {
        if (!window.confirm('Al marcarlo como "no es factura" se quita de la lista de facturas y deja de contar en el IVA. ¿Seguir?')) return;
      }
      await api('POST', 'revision/documento/' + d.id, { ...v, ejercicio: Number(v.ejercicio), revisado: true });
      close(); toast('Guardado y marcado como revisado');
      EXP_ARBOL = null;
      await refreshCache();
      if (alTerminar) alTerminar(); else router();
    },
  });
}

// ---- Importar facturas --------------------------------------------
// IMP.filas: una por fichero. Cada fila guarda la propuesta del servidor y lo
// que la persona va cambiando en pantalla.
const IMP = { filas: [], cargado: false, comun: {}, ocupado: false };
const MAX_LOTE_BYTES = 20 * 1024 * 1024;

function filaDesdeItem(lote, it) {
  const p = it.propuesta || {};
  const imp = p.importes || {};
  const grave = (it.avisos || []).some((a) => a.grave);
  return {
    lote, token: it.token, nombre: it.nombre, rechazado: it.rechazado || null,
    avisos: it.avisos || [], motivos: p.motivos || [], conTexto: it.conTexto,
    fechasPosibles: p.fechasPosibles || [],
    cliente: p.cliente || '', ejercicio: p.ejercicio || '', trimestre: p.trimestre || '',
    sentido: p.sentido || '', numero: p.numero || '', fecha: p.fecha || '',
    contraparte: p.contraparte || '',
    base: imp.base ?? '', iva: imp.iva ?? (imp.total ? '' : 21), irpf: imp.irpf || 0, total: imp.total ?? '',
    importeOrigen: imp.total ? 'pdf' : null, fiabilidad: imp.fiabilidad || null,
    listo: !!p.listo, grave,
    // Propuesta completa pero no segura (p. ej. "¿gasto o ingreso?"): se pide
    // que alguien la mire antes de marcarla.
    porComprobar: !p.listo && !grave,
    marcado: !!p.listo && !grave,
    forzar: false, forzarPeriodo: false, error: null,
  };
}

async function cargarPendientes() {
  const lotes = await get('importar/pendientes');
  IMP.filas = [];
  for (const l of lotes) for (const it of l.items) if (it.propuesta) IMP.filas.push(filaDesdeItem(l.lote, it));
  IMP.cargado = true;
}

function problemasFila(f) {
  const out = [];
  if (!f.cliente) out.push('cliente');
  if (!f.ejercicio) out.push('año');
  if (!f.trimestre) out.push('trimestre');
  if (!f.sentido) out.push('tipo');
  if (f.fecha && f.ejercicio && f.trimestre) {
    const t = Math.floor((Number(f.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T';
    if ((Number(f.fecha.slice(0, 4)) !== Number(f.ejercicio) || t !== f.trimestre) && !f.forzarPeriodo) out.push('la fecha no cae en ese trimestre');
  }
  const b = num(f.base), iv = num(f.iva), t = num(f.total);
  if (b != null && iv != null && t != null && !cuadra(b, iv, num(f.irpf) || 0, t)) out.push('los importes no cuadran');
  if (f.grave && !f.forzar) out.push('tiene un aviso grave');
  return out;
}

async function renderImportar() {
  const turno = ++NAV;
  if (!IMP.cargado) {
    view.innerHTML = '<div class="empty">Cargando…</div>';
    try { await cargarPendientes(); } catch (e) { if (turno === NAV) view.innerHTML = `<div class="empty">${esc(e.message)}</div>`; return; }
    if (turno !== NAV) return;
  }
  view.innerHTML = '';
  view.appendChild(h('<h1>Importar facturas</h1>'));
  view.appendChild(h('<p class="sub">Arrastra aquí las facturas nuevas. El programa propone dónde va cada una y lee los importes; tú revisas y confirmas. Nada se archiva hasta que pulses «Importar».</p>'));

  // --- 1. Soltar ficheros ---
  const zona = h(`<div class="dropzone">
    <div class="dz-ico">📄</div>
    <div><b>Suelta aquí los PDF</b> o <label class="dz-link">elígelos<input type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.tif,.tiff,.xml,.xsig" hidden></label></div>
    <div class="hint">También imágenes y facturas electrónicas (XML). Puedes soltar muchas a la vez.</div>
  </div>`);
  const input = zona.querySelector('input');
  const cli = clientesArchivo();
  const comun = h(`<details class="comun"${IMP.comun.cliente || IMP.comun.ejercicio ? ' open' : ''}>
    <summary>Datos comunes del lote <span class="hint">(opcional: solo rellenan lo que el programa no averigüe)</span></summary>
    <div class="comun-campos">
      <label>Cliente<select data-c="cliente">${opciones(cli.map((c) => ({ v: c.id, l: c.alias })), IMP.comun.cliente, '—')}</select></label>
      <label>Año<input data-c="ejercicio" type="number" min="2000" max="2100" value="${esc(IMP.comun.ejercicio || '')}" placeholder="—"></label>
      <label>Trimestre<select data-c="trimestre">${opciones(TRIMS.map((t) => ({ v: t, l: t })), IMP.comun.trimestre, '—')}</select></label>
      <label>Tipo<select data-c="sentido">${opciones(TIPOS_DOC, IMP.comun.sentido, '—')}</select></label>
    </div>
    <div class="hint">Útil, por ejemplo, para el 4T 2022 de Alfonso cuando se extraiga del .rar: elige Alfonso · 2022 · 4T y suelta todo.</div>
  </details>`);
  comun.querySelectorAll('[data-c]').forEach((el) => { el.onchange = () => { IMP.comun[el.dataset.c] = el.value; }; });
  const progreso = h('<div class="progreso" hidden><div class="barra"><i></i></div><span></span></div>');

  const subir = async (files) => {
    if (IMP.ocupado) return;
    const lista = [...files];
    if (!lista.length) return;
    IMP.ocupado = true;
    progreso.hidden = false;
    const barra = progreso.querySelector('i');
    const texto = progreso.querySelector('span');
    let hechos = 0, lote = null;
    try {
      // Se envían en tandas de ~20 MB para no pasar el límite del servidor.
      let tanda = [], peso = 0;
      const enviar = async () => {
        if (!tanda.length) return;
        const archivos = [];
        for (const f of tanda) archivos.push({ nombre: f.name, contenidoBase64: await fileToB64(f) });
        const r = await api('POST', 'importar/analizar', { archivos, lote, comun: IMP.comun });
        lote = r.lote;
        for (const it of r.items) IMP.filas.push(filaDesdeItem(r.lote, it));
        hechos += tanda.length;
        barra.style.width = Math.round(100 * hechos / lista.length) + '%';
        texto.textContent = `Analizadas ${hechos} de ${lista.length}…`;
        tanda = []; peso = 0;
      };
      for (const f of lista) {
        if (f.size > 45 * 1024 * 1024) {
          IMP.filas.push({ token: 'x' + Math.random(), nombre: f.name, rechazado: 'Demasiado grande (más de 45 MB).' });
          continue;
        }
        if (peso + f.size > MAX_LOTE_BYTES && tanda.length) await enviar();
        tanda.push(f); peso += f.size;
      }
      await enviar();
      toast(`${hechos} archivo(s) analizados`);
    } catch (e) { toast(e.message, true); }
    finally {
      IMP.ocupado = false;
      CACHE.st = await get('stats'); pintarCabecera();
      repintar('importar');
    }
  };
  input.onchange = () => subir(input.files);
  zona.addEventListener('dragover', (e) => { e.preventDefault(); zona.classList.add('encima'); });
  zona.addEventListener('dragleave', () => zona.classList.remove('encima'));
  zona.addEventListener('drop', (e) => { e.preventDefault(); zona.classList.remove('encima'); subir(e.dataTransfer.files); });
  view.append(zona, comun, progreso);

  if (!IMP.filas.length) {
    view.appendChild(h('<div class="vacio-exp" style="margin-top:16px">No hay nada pendiente de importar.</div>'));
    return;
  }

  // --- 2. Revisar y confirmar ---
  const validas = IMP.filas.filter((f) => !f.rechazado);
  const esLista = (f) => !problemasFila(f).length && !f.porComprobar;
  const listas = validas.filter(esLista).length;
  const graves = validas.filter((f) => f.grave && !f.forzar).length;
  const pl = (n, uno, varios) => `<b>${n}</b> ${n === 1 ? uno : varios}`;
  view.appendChild(h(`<h2 class="h2">Revisa y confirma <span class="hint">(${validas.length} archivo${validas.length === 1 ? '' : 's'})</span></h2>`));
  view.appendChild(h(`<div class="exp-resumen">
    <span><span class="pto verde"></span> ${pl(listas, 'lista para importar', 'listas para importar')}</span>
    <span><span class="pto ambar"></span> ${pl(validas.length - listas - graves, 'por comprobar o completar', 'por comprobar o completar')}</span>
    <span><span class="pto rojo"></span> ${pl(graves, 'con aviso grave', 'con aviso grave')} (duplicado, número repetido…)</span>
  </div>`));

  const barra = h('<div class="toolbar"></div>');
  const izq = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const bListas = h('<button class="btn">Marcar las listas</button>');
  const bNinguna = h('<button class="btn">Desmarcar todo</button>');
  izq.append(bListas, bNinguna);
  const der = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const bDescartar = h('<button class="btn btn-danger">Descartar las no marcadas</button>');
  const bImportar = h('<button class="btn btn-accent">Importar marcadas</button>');
  der.append(bDescartar, bImportar);
  barra.append(izq, der);
  view.appendChild(barra);

  const tabla = h(`<div class="tabla-scroll"><table class="imp-tabla"><thead><tr>
    <th></th><th>Documento y avisos</th><th>Cliente</th><th>Año</th><th>Trim.</th><th>Tipo</th><th>Nº factura</th><th>Fecha</th>
    <th>Base €</th><th>IVA %</th><th>IRPF %</th><th>Total €</th>
  </tr></thead><tbody></tbody></table></div>`);
  const tb = tabla.querySelector('tbody');
  view.appendChild(tabla);

  const contarMarcadas = () => {
    const n = IMP.filas.filter((f) => f.marcado && !f.rechazado).length;
    bImportar.textContent = `Importar marcadas (${n})`;
    bImportar.disabled = !n;
  };

  const pintarFila = (f) => {
    if (f.rechazado) {
      const tr = h(`<tr class="fila-rechazada"><td></td><td><div class="doc-nom">${esc(f.nombre)}</div></td><td colspan="10"><span class="aviso-inc aviso-dup">${esc(f.rechazado)}</span> </td></tr>`);
      const x = h('<button class="btn btn-sm">Quitar de la lista</button>');
      x.onclick = () => { IMP.filas = IMP.filas.filter((y) => y !== f); renderImportar(); };
      tr.lastElementChild.appendChild(x);
      return tr;
    }
    const tr = h('<tr></tr>');
    const celda = (html) => { const td = h('<td></td>'); td.innerHTML = html; tr.appendChild(td); return td; };
    const chk = h('<input type="checkbox" class="chk-grande" title="Importar este archivo">');
    chk.checked = f.marcado;
    chk.onchange = () => { f.marcado = chk.checked; if (chk.checked) f.porComprobar = false; estado(); contarMarcadas(); };
    celda('').appendChild(chk);

    const nom = celda(`<div class="doc-nom">${esc(f.nombre)}</div>`);
    const ver = h('<a href="#" class="ver-pdf">👁 ver PDF</a>');
    ver.onclick = (e) => { e.preventDefault(); window.open(`/api/importar/ver/${f.lote}/${f.token}`, '_blank', 'noopener'); };
    nom.appendChild(ver);
    nom.appendChild(h(`<div class="hint motivos">${esc(f.motivos.slice(0, 2).join(' · ') || (f.conTexto ? '' : 'Sin texto legible (escaneo): rellena los datos mirando el PDF.'))}</div>`));
    const tdE = h('<div class="estado-fila"></div>');
    nom.appendChild(tdE);

    const campo = (html, clave, conv) => {
      const td = celda(html);
      const el = td.firstElementChild;
      el.oninput = el.onchange = () => {
        f[clave] = conv ? conv(el.value) : el.value;
        if (['base', 'iva', 'irpf'].includes(clave) && f.totalAuto !== false) {
          const b = num(f.base), iv = num(f.iva);
          if (b != null && iv != null) {
            f.total = +(b * (1 + (iv - (num(f.irpf) || 0)) / 100)).toFixed(2);
            tr.querySelector('[data-total]').value = f.total;
          }
        }
        if (clave === 'total') f.totalAuto = false;
        if (['base', 'iva', 'irpf', 'total'].includes(clave)) f.importeOrigen = 'manual';
        // Quien toca un dato ya está mirando la factura.
        f.porComprobar = false;
        f.error = null;
        if (!problemasFila(f).length && !f.marcado && !f.grave) { f.marcado = true; chk.checked = true; contarMarcadas(); }
        estado();
      };
      return el;
    };
    const vacio = (k) => (f[k] === '' || f[k] == null ? ' falta' : '');
    campo(`<select class="${vacio('cliente')}">${opciones(cli.map((c) => ({ v: c.id, l: c.alias })), f.cliente, '¿?')}</select>`, 'cliente');
    campo(`<input data-ej type="number" class="w-anio${vacio('ejercicio')}" value="${esc(f.ejercicio)}">`, 'ejercicio', (v) => (v ? Number(v) : ''));
    campo(`<select data-tr class="${vacio('trimestre')}">${opciones(TRIMS.map((t) => ({ v: t, l: t })), f.trimestre, '¿?')}</select>`, 'trimestre');
    campo(`<select class="${vacio('sentido')}">${opciones(TIPOS_DOC, f.sentido, '¿?')}</select>`, 'sentido');
    campo(`<input class="w-num" value="${esc(f.numero)}">`, 'numero');
    // Fecha: al elegirla, el año y el trimestre se ponen solos.
    const tdF = celda('');
    const inF = h(`<input type="date" value="${esc(f.fecha)}">`);
    tdF.appendChild(inF);
    inF.oninput = inF.onchange = () => {
      f.fecha = inF.value;
      if (f.fecha) {
        f.ejercicio = Number(f.fecha.slice(0, 4));
        f.trimestre = Math.floor((Number(f.fecha.slice(5, 7)) - 1) / 3) + 1 + 'T';
        tr.querySelector('[data-ej]').value = f.ejercicio;
        tr.querySelector('[data-tr]').value = f.trimestre;
        f.forzarPeriodo = false;
      }
      if (!problemasFila(f).length && !f.marcado && !f.grave) { f.marcado = true; chk.checked = true; contarMarcadas(); }
      estado();
    };
    if (f.fechasPosibles.length) {
      const alt = h(`<div class="hint">El PDF tiene varias: ${f.fechasPosibles.map((x) => `<a href="#" data-f="${x}">${fdate(x)}</a>`).join(', ')}</div>`);
      alt.querySelectorAll('[data-f]').forEach((a) => { a.onclick = (e) => { e.preventDefault(); inF.value = a.dataset.f; inF.onchange(); }; });
      tdF.appendChild(alt);
    }
    campo(`<input class="w-imp" inputmode="decimal" value="${esc(f.base)}">`, 'base', (v) => v.replace(',', '.'));
    campo(`<input class="w-pct" inputmode="decimal" value="${esc(f.iva)}">`, 'iva', (v) => v.replace(',', '.'));
    campo(`<input class="w-pct" inputmode="decimal" value="${esc(f.irpf)}">`, 'irpf', (v) => v.replace(',', '.'));
    campo(`<input data-total class="w-imp" inputmode="decimal" value="${esc(f.total)}">`, 'total', (v) => v.replace(',', '.'));

    function estado() {
      const prob = problemasFila(f);
      tr.querySelectorAll('.falta').forEach((el) => { if (el.value) el.classList.remove('falta'); });
      tr.className = f.error ? 'fila-error'
        : prob.length ? (f.grave && !f.forzar ? 'fila-grave' : 'fila-pendiente')
          : f.porComprobar && !f.marcado ? 'fila-pendiente' : 'fila-lista';
      tdE.innerHTML = '';
      if (f.error) tdE.appendChild(h(`<div class="aviso-inc aviso-dup">No se importó: ${esc(f.error)}</div>`));
      for (const a of f.avisos) tdE.appendChild(h(`<div class="${a.grave ? 'aviso-inc aviso-dup' : 'aviso-inc'}">${esc(a.texto)}</div>`));
      if (f.fiabilidad && f.importeOrigen === 'pdf') tdE.appendChild(h(`<div class="hint">Importe leído del PDF (fiabilidad ${esc(f.fiabilidad)}): compruébalo.</div>`));
      if (f.grave) {
        const l = h(`<label class="forzar"><input type="checkbox"${f.forzar ? ' checked' : ''}> Importar igualmente</label>`);
        l.querySelector('input').onchange = (e) => {
          f.forzar = e.target.checked;
          if (f.forzar) { f.marcado = true; chk.checked = true; f.error = null; }
          estado(); contarMarcadas();
        };
        tdE.appendChild(l);
      }
      if (prob.includes('la fecha no cae en ese trimestre')) {
        const l = h('<label class="forzar"><input type="checkbox"> Dejarla en ese trimestre igualmente</label>');
        l.querySelector('input').onchange = (e) => { f.forzarPeriodo = e.target.checked; estado(); };
        tdE.appendChild(l);
      }
      const faltan = prob.filter((p) => p !== 'tiene un aviso grave');
      if (faltan.length) tdE.appendChild(h(`<div class="aviso-inc">Falta: ${esc(faltan.join(', '))}</div>`));
      else if (f.grave && !f.forzar) { /* el aviso grave ya se ve arriba */ }
      else if (f.porComprobar && !f.marcado) tdE.appendChild(h('<div class="aviso-inc">Compruébala y márcala para importarla.</div>'));
      else tdE.appendChild(h('<span class="tag ok">✓ lista</span>'));
    }
    estado();
    return tr;
  };

  for (const f of IMP.filas) tb.appendChild(pintarFila(f));
  contarMarcadas();

  bListas.onclick = () => { IMP.filas.forEach((f) => { f.marcado = !f.rechazado && esLista(f); }); renderImportar(); };
  bNinguna.onclick = () => { IMP.filas.forEach((f) => { f.marcado = false; }); renderImportar(); };

  bImportar.onclick = async () => {
    const marcadas = IMP.filas.filter((f) => f.marcado && !f.rechazado);
    const conProblemas = marcadas.filter((f) => problemasFila(f).length);
    if (conProblemas.length) {
      toast(`${conProblemas.length} de las marcadas aún tienen datos por completar (en amarillo).`, true);
      return;
    }
    bImportar.disabled = true; bImportar.textContent = 'Importando…';
    const porLote = {};
    for (const f of marcadas) (porLote[f.lote] = porLote[f.lote] || []).push(f);
    let ok = 0, ko = 0;
    try {
      for (const [lote, filas] of Object.entries(porLote)) {
        const r = await api('POST', 'importar/confirmar', {
          lote,
          items: filas.map((f) => ({
            token: f.token, cliente: f.cliente, ejercicio: Number(f.ejercicio), trimestre: f.trimestre,
            sentido: f.sentido, numero: f.numero, fecha: f.fecha || null, contraparte: f.contraparte,
            base: f.base, iva: f.iva, irpf: f.irpf, total: f.total, importeOrigen: f.importeOrigen,
            forzar: f.forzar, forzarPeriodo: f.forzarPeriodo,
          })),
        });
        const hechos = new Set(r.importados.map((x) => x.token));
        ok += hechos.size;
        IMP.filas = IMP.filas.filter((f) => !hechos.has(f.token));
        for (const e of r.errores) {
          const f = IMP.filas.find((x) => x.token === e.token);
          if (f) {
            f.error = e.error; f.marcado = false; ko++;
            // Un aviso grave que aparece al confirmar (p. ej. un escaneo cuya
            // fecha e importe coinciden con otra factura) también se puede saltar.
            if (e.grave) { f.grave = true; f.forzar = false; }
          }
        }
      }
    } catch (e) { toast(e.message, true); }
    EXP_ARBOL = null;
    await refreshCache();
    toast(ko ? `Importadas ${ok}. ${ko} no se pudieron importar (en rojo).` : `Importadas ${ok}. Ya están en el Archivo.`, !!ko);
    repintar('importar');
  };

  bDescartar.onclick = () => {
    const quitar = IMP.filas.filter((f) => !f.marcado);
    if (!quitar.length) return toast('No hay nada sin marcar.');
    confirmar(`¿Descartar ${quitar.length} archivo(s)? Se borran de la espera y no se importan.`, async () => {
      const porLote = {};
      for (const f of quitar) if (!f.rechazado) (porLote[f.lote] = porLote[f.lote] || []).push(f.token);
      for (const [lote, tokens] of Object.entries(porLote)) await api('POST', 'importar/descartar', { lote, tokens });
      IMP.filas = IMP.filas.filter((f) => f.marcado);
      CACHE.st = await get('stats'); pintarCabecera();
      toast('Descartados');
      repintar('importar');
    });
  };
}

// ---- Revisar -----------------------------------------------------
const REV = { vista: 'clasificacion', filtro: '', filtroImp: 'pdf', mostrar: 100 };

async function renderRevisar() {
  view.innerHTML = '';
  view.appendChild(h('<h1>Revisar</h1>'));
  view.appendChild(h('<p class="sub">Lo que el programa no puede dar por bueno sin que alguien lo mire. Nada se borra ni se mueve: solo se corrige la clasificación.</p>'));

  const pendDocs = CACHE.documentos.filter((d) => avisosDoc(d).length);
  const porConfirmar = CACHE.facturas.filter((f) => f.total > 0 && f.importeOrigen === 'pdf' && !f.importeConfirmado);
  const sinImporte = CACHE.facturas.filter((f) => !(f.total > 0));

  const pest = h(`<div class="segmento">
    <button data-v="clasificacion">Clasificación <span class="badge">${pendDocs.length}</span></button>
    <button data-v="importes">Importes <span class="badge">${porConfirmar.length + sinImporte.length}</span></button>
  </div>`);
  pest.querySelectorAll('button').forEach((b) => {
    b.classList.toggle('activo', b.dataset.v === REV.vista);
    b.onclick = () => { REV.vista = b.dataset.v; REV.mostrar = 100; renderRevisar(); };
  });
  view.appendChild(pest);

  // --- Acciones automáticas ---
  const acciones = h('<div class="card acciones-auto"></div>');
  const bAud = h('<button class="btn">🔎 Buscar problemas en los PDF</button>');
  const bImp = h('<button class="btn">💶 Leer importes de los PDF</button>');
  acciones.append(
    h('<div><b>Comprobaciones automáticas</b><div class="hint">Leen el contenido de los PDF: fechas que caen en otro trimestre, facturas propias archivadas como gasto, importes. Tardan unos segundos. No cambian nada sin avisar.</div></div>'),
    h('<div class="acciones-bot"></div>'),
  );
  acciones.lastElementChild.append(bAud, bImp);
  view.appendChild(acciones);
  const espera = async (btn, txt, fn) => {
    const antes = btn.textContent;
    btn.disabled = true; btn.textContent = txt;
    try { await fn(); } catch (e) { toast(e.message, true); }
    finally { btn.disabled = false; btn.textContent = antes; }
  };
  bAud.onclick = () => espera(bAud, 'Leyendo PDF…', async () => {
    const r = await api('POST', 'revision/auditar');
    const n = r.periodo + r.sentido + r.noFactura;
    toast(n ? `Encontrados ${n} nuevos: ${r.periodo} de trimestre, ${r.sentido} posibles emitidas, ${r.noFactura} que no son factura.` : `Revisados ${r.revisados} documentos: nada nuevo.`);
    await refreshCache(); repintar('revisar');
  });
  bImp.onclick = () => espera(bImp, 'Leyendo PDF…', async () => {
    const r = await api('POST', 'revision/leer-importes');
    toast(`Propuestos ${r.propuestas} importes (${r.alta} fiables, ${r.media} a comprobar). ${r.sinTexto} son escaneos sin texto.`);
    REV.vista = 'importes'; REV.filtroImp = 'pdf';
    await refreshCache(); repintar('revisar');
  });

  const host = h('<div></div>');
  view.appendChild(host);
  if (REV.vista === 'clasificacion') {
    const bloques = h('<div></div>');
    host.appendChild(bloques);
    pintarBloques(bloques);
    pintarRevClasificacion(host, pendDocs);
  } else pintarRevImportes(host, porConfirmar, sinImporte);
}

// --- Clasificación automática por bloques -----------------------------------
const SEGURIDAD = {
  seguro: { etiqueta: 'seguro', cls: 'ok', nota: 'Sin riesgo: no cambia ninguna cifra.' },
  revisar: { etiqueta: 'cambia cifras', cls: 'aviso', nota: 'Mueve importes de trimestre o de signo. Míralo antes de aprobar.' },
  opcional: { etiqueta: 'decisión del despacho', cls: '', nota: 'Puede estar bien como está: solo aprueba si el despacho lo quiere así.' },
};

async function pintarBloques(host) {
  host.innerHTML = '';
  let bloques;
  try { bloques = await get('revision/propuestas'); }
  catch { return; }
  if (!host.isConnected || !bloques.length) return; // ya se pintó otra pantalla

  const total = bloques.reduce((a, b) => a + b.total, 0);
  const seguros = bloques.filter((b) => b.seguridad === 'seguro');
  const cab = h(`<div class="bloques-cab">
    <div><b>El programa puede clasificar ${total} documento(s)</b>
      <div class="hint">Cada bloque dice qué cambia y por qué. Nada se aplica hasta que lo apruebas, y todo queda en 🕘 Trazabilidad, donde se puede deshacer.</div></div>
  </div>`);
  if (seguros.length) {
    const nSeg = seguros.reduce((a, b) => a + b.total, 0);
    const bTodo = h(`<button class="btn btn-accent">✓ Aprobar los ${nSeg} seguros</button>`);
    bTodo.onclick = async () => {
      if (!confirm(`Se van a clasificar ${nSeg} documentos de los bloques sin riesgo. Se puede deshacer desde Trazabilidad. ¿Sigo?`)) return;
      bTodo.disabled = true; bTodo.textContent = 'Aplicando…';
      let ok = 0;
      for (const b of seguros) {
        try { ok += (await api('POST', 'revision/aplicar', { bloque: b.id })).aplicados; }
        catch (e) { toast(e.message, true); }
      }
      toast(`Clasificados ${ok} documentos.`);
      EXP_ARBOL = null; await refreshCache(); repintar('revisar');
    };
    cab.appendChild(bTodo);
  }
  host.appendChild(cab);

  for (const b of bloques) {
    const s = SEGURIDAD[b.seguridad] || SEGURIDAD.revisar;
    const card = h(`<div class="card bloque">
      <div class="bloque-cab">
        <div class="bloque-txt">
          <div class="bloque-tit"><b>${esc(b.titulo)}</b> <span class="tag ${s.cls}">${esc(s.etiqueta)}</span> <span class="badge">${b.total}</span></div>
          <div class="hint">${esc(b.explicacion)} ${esc(s.nota)}</div>
        </div>
        <div class="bloque-bot"></div>
      </div>
      <div class="bloque-detalle" hidden></div>
    </div>`);
    const bot = card.querySelector('.bloque-bot');
    const det = card.querySelector('.bloque-detalle');

    const bVer = h(`<button class="btn btn-sm">Ver los ${b.total}</button>`);
    bVer.onclick = () => {
      det.hidden = !det.hidden;
      bVer.textContent = det.hidden ? `Ver los ${b.total}` : 'Ocultar';
      if (det.hidden || det.childElementCount) return;
      const t = h('<table class="doc-tabla"><thead><tr><th>Documento</th><th>Ahora</th><th>Quedará</th><th>Por qué</th><th></th></tr></thead><tbody></tbody></table>');
      const tb = t.querySelector('tbody');
      for (const it of b.items) {
        const tr = h(`<tr>
          <td><div class="doc-nom">${esc(it.nombre)}</div><div class="hint">${esc(it.rutaRelativa)}</div></td>
          <td class="n">${esc(it.antesTexto)}</td>
          <td class="n"><b>${esc(it.despuesTexto)}</b></td>
          <td>${esc(it.motivo)}</td>
          <td></td>
        </tr>`);
        const bv = h('<button class="btn btn-sm btn-accent">Ver</button>');
        bv.onclick = () => verDocumento(it.documentoId);
        tr.lastElementChild.appendChild(bv);
        tb.appendChild(tr);
      }
      det.appendChild(t);
      if (b.total > b.items.length) det.appendChild(h(`<p class="hint">Se listan ${b.items.length} de ${b.total}; se aplican todos.</p>`));
    };

    const bAp = h(`<button class="btn ${b.seguridad === 'seguro' ? 'btn-accent' : ''}">Aprobar las ${b.total}</button>`);
    bAp.onclick = async () => {
      if (b.seguridad !== 'seguro' && !confirm(`${b.titulo}: ${b.total} documentos.\n\n${b.explicacion}\n\nSe puede deshacer desde Trazabilidad. ¿Sigo?`)) return;
      bAp.disabled = true; bAp.textContent = 'Aplicando…';
      try {
        const r = await api('POST', 'revision/aplicar', { bloque: b.id });
        toast(`Clasificados ${r.aplicados}` + (r.errores.length ? `, ${r.errores.length} con problemas` : '') + '.');
        EXP_ARBOL = null; await refreshCache(); repintar('revisar');
      } catch (e) { toast(e.message, true); bAp.disabled = false; bAp.textContent = `Aprobar las ${b.total}`; }
    };
    bot.append(bVer, bAp);
    host.appendChild(card);
  }
}

function pintarRevClasificacion(host, pendDocs) {
  const grupos = [
    { v: '', l: 'Todo' },
    { v: 'sentido', l: '¿Emitida o gasto?' },
    { v: 'periodo', l: 'Trimestre dudoso' },
    { v: 'duplicado', l: 'Duplicados' },
    { v: 'no-factura', l: 'No son factura' },
    { v: 'revisar', l: 'Sin clasificar' },
  ];
  const cuenta = (v) => (v ? pendDocs.filter((d) => avisosDoc(d).some((a) => a.cod === v)).length : pendDocs.length);
  const chips = h('<div class="chips"></div>');
  for (const g of grupos) {
    const n = cuenta(g.v);
    if (g.v && !n) continue;
    const b = h(`<button class="chip${REV.filtro === g.v ? ' activo' : ''}">${esc(g.l)} <b>${n}</b></button>`);
    b.onclick = () => { REV.filtro = g.v; REV.mostrar = 100; renderRevisar(); };
    chips.appendChild(b);
  }
  host.appendChild(chips);

  const expl = {
    sentido: 'Tienen la numeración de facturas del propio cliente, pero están archivadas como gasto. Si al verlas el cliente es quien factura, cámbialas a «Emitida».',
    periodo: 'La fecha de la factura cae en otro trimestre que la carpeta donde está. Para el IVA cuenta el trimestre de la fecha.',
    duplicado: 'Son copias idénticas de otro documento. Si se deja todo como está, se contarían dos veces: marca como «No es una factura» la copia sobrante.',
    'no-factura': 'Son justificantes de pago (tickets de Redsys), no facturas: no sirven para deducir el IVA.',
    revisar: 'No se pudo saber su tipo o su trimestre.',
  };
  if (expl[REV.filtro]) host.appendChild(h(`<p class="hint">${esc(expl[REV.filtro])}</p>`));

  const lista = pendDocs.filter((d) => !REV.filtro || avisosDoc(d).some((a) => a.cod === REV.filtro));
  if (!lista.length) { host.appendChild(h('<div class="vacio-exp">✓ Nada pendiente aquí.</div>')); return; }

  const t = h('<table class="doc-tabla"><thead><tr><th>Documento</th><th>Ahora está como</th><th>Qué pasa</th><th></th></tr></thead><tbody></tbody></table>');
  const tb = t.querySelector('tbody');
  for (const d of lista.slice(0, REV.mostrar)) {
    const tr = h(`<tr>
      <td><div class="doc-nom">${esc(d.nombre)}</div><div class="hint">${esc(d.rutaRelativa || '')}</div></td>
      <td style="white-space:nowrap">${descripcionDoc(d)}</td>
      <td>${avisosDoc(d).map((a) => `<div>${esc(a.texto)}</div>`).join('')}</td>
      <td><div class="acciones"></div></td>
    </tr>`);
    const acc = tr.querySelector('.acciones');
    const bVer = h('<button class="btn btn-sm btn-accent">Ver</button>');
    bVer.onclick = () => verDocumento(d.id);
    const bCor = h('<button class="btn btn-sm">Corregir</button>');
    bCor.onclick = () => corregirDoc(d, renderRevisar);
    const bOk = h('<button class="btn btn-sm" title="La clasificación actual es correcta">Está bien</button>');
    bOk.onclick = async () => {
      await api('POST', 'revision/documento/' + d.id, { revisado: true, nota: 'revisado: se deja como estaba' });
      EXP_ARBOL = null;
      await refreshCache(); repintar('revisar');
    };
    // Atajo para el caso más claro: numeración propia -> emitida.
    if (avisosDoc(d).some((a) => a.cod === 'sentido')) {
      const bE = h('<button class="btn btn-sm">Es emitida</button>');
      bE.onclick = async () => {
        await api('POST', 'revision/documento/' + d.id, { sentido: 'emitida', revisado: true, nota: 'numeración propia del cliente: es una factura emitida' });
        EXP_ARBOL = null;
        toast('Cambiada a emitida'); await refreshCache(); repintar('revisar');
      };
      acc.appendChild(bE);
    }
    acc.append(bVer, bCor, bOk);
    tb.appendChild(tr);
  }
  host.appendChild(t);
  if (lista.length > REV.mostrar) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${lista.length - REV.mostrar})</button>`);
    mas.onclick = () => { REV.mostrar += 100; renderRevisar(); };
    host.appendChild(mas);
  }
}

function pintarRevImportes(host, porConfirmar, sinImporte) {
  const chips = h('<div class="chips"></div>');
  for (const g of [{ v: 'pdf', l: 'Leídos del PDF, por confirmar', n: porConfirmar.length }, { v: 'sin', l: 'Sin importe', n: sinImporte.length }]) {
    const b = h(`<button class="chip${REV.filtroImp === g.v ? ' activo' : ''}">${esc(g.l)} <b>${g.n}</b></button>`);
    b.onclick = () => { REV.filtroImp = g.v; REV.mostrar = 100; renderRevisar(); };
    chips.appendChild(b);
  }
  host.appendChild(chips);
  host.appendChild(h(`<p class="hint">${REV.filtroImp === 'pdf'
    ? 'Importes leídos automáticamente. Ábrelos con «Ver», comprueba y pulsa «Confirmar». Los de fiabilidad alta cuadran con la etiqueta «Total» del documento.'
    : 'Facturas sin importe: suelen ser escaneos. Ábrelas con «Ver» y escribe base, IVA y total.'}</p>`));

  let lista = REV.filtroImp === 'pdf' ? porConfirmar : sinImporte;
  lista = lista.slice().sort((a, b) => (a.importeFiabilidad === 'alta' ? 0 : 1) - (b.importeFiabilidad === 'alta' ? 0 : 1) || String(a.fecha).localeCompare(String(b.fecha)));
  if (!lista.length) { host.appendChild(h('<div class="vacio-exp">✓ Nada pendiente aquí.</div>')); return; }

  if (REV.filtroImp === 'pdf') {
    // «Alta» dice que el total coincide con la etiqueta del PDF, pero no que
    // base e IVA cuadren: una factura con dos tipos de IVA puede leerse con uno
    // solo y quedar a 4 céntimos. Esas se confirman a mano, nunca en bloque.
    const cuadra = (f) => Math.abs((f.base || 0) * (1 + ((f.iva || 0) - (f.irpf || 0)) / 100) - (f.total || 0)) <= 0.01;
    const altas = lista.filter((f) => f.importeFiabilidad === 'alta' && cuadra(f));
    if (altas.length) {
      const b = h(`<button class="btn" style="margin-bottom:10px">Confirmar las ${altas.length} de fiabilidad alta</button>`);
      b.onclick = () => confirmar(`Se darán por buenos ${altas.length} importes que cuadran con la etiqueta «Total» de su PDF. Recomendado: revisa antes unos cuantos con «Ver». ¿Confirmar?`, async () => {
        let ok = 0;
        for (const f of altas) {
          try { await api('POST', 'revision/factura/' + f.id, { base: f.base, iva: f.iva, irpf: f.irpf || 0, total: f.total }); ok++; } catch { /* sigue */ }
        }
        toast(`Confirmados ${ok}`); await refreshCache(); repintar('revisar');
      });
      host.appendChild(b);
    }
  }

  const t = h(`<div class="tabla-scroll"><table class="imp-tabla"><thead><tr>
    <th>Factura</th><th>Cliente · periodo</th><th>Base</th><th>IVA %</th><th>IRPF %</th><th>Total</th><th></th>
  </tr></thead><tbody></tbody></table></div>`);
  const tb = t.querySelector('tbody');
  for (const f of lista.slice(0, REV.mostrar)) {
    const d = CACHE.documentos.find((x) => x.id === f.documentoId);
    const tr = h(`<tr>
      <td><div class="doc-nom">${esc(d ? d.nombre : f.numero)}</div>
        <div class="hint">${f.sentido === 'emitida' ? 'Emitida' : 'Recibida'} · nº ${esc(f.numero || '—')}${f.importeFiabilidad ? ' · fiabilidad ' + esc(f.importeFiabilidad) : ''}</div></td>
      <td style="white-space:nowrap">${esc(aliasDeId(f.sujetoId))} · ${esc(f.trimestre || '')} ${esc(f.ejercicio || '')}</td>
      <td><input class="w-imp" data-k="base" inputmode="decimal" value="${f.base || ''}"></td>
      <td><input class="w-pct" data-k="iva" inputmode="decimal" value="${f.iva ?? 21}"></td>
      <td><input class="w-pct" data-k="irpf" inputmode="decimal" value="${f.irpf || 0}"></td>
      <td><input class="w-imp" data-k="total" inputmode="decimal" value="${f.total || ''}"></td>
      <td><div class="acciones"></div></td>
    </tr>`);
    const val = (k) => tr.querySelector(`[data-k="${k}"]`);
    const recalcular = () => {
      const b = num(val('base').value.replace(',', '.')), iv = num(val('iva').value.replace(',', '.')), ir = num(val('irpf').value.replace(',', '.')) || 0;
      if (b != null && iv != null) val('total').value = (b * (1 + (iv - ir) / 100)).toFixed(2);
    };
    ['base', 'iva', 'irpf'].forEach((k) => { val(k).oninput = recalcular; });
    const acc = tr.querySelector('.acciones');
    if (d) { const bV = h('<button class="btn btn-sm btn-accent">Ver</button>'); bV.onclick = () => verDocumento(d.id, d.nombre); acc.appendChild(bV); }
    const bC = h('<button class="btn btn-sm">Confirmar</button>');
    bC.onclick = async () => {
      const cuerpo = {};
      for (const k of ['base', 'iva', 'irpf', 'total']) cuerpo[k] = num(val(k).value.replace(',', '.'));
      if (!(cuerpo.total > 0) || cuerpo.base == null) return toast('Escribe al menos la base y el total.', true);
      try {
        await api('POST', 'revision/factura/' + f.id, cuerpo);
        tr.remove();
        toast('Importe confirmado');
        CACHE.st = await get('stats'); pintarCabecera();
        Object.assign(f, cuerpo, { importeConfirmado: true });
      } catch (e) { toast(e.message, true); }
    };
    acc.appendChild(bC);
    tb.appendChild(tr);
  }
  host.appendChild(t);
  if (lista.length > REV.mostrar) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${lista.length - REV.mostrar})</button>`);
    mas.onclick = () => { REV.mostrar += 100; renderRevisar(); };
    host.appendChild(mas);
  }
}

// ---- Mapa de relaciones (idea "graphify") -------------------------
async function renderMapa() {
  const turno = ++NAV;
  view.innerHTML = '';
  view.appendChild(h('<h1>Mapa de relaciones</h1>'));
  view.appendChild(h('<p class="sub">Grafo de conocimiento del despacho: grupos → sujetos → facturas / documentos / informes.</p>'));
  const colors = { grupo: '#0d0d0f', sujeto: '#f2635f', factura: '#f0904a', documento: '#3a7bd5', informe: '#1f9d63' };
  view.appendChild(h('<div class="legend">' + Object.entries(colors).map(([k, c]) => `<span><i class="dot" style="background:${c}"></i>${k}</span>`).join('') + '</div>'));
  const g = await get('grafo');
  if (turno !== NAV) return;
  if (!g.nodes.length) { view.appendChild(h('<div class="empty">Aún no hay datos que relacionar.</div>')); return; }

  // layout radial por tipo
  const W = 1100, H = 640, cx = W / 2, cy = H / 2;
  const byType = {};
  g.nodes.forEach((n) => (byType[n.tipo] = byType[n.tipo] || []).push(n));
  const radius = { grupo: 90, sujeto: 210, factura: 340, documento: 340, informe: 460 };
  const pos = {};
  Object.entries(byType).forEach(([tipo, arr]) => {
    arr.forEach((n, k) => {
      const ang = (k / arr.length) * Math.PI * 2 + (tipo === 'documento' ? 0.5 : 0);
      pos[n.id] = { x: cx + Math.cos(ang) * (radius[tipo] || 260), y: cy + Math.sin(ang) * (radius[tipo] || 260) };
    });
  });
  const edges = g.edges.map((e) => {
    const a = pos[e.from], b = pos[e.to];
    if (!a || !b) return '';
    return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#c9ccd3" stroke-width="1"/>`;
  }).join('');
  const nodes = g.nodes.map((n) => {
    const p = pos[n.id];
    return `<g><circle cx="${p.x}" cy="${p.y}" r="${n.tipo === 'grupo' ? 9 : 6}" fill="${colors[n.tipo]}"/><text x="${p.x + 9}" y="${p.y + 4}" font-size="11" fill="#1c1d21">${esc(n.label).slice(0, 26)}</text></g>`;
  }).join('');
  view.appendChild(h(`<div class="graph-wrap"><svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${edges}${nodes}</svg></div>`));
}

// ---- Configuración -----------------------------------------------
// Elegir la carpeta del archivo y comprobarla de verdad: se cuenta cuántos de
// los documentos aparecen dentro, que una carpeta con el nombre correcto pero
// medio vacía es el fallo que nadie ve hasta que falla «Ver».
function tarjetaCarpetaArchivo(c) {
  const card = h(`<div class="card" style="max-width:820px;margin-bottom:16px">
    <b>Carpeta de las facturas</b>
    <p class="hint" style="margin:6px 0 12px">La carpeta que contiene las carpetas de cada cliente y año. De aquí saca el programa los PDF que abre «Ver». Nada de fuera de esta carpeta se abre nunca.</p>
    <div class="field"><label>Ruta en este ordenador</label>
      <input data-carpeta placeholder="Ej.: D:\\Asesoria\\Archivo" value="${esc(c.rutaArchivo || '')}">
      <div class="hint">Ábrela en el explorador de Windows, pulsa en la barra de direcciones de arriba, copia y pega aquí.</div>
    </div>
    <div class="carpeta-acc"></div>
    <div class="carpeta-res"></div>
  </div>`);
  const input = card.querySelector('[data-carpeta]');
  const acc = card.querySelector('.carpeta-acc');
  const res = card.querySelector('.carpeta-res');
  const bloqueada = (c._bloqueadosPorEnv || []).includes('rutaArchivo');

  const pintar = (e, guardada) => {
    res.innerHTML = '';
    if (!e) return;
    if (!e.existe) {
      res.appendChild(h(`<div class="res-mal">✕ Esa carpeta no existe en este ordenador.</div>`));
      return;
    }
    const clase = e.encontrados === 0 ? 'res-mal' : (e.faltan ? 'res-medio' : 'res-bien');
    const icono = e.encontrados === 0 ? '✕' : (e.faltan ? '!' : '✓');
    res.appendChild(h(`<div class="${clase}">${icono} Se encuentran <b>${e.encontrados.toLocaleString('es-ES')}</b> de ${e.total.toLocaleString('es-ES')} documentos${guardada ? ' · carpeta guardada' : ''}.</div>`));
    if (e.encontrados === 0 && e.carpetasEsperadas && e.carpetasEsperadas.length) {
      res.appendChild(h(`<div class="hint">Dentro deberían verse carpetas como: ${esc(e.carpetasEsperadas.slice(0, 4).join(', '))}. Puede que hayas elegido una carpeta de más o de menos.</div>`));
    } else if (e.faltan && e.ejemplos.length) {
      res.appendChild(h(`<div class="hint">No aparecen, por ejemplo: ${esc(e.ejemplos.slice(0, 3).join(' · '))}</div>`));
    }
  };

  const comprobar = async (guardar) => {
    const ruta = input.value.trim();
    if (!ruta) return toast('Escribe o busca la carpeta primero.', true);
    res.innerHTML = '<div class="hint">Comprobando…</div>';
    try {
      const e = await api('POST', 'archivo/comprobar', { ruta });
      if (guardar && e.existe) {
        await api('PUT', 'config', { ...CACHE.config, rutaArchivo: ruta });
        CACHE.config = await get('config');
        ARCHIVO_ESTADO = null;
        await pintarAvisoArchivo();
        toast('Carpeta guardada');
      }
      pintar(e, guardar && e.existe);
      if (guardar && !e.existe) toast('No se ha guardado: esa carpeta no existe.', true);
    } catch (err) { toast(err.message, true); res.innerHTML = ''; }
  };

  const bComp = h('<button class="btn">Comprobar</button>');
  bComp.onclick = () => comprobar(false);
  const bGuardar = h('<button class="btn btn-accent">Usar esta carpeta</button>');
  bGuardar.onclick = () => comprobar(true);
  const bBuscar = h('<button class="btn">Buscarla por mí</button>');
  bBuscar.onclick = async () => {
    res.innerHTML = '<div class="hint">Buscando en las carpetas habituales…</div>';
    try {
      const r = await api('POST', 'archivo/buscar-carpeta', {});
      res.innerHTML = '';
      if (!r.candidatos.length) {
        res.appendChild(h('<div class="res-medio">! No la he encontrado sola. Cópiala del explorador de Windows y pégala arriba.</div>'));
        return;
      }
      res.appendChild(h('<div class="hint">Carpetas que parecen el archivo:</div>'));
      for (const cand of r.candidatos) {
        const fila = h(`<div class="cand"><code>${esc(cand.ruta)}</code> <span class="hint">${cand.aciertos} de ${cand.de} carpetas</span></div>`);
        const b = h('<button class="btn btn-sm">Usar esta</button>');
        b.onclick = () => { input.value = cand.ruta; comprobar(true); };
        fila.appendChild(b);
        res.appendChild(fila);
      }
    } catch (err) { toast(err.message, true); res.innerHTML = ''; }
  };
  acc.append(bBuscar, bComp, bGuardar);

  if (bloqueada) {
    input.readOnly = true;
    input.style.background = '#f4f5f7';
    [bGuardar, bBuscar].forEach((b) => { b.disabled = true; });
    card.appendChild(h('<div class="hint">Esta carpeta viene del archivo .env (GF_RUTA_ARCHIVO). Para cambiarla, edita .env y reinicia el programa.</div>'));
  }
  if (c.rutaArchivo) comprobar(false);
  return card;
}

// ---- Versión del programa ---------------------------------------------------
// Las versiones nuevas se instalan solas al abrir el programa. Mientras tanto,
// si ya se sabe que hay una, se avisa arriba con la opción de hacerlo ya.
let ACT_ESTADO = null;

async function pintarAvisoVersion() {
  const caja = document.getElementById('aviso-version');
  if (!caja) return;
  try { ACT_ESTADO = await get('actualizacion'); } catch { return; }
  const d = ACT_ESTADO.disponible;
  if (!d) { caja.hidden = true; caja.innerHTML = ''; return; }
  caja.hidden = false;
  caja.innerHTML = '';
  const b = h(`<div class="aviso-version"><span>⬆ <b>Hay una versión nueva del programa (${esc(d.version)}).</b> ${esc(d.notas || '')} Se instalará sola la próxima vez que lo abras.</span></div>`);
  const bAhora = h('<button class="btn btn-sm btn-accent">Instalar ahora</button>');
  bAhora.onclick = () => instalarVersion(d.version);
  b.appendChild(bAhora);
  caja.appendChild(b);
}

// Instala y espera a que el programa vuelva con la versión nueva.
async function instalarVersion(version) {
  confirmar(`Se instalará la versión ${version}. El programa se reinicia en unos segundos; tus datos no se tocan. ¿Seguir?`, async () => {
    let r;
    try { r = await api('POST', 'actualizacion/instalar', {}); }
    catch (e) { return toast(e.message, true); }
    if (!r.instalada) return toast(r.mensaje || 'No había nada que instalar.');
    if (!r.reinicia) {
      toast(`Instalada la ${r.version}. Cierra el programa y vuelve a abrirlo con INICIAR.bat para usarla.`);
      return pintarAvisoVersion();
    }
    toast(`Instalada la ${r.version}. Reiniciando…`);
    await esperarVersion(r.version);
  });
}

async function esperarVersion(version) {
  for (let i = 0; i < 60; i++) {
    await new Promise((res) => setTimeout(res, 1000));
    try {
      const st = await get('stats');
      if (st.version === version) { location.reload(); return; }
    } catch { /* aún reiniciando */ }
  }
  toast('El programa tarda en volver. Recarga la página en un momento.', true);
}

function tarjetaVersion() {
  const card = h(`<div class="card" style="max-width:820px;margin-bottom:16px">
    <b>Versión del programa</b>
    <div class="version-cuerpo" style="margin-top:8px"><div class="hint">Cargando…</div></div>
  </div>`);
  const cuerpo = card.querySelector('.version-cuerpo');
  const cuando = (iso) => iso ? new Date(iso).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' }) : 'nunca';

  const pintar = (e) => {
    cuerpo.innerHTML = '';
    const lineas = [`Instalada: <b>${esc(e.actual)}</b>`];
    if (!e.configurado) {
      lineas.push('Actualizaciones automáticas: <b>sin configurar</b> (falta GF_ACTUALIZACIONES_URL en el archivo .env).');
    } else {
      lineas.push(`Actualizaciones automáticas: <b>activadas</b> · última comprobación: ${esc(cuando(e.ultimaComprobacion))}`);
      if (e.errorComprobacion) lineas.push(`<span style="color:#8d2b28">${esc(e.errorComprobacion)}</span>`);
      lineas.push(e.disponible
        ? `<b>Hay versión nueva: ${esc(e.disponible.version)}</b>${e.disponible.notas ? ' — ' + esc(e.disponible.notas) : ''}`
        : 'Estás en la última versión publicada.');
    }
    if (e.vueltaAtrasAMedias) lineas.push('La vuelta a la versión anterior se quedó a medias. Pulsa otra vez «Volver a la ' + esc(e.anteriores[0]) + '» o cierra y abre el programa: se termina sola.');
    if (e.pendienteDeConfirmar) lineas.push('Recién instalada: se da por buena tras 30 segundos en marcha. Si fallara al arrancar, el programa vuelve solo a la anterior.');
    cuerpo.appendChild(h('<div style="display:grid;gap:4px">' + lineas.map((l) => '<div>' + l + '</div>').join('') + '</div>'));

    const acc = h('<div class="carpeta-acc" style="margin-top:10px"></div>');
    if (e.configurado) {
      const bBuscar = h('<button class="btn">Buscar ahora</button>');
      bBuscar.onclick = async () => {
        bBuscar.disabled = true;
        try { pintar(await api('POST', 'actualizacion/buscar', {})); pintarAvisoVersion(); }
        catch (err) { toast(err.message, true); bBuscar.disabled = false; }
      };
      acc.appendChild(bBuscar);
    }
    if (e.disponible) {
      const bInst = h(`<button class="btn btn-accent">Instalar la ${esc(e.disponible.version)}</button>`);
      bInst.onclick = () => instalarVersion(e.disponible.version);
      acc.appendChild(bInst);
    }
    if (e.anteriores && e.anteriores.length) {
      const bVolver = h(`<button class="btn">Volver a la ${esc(e.anteriores[0])}</button>`);
      bVolver.onclick = () => confirmar(`Se volverá a la versión ${e.anteriores[0]} y la ${e.actual} no se volverá a instalar sola. Tus datos no se tocan. ¿Seguir?`, async () => {
        try {
          const r = await api('POST', 'actualizacion/volver', {});
          if (r.reinicia) { toast('Volviendo a la ' + r.a + '…'); await esperarVersion(r.a); }
          else toast('Hecho. Cierra el programa y vuelve a abrirlo con INICIAR.bat.');
        } catch (err) { toast(err.message, true); }
      });
      acc.appendChild(bVolver);
    }
    if (acc.children.length) cuerpo.appendChild(acc);

    if (e.historial && e.historial.length) {
      const lista = h('<div class="hint" style="margin-top:10px;display:grid;gap:2px"></div>');
      for (const x of e.historial.slice(0, 5)) lista.appendChild(h(`<div>${esc(cuando(x.fecha))} · ${esc(x.texto)}</div>`));
      cuerpo.appendChild(lista);
    }
  };
  get('actualizacion').then(pintar).catch((err) => { cuerpo.innerHTML = '<div class="hint">' + esc(err.message) + '</div>'; });
  return card;
}

function renderConfig() {
  const c = CACHE.config;
  view.innerHTML = '';
  view.appendChild(h('<h1>Configuración</h1>'));
  view.appendChild(h('<p class="sub">Dónde están las facturas en este ordenador y, si algún día existe, la conexión con el servidor de la oficina.</p>'));

  // La carpeta del archivo va primero y con comprobación: es lo único que hay
  // que acertar para que el programa abra los PDF en este ordenador.
  view.appendChild(tarjetaCarpetaArchivo(c));
  view.appendChild(tarjetaVersion());

  const form = h('<div class="card" style="display:grid;gap:12px;max-width:640px"></div>');
  const f = (label, name, val, hint, type = 'text') => {
    const w = h(`<div class="field"><label>${esc(label)}</label><input type="${type}" data-name="${name}" value="${esc(val || '')}">${hint ? `<div class="hint">${esc(hint)}</div>` : ''}</div>`);
    return w;
  };
  form.appendChild(f('URL base de la API', 'apiBaseUrl', c.apiBaseUrl, 'Dirección del servidor de archivos de la oficina, que debe exponer GET /ficheros. NO es la dirección de este programa. Vacío = sincronización desactivada.'));
  // La clave solo vive en el .env. El campo se muestra para saber si esta
  // puesta, pero bloqueado: escribirla aqui la guardaria en data/db.json, que
  // es justo el fichero que se entrega al cliente dentro del paquete.
  const campoClave = f('API Key / Token', 'apiKey', c.apiKey,
    'Se escribe en el archivo .env (GF_API_KEY), nunca aquí. Se envía como cabecera Authorization: Bearer …', 'password');
  const inputClave = campoClave.querySelector('input');
  inputClave.readOnly = true;
  inputClave.style.background = '#f4f5f7';
  inputClave.placeholder = 'Sin definir — ponla en el archivo .env';
  form.appendChild(campoClave);
  form.appendChild(f('Ruta del servidor local', 'servidorLocal', c.servidorLocal, 'Ruta UNC de referencia, ej. \\\\SERVIDOR-OFICINA\\Asesoria'));
  form.appendChild(f('Carpeta de fichas', 'carpetaFichas', c.carpetaFichas, 'Subcarpeta donde están las fichas dentro del servidor. Déjalo vacío si no la usas.'));
  form.appendChild(f('Brand de inversión', 'brandInversion', c.brandInversion, 'Ej.: 4T-26'));
  form.appendChild(h(`<div class="field"><label>Gestión adicional (correo / anotación manuscrita)</label><textarea data-name="notas">${esc(c.notas || '')}</textarea><div class="hint">Pendiente de precisar.</div></div>`));

  const bar = h('<div style="display:flex;gap:8px;flex-wrap:wrap"></div>');
  const save = h('<button class="btn btn-accent">Guardar configuración</button>');
  const test = h('<button class="btn">Probar conexión</button>');
  const sync = h('<button class="btn">Sincronizar ahora</button>');
  bar.append(save, test, sync);
  form.appendChild(bar);
  view.appendChild(form);

  view.appendChild(h(`<div class="card" style="margin-top:16px;max-width:640px">
    <b>Contrato esperado de la API</b>
    <pre style="white-space:pre-wrap;font-size:12px;color:#444">GET {URL base}/ficheros
Authorization: Bearer {API Key}

respuesta: [
  { "nombre": "factura_2026_001.pdf", "tipo": "pdf",
    "sujetoNif": "B12345678", "contenidoBase64": "JVBERi0…", "tamano": 12345 }
]</pre>
    <div class="hint">Los ficheros con <code>sujetoNif</code> coincidente se asocian automáticamente al sujeto. Los repetidos no se duplican.</div>
  </div>`));

  // Campos que manda el .env: se muestran, no se editan y no se reenvian al guardar.
  const bloqueados = c._bloqueadosPorEnv || [];
  if (bloqueados.length) {
    form.querySelectorAll('[data-name]').forEach((i) => {
      if (!bloqueados.includes(i.dataset.name)) return;
      i.readOnly = true;
      i.style.background = '#f4f5f7';
      i.style.color = '#6b7280';
      const texto = 'Definido en el archivo .env. Para cambiarlo, edita .env y reinicia el programa.';
      const hint = i.parentElement.querySelector('.hint');
      if (hint) hint.textContent = texto;
      else i.parentElement.appendChild(h('<div class="hint"></div>')).textContent = texto;
    });
    view.insertBefore(h('<div class="card" style="max-width:640px;border-left:4px solid #f0904a"><b>Claves cargadas desde .env</b><div class="hint">Los campos marcados vienen del archivo <code>.env</code> que hay junto a <code>server.js</code>. Se editan ahi; aqui solo se muestran. La clave nunca se guarda en <code>data/db.json</code>.</div></div>'), form);
  }

  const read = () => {
    const o = {};
    form.querySelectorAll('[data-name]').forEach((i) => { if (!i.readOnly) o[i.dataset.name] = i.value; });
    return o;
  };
  const refrescarBotones = () => {
    const url = (form.querySelector('[data-name="apiBaseUrl"]') || {}).value || '';
    const sinApi = !url.trim();
    for (const b of [test, sync]) {
      b.disabled = sinApi;
      b.title = sinApi ? 'Primero pon la dirección del servidor de archivos de la oficina.' : '';
      b.style.opacity = sinApi ? 0.45 : 1;
      b.style.cursor = sinApi ? 'not-allowed' : 'pointer';
    }
    aviso.hidden = !sinApi;
  };
  const aviso = h('<div class="hint" style="margin-top:4px">Sin dirección de API, la sincronización está desactivada. El resto del programa funciona igual: el archivo de facturas se lee de la carpeta local.</div>');
  form.appendChild(aviso);
  const inputUrl = form.querySelector('[data-name="apiBaseUrl"]');
  if (inputUrl) inputUrl.addEventListener('input', refrescarBotones);
  refrescarBotones();

  save.onclick = async () => { CACHE.config = await api('PUT', 'config', read()); toast('Configuración guardada'); refrescarBotones(); };
  test.onclick = async () => {
    await api('PUT', 'config', read());
    try { const r = await api('POST', 'probar-conexion'); toast(r.ok ? 'Conexión OK (HTTP ' + r.status + ')' : 'Respuesta HTTP ' + r.status, !r.ok); }
    catch (e) { toast(e.message, true); }
  };
  sync.onclick = async () => { await api('PUT', 'config', read()); doSync(); };
}

// ---------------------------------------------------------------------------
// Sincronización
// ---------------------------------------------------------------------------
async function doSync() {
  const btn = document.getElementById('btn-sync');
  btn.disabled = true; btn.textContent = 'Sincronizando…';
  try {
    const r = await api('POST', 'sincronizar');
    toast(`Sincronizado: ${r.creados} documentos nuevos de ${r.recibidos} recibidos.`);
    await refreshCache();
    router();
  } catch (e) { toast(e.message, true); }
  finally { btn.disabled = false; btn.textContent = 'Sincronizar servidor local'; }
}

// ---------------------------------------------------------------------------
// Trazabilidad: el historial de todo lo que se ha movido
// ---------------------------------------------------------------------------
const TRAZA = { tipo: '', busca: '', desde: '', hasta: '', limite: 200 };

const TIPOS_MOV = {
  duplicado: 'Copia repetida', 'no-factura': 'No es factura', sentido: 'Emitida o gasto',
  periodo: 'Cambio de trimestre', clasificacion: 'Clasificación', correccion: 'Corrección a mano',
  importacion: 'Importación', borrado: 'Borrado', deshacer: 'Deshecho',
};

async function renderTrazabilidad() {
  const turno = ++NAV;
  view.innerHTML = '';
  view.appendChild(h('<h1>Trazabilidad</h1>'));
  view.appendChild(h('<p class="sub">Todo lo que ha cambiado en el archivo: qué documento, qué tenía antes, qué tiene ahora, quién lo hizo y por qué. Lo que se hizo en bloque se puede deshacer aquí.</p>'));

  const barra = h(`<div class="card traza-filtros">
    <label>Tipo <select></select></label>
    <label>Desde <input type="date"></label>
    <label>Hasta <input type="date"></label>
    <label class="crece">Buscar <input type="search" placeholder="documento, motivo…"></label>
  </div>`);
  const [sel, desde, hasta, busca] = barra.querySelectorAll('select, input');
  sel.appendChild(h('<option value="">Todos</option>'));
  for (const [v, l] of Object.entries(TIPOS_MOV)) sel.appendChild(h(`<option value="${v}">${esc(l)}</option>`));
  sel.value = TRAZA.tipo; desde.value = TRAZA.desde; hasta.value = TRAZA.hasta; busca.value = TRAZA.busca;
  const recargar = () => {
    TRAZA.tipo = sel.value; TRAZA.desde = desde.value; TRAZA.hasta = hasta.value; TRAZA.busca = busca.value.trim();
    renderTrazabilidad();
  };
  sel.onchange = desde.onchange = hasta.onchange = recargar;
  let t0; busca.oninput = () => { clearTimeout(t0); t0 = setTimeout(recargar, 350); };
  view.appendChild(barra);

  const q = new URLSearchParams();
  for (const k of ['tipo', 'desde', 'hasta', 'busca', 'limite']) if (TRAZA[k]) q.set(k, TRAZA[k]);
  let datos;
  try { datos = await get('movimientos?' + q); }
  catch (e) { if (turno === NAV) view.appendChild(h(`<div class="empty">No se pudo leer el historial: ${esc(e.message)}</div>`)); return; }
  if (turno !== NAV) return;

  if (!datos.total) {
    view.appendChild(h('<div class="vacio-exp">Todavía no hay movimientos registrados.</div>'));
    return;
  }

  const resumen = h(`<div class="exp-resumen"><span><b>${datos.total}</b> movimientos</span>
    <span>Mostrando ${datos.movimientos.length}</span></div>`);
  const bCSV = h('<button class="btn btn-sm">⬇ Descargar CSV</button>');
  bCSV.onclick = () => descargarCSV('trazabilidad.csv', [
    { label: 'Fecha', get: (m) => m.fecha.slice(0, 19).replace('T', ' ') },
    { label: 'Tipo', get: (m) => TIPOS_MOV[m.tipo] || m.tipo },
    { label: 'Origen', get: (m) => (m.automatico ? 'Automático (aprobado en bloque)' : 'Persona') },
    { label: 'Documento', get: (m) => m.nombre },
    { label: 'Carpeta', get: (m) => m.rutaRelativa },
    { label: 'Cambio', get: (m) => m.texto },
    { label: 'Motivo', get: (m) => m.motivo },
    { label: 'Deshecho', get: (m) => (m.deshecho ? 'sí' : '') },
  ], datos.movimientos);
  resumen.appendChild(bCSV);
  view.appendChild(resumen);

  const t = h(`<table class="doc-tabla traza"><thead><tr>
    <th>Cuándo</th><th>Qué</th><th>Documento</th><th>Cambio</th><th>Quién</th><th></th>
  </tr></thead><tbody></tbody></table>`);
  const tb = t.querySelector('tbody');
  for (const m of datos.movimientos) {
    const tr = h(`<tr${m.deshecho ? ' class="mov-deshecho"' : ''}>
      <td class="n">${esc(m.fecha.slice(0, 10).split('-').reverse().join('/'))}<div class="hint">${esc(m.fecha.slice(11, 16))}</div></td>
      <td class="n">${esc(TIPOS_MOV[m.tipo] || m.tipo)}</td>
      <td><div class="doc-nom">${esc(m.nombre)}</div><div class="hint">${esc(m.rutaRelativa || '')}</div></td>
      <td>${esc(m.texto)}${m.motivo ? `<div class="hint">${esc(m.motivo)}</div>` : ''}${m.deshecho ? '<div class="hint">deshecho</div>' : ''}</td>
      <td class="n">${m.automatico ? 'Automático' : 'Persona'}</td>
      <td><div class="acciones"></div></td>
    </tr>`);
    const acc = tr.querySelector('.acciones');
    if (m.documentoId) {
      const bv = h('<button class="btn btn-sm btn-accent">Ver</button>');
      bv.onclick = () => verDocumento(m.documentoId);
      acc.appendChild(bv);
    }
    if (m.reversible && !m.deshecho) {
      const bd = h('<button class="btn btn-sm">Deshacer</button>');
      bd.onclick = async () => {
        if (!confirm(`Se devolverá «${m.nombre}» a como estaba:\n${m.texto}\n\n¿Sigo?`)) return;
        bd.disabled = true;
        try {
          await api('POST', `movimientos/${m.id}/deshacer`);
          toast('Deshecho.');
          EXP_ARBOL = null; await refreshCache(); repintar('trazabilidad');
        } catch (e) { toast(e.message, true); bd.disabled = false; }
      };
      acc.appendChild(bd);
    }
    tb.appendChild(tr);
  }
  view.appendChild(t);
  if (datos.total > datos.movimientos.length) {
    const mas = h(`<button class="btn" style="margin-top:10px">Mostrar más (quedan ${datos.total - datos.movimientos.length})</button>`);
    mas.onclick = () => { TRAZA.limite += 200; renderTrazabilidad(); };
    view.appendChild(mas);
  }
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
const ROUTES = {
  panel: renderPanel, archivo: renderArchivo, importar: renderImportar, revisar: renderRevisar,
  trazabilidad: renderTrazabilidad,
  grupos: renderGrupos, sujetos: renderSujetos, facturas: renderFacturas, documentos: renderDocumentos,
  informes: renderInformes, mapa: renderMapa, config: renderConfig,
};
let current = 'panel';

async function reload(col) {
  if (col) CACHE[col] = await get(col);
  if (col === 'facturas') CACHE.facturaDeDoc = new Map(CACHE.facturas.filter((f) => f.documentoId).map((f) => [f.documentoId, f]));
  if (col === 'documentos') EXP_ARBOL = null;
  CACHE.st = await get('stats');
  pintarCabecera();
  router();
}
// Cada vez que se pinta una pantalla sube NAV. Las pantallas que esperan datos
// a mitad de pintarse guardan su turno y, al volver, si ya se ha pintado otra
// cosa, no tocan nada: antes, aprobar un bloque y cambiar de pestaña enseguida
// hacía que «Revisar» se pintara encima de la pestaña nueva.
let NAV = 0;
function router() { NAV++; (ROUTES[current] || renderPanel)(); }
// Tras guardar algo se vuelve a pintar, pero solo si se sigue en esa pantalla.
function repintar(tab) { if (current === tab) router(); }

document.getElementById('tabs').addEventListener('click', async (e) => {
  const b = e.target.closest('button[data-tab]');
  if (!b) return;
  document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('active', x === b));
  current = b.dataset.tab;
  if (location.hash.slice(1) !== current) history.pushState(null, '', '#' + current);
  // Al volver a Inicio o a Revisar se refrescan los datos: otra ventana puede
  // haber importado o corregido algo mientras tanto.
  if (current === 'panel' || current === 'revisar') {
    try { await refreshCache(); EXP_ARBOL = null; } catch { /* se pinta con lo que hay */ }
  }
  if (current === 'importar') IMP.cargado = IMP.filas.length > 0;
  router();
});

// Cambiar la dirección a mano (o el botón "atrás") también cambia de pestaña.
window.addEventListener('hashchange', () => {
  const pedida = location.hash.slice(1);
  if (ROUTES[pedida] && pedida !== current) {
    const b = document.querySelector(`#tabs button[data-tab="${pedida}"]`);
    if (b) b.click();
  }
});

// Avisar antes de cerrar si hay una importación a medias.
window.addEventListener('beforeunload', (e) => {
  if (IMP.ocupado) { e.preventDefault(); e.returnValue = ''; }
});
document.getElementById('btn-sync').onclick = doSync;

(async function init() {
  try {
    await refreshCache();
    // La pestaña puede venir en la dirección: http://localhost:4360/#importar
    const pedida = location.hash.slice(1);
    if (ROUTES[pedida]) {
      current = pedida;
      document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('active', x.dataset.tab === pedida));
    }
    router();
    pintarAvisoArchivo(); // si falta la carpeta de las facturas, que se vea ya
    pintarAvisoVersion();
    setInterval(pintarAvisoVersion, 30 * 60 * 1000);
  } catch (e) { view.innerHTML = '<div class="empty">No se pudo cargar: ' + esc(e.message) + '</div>'; }
})();
