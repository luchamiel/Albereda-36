/*
 * Dice por qué puerto va a escuchar el programa.
 * Lo usa INICIAR.bat, que necesita saberlo ANTES de arrancar el servidor
 * para poder vigilar el puerto correcto y abrir el navegador donde toca.
 * Lee el .env con las mismas reglas que server.js.
 */
'use strict';

const fs = require('fs');
const path = require('path');

let puerto = process.env.PORT || '';

const f = path.join(__dirname, '.env');
if (!puerto && fs.existsSync(f)) {
  for (const linea of fs.readFileSync(f, 'utf8').split(String.fromCharCode(10))) {
    const t = linea.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i < 1) continue;
    if (t.slice(0, i).trim() === 'PORT') {
      let v = t.slice(i + 1).trim();
      if (/^".*"$/.test(v) || /^'.*'$/.test(v)) v = v.slice(1, -1);
      if (v) puerto = v;
    }
  }
}

// Si lo del .env no es un puerto válido, se cae al de siempre.
const n = parseInt(puerto, 10);
process.stdout.write(String(n > 0 && n < 65536 ? n : 4360));
