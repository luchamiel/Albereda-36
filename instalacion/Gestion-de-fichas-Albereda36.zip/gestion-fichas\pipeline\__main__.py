"""Permite:  python -m pipeline <comando>"""
import sys
from pathlib import Path

# Los modulos usan imports absolutos entre si: la carpeta del paquete
# tiene que estar en sys.path tanto si se ejecuta desde dentro como desde fuera.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
