"""Rutas y constantes configurables del pipeline. Todo lo ajustable vive aqui."""
import os
from pathlib import Path


def _leer_env() -> dict:
    """Lee el .env que hay junto a INICIAR.bat, con las mismas reglas que server.js.

    Sin esto, las rutas quedarian atadas al ordenador donde se escribio el
    codigo y el pipeline no arrancaria en el equipo del despacho.
    """
    valores = {}
    fichero = Path(__file__).resolve().parent.parent / ".env"
    if not fichero.exists():
        return valores
    for linea in fichero.read_text(encoding="utf-8").splitlines():
        texto = linea.strip()
        if not texto or texto.startswith("#"):
            continue
        clave, sep, valor = texto.partition("=")
        if not sep:
            continue
        valor = valor.strip()
        if len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in "\"'":
            valor = valor[1:-1]
        if valor:
            valores[clave.strip()] = valor
    return valores


_ENV = _leer_env()


def _ajuste(clave: str, por_defecto: str = "") -> str:
    """El entorno del sistema manda sobre el .env, igual que en server.js."""
    return os.environ.get(clave) or _ENV.get(clave) or por_defecto

# --- Rutas -----------------------------------------------------------------
# SOLO LECTURA. El pipeline jamas escribe dentro de esta carpeta.
# Sale de GF_RUTA_ARCHIVO en el .env. Si esta vacio, se usa una carpeta
# Albereda36 junto a la carpeta del programa, igual que hace server.js.
_RUTA_ARCHIVO = _ajuste("GF_RUTA_ARCHIVO")
RAIZ_DATOS = (
    Path(_RUTA_ARCHIVO)
    if _RUTA_ARCHIVO
    else Path(__file__).resolve().parent.parent.parent / "Albereda36"
)

# Todo lo que genera el pipeline va aqui.
CARPETA_TRABAJO = Path(__file__).resolve().parent / "_trabajo"
BUZON_ENTRADA = CARPETA_TRABAJO / "_ENTRADA"
CARPETA_SALIDA = CARPETA_TRABAJO / "_SALIDA"
INVENTARIO_JSON = CARPETA_TRABAJO / "inventario.json"
INVENTARIO_CSV = CARPETA_TRABAJO / "inventario.csv"

# --- App Gestion de fichas -------------------------------------------------
# El puerto tambien sale del .env: si alli dice otro, aqui hay que seguirlo.
# 127.0.0.1 y no "localhost": en Windows, "localhost" prueba antes IPv6.
API_BASE = "http://127.0.0.1:" + _ajuste("PORT", "4360")

# --- Formato de los CSV para Excel en espanol ------------------------------
CSV_ENCODING = "utf-8-sig"   # BOM: Excel respeta tildes y ñ
CSV_SEP = ";"

# --- Clientes canonicos ----------------------------------------------------
# NIF confirmados en los propios nombres de archivo del archivo real:
#   Facturas_Orange_49763368Q_...        -> Maxi
#   FRA_60701_241601_07178015Z.pdf       -> Urbano
CLIENTES = {
    "alfonso": {"nombre": "Alfonso", "razon_social": "ALFONSO BERENGUER MAYOR", "nif": None},
    "maxi":    {"nombre": "Maxi",    "razon_social": "MAXI MICHEL",             "nif": "49763368Q"},
    "urbano":  {"nombre": "Urbano",  "razon_social": "ORLANDO RAUL URBANO DE LA TORRE", "nif": "07178015Z"},
}

# Ejercicios considerados validos al interpretar una fecha.
EJERCICIOS_VALIDOS = range(2021, 2027)

# --- Comprimidos sueltos ya resueltos --------------------------------------
# Evidencia: se leyeron las cabeceras RAR5 con Python puro. Contienen rutas
# "3T 2025/Gastos/136-25 MAXI.pdf" y "4T 2025/Gastos/25330 MAXI MICHEL.pdf",
# y subcarpetas Avatel/Yoigo/Facturas_Orange_49763368Q/google-payments,
# exclusivas de Maxi. Ademas YA estan extraidos en "2025 Maxi/2025 3T|4T".
RAR_RAIZ = {
    "3T 2025.rar": ("Maxi", 2025, "3T"),
    "4T 2025.rar": ("Maxi", 2025, "4T"),
}

# La stdlib NO lee .rar. No anadir 'rarfile': la extraccion es manual con WinRAR.


# --- Red de seguridad ------------------------------------------------------
def asegurar_fuera_de_datos(ruta: Path) -> Path:
    """Aborta si una operacion de escritura apunta al archivo del cliente.

    Son las facturas reales de una asesoria: un borrado o un movimiento ahi
    es irreversible. Toda funcion que escriba debe pasar por aqui.
    """
    ruta = Path(ruta).resolve()
    raiz = RAIZ_DATOS.resolve()
    if ruta == raiz or raiz in ruta.parents:
        raise PermissionError(
            f"BLOQUEADO: intento de escritura dentro del archivo del cliente.\n"
            f"  ruta   : {ruta}\n"
            f"  origen : {raiz}\n"
            f"El pipeline solo LEE de ahi. Revisa la ruta de destino.")
    return ruta
